import 'server-only'
import Papa from 'papaparse'
import { prisma } from '@/lib/prisma'
import { csvRowSchema, MAX_ROWS_MESSAGE } from './constants'
import { MAX_BULK_IMPORT_ROWS } from '@/lib/constants'
import { hashNormalizedText, normalizeQuestionText } from '@/lib/duplicate-detection'
import { validateAnswerForQuestionType } from '@/lib/validation/question'
import { autoFixLatexInText, type LatexIssue } from '@/lib/latex/autoFixLatex'
import { fixBrokenLatexWithAI } from '@/lib/latex/aiFixLatex'
import { parseXlsxToRows } from '@/lib/xlsx/parseXlsxRows'

export type PreviewRowError = { field: string; message: string }

export type PreviewRow = {
  rowIndex: number
  raw: Record<string, string>
  resolved: {
    questionText: string
    optionA: string | null
    optionB: string | null
    optionC: string | null
    optionD: string | null
    correctAnswer: string | null
    explanation: string | null
    subjectId: string | null
    subjectLabel: string | null
    examClassId: string | null
    examClassLabel: string | null
    codeId: string | null
    codeLabel: string | null
    difficultyId: string | null
    difficultyLabel: string | null
    questionNumber: string
    questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER'
    chapterId: string | null
    chapterLabel: string | null
    topicId: string | null
    topicLabel: string | null
    markingScheme: string | null
    examCategoryId: string | null
    examCategoryLabel: string | null
  }
  errors: PreviewRowError[]
  isDuplicateInFile: boolean
  isDuplicateInBank: boolean
  duplicateOfQuestionNumber?: string
  // Equations in this row's text fields that were automatically detected as
  // broken LaTeX and repaired before this row ever reaches the review
  // screen — see src/lib/latex/autoFixLatex.ts. 0 for the overwhelming
  // majority of rows (plain text, or already-valid math).
  latexFixCount: number
  // Equations that FAILED to render even after both the deterministic
  // repairs and (when ANTHROPIC_API_KEY is configured) an AI-assisted
  // repair attempt — surfaced so the reviewer knows exactly which rows
  // still need a manual look. Never blocks import on its own (same
  // permissive behavior CSV import already has for math rendering today).
  latexIssues: string[]
}

export type PreviewResult = {
  totalRows: number
  validRows: number
  invalidRows: number
  duplicateRows: number
  rowsWithLatexFixes: number
  rowsWithLatexIssues: number
  rows: PreviewRow[]
}

/**
 * Parses + validates a CSV file for bulk import WITHOUT writing anything to
 * the database. The caller (preview API route) shows this to the user, who
 * then explicitly confirms which rows to commit.
 */
export async function parseAndValidateCsv(csvText: string): Promise<PreviewResult> {
  const parsed = Papa.parse<Record<string, string>>(csvText, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  })
  return validateRows(parsed.data)
}

/**
 * Same as parseAndValidateCsv, but for a real Excel (.xlsx) file — reads
 * its first worksheet into the exact same row shape via parseXlsxToRows,
 * then runs the identical validation (and LaTeX auto-fix) pipeline. The
 * template's column headers work the same either way.
 */
export async function parseAndValidateXlsx(buffer: Buffer): Promise<PreviewResult> {
  const rows = await parseXlsxToRows(buffer)
  return validateRows(rows)
}

type LatexFieldFix = { text: string | null; fixCount: number; issues: LatexIssue[] }

function fixLatexField(current: string | null, aiFixes?: Map<string, string>): LatexFieldFix {
  if (!current) return { text: current, fixCount: 0, issues: [] }
  const result = autoFixLatexInText(current, aiFixes)
  return { text: result.text, fixCount: result.fixes.length, issues: result.issues }
}

/**
 * Shared validation (+ LaTeX auto-fix) pipeline for both CSV and XLSX
 * imports — takes already-parsed plain row objects (Papa.parse's own
 * output shape for CSV, or parseXlsxToRows' for Excel) so neither source
 * format needs its own copy of this logic.
 */
async function validateRows(rawRows: Record<string, string>[]): Promise<PreviewResult> {
  if (rawRows.length > MAX_BULK_IMPORT_ROWS) {
    throw new Error(MAX_ROWS_MESSAGE)
  }

  const [subjects, examClasses, codes, difficulties, examCategories, chapters, topics] = await Promise.all([
    prisma.subject.findMany({ where: { isActive: true } }),
    prisma.examClass.findMany({ where: { isActive: true } }),
    prisma.code.findMany({ where: { isActive: true } }),
    prisma.difficultyLevel.findMany({ where: { isActive: true } }),
    prisma.examCategory.findMany({ where: { isActive: true } }),
    prisma.chapter.findMany({ where: { isActive: true } }),
    prisma.topic.findMany({ where: { isActive: true } }),
  ])

  const findLookup = <T extends { id: string; code: string; label: string }>(
    list: T[],
    value: string
  ): T | undefined => {
    const v = value.trim().toLowerCase()
    return list.find((l) => l.code.toLowerCase() === v || l.label.toLowerCase() === v)
  }

  // Pull existing normalized-text hashes once so we can flag exact-match
  // duplicates against the live bank without a query per row.
  const existing = await prisma.question.findMany({
    where: { status: 'ACTIVE' },
    select: { questionNumber: true, normalizedTextHash: true },
  })
  const existingHashes = new Map(existing.map((q) => [q.normalizedTextHash, q.questionNumber]))

  const seenInFile = new Set<string>()
  const rows: PreviewRow[] = []
  // Parallel to `rows` (same index) — kept separately from the stringified
  // `latexIssues` on each PreviewRow so the AI-batching pass below can
  // collect/restore exact { expr, message } pairs without round-tripping
  // through a formatted string (an expression could itself legitimately
  // contain almost any character, including " — ").
  const rowLatexIssues: LatexIssue[][] = []

  rawRows.forEach((raw, idx) => {
    const errors: PreviewRowError[] = []
    const result = csvRowSchema.safeParse(raw)

    if (!result.success) {
      for (const issue of result.error.issues) {
        errors.push({ field: String(issue.path[0] ?? 'row'), message: issue.message })
      }
    }

    // Auto-detect and repair broken LaTeX in every free-text field BEFORE
    // anything downstream (duplicate-hashing, the review screen) ever sees
    // it — this first pass is deterministic-only; a second, AI-assisted
    // pass runs once after this whole loop for whatever's still broken
    // (see below), batched across the entire file rather than per-row.
    const questionTextFix = fixLatexField((raw['Question'] ?? '').trim())
    const optionAFix = fixLatexField(raw['Option A']?.trim() || null)
    const optionBFix = fixLatexField(raw['Option B']?.trim() || null)
    const optionCFix = fixLatexField(raw['Option C']?.trim() || null)
    const optionDFix = fixLatexField(raw['Option D']?.trim() || null)
    const explanationFix = fixLatexField(raw['Explanation']?.trim() || null)
    const questionText = questionTextFix.text ?? ''

    const subject = findLookup(subjects, raw['Subject'] ?? '')
    const examClass = findLookup(examClasses, raw['Class'] ?? '')
    const code = findLookup(codes, raw['Code'] ?? '')
    const difficulty = findLookup(difficulties, raw['Difficulty'] ?? '')

    if (!subject) errors.push({ field: 'Subject', message: `Unknown subject "${raw['Subject']}".` })
    if (!examClass) errors.push({ field: 'Class', message: `Unknown class/exam "${raw['Class']}".` })
    if (!code) errors.push({ field: 'Code', message: `Unknown code "${raw['Code']}".` })
    if (!difficulty)
      errors.push({ field: 'Difficulty', message: `Unknown difficulty "${raw['Difficulty']}". Use E, M, or D.` })

    // Exam Category — optional, fixed admin-managed set (NEET / IIT-JEE
    // Main / IIT-JEE Advance / Foundation), so unlike Chapter/Topic a value
    // that doesn't match is a real validation error, not auto-created.
    const examCategoryCell = (raw['Exam Category'] ?? '').trim()
    const examCategory = examCategoryCell ? findLookup(examCategories, examCategoryCell) : undefined
    if (examCategoryCell && !examCategory) {
      errors.push({
        field: 'Exam Category',
        message: `Unknown exam category "${examCategoryCell}". Use NEET, IIT-JEE Main, IIT-JEE Advance, Foundation, or leave blank.`,
      })
    }

    // Chapter/Topic — optional, same as the Add Question form. A value
    // that matches an existing chapter/topic (scoped to the resolved
    // Subject/Chapter) resolves to its id as before. A value that does NOT
    // match anything is no longer a hard error: it's carried through as
    // `chapterLabel`/`topicLabel` with `chapterId`/`topicId` left null, and
    // the confirm step (the only place that writes to the database) will
    // silently create a new Chapter/Topic row for it — the same "just type
    // it and it works" behavior the manual Add Question form already has
    // via CreatableSelect, just applied to bulk import too.
    const chapterCell = (raw['Chapter'] ?? '').trim()
    let chapter: (typeof chapters)[number] | undefined
    if (chapterCell) {
      if (subject) {
        chapter = chapters.find(
          (c) => c.subjectId === subject.id && (c.code.toLowerCase() === chapterCell.toLowerCase() || c.label.toLowerCase() === chapterCell.toLowerCase())
        )
        // No match → will be auto-created at confirm time (see above); not
        // an error.
      } else {
        errors.push({ field: 'Chapter', message: `Chapter "${chapterCell}" given but Subject is invalid.` })
      }
    }

    const topicCell = (raw['Topic'] ?? '').trim()
    let topic: (typeof topics)[number] | undefined
    if (topicCell) {
      if (chapterCell && subject) {
        // Only match against existing topics when the chapter itself
        // already exists — a brand-new chapter (about to be auto-created)
        // can't have any topics yet, so the topic is auto-created too.
        if (chapter) {
          topic = topics.find(
            (t) => t.chapterId === chapter!.id && (t.code.toLowerCase() === topicCell.toLowerCase() || t.label.toLowerCase() === topicCell.toLowerCase())
          )
        }
      } else {
        errors.push({ field: 'Topic', message: `Topic "${topicCell}" given but no valid Chapter was resolved for this row.` })
      }
    }

    // Question Type — defaults to MCQ (same default as manual entry)
    // rather than erroring on a blank cell, since most existing CSVs
    // predate this column entirely.
    const typeCell = (raw['Question Type'] ?? '').trim().toUpperCase()
    let questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER' = 'MCQ'
    if (typeCell) {
      if (typeCell === 'MCQ' || typeCell === 'SUBJECTIVE' || typeCell === 'INTEGER') {
        questionType = typeCell
      } else {
        errors.push({ field: 'Question Type', message: `Unknown question type "${raw['Question Type']}". Use MCQ, SUBJECTIVE, or INTEGER.` })
      }
    }

    const correctAnswerCell = raw['Correct Answer']?.trim() || null
    const answerTypeError = validateAnswerForQuestionType(questionType, correctAnswerCell)
    if (answerTypeError) errors.push({ field: 'Correct Answer', message: answerTypeError })

    let isDuplicateInFile = false
    let isDuplicateInBank = false
    let duplicateOfQuestionNumber: string | undefined

    if (questionText) {
      const hash = hashNormalizedText(questionText)
      const normalized = normalizeQuestionText(questionText)
      if (seenInFile.has(normalized)) {
        isDuplicateInFile = true
      }
      seenInFile.add(normalized)

      if (existingHashes.has(hash)) {
        isDuplicateInBank = true
        duplicateOfQuestionNumber = existingHashes.get(hash)
      }
    }

    const latexFixCount =
      questionTextFix.fixCount + optionAFix.fixCount + optionBFix.fixCount + optionCFix.fixCount + optionDFix.fixCount + explanationFix.fixCount
    const latexIssues = [
      ...questionTextFix.issues,
      ...optionAFix.issues,
      ...optionBFix.issues,
      ...optionCFix.issues,
      ...optionDFix.issues,
      ...explanationFix.issues,
    ]

    rows.push({
      rowIndex: idx,
      raw,
      resolved: {
        questionText,
        optionA: optionAFix.text,
        optionB: optionBFix.text,
        optionC: optionCFix.text,
        optionD: optionDFix.text,
        correctAnswer: correctAnswerCell,
        explanation: explanationFix.text,
        subjectId: subject?.id ?? null,
        subjectLabel: subject?.label ?? null,
        examClassId: examClass?.id ?? null,
        examClassLabel: examClass?.label ?? null,
        codeId: code?.id ?? null,
        codeLabel: code?.label ?? null,
        difficultyId: difficulty?.id ?? null,
        difficultyLabel: difficulty?.label ?? null,
        questionNumber: (raw['Question Number'] ?? '').trim(),
        questionType,
        chapterId: chapter?.id ?? null,
        // Falls back to the raw typed text when it didn't match an
        // existing chapter/topic, so the preview screen shows the
        // to-be-created name and the confirm step knows what to create.
        chapterLabel: chapter?.label ?? (chapterCell || null),
        topicId: topic?.id ?? null,
        topicLabel: topic?.label ?? (topicCell || null),
        markingScheme: raw['Marks']?.trim() || null,
        examCategoryId: examCategory?.id ?? null,
        examCategoryLabel: examCategory?.label ?? null,
      },
      errors,
      isDuplicateInFile,
      isDuplicateInBank,
      duplicateOfQuestionNumber,
      latexFixCount,
      latexIssues: latexIssues.map((i) => `${i.expr} — ${i.message}`),
    })
    rowLatexIssues.push(latexIssues)
  })

  // AI-assisted second pass — only for equations the deterministic repairs
  // above couldn't fix, and only if the server has ANTHROPIC_API_KEY
  // configured (fixBrokenLatexWithAI itself no-ops otherwise, same
  // degrade-gracefully pattern as the PDF/handwritten AI import paths).
  // Batched ONCE across every row in the file — never one call per row —
  // and deduplicated, since the same formula often repeats across a
  // question bank.
  const distinctBroken = new Map<string, string>()
  for (const issues of rowLatexIssues) {
    for (const issue of issues) {
      if (!distinctBroken.has(issue.expr)) distinctBroken.set(issue.expr, issue.message)
    }
  }

  if (distinctBroken.size > 0) {
    const aiFixMap = await fixBrokenLatexWithAI(
      Array.from(distinctBroken, ([expr, message]) => ({ expr, error: message }))
    )

    if (aiFixMap.size > 0) {
      rows.forEach((row, idx) => {
        if (rowLatexIssues[idx].length === 0) return

        const qFix = fixLatexField(row.resolved.questionText, aiFixMap)
        const aFix = fixLatexField(row.resolved.optionA, aiFixMap)
        const bFix = fixLatexField(row.resolved.optionB, aiFixMap)
        const cFix = fixLatexField(row.resolved.optionC, aiFixMap)
        const dFix = fixLatexField(row.resolved.optionD, aiFixMap)
        const eFix = fixLatexField(row.resolved.explanation, aiFixMap)

        row.resolved.questionText = qFix.text ?? row.resolved.questionText
        row.resolved.optionA = aFix.text
        row.resolved.optionB = bFix.text
        row.resolved.optionC = cFix.text
        row.resolved.optionD = dFix.text
        row.resolved.explanation = eFix.text

        row.latexFixCount += qFix.fixCount + aFix.fixCount + bFix.fixCount + cFix.fixCount + dFix.fixCount + eFix.fixCount
        const remaining = [...qFix.issues, ...aFix.issues, ...bFix.issues, ...cFix.issues, ...dFix.issues, ...eFix.issues]
        row.latexIssues = remaining.map((i) => `${i.expr} — ${i.message}`)
      })
    }
  }

  return {
    totalRows: rows.length,
    validRows: rows.filter((r) => r.errors.length === 0).length,
    invalidRows: rows.filter((r) => r.errors.length > 0).length,
    duplicateRows: rows.filter((r) => r.isDuplicateInBank || r.isDuplicateInFile).length,
    rowsWithLatexFixes: rows.filter((r) => r.latexFixCount > 0).length,
    rowsWithLatexIssues: rows.filter((r) => r.latexIssues.length > 0).length,
    rows,
  }
}
