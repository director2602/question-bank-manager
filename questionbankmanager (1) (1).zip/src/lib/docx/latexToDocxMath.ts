import 'server-only'
import {
  Math as DocxMath,
  MathFraction,
  MathRadical,
  MathRun,
  MathSubScript,
  MathSubSuperScript,
  MathSuperScript,
  TextRun,
  type MathComponent,
  type ParagraphChild,
} from 'docx'

// ---------------------------------------------------------------------------
// LaTeX -> native Word equation (OMML, via docx's Math* builders) converter.
//
// Scope: the common subset of LaTeX actually seen in question banks —
// fractions, sub/superscripts (incl. combined), roots, \sum/\int/\prod with
// limits (rendered as the operator glyph with ordinary trailing sub/super-
// script, not the stacked-above/below textbook layout — see the note by
// their SYMBOL_MAP entries below), Greek letters, common operators/
// relations, \text/\mathrm wrappers, and \left/\right sizing (stripped,
// delimiter kept literal). Anything
// outside that falls back to plain literal text rather than throwing, so a
// question with unusual LaTeX still exports — just without a typeset
// equation for that one unusual bit, instead of failing the whole export.
//
// This intentionally does NOT reach for an external TeX engine / MathJax —
// docx's own Math/MathFraction/MathRadical/etc. builders emit real OMML
// (Word's native equation format) directly, so the output is an editable
// Word equation, not an image or literal "$...$" text.
// ---------------------------------------------------------------------------

const SYMBOL_MAP: Record<string, string> = {
  // Greek (lowercase)
  alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', varepsilon: 'ε',
  zeta: 'ζ', eta: 'η', theta: 'θ', vartheta: 'ϑ', iota: 'ι', kappa: 'κ',
  lambda: 'λ', mu: 'μ', nu: 'ν', xi: 'ξ', omicron: 'ο', pi: 'π', varpi: 'ϖ',
  rho: 'ρ', varrho: 'ϱ', sigma: 'σ', varsigma: 'ς', tau: 'τ', upsilon: 'υ',
  phi: 'φ', varphi: 'ϕ', chi: 'χ', psi: 'ψ', omega: 'ω',
  // Greek (uppercase)
  Gamma: 'Γ', Delta: 'Δ', Theta: 'Θ', Lambda: 'Λ', Xi: 'Ξ', Pi: 'Π',
  Sigma: 'Σ', Upsilon: 'Υ', Phi: 'Φ', Psi: 'Ψ', Omega: 'Ω',
  // Operators / relations
  times: '×', div: '÷', pm: '±', mp: '∓', cdot: '⋅', ast: '∗', circ: '∘',
  bullet: '∙', oplus: '⊕', otimes: '⊗',
  leq: '≤', le: '≤', geq: '≥', ge: '≥', neq: '≠', ne: '≠', approx: '≈',
  equiv: '≡', sim: '∼', simeq: '≃', propto: '∝', cong: '≅',
  ll: '≪', gg: '≫',
  in: '∈', notin: '∉', subset: '⊂', subseteq: '⊆', supset: '⊃', supseteq: '⊇',
  cup: '∪', cap: '∩', setminus: '∖', emptyset: '∅', varnothing: '∅',
  forall: '∀', exists: '∃', nexists: '∄', therefore: '∴', because: '∵',
  infty: '∞', partial: '∂', nabla: '∇',
  to: '→', rightarrow: '→', longrightarrow: '→', leftarrow: '←',
  leftrightarrow: '↔', Rightarrow: '⇒', Leftarrow: '⇐', Leftrightarrow: '⇔',
  mapsto: '↦', uparrow: '↑', downarrow: '↓',
  angle: '∠', perp: '⊥', parallel: '∥', triangle: '△', square: '□',
  ldots: '…', cdots: '⋯', vdots: '⋮', ddots: '⋱', dots: '…',
  wedge: '∧', vee: '∨', neg: '¬', lnot: '¬',
  hbar: 'ℏ', ell: 'ℓ', Re: 'ℜ', Im: 'ℑ', aleph: 'ℵ',
  degree: '°', prime: '′',
  // Big-operator glyphs. Deliberately plain SYMBOL_MAP entries (not the
  // docx MathSum/MathIntegral nAry builders) — see the "duplicated glyph"
  // bug note in the module history: those builders draw their own
  // hardcoded accent glyph from `children`, so passing the symbol as
  // `children` renders it twice, and there's no MathProd/MathCoprod class
  // at all. Treating them as ordinary atoms means limits attach via the
  // normal postfix _/^ binding below (an ordinary trailing sub/superscript
  // beside the glyph, not stacked above/below it) — correct and
  // unambiguous, at the cost of the stacked textbook look.
  sum: '∑', int: '∫', oint: '∮', prod: '∏', coprod: '∐',
  // Spacing (rendered as a plain space — good enough for a text-flow doc)
  ',': ' ', ';': ' ', ':': ' ', '!': '', quad: '  ', qquad: '    ',
}

// Unicode superscript/subscript digit & sign maps — used inside
// rawBracedText() so a nested ^/_ within \text{}/\mathrm{} (e.g. the "2" in
// \mathrm{kg^2}) renders as a real exponent character (kg²) instead of a
// literal "^2", since that argument is emitted as plain text, not OMML.
const SUPERSCRIPT_MAP: Record<string, string> = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
  '+': '⁺', '-': '⁻', '−': '⁻', '(': '⁽', ')': '⁾', 'n': 'ⁿ', 'i': 'ⁱ',
}
const SUBSCRIPT_MAP: Record<string, string> = {
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
  '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
  '+': '₊', '-': '₋', '−': '₋', '(': '₍', ')': '₎',
}

// Function-style names: the argument that follows (often via _{}/^{}) is
// handled by the normal postfix sub/superscript binding once this name is
// emitted as a plain-text atom — e.g. `\lim_{x\to 0}` becomes the atom
// "lim" immediately followed by a subscript, exactly like any other atom.
const FUNCTION_NAMES = new Set([
  'lim', 'sin', 'cos', 'tan', 'cot', 'sec', 'csc',
  'sinh', 'cosh', 'tanh', 'log', 'ln', 'exp',
  'max', 'min', 'sup', 'inf', 'gcd', 'det', 'arg',
  'arcsin', 'arccos', 'arctan',
])

// Commands whose single {argument} is emitted as literal (non-italic-math)
// text rather than parsed further as math — matches how \text/\mathrm read
// in a typeset question (units, words), not as a product of variables.
const TEXT_WRAPPER_COMMANDS = new Set(['text', 'mathrm', 'mathbf', 'textbf', 'mbox', 'operatorname'])

type Token =
  | { kind: 'char'; value: string }
  | { kind: 'command'; name: string }
  | { kind: 'open' }
  | { kind: 'close' }
  | { kind: 'sup' }
  | { kind: 'sub' }

function tokenize(latex: string): Token[] {
  const tokens: Token[] = []
  let i = 0
  while (i < latex.length) {
    const c = latex[i]
    if (c === '\\') {
      // Command name: a run of letters, or exactly one non-letter symbol
      // (e.g. \, \; \\ ).
      let j = i + 1
      if (j < latex.length && /[a-zA-Z]/.test(latex[j] as string)) {
        while (j < latex.length && /[a-zA-Z]/.test(latex[j] as string)) j++
        tokens.push({ kind: 'command', name: latex.slice(i + 1, j) })
      } else if (j < latex.length) {
        tokens.push({ kind: 'command', name: latex[j] as string })
        j++
      }
      i = j
      continue
    }
    if (c === '{') { tokens.push({ kind: 'open' }); i++; continue }
    if (c === '}') { tokens.push({ kind: 'close' }); i++; continue }
    if (c === '^') { tokens.push({ kind: 'sup' }); i++; continue }
    if (c === '_') { tokens.push({ kind: 'sub' }); i++; continue }
    if (c === '$') { i++; continue } // stray nested $ — ignore
    tokens.push({ kind: 'char', value: c as string })
    i++
  }
  return tokens
}

class Parser {
  private pos = 0
  constructor(private tokens: Token[]) {}

  private peek(): Token | undefined {
    return this.tokens[this.pos]
  }
  private next(): Token | undefined {
    return this.tokens[this.pos++]
  }
  private atEnd(): boolean {
    return this.pos >= this.tokens.length
  }

  /** Parses a sequence of atoms until `}` or end of input (not consuming the `}`). */
  parseGroup(): MathComponent[] {
    const out: MathComponent[] = []
    while (!this.atEnd() && this.peek()?.kind !== 'close') {
      const atom = this.parseOneAtomWithScripts()
      if (atom) out.push(...atom)
    }
    return coalesceRuns(out)
  }

  /** Parses exactly one base atom, then binds any immediately-following ^/_ to it. */
  private parseOneAtomWithScripts(): MathComponent[] | null {
    const base = this.parseBaseAtom()
    if (!base) return null

    let sup: MathComponent[] | null = null
    let sub: MathComponent[] | null = null
    // LaTeX allows ^ and _ in either order (x_1^2 or x^2_1); consume both if present.
    for (let guard = 0; guard < 2; guard++) {
      const t = this.peek()
      if (t?.kind === 'sup' && !sup) {
        this.next()
        sup = this.parseScriptArgument()
      } else if (t?.kind === 'sub' && !sub) {
        this.next()
        sub = this.parseScriptArgument()
      } else {
        break
      }
    }

    if (sup && sub) return [new MathSubSuperScript({ children: base, subScript: sub, superScript: sup })]
    if (sup) return [new MathSuperScript({ children: base, superScript: sup })]
    if (sub) return [new MathSubScript({ children: base, subScript: sub })]
    return base
  }

  /** The argument of a ^ or _: either a {group} or a single following atom. */
  private parseScriptArgument(): MathComponent[] {
    if (this.peek()?.kind === 'open') {
      this.next()
      const inner = this.parseGroup()
      if (this.peek()?.kind === 'close') this.next()
      return inner.length > 0 ? inner : [new MathRun('')]
    }
    const atom = this.parseBaseAtom()
    return atom ?? [new MathRun('')]
  }

  /** One un-scripted atom: a {group}, a command's result, or a single character. */
  private parseBaseAtom(): MathComponent[] | null {
    const t = this.next()
    if (!t) return null

    if (t.kind === 'open') {
      const inner = this.parseGroup()
      if (this.peek()?.kind === 'close') this.next()
      return inner
    }
    if (t.kind === 'close') return null // unmatched — ignore
    if (t.kind === 'sup' || t.kind === 'sub') return null // stray — ignore

    if (t.kind === 'char') {
      return [new MathRun(t.value)]
    }

    // t.kind === 'command'
    return this.parseCommand(t.name)
  }

  private parseBracedArg(): MathComponent[] {
    if (this.peek()?.kind === 'open') {
      this.next()
      const inner = this.parseGroup()
      if (this.peek()?.kind === 'close') this.next()
      return inner
    }
    // No braces — LaTeX allows a single following token as the argument
    // (e.g. \sqrt2, \frac12 written without braces).
    const atom = this.parseBaseAtom()
    return atom ?? []
  }

  /** Raw (unparsed-as-math) text of a {...} argument — for \text{...} etc. */
  private rawBracedText(): string {
    if (this.peek()?.kind !== 'open') return ''
    this.next()
    let depth = 1
    let text = ''
    while (!this.atEnd() && depth > 0) {
      const t = this.next() as Token
      if (t.kind === 'open') depth++
      else if (t.kind === 'close') { depth--; if (depth === 0) break }
      else if (t.kind === 'char') text += t.value
      else if (t.kind === 'command') text += SYMBOL_MAP[t.name] ?? t.name
      else if (t.kind === 'sup') text += this.rawScriptArgument(SUPERSCRIPT_MAP, '^')
      else if (t.kind === 'sub') text += this.rawScriptArgument(SUBSCRIPT_MAP, '_')
    }
    return text
  }

  /**
   * Reads one ^/_ argument (a {group} or a single token) while inside
   * rawBracedText(), converting each character through `map` (Unicode
   * super/subscript digits etc.) so e.g. \mathrm{kg^2} yields "kg²" rather
   * than the literal "kg^2". Characters outside `map` (e.g. letters, which
   * have no Unicode superscript form in general) fall back to the plain
   * marker + character, same as the previous literal behavior.
   */
  private rawScriptArgument(map: Record<string, string>, marker: string): string {
    const convert = (s: string) => [...s].map((ch) => map[ch] ?? `${marker}${ch}`).join('')
    if (this.peek()?.kind === 'open') {
      this.next()
      let depth = 1
      let inner = ''
      while (!this.atEnd() && depth > 0) {
        const t = this.next() as Token
        if (t.kind === 'open') depth++
        else if (t.kind === 'close') { depth--; if (depth === 0) break }
        else if (t.kind === 'char') inner += t.value
        else if (t.kind === 'command') inner += SYMBOL_MAP[t.name] ?? t.name
      }
      return convert(inner)
    }
    const t = this.next()
    if (!t) return ''
    if (t.kind === 'char') return convert(t.value)
    if (t.kind === 'command') return convert(SYMBOL_MAP[t.name] ?? t.name)
    return ''
  }

  private parseCommand(name: string): MathComponent[] | null {
    if (name === 'frac' || name === 'dfrac' || name === 'tfrac') {
      const num = this.parseBracedArg()
      const den = this.parseBracedArg()
      return [new MathFraction({ numerator: num.length ? num : [new MathRun('')], denominator: den.length ? den : [new MathRun('')] })]
    }

    if (name === 'sqrt') {
      let degree: MathComponent[] | undefined
      if (this.peek()?.kind === 'char' && (this.peek() as Extract<Token, { kind: 'char' }>).value === '[') {
        // Optional [n] degree — scan raw chars until ']'.
        this.next()
        let deg = ''
        while (!this.atEnd() && !(this.peek()?.kind === 'char' && (this.peek() as Extract<Token, { kind: 'char' }>).value === ']')) {
          const t = this.next() as Token
          if (t.kind === 'char') deg += t.value
        }
        if (this.peek()?.kind === 'char') this.next() // consume ']'
        degree = deg ? [new MathRun(deg)] : undefined
      }
      const arg = this.parseBracedArg()
      return [new MathRadical({ children: arg.length ? arg : [new MathRun('')], degree })]
    }

    if (name === 'left' || name === 'right') {
      // Sizing commands — keep the following delimiter char literally,
      // drop the sizing instruction itself. `\left.`/`\right.` means "no
      // visible delimiter" in LaTeX.
      const t = this.peek()
      if (t?.kind === 'char') {
        this.next()
        return t.value === '.' ? [] : [new MathRun(t.value)]
      }
      return []
    }

    if (TEXT_WRAPPER_COMMANDS.has(name)) {
      const raw = this.rawBracedText()
      return raw ? [new MathRun(raw)] : []
    }

    if (name === 'displaystyle' || name === 'textstyle' || name === 'scriptstyle' || name === 'limits' || name === 'nolimits') {
      return [] // styling hints with no argument — no-op
    }

    if (FUNCTION_NAMES.has(name)) {
      return [new MathRun(name)]
    }

    if (name in SYMBOL_MAP) {
      return [new MathRun(SYMBOL_MAP[name] as string)]
    }

    // Unknown command — fall back to its name rather than dropping content
    // silently (e.g. an uncommon macro still shows up as readable text).
    return name.length === 1 && !/[a-zA-Z]/.test(name) ? [new MathRun(name)] : [new MathRun(name)]
  }
}

/** Merges consecutive plain MathRun components into one, for tidier output. */
function coalesceRuns(components: MathComponent[]): MathComponent[] {
  const out: MathComponent[] = []
  for (const c of components) {
    const prev = out[out.length - 1]
    if (c instanceof MathRun && prev instanceof MathRun) {
      // MathRun has no public text getter, so we can't merge post-hoc —
      // keep as separate runs. (Word renders adjacent MathRuns seamlessly;
      // this only affects XML verbosity, not appearance.)
      out.push(c)
    } else {
      out.push(c)
    }
  }
  return out
}

/**
 * Converts one LaTeX math expression (without the surrounding $ / \( \)
 * delimiters) into docx MathComponents. Never throws — worst case, falls
 * back to a single literal MathRun of the raw source so the export still
 * succeeds.
 */
export function parseLatexToMathComponents(latex: string): MathComponent[] {
  try {
    const tokens = tokenize(latex)
    const parser = new Parser(tokens)
    const result = parser.parseGroup()
    return result.length > 0 ? result : [new MathRun(latex)]
  } catch {
    return [new MathRun(latex)]
  }
}

// Matches $$...$$, \[...\], $...$, \(...\) — display forms checked first so
// `$$` isn't mis-split as two adjacent `$...$` spans.
const MATH_SPAN_RE = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\$([^$\n]+?)\$|\\\(([\s\S]+?)\\\)/g

/**
 * Splits `text` on inline/display LaTeX math spans and returns an ordered
 * list of paragraph children — plain TextRun for the surrounding prose,
 * native Word `Math` (OMML) elements for each span. Text with no math at
 * all still returns a single TextRun, so every existing call site keeps
 * working by just swapping `new TextRun({text: ...})` for this.
 */
export function textWithMathToRuns(
  text: string,
  runOptions: { size: number; bold?: boolean; italics?: boolean; color?: string } = { size: 22 }
): ParagraphChild[] {
  if (!text) return []
  const out: ParagraphChild[] = []
  let lastIndex = 0
  MATH_SPAN_RE.lastIndex = 0
  let match: RegExpExecArray | null

  const pushText = (s: string) => {
    if (!s) return
    out.push(new TextRun({ text: s, ...runOptions }))
  }

  while ((match = MATH_SPAN_RE.exec(text))) {
    if (match.index > lastIndex) pushText(text.slice(lastIndex, match.index))
    const latex = match[1] ?? match[2] ?? match[3] ?? match[4] ?? ''
    if (latex.trim()) {
      out.push(new DocxMath({ children: parseLatexToMathComponents(latex.trim()) }))
    }
    lastIndex = MATH_SPAN_RE.lastIndex
  }
  if (lastIndex < text.length) pushText(text.slice(lastIndex))

  return out.length > 0 ? out : [new TextRun({ text, ...runOptions })]
}
