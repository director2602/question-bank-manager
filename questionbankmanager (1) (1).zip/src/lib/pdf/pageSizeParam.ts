// Deliberately has zero imports from anything that touches Prisma/the
// database — kept as its own tiny, pure module (rather than living inline
// in paperLayout.ts, which does) so it can be unit-tested directly without
// pulling in a live database client.

/**
 * Parses a `pageSizeMm=<width>x<height>` query-string value (e.g.
 * `210x285`) into a `pageSizeOverride` for `resolvePaperLayoutSettings`.
 * Shared by the print route and both export routes so the "download at a
 * custom physical size" URL format is defined in exactly one place.
 * Returns null for a missing/malformed value — callers then simply fall
 * back to the paper's normal persisted page size, never a hard error, so a
 * mistyped URL degrades gracefully instead of breaking the export.
 */
export function parsePageSizeMmParam(param: string | null | undefined): { widthMm: number; heightMm: number } | null {
  if (!param) return null
  const match = /^(\d+(?:\.\d+)?)x(\d+(?:\.\d+)?)$/i.exec(param.trim())
  if (!match) return null
  const widthMm = Number(match[1])
  const heightMm = Number(match[2])
  if (!Number.isFinite(widthMm) || !Number.isFinite(heightMm) || widthMm <= 0 || heightMm <= 0) return null
  // Sanity bounds — generous enough for any real paper size, tight enough
  // to reject obvious garbage (e.g. a pasted timestamp) before it reaches
  // the PDF/DOCX renderers.
  if (widthMm > 1000 || heightMm > 1000) return null
  return { widthMm, heightMm }
}
