import 'server-only'
import { prisma } from '@/lib/prisma'
import { paperSettingsSchema } from '@/lib/validation/paperSettings'
import { DEFAULT_PAPER_LAYOUT_SETTINGS, type PaperLayoutSettings } from './paperHtml'

// Re-exported for convenience so callers (the print/export routes) only
// need one import line — see pageSizeParam.ts for why the implementation
// itself lives in a separate, Prisma-free module.
export { parsePageSizeMmParam } from './pageSizeParam'

/**
 * Loads the persisted PaperSettings row for a paper (falling back to the
 * app defaults when one doesn't exist yet — e.g. a paper created before
 * this feature, or one nobody has opened the settings panel for) and
 * applies it identically wherever a paper is rendered: the print view, the
 * PDF exporter, and the DOCX exporter (feature spec: "one source of truth,
 * not three").
 *
 * This deliberately does NOT create the row if missing — that lazy-create
 * happens once, explicitly, in GET /api/papers/:id/settings (the endpoint
 * the Paper Settings panel calls), so a paper nobody has ever opened
 * settings for doesn't get a settings row written just because someone
 * printed or exported it.
 *
 * `columnsOverride` preserves the pre-existing `?columns=` query-string
 * behavior on the print/export routes as an explicit one-off override of
 * the persisted setting, without it being the source of truth.
 *
 * `pageSizeOverride` is the same idea for physical page size — e.g. a
 * one-off "download as 210×285mm" choice on the export dropdown — applied
 * only to this render via PaperLayoutSettings.customPageSizeMm, never
 * written back to the paper's saved settings.
 *
 * `draftOverride` is for the Paper Settings panel's live side-by-side
 * preview: while the user is still adjusting settings (before hitting
 * Save), the panel re-requests the print view with its in-memory,
 * not-yet-saved settings object passed through as `draftOverride`, so the
 * preview reflects the change immediately without ever touching the
 * database. It's validated with the exact same zod schema used to persist
 * real settings (`paperSettingsSchema`) — an invalid/malformed value (e.g.
 * a hand-edited URL) is silently ignored rather than breaking the render,
 * same "never fail the whole export over one bad input" spirit as the
 * columns/page-size overrides above.
 */
export async function resolvePaperLayoutSettings(
  paperId: string,
  columnsOverride?: number | null,
  pageSizeOverride?: { widthMm: number; heightMm: number } | null,
  draftOverride?: unknown
): Promise<PaperLayoutSettings> {
  const row = await prisma.paperSettings.findUnique({ where: { paperId } })

  const base: PaperLayoutSettings = row
    ? {
        pageSize: row.pageSize,
        orientation: row.orientation,
        marginTopMm: row.marginTopMm,
        marginBottomMm: row.marginBottomMm,
        marginLeftMm: row.marginLeftMm,
        marginRightMm: row.marginRightMm,
        columns: row.columns,
        columnGapMm: row.columnGapMm,
        showHeader: row.showHeader,
        showFooter: row.showFooter,
        showPageNumbers: row.showPageNumbers,
        fontFamily: row.fontFamily,
        fontSizePt: row.fontSizePt,
        lineSpacing: row.lineSpacing,
        questionSpacingPx: row.questionSpacingPx,
        optionSpacingPx: row.optionSpacingPx,
        imageQualityPercent: row.imageQualityPercent,
        maxImageWidthMm: row.maxImageWidthMm,
        imageAlignment: row.imageAlignment,
        questionNumberingStyle: row.questionNumberingStyle,
        marksDisplayStyle: row.marksDisplayStyle,
      }
    : DEFAULT_PAPER_LAYOUT_SETTINGS

  let result = base
  if (columnsOverride && Number.isInteger(columnsOverride) && columnsOverride >= 1 && columnsOverride <= 3) {
    result = { ...result, columns: columnsOverride }
  }
  if (
    pageSizeOverride &&
    Number.isFinite(pageSizeOverride.widthMm) &&
    Number.isFinite(pageSizeOverride.heightMm) &&
    pageSizeOverride.widthMm > 0 &&
    pageSizeOverride.heightMm > 0
  ) {
    result = { ...result, customPageSizeMm: pageSizeOverride }
  }
  if (draftOverride && typeof draftOverride === 'object') {
    const parsed = paperSettingsSchema.safeParse(draftOverride)
    if (parsed.success) {
      result = { ...result, ...parsed.data }
    }
  }
  return result
}
