'use client'

import { useState } from 'react'
import { downloadFile } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'

type ExportMode = 'question' | 'answerKey' | 'solutions'
type ExportFormat = 'pdf' | 'docx' | 'csv'
// 'DEFAULT' means "use this paper's own saved page size as normal" — the
// actual A4/Letter/Legal choice still lives in Paper Settings. '210x285' is
// a one-off download-time override for the "short A4" size some
// printers/binders expect (see parsePageSizeMmParam) — it's a `pageSizeMm`
// query param on the export request only, never written back to the
// paper's saved settings. Irrelevant for CSV, which has no page geometry.
type PageSizeChoice = 'DEFAULT' | '210x285'

const FORMAT_LABEL: Record<ExportFormat, string> = { pdf: 'PDF', docx: 'Word', csv: 'CSV' }

/**
 * Unified export control for a paper — one mode selector (Question Paper /
 * Answer Key / Solutions) plus a button per format (PDF/Word/CSV), each
 * with its own "Generating…" loading state and a toast on failure. Replaces
 * the old ad hoc `<a href="/api/.../export/pdf">Download PDF</a>` link,
 * which could only ever offer PDF, couldn't show progress, and — since a
 * plain link navigation can't distinguish a binary success response from a
 * JSON error body — silently showed the browser's raw error page (or a
 * downloaded file literally named "error") whenever export failed.
 */
export function DownloadMenu({ paperId }: { paperId: string }) {
  const { show } = useToast()
  const [mode, setMode] = useState<ExportMode>('question')
  const [pageSize, setPageSize] = useState<PageSizeChoice>('DEFAULT')
  const [loadingFormat, setLoadingFormat] = useState<ExportFormat | null>(null)

  async function handleDownload(format: ExportFormat) {
    setLoadingFormat(format)
    try {
      const sizeParam = format !== 'csv' && pageSize === '210x285' ? '&pageSizeMm=210x285' : ''
      const { blob, filename } = await downloadFile(`/api/papers/${paperId}/export/${format}?mode=${mode}${sizeParam}`)
      const objectUrl = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = objectUrl
      link.download = filename
      document.body.appendChild(link)
      link.click()
      link.remove()
      URL.revokeObjectURL(objectUrl)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoadingFormat(null)
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <label className="flex items-center gap-1 text-xs text-ink-muted">
        Export:
        <select
          className="input !h-8 !py-0 text-xs"
          value={mode}
          onChange={(e) => setMode(e.target.value as ExportMode)}
        >
          <option value="question">Question Paper</option>
          <option value="answerKey">Answer Key</option>
          <option value="solutions">Solutions</option>
        </select>
      </label>
      <label className="flex items-center gap-1 text-xs text-ink-muted">
        Page size:
        <select
          className="input !h-8 !py-0 text-xs"
          value={pageSize}
          onChange={(e) => setPageSize(e.target.value as PageSizeChoice)}
          title="Applies to this download only — the paper's saved default page size (set in Paper Settings) is unchanged."
        >
          <option value="DEFAULT">This paper&apos;s default</option>
          <option value="210x285">210 × 285 mm</option>
        </select>
      </label>
      {(['pdf', 'docx', 'csv'] as ExportFormat[]).map((format) => (
        <button
          key={format}
          type="button"
          className="btn-secondary"
          disabled={loadingFormat !== null}
          onClick={() => handleDownload(format)}
        >
          {loadingFormat === format ? `Generating ${FORMAT_LABEL[format]}…` : `Download ${FORMAT_LABEL[format]}`}
        </button>
      ))}
    </div>
  )
}
