import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { renderPaperHtml, getPageDimensionsMm, type PaperExportMode } from '@/lib/pdf/paperHtml'
import { resolvePaperLayoutSettings, parsePageSizeMmParam } from '@/lib/pdf/paperLayout'
import { renderHtmlToPdfBuffer } from '@/lib/pdf/paperPdf'
import { resolveCoverDesignForRender } from '@/lib/pdf/coverDesignPipeline'

// GET /api/papers/:id/export/pdf?mode=question|answerKey|solutions&columns=1-3&pageSizeMm=210x285
//
// `pageSizeMm=<width>x<height>` is the one-off "download at a custom
// physical size" choice (e.g. 210x285 for the "short A4" some
// printers/binders expect) offered alongside the paper's normal saved page
// size — see parsePageSizeMmParam / resolvePaperLayoutSettings. It's
// applied only to this one download and never written back to the paper's
// saved settings.
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    const mode = (searchParams.get('mode') as PaperExportMode) || 'question'
    if (!['question', 'answerKey', 'solutions'].includes(mode)) {
      return NextResponse.json({ error: 'Invalid export mode.' }, { status: 400 })
    }
    const columnsParam = searchParams.get('columns')
    const columnsOverride = columnsParam ? Number(columnsParam) : null
    const pageSizeOverride = parsePageSizeMmParam(searchParams.get('pageSizeMm'))

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const [questions, layout, coverDesign] = await Promise.all([
      buildPaperSnapshot(params.id),
      resolvePaperLayoutSettings(params.id, columnsOverride, pageSizeOverride),
      resolveCoverDesignForRender(paper.coverDesign),
    ])
    if (questions.length === 0) {
      return NextResponse.json({ error: 'This paper has no questions to export.' }, { status: 422 })
    }

    const html = renderPaperHtml(
      {
        title: paper.title,
        subtitle: paper.subtitle,
        paperNumber: paper.paperNumber,
        instituteName: paper.instituteName,
        logoUrl: paper.logoUrl,
        examName: paper.examName,
        subjectLabel: paper.subjectLabel,
        classLabel: paper.classLabel,
        examDate: paper.examDate ? paper.examDate.toISOString().slice(0, 10) : null,
        examTime: paper.examTime,
        maxMarks: paper.maxMarks,
        instructions: paper.instructions,
        headerText: paper.headerText,
        footerText: paper.footerText,
      },
      questions,
      mode,
      layout,
      coverDesign,
      paper.separateFrontPage
    )

    const { widthMm, heightMm } = getPageDimensionsMm(layout)
    let pdfBuffer: Buffer
    try {
      pdfBuffer = await renderHtmlToPdfBuffer(html, {
        showPageNumbers: layout.showPageNumbers,
        showFooter: layout.showFooter,
        pageWidthMm: widthMm,
        pageHeightMm: heightMm,
      })
    } catch (err) {
      console.error('[paper export pdf] Puppeteer failed', err)
      return NextResponse.json(
        {
          error:
            'Server-side PDF generation is unavailable right now. Use the Print button on the paper’s print view instead — it produces an identical PDF via your browser’s Save as PDF option.',
        },
        { status: 502 }
      )
    }

    await writeAuditLog({
      userId: user.id,
      action: 'PAPER_EXPORTED_PDF',
      entityType: 'PAPER',
      entityId: params.id,
      description: `${user.fullName ?? user.email} exported paper "${paper.title}" (#${paper.paperNumber}) as PDF (${mode}).`,
    })

    const sizeSuffix = pageSizeOverride ? `-${pageSizeOverride.widthMm}x${pageSizeOverride.heightMm}mm` : ''
    return new NextResponse(new Uint8Array(pdfBuffer), {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="paper-${paper.paperNumber}-${mode}${sizeSuffix}.pdf"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
