import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import type { PaperExportMode } from '@/lib/pdf/paperHtml'
import { resolvePaperLayoutSettings, parsePageSizeMmParam } from '@/lib/pdf/paperLayout'
import { buildPaperDocxBuffer } from '@/lib/docx/paperDocx'
import { resolveCoverDesignForRender } from '@/lib/pdf/coverDesignPipeline'

// GET /api/papers/:id/export/docx?mode=question|answerKey|solutions&columns=1-3&pageSizeMm=210x285
//
// Mirrors /api/papers/:id/export/pdf's contract (same query params, same
// auth, same 404/422 behavior) so the frontend Download Menu can treat all
// export formats uniformly — see buildPaperDocxBuffer's doc comment for
// what is and isn't faithfully reproduced from the PDF/print letterhead.
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    const mode = (searchParams.get('mode') as PaperExportMode) || 'question'
    if (!['question', 'answerKey', 'solutions'].includes(mode)) {
      return NextResponse.json({ error: 'Invalid export mode.' }, { status: 400 })
    }
    const columnsParam = searchParams.get('columns')
    const columnsOverride = columnsParam ? Number(columnsParam) : null
    const pageSizeOverride = parsePageSizeMmParam(searchParams.get('pageSizeMm'))

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const [questions, layout, coverDesign] = await Promise.all([
      buildPaperSnapshot(params.id),
      resolvePaperLayoutSettings(params.id, columnsOverride, pageSizeOverride),
      resolveCoverDesignForRender(paper.coverDesign),
    ])
    if (questions.length === 0) {
      return NextResponse.json({ error: 'This paper has no questions to export.' }, { status: 422 })
    }

    let docxBuffer: Buffer
    try {
      docxBuffer = await buildPaperDocxBuffer(
        {
          title: paper.title,
          subtitle: paper.subtitle,
          paperNumber: paper.paperNumber,
          instituteName: paper.instituteName,
          logoUrl: paper.logoUrl,
          examName: paper.examName,
          subjectLabel: paper.subjectLabel,
          classLabel: paper.classLabel,
          examDate: paper.examDate ? paper.examDate.toISOString().slice(0, 10) : null,
          examTime: paper.examTime,
          maxMarks: paper.maxMarks,
          instructions: paper.instructions,
          headerText: paper.headerText,
          footerText: paper.footerText,
        },
        questions,
        mode,
        layout,
        coverDesign,
        paper.separateFrontPage
      )
    } catch (err) {
      console.error('[paper export docx] generation failed', err)
      return NextResponse.json(
        { error: 'Word export failed. Try the PDF export or the Print view instead.' },
        { status: 502 }
      )
    }

    await writeAuditLog({
      userId: user.id,
      action: 'PAPER_EXPORTED_DOCX',
      entityType: 'PAPER',
      entityId: params.id,
      description: `${user.fullName ?? user.email} exported paper "${paper.title}" (#${paper.paperNumber}) as Word (${mode}).`,
    })

    const sizeSuffix = pageSizeOverride ? `-${pageSizeOverride.widthMm}x${pageSizeOverride.heightMm}mm` : ''
    return new NextResponse(new Uint8Array(docxBuffer), {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="paper-${paper.paperNumber}-${mode}${sizeSuffix}.docx"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
