import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { renderPaperHtml, type PaperExportMode } from '@/lib/pdf/paperHtml'
import { resolvePaperLayoutSettings, parsePageSizeMmParam } from '@/lib/pdf/paperLayout'
import { resolveCoverDesignForRender } from '@/lib/pdf/coverDesignPipeline'

// GET /papers/:id/print?mode=question|answerKey|solutions&columns=1-3&pageSizeMm=210x285&draft=<json>
//
// Renders the paper as a standalone, print-ready HTML page (auth-gated by
// middleware.ts like every other non-public route). This is the CANONICAL
// "Printable HTML" / "Print Paper" feature (§14) — a user can hit
// Ctrl/Cmd+P and choose "Save as PDF" for an export that always works, with
// no server-side PDF pipeline dependency.
//
// `pageSizeMm=<width>x<height>` is the one-off "download/preview at a
// custom physical size" override (e.g. 210x285 for the "short A4" some
// printers/binders expect) — see resolvePaperLayoutSettings's
// pageSizeOverride param. Never persisted.
//
// `draft=<url-encoded JSON>` is used by the Paper Settings panel's live
// preview: it carries the panel's in-memory, not-yet-saved settings so the
// preview reflects changes immediately, without writing anything to the
// database. See resolvePaperLayoutSettings's draftOverride param.
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    const mode = (searchParams.get('mode') as PaperExportMode) || 'question'
    if (!['question', 'answerKey', 'solutions'].includes(mode)) {
      return NextResponse.json({ error: 'Invalid print mode.' }, { status: 400 })
    }
    const columnsParam = searchParams.get('columns')
    const columnsOverride = columnsParam ? Number(columnsParam) : null
    const pageSizeOverride = parsePageSizeMmParam(searchParams.get('pageSizeMm'))
    const draftParam = searchParams.get('draft')
    let draftOverride: unknown
    if (draftParam) {
      try {
        draftOverride = JSON.parse(draftParam)
      } catch {
        // Malformed draft JSON — ignore and fall back to persisted settings
        // rather than failing the whole preview render.
      }
    }

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const [questions, layout, coverDesign] = await Promise.all([
      buildPaperSnapshot(params.id),
      resolvePaperLayoutSettings(params.id, columnsOverride, pageSizeOverride, draftOverride),
      resolveCoverDesignForRender(paper.coverDesign),
    ])
    if (questions.length === 0) {
      return new NextResponse('<p style="font-family:sans-serif;padding:40px;">This paper has no questions yet.</p>', {
        headers: { 'Content-Type': 'text/html; charset=utf-8' },
      })
    }

    const html = renderPaperHtml(
      {
        title: paper.title,
        subtitle: paper.subtitle,
        paperNumber: paper.paperNumber,
        instituteName: paper.instituteName,
        logoUrl: paper.logoUrl,
        examName: paper.examName,
        subjectLabel: paper.subjectLabel,
        classLabel: paper.classLabel,
        examDate: paper.examDate ? paper.examDate.toISOString().slice(0, 10) : null,
        examTime: paper.examTime,
        maxMarks: paper.maxMarks,
        instructions: paper.instructions,
        headerText: paper.headerText,
        footerText: paper.footerText,
      },
      questions,
      mode,
      layout,
      coverDesign,
      paper.separateFrontPage
    )

    return new NextResponse(html, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })
  } catch (error) {
    return handleApiError(error)
  }
}
