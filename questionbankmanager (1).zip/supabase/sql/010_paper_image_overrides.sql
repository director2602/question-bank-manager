-- ─────────────────────────────────────────────────────────────────────────
-- Paper-scoped IMAGE overrides — same idea as 009's paper_questions text
-- override columns, applied to images:
--
-- 1) question_images gains two nullable columns. paper_question_id, when
--    set, means this image row belongs to ONE specific paper's question
--    instance only (added or replaced from inside that paper) — it is
--    NEVER linked to question_version_id and never touches the master
--    Question Bank. overrides_image_id, when also set, names the master
--    image this row stands in for (a replacement); left null it's a
--    brand-new image added only within that paper.
--
-- 2) paper_image_removals is a new small table: one row means "hide this
--    master question_images row within this one paper_questions row only".
--    The master image itself is never touched — deleting this row restores
--    it for that paper.
--
-- Every existing question_images row is completely unaffected (both new
-- columns default to null), and buildPaperSnapshot is the only place that
-- merges any of this in — no other reader of question_images changes
-- behavior. Purely additive: no existing column, table, row, or constraint
-- is altered or removed.
-- ─────────────────────────────────────────────────────────────────────────

alter table public.question_images
  add column if not exists paper_question_id uuid references public.paper_questions(id) on delete cascade,
  add column if not exists overrides_image_id uuid references public.question_images(id) on delete set null;
create index if not exists question_images_paper_question_id_idx on public.question_images(paper_question_id);

create table if not exists public.paper_image_removals (
  id uuid primary key default gen_random_uuid(),
  paper_question_id uuid not null references public.paper_questions(id) on delete cascade,
  question_image_id uuid not null references public.question_images(id) on delete cascade,
  removed_by_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (paper_question_id, question_image_id)
);
alter table public.paper_image_removals enable row level security;
create index if not exists paper_image_removals_paper_question_id_idx on public.paper_image_removals(paper_question_id);
