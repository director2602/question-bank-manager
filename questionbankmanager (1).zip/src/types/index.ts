import type { RoleCode, PaperMode, PaperStatus, QuestionStatus, QuestionType, SectionNumberingMode, AnswerSpaceSize, QuestionNumberingStyle, MarksDisplayStyle } from '@prisma/client'

export type LookupOption = {
  id: string
  code: string
  label: string
  sortOrder: number
}

// A Chapter is scoped to a Subject; a Topic is scoped to a Chapter — see
// useLookups()'s chapters/topics arrays, each item carrying its parent id
// so the UI can filter the dropdown as the parent selection changes.
export type ChapterOption = LookupOption & { subjectId: string }
export type TopicOption = LookupOption & { chapterId: string }

export type QuestionListItem = {
  id: string
  questionNumber: string
  status: QuestionStatus
  rowVersion: number
  subject: LookupOption
  examClass: LookupOption
  code: LookupOption
  difficulty: LookupOption
  questionType: QuestionType
  chapter: LookupOption | null
  topic: LookupOption | null
  questionText: string
  hasImages: boolean
  versionNumber: number
  createdBy: { id: string; fullName: string | null; email: string }
  createdAt: string
  updatedAt: string
}

export type QuestionDetail = QuestionListItem & {
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  images: {
    id: string
    storagePath: string
    fileName: string
    sortOrder: number
    url: string
    optionSlot: 'A' | 'B' | 'C' | 'D' | null
  }[]
}

export type PaperFilterLine = {
  subjectId: string
  examClassId: string
  codeId: string
  difficultyId: string
  count: number
}

export type AvailableCountResult = PaperFilterLine & {
  available: number
  labels: { subject: string; examClass: string; code: string; difficulty: string }
}

export type PaperListItem = {
  id: string
  paperNumber: number
  title: string
  mode: PaperMode
  status: PaperStatus
  questionCount: number
  folder: { id: string; name: string } | null
  createdBy: { id: string; fullName: string | null; email: string }
  createdAt: string
  updatedAt: string
}

export type PaperFolderItem = {
  id: string
  name: string
  paperCount: number
  createdAt: string
}

export type SessionUser = {
  id: string
  email: string
  fullName: string | null
  role: RoleCode
}

export type ApiErrorBody = {
  error: string
  code?: string
  fieldErrors?: Record<string, string[] | undefined>
  shortfalls?: Array<{
    subject: string
    examClass: string
    code: string
    difficulty: string
    requested: number
    available: number
  }>
  // Advanced Paper Builder's per-section, per-type shortfall reporting
  // (spec §23) — deliberately a separate field from `shortfalls` above
  // rather than reusing its shape, since a section shortfall is keyed by
  // section/chapter/questionType, not subject/examClass/code/difficulty.
  sectionShortfalls?: Array<{
    sectionLabel: string
    questionType: QuestionType
    chapterLabel: string | null
    requested: number
    available: number
    message: string
  }>
  latest?: unknown
}

// ── Advanced Paper Builder ─────────────────────────────────────────────

export type SelectionMode = 'AUTOMATIC' | 'MANUAL' | 'HYBRID'

// One row of per-type configuration within a section — "MCQ: 10 questions,
// 1 mark each, Medium difficulty" etc. A section can mix multiple types
// (spec §4) by having more than one entry here.
export type SectionTypeConfig = {
  key: string
  questionType: QuestionType
  count: number
  marksPerQuestion: number
  difficultyId: string | null
}

export type PaperSectionInput = {
  key: string
  label: string
  title: string
  instructions: string | null
  numberingMode: SectionNumberingMode
  answerSpace: AnswerSpaceSize
  customAnswerSpaceMm: number | null
  chapterScope: 'ALL' | 'SELECTED'
  chapterIds: string[]
  topicScope: 'ALL' | 'SELECTED'
  topicIds: string[]
  selectionMode: SelectionMode
  types: SectionTypeConfig[]
  // Final, explicit question-id list for MANUAL/HYBRID sections (HYBRID
  // starts from an auto-generated list the user then edits client-side —
  // by submission time both modes are just "the final list").
  manualQuestionIds: string[]
}

export type PaperHeadingFieldKey =
  | 'schoolName'
  | 'examName'
  | 'subject'
  | 'class'
  | 'academicYear'
  | 'time'
  | 'maximumMarks'
  | 'rollNumber'
  | 'studentName'
  | 'date'

export type PaperHeadingConfig = {
  title: string | null
  subtitle: string | null
  fields: Record<PaperHeadingFieldKey, { show: boolean; customText: string | null }>
  fontFamily: string | null
  fontSizePt: number | null
  bold: boolean
  alignment: 'LEFT' | 'CENTER' | 'RIGHT'
  logoUrl: string | null
  logoWidthMm: number | null
}

export type PaperSectionItem = {
  id: string
  position: number
  label: string
  title: string
  instructions: string | null
  numberingMode: SectionNumberingMode
  answerSpace: AnswerSpaceSize
  customAnswerSpaceMm: number | null
  typeConfig: SectionTypeConfig[]
  questionCount: number
  marks: number
}

export type { QuestionType, SectionNumberingMode, AnswerSpaceSize, QuestionNumberingStyle, MarksDisplayStyle }
