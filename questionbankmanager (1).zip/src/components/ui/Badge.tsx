const DIFFICULTY_COLORS: Record<string, string> = {
  E: 'bg-green-100 text-green-800',
  M: 'bg-amber-100 text-amber-800',
  D: 'bg-red-100 text-red-800',
}

export function DifficultyBadge({ code, label }: { code: string; label: string }) {
  return <span className={`badge ${DIFFICULTY_COLORS[code] ?? 'bg-surface-muted text-ink-muted'}`}>{label}</span>
}

export function StatusBadge({ status }: { status: 'ACTIVE' | 'ARCHIVED' }) {
  return (
    <span className={`badge ${status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-surface-muted text-ink-muted'}`}>
      {status === 'ACTIVE' ? 'Active' : 'Archived'}
    </span>
  )
}

// ADMIN = "Owner" (the single full-control account), EDITOR = "User" (the
// standard role every other account gets), VIEWER = optional read-only
// tier. See src/lib/constants.ts for the full role model.
const ROLE_LABELS: Record<string, string> = { ADMIN: 'Owner', EDITOR: 'User', VIEWER: 'Viewer' }

export function RoleBadge({ role }: { role: string }) {
  const colors: Record<string, string> = {
    ADMIN: 'bg-brand-100 text-brand-800',
    EDITOR: 'bg-amber-100 text-amber-800',
    VIEWER: 'bg-surface-muted text-ink-muted',
  }
  return <span className={`badge ${colors[role] ?? 'bg-surface-muted text-ink-muted'}`}>{ROLE_LABELS[role] ?? role}</span>
}

export function Tag({ children }: { children: React.ReactNode }) {
  return <span className="badge border border-surface-border bg-surface-subtle text-ink-muted">{children}</span>
}
