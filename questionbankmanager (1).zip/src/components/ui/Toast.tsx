'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'

type Toast = { id: number; kind: 'success' | 'error' | 'info'; message: string }

const ToastContext = createContext<{ show: (kind: Toast['kind'], message: string) => void } | null>(null)

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])

  const show = useCallback((kind: Toast['kind'], message: string) => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, kind, message }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 5000)
  }, [])

  const value = useMemo(() => ({ show }), [show])

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-auto min-w-[260px] max-w-sm rounded-md border px-4 py-3 text-sm shadow-card ${
              t.kind === 'success'
                ? 'border-green-200 bg-green-50 text-success'
                : t.kind === 'error'
                  ? 'border-red-200 bg-red-50 text-danger'
                  : 'border-surface-border bg-white text-ink'
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast must be used within ToastProvider')
  return ctx
}

export function errorMessage(err: unknown): string {
  if (err && typeof err === 'object' && 'message' in err) return String((err as Error).message)
  return 'Something went wrong. Please try again.'
}
