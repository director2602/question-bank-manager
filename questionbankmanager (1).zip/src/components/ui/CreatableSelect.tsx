'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import type { LookupOption } from '@/types'

/**
 * A "type it and it just works" field for Chapter/Topic: type freely,
 * matching existing entries suggest as you type, and committing (Enter,
 * clicking away, or picking a suggestion) either selects the matching
 * existing entry or creates a brand-new one automatically — no separate
 * "+ Create" step. Replaces the old dropdown-plus-button flow per direct
 * user feedback: "we need to add chapter name manually during addition of
 * question."
 *
 * Duplicate-safe: a case-insensitive exact match against the known options
 * (including ones created earlier in this same form session, which won't
 * appear in `options` until the page reloads) is treated as a SELECT, never
 * a second create — so typing "Mechanics" twice never makes two chapters.
 */
// Internally we only ever read `.id`/`.label`, so options created on the fly
// (which only carry those two fields) can mix with the full `LookupOption`
// list from the parent without a type mismatch.
type Option = { id: string; label: string }

export function CreatableSelect({
  options,
  value,
  onSelectExisting,
  onCreateNew,
  onClear,
  placeholder = 'Type to search or add new…',
  disabled = false,
  createLabel = 'Add',
}: {
  options: LookupOption[]
  value: string | null
  onSelectExisting: (id: string) => void
  onCreateNew: (label: string) => Promise<{ id: string; label: string } | null>
  onClear: () => void
  placeholder?: string
  disabled?: boolean
  createLabel?: string
}) {
  const [text, setText] = useState('')
  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  // Entries created earlier in this same form session — kept locally since
  // the parent's lookup list isn't refetched mid-session, so a second
  // matching entry can still be recognized instead of re-created.
  const [extraOptions, setExtraOptions] = useState<Option[]>([])
  const rootRef = useRef<HTMLDivElement>(null)
  const lastValueRef = useRef<string | null>(null)
  const stateRef = useRef({ text: '', value: value as string | null })

  const allOptions = useMemo<Option[]>(() => {
    const seen = new Set(options.map((o) => o.id))
    return [...options, ...extraOptions.filter((o) => !seen.has(o.id))]
  }, [options, extraOptions])

  const exactMatch = useMemo(
    () => allOptions.find((o) => o.label.trim().toLowerCase() === text.trim().toLowerCase()),
    [allOptions, text]
  )

  const filtered = useMemo(() => {
    const q = text.trim().toLowerCase()
    if (!q) return allOptions
    return allOptions.filter((o) => o.label.toLowerCase().includes(q))
  }, [allOptions, text])

  // Sync displayed text when the selected id changes from OUTSIDE (e.g. a
  // parent cascade-clear on Subject change) — but never fight the user
  // while they're actively typing/selecting themselves.
  useEffect(() => {
    if (value === lastValueRef.current) return
    lastValueRef.current = value
    if (!value) {
      setText('')
      return
    }
    const match = allOptions.find((o) => o.id === value)
    if (match) setText(match.label)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value])

  useEffect(() => {
    stateRef.current = { text, value }
  }, [text, value])

  async function commit() {
    const trimmed = stateRef.current.text.trim()
    if (!trimmed) {
      if (stateRef.current.value) onClear()
      return
    }
    const match = allOptions.find((o) => o.label.trim().toLowerCase() === trimmed.toLowerCase())
    if (match) {
      if (match.id !== stateRef.current.value) {
        lastValueRef.current = match.id
        onSelectExisting(match.id)
      }
      return
    }
    setSaving(true)
    try {
      const created = await onCreateNew(trimmed)
      if (created) {
        setExtraOptions((prev) => [...prev, created])
        lastValueRef.current = created.id
        setText(created.label)
        onSelectExisting(created.id)
      }
    } finally {
      setSaving(false)
    }
  }

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false)
        commit()
      }
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function selectOption(o: Option) {
    lastValueRef.current = o.id
    setText(o.label)
    setOpen(false)
    onSelectExisting(o.id)
  }

  return (
    <div ref={rootRef} className="relative">
      <input
        className="input"
        placeholder={placeholder}
        value={text}
        disabled={disabled || saving}
        onChange={(e) => {
          setText(e.target.value)
          setOpen(true)
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault()
            commit()
            setOpen(false)
          } else if (e.key === 'Escape') {
            setOpen(false)
          }
        }}
      />
      {saving && <p className="mt-1 text-xs text-ink-faint">Saving “{text.trim()}”…</p>}
      {open && !disabled && !saving && (filtered.length > 0 || (text.trim() && !exactMatch)) && (
        <div className="absolute z-20 mt-1 w-full rounded-md border border-surface-border bg-white shadow-card">
          <ul className="max-h-56 overflow-y-auto py-1">
            {filtered.map((o) => (
              <li key={o.id}>
                <button
                  type="button"
                  className="block w-full px-3 py-2 text-left text-sm text-ink hover:bg-surface-muted"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => selectOption(o)}
                >
                  {o.label}
                </button>
              </li>
            ))}
            {text.trim() && !exactMatch && (
              <li>
                <button
                  type="button"
                  className="block w-full border-t border-surface-border px-3 py-2 text-left text-sm text-brand-700 hover:bg-brand-50"
                  onMouseDown={(e) => e.preventDefault()}
                  onClick={() => {
                    commit()
                    setOpen(false)
                  }}
                >
                  {createLabel} “{text.trim()}”
                </button>
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  )
}
