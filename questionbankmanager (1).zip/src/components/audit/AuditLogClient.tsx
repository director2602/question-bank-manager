'use client'

import { useCallback, useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { Pagination } from '@/components/ui/Pagination'

type LogItem = {
  id: string
  action: string
  entityType: string
  entityId: string | null
  description: string
  user: { id: string; fullName: string | null; email: string } | null
  createdAt: string
}

type ListResponse = { items: LogItem[]; page: number; pageSize: number; total: number; totalPages: number }

export function AuditLogClient() {
  const { show } = useToast()
  const [page, setPage] = useState(1)
  const [entityType, setEntityType] = useState('')
  const [data, setData] = useState<ListResponse | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(page) })
      if (entityType) params.set('entityType', entityType)
      const result = await apiFetch<ListResponse>(`/api/audit-logs?${params.toString()}`)
      setData(result)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, entityType])

  useEffect(() => {
    load()
  }, [load])

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {['', 'QUESTION', 'PAPER', 'USER', 'SETTINGS'].map((t) => (
          <button
            key={t || 'all'}
            className={`btn-secondary !py-1 ${entityType === t ? '!bg-brand-600 !text-white' : ''}`}
            onClick={() => {
              setEntityType(t)
              setPage(1)
            }}
          >
            {t || 'All'}
          </button>
        ))}
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="border-b border-surface-border bg-surface-subtle text-left text-xs uppercase tracking-wide text-ink-faint">
            <tr>
              <th className="px-3 py-2">When</th>
              <th className="px-3 py-2">User</th>
              <th className="px-3 py-2">Action</th>
              <th className="px-3 py-2">Description</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {loading && (
              <tr>
                <td colSpan={4} className="px-3 py-8 text-center text-ink-faint">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && data?.items.length === 0 && (
              <tr>
                <td colSpan={4} className="px-3 py-8 text-center text-ink-faint">
                  No audit events yet.
                </td>
              </tr>
            )}
            {!loading &&
              data?.items.map((log) => (
                <tr key={log.id} className="align-top hover:bg-surface-subtle">
                  <td className="whitespace-nowrap px-3 py-3 text-ink-faint">{new Date(log.createdAt).toLocaleString()}</td>
                  <td className="px-3 py-3 text-ink-muted">{log.user?.fullName ?? log.user?.email ?? 'System'}</td>
                  <td className="px-3 py-3">
                    <span className="badge bg-surface-muted text-ink-muted">{log.action}</span>
                  </td>
                  <td className="px-3 py-3">{log.description}</td>
                </tr>
              ))}
          </tbody>
        </table>
        {data && (
          <Pagination page={data.page} totalPages={data.totalPages} total={data.total} pageSize={data.pageSize} onPageChange={setPage} />
        )}
      </div>
    </div>
  )
}
