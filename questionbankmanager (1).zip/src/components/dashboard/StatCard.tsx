export function StatCard({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <div className="card p-4">
      <div className="text-xs font-medium uppercase tracking-wide text-ink-faint">{label}</div>
      <div className="mt-1.5 text-2xl font-semibold text-ink">{value}</div>
      {hint && <div className="mt-1 text-xs text-ink-muted">{hint}</div>}
    </div>
  )
}

export function DifficultyBreakdownTable({
  rows,
}: {
  rows: { label: string; count: number; percentOfBank: number; usedCount: number; percentUsed: number }[]
}) {
  if (rows.length === 0) return <p className="text-sm text-ink-faint">No data yet.</p>
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wide text-ink-faint">
            <th className="pb-2 pr-2 font-medium">Difficulty</th>
            <th className="pb-2 pr-2 text-right font-medium">Questions</th>
            <th className="pb-2 pr-2 text-right font-medium">% of Bank</th>
            <th className="pb-2 pr-2 text-right font-medium">Used in Papers</th>
            <th className="pb-2 text-right font-medium">% Used</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-surface-border">
          {rows.map((r) => (
            <tr key={r.label}>
              <td className="py-2 pr-2 text-ink-muted">{r.label}</td>
              <td className="py-2 pr-2 text-right font-medium text-ink">{r.count}</td>
              <td className="py-2 pr-2 text-right text-ink-muted">{r.percentOfBank}%</td>
              <td className="py-2 pr-2 text-right font-medium text-ink">{r.usedCount}</td>
              <td className="py-2 text-right text-ink-muted">{r.percentUsed}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function BarList({ items }: { items: { label: string; count: number }[] }) {
  const max = Math.max(1, ...items.map((i) => i.count))
  return (
    <div className="space-y-2.5">
      {items.length === 0 && <p className="text-sm text-ink-faint">No data yet.</p>}
      {items.map((item) => (
        <div key={item.label} className="flex items-center gap-3">
          <span className="w-28 shrink-0 truncate text-sm text-ink-muted">{item.label}</span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-surface-muted">
            <div
              className="h-full rounded-full bg-brand-500"
              style={{ width: `${Math.max(4, (item.count / max) * 100)}%` }}
            />
          </div>
          <span className="w-10 shrink-0 text-right text-sm font-medium text-ink">{item.count}</span>
        </div>
      ))}
    </div>
  )
}
