'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'

type Template = {
  id: string
  name: string
  instituteName: string
  logoUrl: string | null
  headerText: string | null
  footerText: string | null
  instructions: string | null
  isDefault: boolean
}

export function PaperTemplateManager() {
  const { show } = useToast()
  const [templates, setTemplates] = useState<Template[]>([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({
    name: '',
    instituteName: '',
    logoUrl: '',
    headerText: '',
    footerText: '',
    instructions: '',
    isDefault: false,
  })
  const [saving, setSaving] = useState(false)

  function load() {
    setLoading(true)
    apiFetch<{ items: Template[] }>('/api/settings/institute')
      .then((res) => setTemplates(res.items))
      .catch((err) => show('error', errorMessage(err)))
      .finally(() => setLoading(false))
  }

  useEffect(load, [])

  async function handleCreate() {
    if (!form.name.trim() || !form.instituteName.trim()) {
      show('error', 'Template name and institute name are required.')
      return
    }
    setSaving(true)
    try {
      await apiFetch('/api/settings/institute', { method: 'POST', body: JSON.stringify(form) })
      show('success', 'Template saved.')
      setForm({ name: '', instituteName: '', logoUrl: '', headerText: '', footerText: '', instructions: '', isDefault: false })
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <div className="card p-5">
        <h2 className="mb-3 text-sm font-semibold text-ink">Existing templates</h2>
        {loading && <p className="text-sm text-ink-faint">Loading…</p>}
        <ul className="space-y-2">
          {templates.map((t) => (
            <li key={t.id} className="rounded-md border border-surface-border p-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-medium text-ink">{t.name}</span>
                {t.isDefault && <span className="badge bg-brand-100 text-brand-800">Default</span>}
              </div>
              <p className="text-ink-muted">{t.instituteName}</p>
            </li>
          ))}
          {!loading && templates.length === 0 && <p className="text-sm text-ink-faint">No templates yet — create one.</p>}
        </ul>
      </div>

      <div className="card space-y-3 p-5">
        <h2 className="text-sm font-semibold text-ink">New template</h2>
        <div>
          <label className="label">Template Name</label>
          <input className="input" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
        </div>
        <div>
          <label className="label">Institute Name</label>
          <input className="input" value={form.instituteName} onChange={(e) => setForm((f) => ({ ...f, instituteName: e.target.value }))} />
        </div>
        <div>
          <label className="label">Logo URL</label>
          <input className="input" value={form.logoUrl} onChange={(e) => setForm((f) => ({ ...f, logoUrl: e.target.value }))} />
        </div>
        <div>
          <label className="label">Header Text</label>
          <input className="input" value={form.headerText} onChange={(e) => setForm((f) => ({ ...f, headerText: e.target.value }))} />
        </div>
        <div>
          <label className="label">Footer Text</label>
          <input className="input" value={form.footerText} onChange={(e) => setForm((f) => ({ ...f, footerText: e.target.value }))} />
        </div>
        <div>
          <label className="label">Default Instructions</label>
          <textarea className="input min-h-[70px]" value={form.instructions} onChange={(e) => setForm((f) => ({ ...f, instructions: e.target.value }))} />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={form.isDefault} onChange={(e) => setForm((f) => ({ ...f, isDefault: e.target.checked }))} />
          Make this the default template
        </label>
        <button className="btn-primary" onClick={handleCreate} disabled={saving}>
          {saving ? 'Saving…' : 'Save Template'}
        </button>
      </div>
    </div>
  )
}
