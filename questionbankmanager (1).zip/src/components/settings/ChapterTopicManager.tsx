'use client'

import { useEffect, useMemo, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'

type ChapterRow = {
  id: string
  subjectId: string
  code: string
  label: string
  sortOrder: number
  isActive: boolean
  questionCount: number
  topicCount: number
}

type TopicRow = {
  id: string
  chapterId: string
  code: string
  label: string
  sortOrder: number
  isActive: boolean
  questionCount: number
}

// Native HTML5 drag-and-drop — no extra dependency needed for a simple
// single-column reorderable list. Up/down buttons are kept alongside as an
// accessible, no-drag-required alternative to the exact same reorder API.
function ReorderableList<T extends { id: string; label: string; code: string; isActive: boolean }>({
  items,
  onReorder,
  onEdit,
  onDelete,
  extra,
}: {
  items: T[]
  onReorder: (orderedIds: string[]) => void
  onEdit: (item: T, patch: { code?: string; label?: string; isActive?: boolean }) => void
  onDelete: (item: T) => void
  extra?: (item: T) => React.ReactNode
}) {
  const [dragId, setDragId] = useState<string | null>(null)
  const [editing, setEditing] = useState<string | null>(null)
  const [editLabel, setEditLabel] = useState('')
  const [editCode, setEditCode] = useState('')

  function move(id: string, dir: -1 | 1) {
    const idx = items.findIndex((i) => i.id === id)
    const swapWith = idx + dir
    if (idx < 0 || swapWith < 0 || swapWith >= items.length) return
    const next = [...items]
    const a = next[idx]
    const b = next[swapWith]
    if (!a || !b) return
    next[idx] = b
    next[swapWith] = a
    onReorder(next.map((i) => i.id))
  }

  function handleDrop(targetId: string) {
    if (!dragId || dragId === targetId) return
    const from = items.findIndex((i) => i.id === dragId)
    const to = items.findIndex((i) => i.id === targetId)
    if (from < 0 || to < 0) return
    const next = [...items]
    const [moved] = next.splice(from, 1)
    if (!moved) return
    next.splice(to, 0, moved)
    onReorder(next.map((i) => i.id))
    setDragId(null)
  }

  return (
    <ul className="divide-y divide-surface-border rounded-md border border-surface-border">
      {items.map((item, idx) => (
        <li
          key={item.id}
          draggable
          onDragStart={() => setDragId(item.id)}
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => handleDrop(item.id)}
          className={`flex items-center gap-2 px-3 py-2 text-sm ${!item.isActive ? 'opacity-50' : ''}`}
        >
          <span className="cursor-grab select-none text-ink-faint" title="Drag to reorder">
            ⠿
          </span>
          <div className="flex flex-col">
            <button className="text-ink-faint hover:text-ink" disabled={idx === 0} onClick={() => move(item.id, -1)}>
              ▲
            </button>
            <button
              className="text-ink-faint hover:text-ink"
              disabled={idx === items.length - 1}
              onClick={() => move(item.id, 1)}
            >
              ▼
            </button>
          </div>

          {editing === item.id ? (
            <div className="flex flex-1 items-center gap-2">
              <input className="input !py-1" value={editCode} onChange={(e) => setEditCode(e.target.value)} placeholder="Code" />
              <input className="input !py-1 flex-1" value={editLabel} onChange={(e) => setEditLabel(e.target.value)} placeholder="Name" />
              <button
                className="btn-primary !px-2 !py-1"
                onClick={() => {
                  onEdit(item, { code: editCode, label: editLabel })
                  setEditing(null)
                }}
              >
                Save
              </button>
              <button className="btn-ghost !px-2 !py-1" onClick={() => setEditing(null)}>
                Cancel
              </button>
            </div>
          ) : (
            <div className="flex flex-1 items-center gap-2">
              <span className="rounded bg-surface-muted px-1.5 py-0.5 text-xs text-ink-faint">{item.code}</span>
              <span className="flex-1 font-medium text-ink">{item.label}</span>
              {!item.isActive && <span className="text-xs text-ink-faint">(inactive)</span>}
              {extra?.(item)}
            </div>
          )}

          {editing !== item.id && (
            <div className="flex gap-1">
              <button
                className="btn-ghost !px-2 !py-1"
                onClick={() => {
                  setEditing(item.id)
                  setEditCode(item.code)
                  setEditLabel(item.label)
                }}
              >
                Edit
              </button>
              <button
                className="btn-ghost !px-2 !py-1"
                onClick={() => onEdit(item, { isActive: !item.isActive })}
              >
                {item.isActive ? 'Deactivate' : 'Activate'}
              </button>
              <button className="btn-ghost !px-2 !py-1 text-danger" onClick={() => onDelete(item)}>
                Delete
              </button>
            </div>
          )}
        </li>
      ))}
      {items.length === 0 && <li className="px-3 py-6 text-center text-sm text-ink-faint">Nothing here yet.</li>}
    </ul>
  )
}

export function ChapterTopicManager() {
  const { show } = useToast()
  const { lookups } = useLookups()
  const [subjectId, setSubjectId] = useState<string | null>(null)
  const [chapters, setChapters] = useState<ChapterRow[]>([])
  const [topicsByChapter, setTopicsByChapter] = useState<Record<string, TopicRow[]>>({})
  const [expanded, setExpanded] = useState<string | null>(null)
  const [newChapterCode, setNewChapterCode] = useState('')
  const [newChapterLabel, setNewChapterLabel] = useState('')
  const [newTopicCode, setNewTopicCode] = useState('')
  const [newTopicLabel, setNewTopicLabel] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!subjectId && lookups.subjects.length > 0) setSubjectId(lookups.subjects[0]?.id ?? null)
  }, [lookups.subjects, subjectId])

  function loadChapters() {
    if (!subjectId) return
    setLoading(true)
    apiFetch<{ items: ChapterRow[] }>(`/api/chapters?subjectId=${subjectId}`)
      .then((res) => setChapters(res.items))
      .catch((err) => show('error', errorMessage(err)))
      .finally(() => setLoading(false))
  }

  useEffect(loadChapters, [subjectId])

  function loadTopics(chapterId: string) {
    apiFetch<{ items: TopicRow[] }>(`/api/topics?chapterId=${chapterId}`)
      .then((res) => setTopicsByChapter((prev) => ({ ...prev, [chapterId]: res.items })))
      .catch((err) => show('error', errorMessage(err)))
  }

  async function createChapter() {
    if (!subjectId || !newChapterCode.trim() || !newChapterLabel.trim()) return
    try {
      await apiFetch('/api/chapters', {
        method: 'POST',
        body: JSON.stringify({ subjectId, code: newChapterCode.trim(), label: newChapterLabel.trim() }),
      })
      setNewChapterCode('')
      setNewChapterLabel('')
      loadChapters()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function editChapter(item: ChapterRow, patch: { code?: string; label?: string; isActive?: boolean }) {
    try {
      await apiFetch(`/api/chapters/${item.id}`, { method: 'PATCH', body: JSON.stringify(patch) })
      loadChapters()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function deleteChapter(item: ChapterRow) {
    try {
      await apiFetch(`/api/chapters/${item.id}`, { method: 'DELETE' })
      loadChapters()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function reorderChapters(orderedIds: string[]) {
    if (!subjectId) return
    setChapters((prev) => orderedIds.map((id) => prev.find((c) => c.id === id)!).filter(Boolean))
    try {
      await apiFetch('/api/chapters/reorder', { method: 'POST', body: JSON.stringify({ subjectId, orderedIds }) })
    } catch (err) {
      show('error', errorMessage(err))
      loadChapters()
    }
  }

  async function createTopic(chapterId: string) {
    if (!newTopicCode.trim() || !newTopicLabel.trim()) return
    try {
      await apiFetch('/api/topics', {
        method: 'POST',
        body: JSON.stringify({ chapterId, code: newTopicCode.trim(), label: newTopicLabel.trim() }),
      })
      setNewTopicCode('')
      setNewTopicLabel('')
      loadTopics(chapterId)
      loadChapters()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function editTopic(chapterId: string, item: TopicRow, patch: { code?: string; label?: string; isActive?: boolean }) {
    try {
      await apiFetch(`/api/topics/${item.id}`, { method: 'PATCH', body: JSON.stringify(patch) })
      loadTopics(chapterId)
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function deleteTopic(chapterId: string, item: TopicRow) {
    try {
      await apiFetch(`/api/topics/${item.id}`, { method: 'DELETE' })
      loadTopics(chapterId)
      loadChapters()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function reorderTopics(chapterId: string, orderedIds: string[]) {
    setTopicsByChapter((prev) => ({
      ...prev,
      [chapterId]: orderedIds.map((id) => prev[chapterId]?.find((t) => t.id === id)!).filter(Boolean),
    }))
    try {
      await apiFetch('/api/topics/reorder', { method: 'POST', body: JSON.stringify({ chapterId, orderedIds }) })
    } catch (err) {
      show('error', errorMessage(err))
      loadTopics(chapterId)
    }
  }

  const subjectOptions = useMemo(() => lookups.subjects, [lookups.subjects])

  return (
    <div className="space-y-4">
      <div className="card p-4">
        <div className="max-w-xs">
          <SearchableSelect label="Subject" options={subjectOptions} value={subjectId} onChange={setSubjectId} />
        </div>
      </div>

      <div className="card space-y-3 p-4">
        <h2 className="text-sm font-semibold text-ink">Chapters</h2>
        <div className="flex gap-2">
          <input className="input w-32" placeholder="Code" value={newChapterCode} onChange={(e) => setNewChapterCode(e.target.value)} />
          <input
            className="input flex-1"
            placeholder="Chapter name, e.g. Quadratic Equations"
            value={newChapterLabel}
            onChange={(e) => setNewChapterLabel(e.target.value)}
          />
          <button className="btn-primary" onClick={createChapter} disabled={!subjectId}>
            + Add Chapter
          </button>
        </div>

        {loading ? (
          <p className="text-sm text-ink-faint">Loading…</p>
        ) : (
          <ReorderableList
            items={chapters}
            onReorder={reorderChapters}
            onEdit={editChapter}
            onDelete={deleteChapter}
            extra={(c) => (
              <button
                className="ml-2 text-xs text-brand-700 hover:underline"
                onClick={() => {
                  const next = expanded === c.id ? null : c.id
                  setExpanded(next)
                  if (next) loadTopics(next)
                }}
              >
                {c.topicCount} topic{c.topicCount === 1 ? '' : 's'} · {c.questionCount} question
                {c.questionCount === 1 ? '' : 's'} {expanded === c.id ? '▲' : '▼'}
              </button>
            )}
          />
        )}
      </div>

      {expanded &&
        (() => {
          const chapter = chapters.find((c) => c.id === expanded)
          if (!chapter) return null
          const topics = topicsByChapter[expanded] ?? []
          return (
            <div className="card space-y-3 p-4">
              <h2 className="text-sm font-semibold text-ink">Topics in &ldquo;{chapter.label}&rdquo;</h2>
              <p className="text-xs text-ink-faint">
                Sequence here is the persistent order used everywhere this chapter&rsquo;s topics are listed.
              </p>
              <div className="flex gap-2">
                <input className="input w-32" placeholder="Code" value={newTopicCode} onChange={(e) => setNewTopicCode(e.target.value)} />
                <input
                  className="input flex-1"
                  placeholder="Topic name, e.g. Discriminant"
                  value={newTopicLabel}
                  onChange={(e) => setNewTopicLabel(e.target.value)}
                />
                <button className="btn-primary" onClick={() => createTopic(expanded)}>
                  + Add Topic
                </button>
              </div>
              <ReorderableList
                items={topics}
                onReorder={(ids) => reorderTopics(expanded, ids)}
                onEdit={(item, patch) => editTopic(expanded, item, patch)}
                onDelete={(item) => deleteTopic(expanded, item)}
                extra={(t) => (
                  <span className="ml-2 text-xs text-ink-faint">
                    {t.questionCount} question{t.questionCount === 1 ? '' : 's'}
                  </span>
                )}
              />
            </div>
          )
        })()}
    </div>
  )
}
