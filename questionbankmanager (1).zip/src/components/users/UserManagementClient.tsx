'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { RoleBadge } from '@/components/ui/Badge'

type UserRow = {
  id: string
  email: string
  fullName: string | null
  role: 'ADMIN' | 'EDITOR' | 'VIEWER'
  isActive: boolean
  createdAt: string
}

export function UserManagementClient({ currentUserId }: { currentUserId: string }) {
  const { show } = useToast()
  const [users, setUsers] = useState<UserRow[] | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)

  const [showAddForm, setShowAddForm] = useState(false)
  const [newEmail, setNewEmail] = useState('')
  const [newFullName, setNewFullName] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [newRole, setNewRole] = useState<UserRow['role']>('EDITOR')
  const [creating, setCreating] = useState(false)

  function load() {
    apiFetch<{ items: UserRow[] }>('/api/users')
      .then((res) => setUsers(res.items))
      .catch((err) => show('error', errorMessage(err)))
  }

  useEffect(load, [])

  async function handleCreateUser(e: React.FormEvent) {
    e.preventDefault()
    if (newPassword.length < 8) {
      show('error', 'Password must be at least 8 characters.')
      return
    }
    setCreating(true)
    try {
      await apiFetch('/api/users', {
        method: 'POST',
        body: JSON.stringify({ email: newEmail, fullName: newFullName, password: newPassword, roleCode: newRole }),
      })
      show('success', `Account created for ${newEmail}.`)
      setNewEmail('')
      setNewFullName('')
      setNewPassword('')
      setNewRole('EDITOR')
      setShowAddForm(false)
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setCreating(false)
    }
  }

  async function changeRole(id: string, roleCode: UserRow['role']) {
    setBusyId(id)
    try {
      await apiFetch(`/api/users/${id}/role`, { method: 'PATCH', body: JSON.stringify({ roleCode }) })
      show('success', 'Role updated.')
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusyId(null)
    }
  }

  async function toggleActive(id: string, isActive: boolean) {
    setBusyId(id)
    try {
      await apiFetch(`/api/users/${id}/status`, { method: 'PATCH', body: JSON.stringify({ isActive }) })
      show('success', isActive ? 'User activated.' : 'User deactivated.')
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusyId(null)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button className="btn-primary" onClick={() => setShowAddForm((v) => !v)}>
          {showAddForm ? 'Cancel' : '+ Add User'}
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleCreateUser} className="card grid grid-cols-1 gap-3 p-4 sm:grid-cols-4">
          <div>
            <label className="label">Full name</label>
            <input required className="input" value={newFullName} onChange={(e) => setNewFullName(e.target.value)} />
          </div>
          <div>
            <label className="label">Email</label>
            <input required type="email" className="input" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
          </div>
          <div>
            <label className="label">Password</label>
            <input required type="password" minLength={8} className="input" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          </div>
          <div>
            <label className="label">Role</label>
            <select className="input" value={newRole} onChange={(e) => setNewRole(e.target.value as UserRow['role'])}>
              <option value="ADMIN">Owner</option>
              <option value="EDITOR">User</option>
              <option value="VIEWER">Viewer (read-only)</option>
            </select>
          </div>
          <div className="sm:col-span-4 flex justify-end">
            <button type="submit" className="btn-primary" disabled={creating}>
              {creating ? 'Creating…' : 'Create Account'}
            </button>
          </div>
        </form>
      )}

      <div className="card overflow-hidden">
      <table className="w-full text-sm">
        <thead className="border-b border-surface-border bg-surface-subtle text-left text-xs uppercase tracking-wide text-ink-faint">
          <tr>
            <th className="px-3 py-2">Name</th>
            <th className="px-3 py-2">Email</th>
            <th className="px-3 py-2">Role</th>
            <th className="px-3 py-2">Status</th>
            <th className="px-3 py-2">Joined</th>
            <th className="px-3 py-2 text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-surface-border">
          {!users && (
            <tr>
              <td colSpan={6} className="px-3 py-8 text-center text-ink-faint">
                Loading…
              </td>
            </tr>
          )}
          {users?.map((u) => (
            <tr key={u.id} className="hover:bg-surface-subtle">
              <td className="px-3 py-3 font-medium text-ink">{u.fullName ?? '—'}</td>
              <td className="px-3 py-3 text-ink-muted">{u.email}</td>
              <td className="px-3 py-3">
                <select
                  className="input !w-auto !py-1"
                  value={u.role}
                  disabled={busyId === u.id || u.id === currentUserId}
                  onChange={(e) => changeRole(u.id, e.target.value as UserRow['role'])}
                >
                  <option value="ADMIN">Owner</option>
                  <option value="EDITOR">User</option>
                  <option value="VIEWER">Viewer (read-only)</option>
                </select>
              </td>
              <td className="px-3 py-3">
                <span className={`badge ${u.isActive ? 'bg-green-100 text-green-800' : 'bg-surface-muted text-ink-muted'}`}>
                  {u.isActive ? 'Active' : 'Deactivated'}
                </span>
              </td>
              <td className="px-3 py-3 text-ink-faint">{new Date(u.createdAt).toLocaleDateString()}</td>
              <td className="px-3 py-3 text-right">
                <button
                  className="btn-ghost !px-2 !py-1"
                  disabled={busyId === u.id || u.id === currentUserId}
                  onClick={() => toggleActive(u.id, !u.isActive)}
                >
                  {u.isActive ? 'Deactivate' : 'Activate'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  )
}
