'use client'

import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { MathText } from '@/components/questions/MathRenderer'

type ExtractedImage = { id: string; url: string }

type ExtractedRow = {
  tempId: string
  questionNumber: string | null
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  rawBlock: string
  lowConfidence: boolean
  isDuplicateInFile: boolean
  isDuplicateInBank: boolean
  duplicateOfQuestionNumber?: string
  images: ExtractedImage[]
}

type DocxPreviewResult = {
  totalDetected: number
  lowConfidenceCount: number
  duplicateCount: number
  imageCount: number
  diagramWarning: string | null
  rows: ExtractedRow[]
}

type EditableRow = ExtractedRow & {
  include: boolean
  subjectId: string | null
  examClassId: string | null
  codeId: string | null
  difficultyId: string | null
  expanded: boolean
  includedImageIds: Set<string>
}

// Mirrors PdfUploadWizard.tsx's structure closely on purpose — same review
// UX for every bulk-import source (CSV/PDF/handwritten/Word), just pointed
// at the .docx-specific preview endpoint. Nothing is saved to the bank
// until the user reviews and confirms below.
export function DocxUploadWizard() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()
  const inputRef = useRef<HTMLInputElement>(null)
  const [loading, setLoading] = useState(false)
  const [importing, setImporting] = useState(false)
  const [meta, setMeta] = useState<Omit<DocxPreviewResult, 'rows'> | null>(null)
  const [rows, setRows] = useState<EditableRow[]>([])
  const [bulkTags, setBulkTags] = useState<{
    subjectId: string | null
    examClassId: string | null
    codeId: string | null
    difficultyId: string | null
  }>({ subjectId: null, examClassId: null, codeId: null, difficultyId: null })

  async function handleFile(file: File) {
    setLoading(true)
    setRows([])
    setMeta(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const result = await apiFetch<DocxPreviewResult>('/api/questions/bulk-import/docx-preview', {
        method: 'POST',
        body: formData,
      })
      setMeta(result)
      setRows(
        result.rows.map((r) => ({
          ...r,
          include: !r.isDuplicateInFile && !r.isDuplicateInBank,
          subjectId: null,
          examClassId: null,
          codeId: null,
          difficultyId: null,
          expanded: false,
          includedImageIds: new Set(r.images.map((img) => img.id)),
        }))
      )
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  function applyBulkTags() {
    setRows((prev) =>
      prev.map((r) => ({
        ...r,
        subjectId: bulkTags.subjectId ?? r.subjectId,
        examClassId: bulkTags.examClassId ?? r.examClassId,
        codeId: bulkTags.codeId ?? r.codeId,
        difficultyId: bulkTags.difficultyId ?? r.difficultyId,
      }))
    )
    show('info', 'Applied to all rows below. You can still override individual rows.')
  }

  function updateRow(tempId: string, patch: Partial<EditableRow>) {
    setRows((prev) => prev.map((r) => (r.tempId === tempId ? { ...r, ...patch } : r)))
  }

  function toggleImage(tempId: string, imageId: string) {
    setRows((prev) =>
      prev.map((r) => {
        if (r.tempId !== tempId) return r
        const next = new Set(r.includedImageIds)
        if (next.has(imageId)) next.delete(imageId)
        else next.add(imageId)
        return { ...r, includedImageIds: next }
      })
    )
  }

  const selectedRows = rows.filter((r) => r.include)
  const readyCount = selectedRows.filter(
    (r) => r.subjectId && r.examClassId && r.codeId && r.difficultyId && r.questionText.trim() && r.questionNumber?.trim()
  ).length

  async function handleImport() {
    const toImport = selectedRows.filter(
      (r) => r.subjectId && r.examClassId && r.codeId && r.difficultyId && r.questionText.trim() && r.questionNumber?.trim()
    )
    if (toImport.length === 0) {
      show('error', 'Select at least one fully-tagged row (Subject, Class, Code, Difficulty, and Question No. are all required).')
      return
    }

    setImporting(true)
    try {
      const payload = toImport.map((r, idx) => ({
        rowIndex: idx,
        questionText: r.questionText,
        optionA: r.optionA,
        optionB: r.optionB,
        optionC: r.optionC,
        optionD: r.optionD,
        correctAnswer: r.correctAnswer,
        explanation: r.explanation,
        subjectId: r.subjectId!,
        examClassId: r.examClassId!,
        codeId: r.codeId!,
        difficultyId: r.difficultyId!,
        questionNumber: r.questionNumber!,
        imageIds: Array.from(r.includedImageIds),
      }))
      const result = await apiFetch<{ importedCount: number }>('/api/questions/bulk-import/confirm', {
        method: 'POST',
        body: JSON.stringify({ rowIndexes: payload.map((p) => p.rowIndex), rows: payload }),
      })
      show('success', `Imported ${result.importedCount} question(s) from the Word document.`)
      router.push('/questions')
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setImporting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">1. Upload a Word document</h2>
        <p className="mb-3 text-sm text-ink-muted">
          Works best with typed .docx question papers that number questions clearly (e.g. &ldquo;1.&rdquo;, &ldquo;Q1.&rdquo;).
          Only the newer .docx format is supported — if your file is an older .doc, open it in Word and save it as
          .docx first. Any images embedded in the document are extracted automatically and attached to the nearest
          question. Nothing is saved until you review and confirm below.
        </p>
        <input
          ref={inputRef}
          type="file"
          accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          className="block text-sm"
        />
        {loading && <p className="mt-2 text-sm text-ink-muted">Extracting questions from the Word document…</p>}
      </div>

      {meta && (
        <div className="card p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold text-ink">2. Assign tags &amp; review</h2>
            <div className="flex gap-3 text-xs text-ink-muted">
              <span>{meta.totalDetected} questions detected</span>
              {meta.imageCount > 0 && <span>{meta.imageCount} image(s) found</span>}
              {meta.lowConfidenceCount > 0 && (
                <span className="text-warning">{meta.lowConfidenceCount} need a closer look</span>
              )}
              {meta.duplicateCount > 0 && <span className="text-warning">{meta.duplicateCount} possible duplicates</span>}
            </div>
          </div>

          {meta.diagramWarning && (
            <div className="mb-4 rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
              {meta.diagramWarning}
            </div>
          )}

          <div className="mb-4 rounded-md border border-surface-border bg-surface-subtle p-3">
            <p className="mb-2 text-xs font-medium text-ink-muted">
              Apply the same tags to every detected question (you can still override any row individually):
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
              <SearchableSelect
                label="Subject"
                options={lookups.subjects}
                value={bulkTags.subjectId}
                onChange={(v) => setBulkTags((t) => ({ ...t, subjectId: v }))}
              />
              <SearchableSelect
                label="Class / Exam"
                options={lookups.examClasses}
                value={bulkTags.examClassId}
                onChange={(v) => setBulkTags((t) => ({ ...t, examClassId: v }))}
              />
              <SearchableSelect
                label="Code"
                options={lookups.codes}
                value={bulkTags.codeId}
                onChange={(v) => setBulkTags((t) => ({ ...t, codeId: v }))}
              />
              <SearchableSelect
                label="Difficulty"
                options={lookups.difficultyLevels}
                value={bulkTags.difficultyId}
                onChange={(v) => setBulkTags((t) => ({ ...t, difficultyId: v }))}
              />
              <div className="flex items-end">
                <button className="btn-secondary w-full" onClick={applyBulkTags}>
                  Apply to all
                </button>
              </div>
            </div>
          </div>

          <div className="max-h-[520px] space-y-2 overflow-y-auto">
            {rows.map((row) => (
              <div
                key={row.tempId}
                className={`rounded-md border p-3 text-sm ${
                  row.lowConfidence ? 'border-amber-300 bg-amber-50' : 'border-surface-border'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <label className="flex items-start gap-2">
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={row.include}
                      onChange={(e) => updateRow(row.tempId, { include: e.target.checked })}
                    />
                    <span>
                      <MathText text={row.questionText || '(No text detected — edit manually below)'} />
                    </span>
                  </label>
                  <button className="btn-ghost !px-2 !py-1 text-xs" onClick={() => updateRow(row.tempId, { expanded: !row.expanded })}>
                    {row.expanded ? 'Collapse' : 'Edit'}
                  </button>
                </div>
                {(row.isDuplicateInBank || row.isDuplicateInFile || row.lowConfidence) && (
                  <div className="mt-1 ml-6 text-xs text-warning">
                    {row.lowConfidence && 'Boundary detection was uncertain for this block. '}
                    {row.isDuplicateInBank && `Matches existing question #${row.duplicateOfQuestionNumber}. `}
                    {row.isDuplicateInFile && 'Duplicate within this file. '}
                  </div>
                )}

                {row.images.length > 0 && (
                  <div className="mt-2 ml-6 flex flex-wrap gap-2">
                    {row.images.map((img) => {
                      const included = row.includedImageIds.has(img.id)
                      return (
                        <label
                          key={img.id}
                          className={`flex cursor-pointer flex-col items-center gap-1 rounded-md border p-1 text-[11px] ${
                            included ? 'border-brand-400' : 'border-surface-border opacity-50'
                          }`}
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={img.url} alt="Extracted image" className="h-20 w-20 rounded object-contain" />
                          <span className="flex items-center gap-1">
                            <input
                              type="checkbox"
                              checked={included}
                              onChange={() => toggleImage(row.tempId, img.id)}
                            />
                            Keep image
                          </span>
                        </label>
                      )
                    })}
                  </div>
                )}

                {row.expanded && (
                  <div className="mt-3 ml-6 space-y-2">
                    <textarea
                      className="input min-h-[70px]"
                      value={row.questionText}
                      onChange={(e) => updateRow(row.tempId, { questionText: e.target.value })}
                    />
                    <div className="grid grid-cols-2 gap-2">
                      {(['optionA', 'optionB', 'optionC', 'optionD'] as const).map((key, idx) => (
                        <input
                          key={key}
                          className="input"
                          placeholder={`Option ${['A', 'B', 'C', 'D'][idx]}`}
                          value={row[key] ?? ''}
                          onChange={(e) => updateRow(row.tempId, { [key]: e.target.value } as Partial<EditableRow>)}
                        />
                      ))}
                    </div>
                    <input
                      className="input w-32"
                      placeholder="Question No."
                      value={row.questionNumber ?? ''}
                      onChange={(e) => updateRow(row.tempId, { questionNumber: e.target.value })}
                    />
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      <SearchableSelect
                        label="Subject"
                        options={lookups.subjects}
                        value={row.subjectId}
                        onChange={(v) => updateRow(row.tempId, { subjectId: v })}
                      />
                      <SearchableSelect
                        label="Class / Exam"
                        options={lookups.examClasses}
                        value={row.examClassId}
                        onChange={(v) => updateRow(row.tempId, { examClassId: v })}
                      />
                      <SearchableSelect
                        label="Code"
                        options={lookups.codes}
                        value={row.codeId}
                        onChange={(v) => updateRow(row.tempId, { codeId: v })}
                      />
                      <SearchableSelect
                        label="Difficulty"
                        options={lookups.difficultyLevels}
                        value={row.difficultyId}
                        onChange={(v) => updateRow(row.tempId, { difficultyId: v })}
                      />
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm text-ink-muted">
              {selectedRows.length} selected · {readyCount} fully tagged and ready
            </span>
            <button className="btn-primary" onClick={handleImport} disabled={importing || readyCount === 0}>
              {importing ? 'Importing…' : `Import ${readyCount} question(s)`}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
