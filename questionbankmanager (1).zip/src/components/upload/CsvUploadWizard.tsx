'use client'

import { useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { MathText } from '@/components/questions/MathRenderer'

type PreviewRow = {
  rowIndex: number
  raw: Record<string, string>
  resolved: {
    questionText: string
    optionA: string | null
    optionB: string | null
    optionC: string | null
    optionD: string | null
    correctAnswer: string | null
    explanation: string | null
    subjectId: string | null
    subjectLabel: string | null
    examClassId: string | null
    examClassLabel: string | null
    codeId: string | null
    codeLabel: string | null
    difficultyId: string | null
    difficultyLabel: string | null
    questionNumber: string
  }
  errors: { field: string; message: string }[]
  isDuplicateInFile: boolean
  isDuplicateInBank: boolean
  duplicateOfQuestionNumber?: string
}

type PreviewResult = {
  totalRows: number
  validRows: number
  invalidRows: number
  duplicateRows: number
  rows: PreviewRow[]
}

export function CsvUploadWizard() {
  const router = useRouter()
  const { show } = useToast()
  const inputRef = useRef<HTMLInputElement>(null)
  const [preview, setPreview] = useState<PreviewResult | null>(null)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [loading, setLoading] = useState(false)
  const [importing, setImporting] = useState(false)
  const [rowErrors, setRowErrors] = useState<Record<number, string>>({})

  async function handleFile(file: File) {
    setLoading(true)
    setPreview(null)
    setRowErrors({})
    try {
      const formData = new FormData()
      formData.append('file', file)
      const result = await apiFetch<PreviewResult>('/api/questions/bulk-import/preview', {
        method: 'POST',
        body: formData,
      })
      setPreview(result)
      setSelected(
        new Set(result.rows.filter((r) => r.errors.length === 0 && !r.isDuplicateInFile).map((r) => r.rowIndex))
      )
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  async function handleConfirm() {
    if (!preview) return
    const rows = preview.rows
      .filter((r) => selected.has(r.rowIndex) && r.errors.length === 0)
      .map((r) => ({
        rowIndex: r.rowIndex,
        questionText: r.resolved.questionText,
        optionA: r.resolved.optionA,
        optionB: r.resolved.optionB,
        optionC: r.resolved.optionC,
        optionD: r.resolved.optionD,
        correctAnswer: r.resolved.correctAnswer,
        explanation: r.resolved.explanation,
        subjectId: r.resolved.subjectId!,
        examClassId: r.resolved.examClassId!,
        codeId: r.resolved.codeId!,
        difficultyId: r.resolved.difficultyId!,
        questionNumber: r.resolved.questionNumber,
      }))

    if (rows.length === 0) {
      show('error', 'Select at least one valid row to import.')
      return
    }

    setImporting(true)
    setRowErrors({})
    try {
      const result = await apiFetch<{ importedCount: number }>('/api/questions/bulk-import/confirm', {
        method: 'POST',
        body: JSON.stringify({ rowIndexes: rows.map((r) => r.rowIndex), rows }),
      })
      show('success', `Imported ${result.importedCount} question(s).`)
      router.push('/questions')
    } catch (err) {
      if (err instanceof ApiError && (err.body as any).rowErrors) {
        const map: Record<number, string> = {}
        for (const re of (err.body as any).rowErrors as { rowIndex: number; message: string }[]) {
          map[re.rowIndex] = re.message
        }
        setRowErrors(map)
      }
      show('error', errorMessage(err))
    } finally {
      setImporting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">1. Download the template</h2>
        <p className="mb-3 text-sm text-ink-muted">
          Use this exact column structure. Subject/Class/Code/Difficulty must match the existing values (or their
          codes, e.g. &ldquo;E&rdquo; for Easy).
        </p>
        <a href="/templates/question_import_template.csv" download className="btn-secondary inline-flex">
          Download CSV Template
        </a>
      </div>

      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">2. Upload your file</h2>
        <input
          ref={inputRef}
          type="file"
          accept=".csv"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          className="block text-sm"
        />
        {loading && <p className="mt-2 text-sm text-ink-muted">Processing…</p>}
      </div>

      {preview && (
        <div className="card p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold text-ink">3. Review before importing</h2>
            <div className="flex gap-3 text-xs text-ink-muted">
              <span>{preview.totalRows} rows</span>
              <span className="text-danger">{preview.invalidRows} invalid</span>
              <span className="text-warning">{preview.duplicateRows} possible duplicates</span>
            </div>
          </div>

          <div className="max-h-[480px] overflow-auto rounded-md border border-surface-border">
            <table className="w-full text-xs">
              <thead className="sticky top-0 border-b border-surface-border bg-surface-subtle text-left uppercase tracking-wide text-ink-faint">
                <tr>
                  <th className="px-2 py-2">
                    <input
                      type="checkbox"
                      checked={
                        preview.rows.filter((r) => r.errors.length === 0).length > 0 &&
                        preview.rows.filter((r) => r.errors.length === 0).every((r) => selected.has(r.rowIndex))
                      }
                      onChange={(e) => {
                        setSelected(
                          e.target.checked
                            ? new Set(preview.rows.filter((r) => r.errors.length === 0).map((r) => r.rowIndex))
                            : new Set()
                        )
                      }}
                    />
                  </th>
                  <th className="px-2 py-2">Row</th>
                  <th className="px-2 py-2">Question</th>
                  <th className="px-2 py-2">Tags</th>
                  <th className="px-2 py-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border">
                {preview.rows.map((row) => (
                  <tr key={row.rowIndex} className={row.errors.length > 0 ? 'bg-red-50' : undefined}>
                    <td className="px-2 py-2 align-top">
                      <input
                        type="checkbox"
                        disabled={row.errors.length > 0}
                        checked={selected.has(row.rowIndex)}
                        onChange={(e) => {
                          setSelected((prev) => {
                            const next = new Set(prev)
                            if (e.target.checked) next.add(row.rowIndex)
                            else next.delete(row.rowIndex)
                            return next
                          })
                        }}
                      />
                    </td>
                    <td className="px-2 py-2 align-top text-ink-faint">{row.rowIndex + 1}</td>
                    <td className="max-w-sm px-2 py-2 align-top">
                      <MathText text={row.resolved.questionText.slice(0, 160)} />
                      <div className="mt-1 text-ink-faint">No. {row.resolved.questionNumber}</div>
                    </td>
                    <td className="px-2 py-2 align-top text-ink-muted">
                      {row.resolved.subjectLabel ?? row.raw['Subject']} / {row.resolved.examClassLabel ?? row.raw['Class']} /{' '}
                      {row.resolved.codeLabel ?? row.raw['Code']} / {row.resolved.difficultyLabel ?? row.raw['Difficulty']}
                    </td>
                    <td className="px-2 py-2 align-top">
                      {row.errors.length > 0 && (
                        <div className="text-danger">{row.errors.map((e) => e.message).join('; ')}</div>
                      )}
                      {row.isDuplicateInBank && (
                        <div className="text-warning">Matches existing #{row.duplicateOfQuestionNumber}</div>
                      )}
                      {row.isDuplicateInFile && <div className="text-warning">Duplicate within this file</div>}
                      {rowErrors[row.rowIndex] && <div className="text-danger">{rowErrors[row.rowIndex]}</div>}
                      {row.errors.length === 0 && !row.isDuplicateInBank && !row.isDuplicateInFile && (
                        <span className="text-success">Ready</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm text-ink-muted">{selected.size} row(s) selected for import</span>
            <button className="btn-primary" onClick={handleConfirm} disabled={importing || selected.size === 0}>
              {importing ? 'Importing…' : `Import ${selected.size} question(s)`}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
