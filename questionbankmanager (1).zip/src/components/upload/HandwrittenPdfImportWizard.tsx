'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { CreatableSelect } from '@/components/ui/CreatableSelect'
import { slugCode } from '@/lib/slugCode'
import { MathText } from '@/components/questions/MathRenderer'
import type { ChapterOption, TopicOption } from '@/types'

type Confidence = 'HIGH' | 'MEDIUM' | 'LOW'
type QuestionType = 'MCQ' | 'SUBJECTIVE' | 'INTEGER'

type ReviewDiagram = {
  key: string
  diagramType: string
  confidence: Confidence
  needsReview: boolean
  reviewReason: string | null
  generatedSvg: string
  originalImageUrl: string | null
  originalStoragePath: string | null
}

type ReviewQuestion = {
  tempId: string
  pageNumber: number
  questionNumber: string | null
  questionType: QuestionType
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  diagramKeys: string[]
  confidence: Confidence
  needsReview: boolean
  reviewReason: string | null
}

type HandwrittenReviewResult = {
  totalPages: number
  questions: ReviewQuestion[]
  diagrams: ReviewDiagram[]
}

type JobStatusResponse = {
  jobId: string
  status: 'PENDING' | 'PROCESSING' | 'REVIEW' | 'FAILED'
  stage: string | null
  totalPages: number | null
  errorMessage: string | null
  result: HandwrittenReviewResult | null
  confirmedAt: string | null
  confirmedQuestionCount: number | null
}

type EditableRow = ReviewQuestion & {
  include: boolean
  subjectId: string | null
  examClassId: string | null
  chapterId: string | null
  topicId: string | null
  codeId: string | null
  difficultyId: string | null
  markingScheme: string
  expanded: boolean
}

type DiagramChoice = 'generated' | 'original'
type DiagramState = { choice: DiagramChoice; editedSvg: string; editing: boolean; regenerating: boolean }

const POLL_INTERVAL_MS = 2500

export function HandwrittenPdfImportWizard() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()
  const inputRef = useRef<HTMLInputElement>(null)

  const [uploading, setUploading] = useState(false)
  const [jobId, setJobId] = useState<string | null>(null)
  const [job, setJob] = useState<JobStatusResponse | null>(null)
  const [rows, setRows] = useState<EditableRow[]>([])
  const [diagramState, setDiagramState] = useState<Record<string, DiagramState>>({})
  const [importing, setImporting] = useState(false)
  const [imported, setImported] = useState(false)
  // Chapters/Topics created on the fly via a row's "type to add" field —
  // kept here (not per-row) so a chapter created while tagging question 1
  // is immediately offered as a suggestion for question 2, instead of each
  // row only knowing about its own creations.
  const [extraChapters, setExtraChapters] = useState<ChapterOption[]>([])
  const [extraTopics, setExtraTopics] = useState<TopicOption[]>([])

  async function createChapter(subjectId: string, label: string): Promise<{ id: string; label: string } | null> {
    try {
      const res = await apiFetch<{ item: { id: string } }>('/api/chapters', {
        method: 'POST',
        body: JSON.stringify({ subjectId, code: slugCode(label, 'CH'), label }),
      })
      show('success', `Chapter "${label}" added.`)
      setExtraChapters((prev) => [...prev, { id: res.item.id, code: '', label, sortOrder: 0, subjectId }])
      return { id: res.item.id, label }
    } catch (err) {
      show('error', errorMessage(err))
      return null
    }
  }

  async function createTopic(chapterId: string, label: string): Promise<{ id: string; label: string } | null> {
    try {
      const res = await apiFetch<{ item: { id: string } }>('/api/topics', {
        method: 'POST',
        body: JSON.stringify({ chapterId, code: slugCode(label, 'TP'), label }),
      })
      show('success', `Topic "${label}" added.`)
      setExtraTopics((prev) => [...prev, { id: res.item.id, code: '', label, sortOrder: 0, chapterId }])
      return { id: res.item.id, label }
    } catch (err) {
      show('error', errorMessage(err))
      return null
    }
  }

  const diagramsByKey = useMemo(
    () => new Map((job?.result?.diagrams ?? []).map((d) => [d.key, d])),
    [job?.result?.diagrams]
  )

  // Poll while a job is in flight. Shows the discrete stage messages the
  // pipeline reports ("Uploading…", "Reading handwriting…", "Detecting
  // diagrams…", …) rather than making the browser wait on one long
  // request — per "do not make the browser wait indefinitely".
  useEffect(() => {
    if (!jobId) return
    if (job && (job.status === 'REVIEW' || job.status === 'FAILED')) return
    let cancelled = false
    const timer = setInterval(async () => {
      try {
        const res = await apiFetch<JobStatusResponse>(`/api/questions/bulk-import/handwritten/${jobId}`)
        if (cancelled) return
        setJob(res)
        if (res.status === 'REVIEW' && res.result) {
          setRows(
            res.result.questions.map((q) => ({
              ...q,
              include: true,
              subjectId: null,
              examClassId: null,
              chapterId: null,
              topicId: null,
              codeId: null,
              difficultyId: null,
              markingScheme: '',
              expanded: q.needsReview,
            }))
          )
          const ds: Record<string, DiagramState> = {}
          for (const d of res.result.diagrams) {
            ds[d.key] = { choice: 'generated', editedSvg: d.generatedSvg, editing: false, regenerating: false }
          }
          setDiagramState(ds)
        }
      } catch (err) {
        if (!cancelled) show('error', errorMessage(err))
      }
    }, POLL_INTERVAL_MS)
    return () => {
      cancelled = true
      clearInterval(timer)
    }
  }, [jobId, job, show])

  async function handleFile(file: File) {
    setUploading(true)
    setJob(null)
    setJobId(null)
    setRows([])
    setDiagramState({})
    setImported(false)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await apiFetch<{ jobId: string }>('/api/questions/bulk-import/handwritten/upload', {
        method: 'POST',
        body: formData,
      })
      setJobId(res.jobId)
      setJob({ jobId: res.jobId, status: 'PENDING', stage: 'Uploading…', totalPages: null, errorMessage: null, result: null, confirmedAt: null, confirmedQuestionCount: null })
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setUploading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  function updateRow(tempId: string, patch: Partial<EditableRow>) {
    setRows((prev) => prev.map((r) => (r.tempId === tempId ? { ...r, ...patch } : r)))
  }

  function setSubject(tempId: string, v: string | null) {
    updateRow(tempId, { subjectId: v, chapterId: null, topicId: null })
  }
  function setChapter(tempId: string, v: string | null) {
    updateRow(tempId, { chapterId: v, topicId: null })
  }

  async function regenerateDiagram(key: string) {
    if (!jobId) return
    setDiagramState((prev) => ({ ...prev, [key]: { ...prev[key], regenerating: true } }))
    try {
      const res = await apiFetch<{ diagram: ReviewDiagram }>(
        `/api/questions/bulk-import/handwritten/${jobId}/diagram/${key}/regenerate`,
        { method: 'POST', body: JSON.stringify({}) }
      )
      setJob((prev) =>
        prev && prev.result
          ? { ...prev, result: { ...prev.result, diagrams: prev.result.diagrams.map((d) => (d.key === key ? res.diagram : d)) } }
          : prev
      )
      setDiagramState((prev) => ({
        ...prev,
        [key]: { choice: 'generated', editedSvg: res.diagram.generatedSvg, editing: false, regenerating: false },
      }))
      show('success', 'Diagram regenerated from the original image.')
    } catch (err) {
      show('error', errorMessage(err))
      setDiagramState((prev) => ({ ...prev, [key]: { ...prev[key], regenerating: false } }))
    }
  }

  const readyRows = rows.filter(
    (r) =>
      r.include &&
      r.subjectId &&
      r.examClassId &&
      r.codeId &&
      r.difficultyId &&
      r.questionNumber?.trim() &&
      r.questionText.trim()
  )

  async function handleImport() {
    if (!jobId) return
    if (readyRows.length === 0) {
      show('error', 'Select at least one fully-tagged row (Subject, Class, Code, Difficulty, and Question No. are all required).')
      return
    }
    setImporting(true)
    try {
      const payload = readyRows.map((r) => ({
        tempId: r.tempId,
        questionNumber: r.questionNumber!.trim(),
        subjectId: r.subjectId!,
        examClassId: r.examClassId!,
        chapterId: r.chapterId,
        topicId: r.topicId,
        codeId: r.codeId!,
        difficultyId: r.difficultyId!,
        questionType: r.questionType,
        questionText: r.questionText,
        optionA: r.optionA,
        optionB: r.optionB,
        optionC: r.optionC,
        optionD: r.optionD,
        correctAnswer: r.correctAnswer,
        explanation: r.explanation,
        markingScheme: r.markingScheme || null,
        diagramSelections: r.diagramKeys.map((k) => {
          const ds = diagramState[k]
          const original = diagramsByKey.get(k)?.generatedSvg
          return {
            key: k,
            choice: ds?.choice ?? 'generated',
            editedSvg: ds && ds.choice === 'generated' && ds.editedSvg !== original ? ds.editedSvg : undefined,
          }
        }),
      }))
      const result = await apiFetch<{ importedCount: number }>(
        `/api/questions/bulk-import/handwritten/${jobId}/confirm`,
        { method: 'POST', body: JSON.stringify({ rows: payload }) }
      )
      show('success', `Imported ${result.importedCount} question(s) from the handwritten PDF.`)
      setImported(true)
      router.push('/questions')
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setImporting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">1. Upload a handwritten PDF, PNG, or JPG</h2>
        <p className="mb-3 text-sm text-ink-muted">
          Photos or scans of handwritten question papers. Every question and diagram is transcribed into clean,
          professional digital content — never solved, rewritten, or invented — and every result carries a confidence
          level so anything uncertain is flagged for your review before it reaches the Question Bank.
        </p>
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf,.pdf,image/png,.png,image/jpeg,.jpg,.jpeg"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          className="block text-sm"
          disabled={uploading || (job !== null && job.status !== 'FAILED' && job.status !== 'REVIEW')}
        />
        {uploading && <p className="mt-2 text-sm text-ink-muted">Uploading…</p>}
      </div>

      {job && (job.status === 'PENDING' || job.status === 'PROCESSING') && (
        <div className="card p-5">
          <p className="text-sm font-medium text-ink">{job.stage ?? 'Processing…'}</p>
          {job.totalPages != null && <p className="mt-1 text-xs text-ink-muted">{job.totalPages} page(s) detected.</p>}
          <p className="mt-2 text-xs text-ink-faint">
            This can take a little while for longer papers — you can leave this tab open, progress updates automatically.
          </p>
        </div>
      )}

      {job && job.status === 'FAILED' && (
        <div className="card border-danger/40 p-5">
          <p className="text-sm font-medium text-danger">Processing failed</p>
          <p className="mt-1 text-sm text-ink-muted">{job.errorMessage}</p>
          <p className="mt-2 text-xs text-ink-faint">The original file was not lost — try uploading again, or a smaller/clearer file.</p>
        </div>
      )}

      {job && job.status === 'REVIEW' && job.result && !imported && (
        <div className="card p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold text-ink">2. Review &amp; tag every question</h2>
            <div className="flex gap-3 text-xs text-ink-muted">
              <span>{job.totalPages ?? '—'} pages</span>
              <span>{job.result.questions.length} question(s) detected</span>
              {job.result.questions.some((q) => q.needsReview) && (
                <span className="text-warning">
                  {job.result.questions.filter((q) => q.needsReview).length} need a closer look
                </span>
              )}
            </div>
          </div>

          {job.confirmedAt && (
            <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-800">
              Already imported {job.confirmedQuestionCount} question(s) from this file. Uploading again will re-run
              extraction as a separate import.
            </div>
          )}

          <div className="max-h-[640px] space-y-3 overflow-y-auto">
            {rows.map((row) => (
              <QuestionRow
                key={row.tempId}
                row={row}
                lookups={lookups}
                extraChapters={extraChapters}
                extraTopics={extraTopics}
                diagrams={row.diagramKeys.map((k) => diagramsByKey.get(k)).filter((d): d is ReviewDiagram => !!d)}
                diagramState={diagramState}
                onUpdate={(patch) => updateRow(row.tempId, patch)}
                onSetSubject={(v) => setSubject(row.tempId, v)}
                onSetChapter={(v) => setChapter(row.tempId, v)}
                createChapter={createChapter}
                createTopic={createTopic}
                onDiagramChoice={(key, choice) => setDiagramState((prev) => ({ ...prev, [key]: { ...prev[key], choice } }))}
                onDiagramEditToggle={(key) => setDiagramState((prev) => ({ ...prev, [key]: { ...prev[key], editing: !prev[key].editing } }))}
                onDiagramSvgEdit={(key, svg) => setDiagramState((prev) => ({ ...prev, [key]: { ...prev[key], editedSvg: svg } }))}
                regenerateDiagram={regenerateDiagram}
              />
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between border-t border-surface-border pt-4">
            <span className="text-sm text-ink-muted">
              {rows.filter((r) => r.include).length} selected · {readyRows.length} fully tagged and ready
            </span>
            <button className="btn-primary" onClick={handleImport} disabled={importing || readyRows.length === 0}>
              {importing ? 'Importing…' : `Import ${readyRows.length} question(s)`}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

function ConfidenceBadge({ confidence, needsReview }: { confidence: Confidence; needsReview: boolean }) {
  if (needsReview) {
    return <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-medium text-amber-800">⚠ Needs review</span>
  }
  const styles: Record<Confidence, string> = {
    HIGH: 'bg-emerald-100 text-emerald-800',
    MEDIUM: 'bg-amber-100 text-amber-800',
    LOW: 'bg-rose-100 text-rose-800',
  }
  const label: Record<Confidence, string> = { HIGH: 'High confidence', MEDIUM: 'Medium confidence', LOW: 'Low confidence' }
  return <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${styles[confidence]}`}>{label[confidence]}</span>
}

function QuestionRow({
  row,
  lookups,
  extraChapters,
  extraTopics,
  diagrams,
  diagramState,
  onUpdate,
  onSetSubject,
  onSetChapter,
  createChapter,
  createTopic,
  onDiagramChoice,
  onDiagramEditToggle,
  onDiagramSvgEdit,
  regenerateDiagram,
}: {
  row: EditableRow
  lookups: ReturnType<typeof useLookups>['lookups']
  extraChapters: ChapterOption[]
  extraTopics: TopicOption[]
  diagrams: ReviewDiagram[]
  diagramState: Record<string, DiagramState>
  onUpdate: (patch: Partial<EditableRow>) => void
  onSetSubject: (v: string | null) => void
  onSetChapter: (v: string | null) => void
  createChapter: (subjectId: string, label: string) => Promise<{ id: string; label: string } | null>
  createTopic: (chapterId: string, label: string) => Promise<{ id: string; label: string } | null>
  onDiagramChoice: (key: string, choice: DiagramChoice) => void
  onDiagramEditToggle: (key: string) => void
  onDiagramSvgEdit: (key: string, svg: string) => void
  regenerateDiagram: (key: string) => void
}) {
  const chapterOptions = useMemo(
    () =>
      row.subjectId
        ? [...lookups.chapters, ...extraChapters].filter((c) => c.subjectId === row.subjectId)
        : [],
    [lookups.chapters, extraChapters, row.subjectId]
  )
  const topicOptions = useMemo(
    () =>
      row.chapterId ? [...lookups.topics, ...extraTopics].filter((t) => t.chapterId === row.chapterId) : [],
    [lookups.topics, extraTopics, row.chapterId]
  )

  return (
    <div className={`rounded-md border p-3 text-sm ${row.needsReview ? 'border-amber-300 bg-amber-50' : 'border-surface-border'}`}>
      <div className="flex items-start justify-between gap-2">
        <label className="flex flex-1 items-start gap-2">
          <input type="checkbox" className="mt-1" checked={row.include} onChange={(e) => onUpdate({ include: e.target.checked })} />
          <span className="flex-1">
            <span className="mb-1 flex flex-wrap items-center gap-2">
              <span className="text-xs text-ink-faint">Page {row.pageNumber}</span>
              <ConfidenceBadge confidence={row.confidence} needsReview={row.needsReview} />
            </span>
            <MathText text={row.questionText || '(No text detected — edit manually below)'} />
          </span>
        </label>
        <button className="btn-ghost !px-2 !py-1 text-xs" onClick={() => onUpdate({ expanded: !row.expanded })}>
          {row.expanded ? 'Collapse' : 'Edit & Tag'}
        </button>
      </div>

      {row.needsReview && row.reviewReason && (
        <p className="mt-1 ml-6 text-xs text-warning">⚠ {row.reviewReason}</p>
      )}

      {diagrams.length > 0 && (
        <div className="mt-3 ml-6 space-y-3">
          {diagrams.map((d) => {
            const ds = diagramState[d.key]
            if (!ds) return null
            return (
              <div key={d.key} className="rounded-md border border-surface-border p-2">
                <div className="mb-1 flex flex-wrap items-center gap-2">
                  <span className="text-xs font-medium text-ink">Diagram ({d.diagramType})</span>
                  <ConfidenceBadge confidence={d.confidence} needsReview={d.needsReview} />
                  {d.needsReview && d.reviewReason && <span className="text-xs text-warning">⚠ {d.reviewReason}</span>}
                </div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <div>
                    <p className="mb-1 text-[11px] font-medium text-ink-faint">Generated (professional)</p>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <div
                      className={`rounded border p-1 ${ds.choice === 'generated' ? 'border-brand-400' : 'border-surface-border opacity-60'}`}
                      dangerouslySetInnerHTML={{ __html: ds.editedSvg }}
                    />
                  </div>
                  <div>
                    <p className="mb-1 text-[11px] font-medium text-ink-faint">Original (as handwritten)</p>
                    {d.originalImageUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={d.originalImageUrl}
                        alt="Original handwritten diagram"
                        className={`h-40 w-full rounded border object-contain ${ds.choice === 'original' ? 'border-brand-400' : 'border-surface-border opacity-60'}`}
                      />
                    ) : (
                      <p className="text-xs text-ink-faint">No original image region could be extracted.</p>
                    )}
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-2 text-xs">
                  <button
                    type="button"
                    className={`btn-ghost !px-2 !py-1 ${ds.choice === 'generated' ? 'font-semibold text-brand-700' : ''}`}
                    onClick={() => onDiagramChoice(d.key, 'generated')}
                  >
                    Accept generated
                  </button>
                  <button
                    type="button"
                    className={`btn-ghost !px-2 !py-1 ${ds.choice === 'original' ? 'font-semibold text-brand-700' : ''}`}
                    disabled={!d.originalImageUrl}
                    onClick={() => onDiagramChoice(d.key, 'original')}
                  >
                    Use original
                  </button>
                  <button type="button" className="btn-ghost !px-2 !py-1" onClick={() => onDiagramEditToggle(d.key)}>
                    {ds.editing ? 'Done editing' : 'Edit'}
                  </button>
                  <button
                    type="button"
                    className="btn-ghost !px-2 !py-1"
                    disabled={ds.regenerating || !d.originalImageUrl}
                    onClick={() => regenerateDiagram(d.key)}
                    title={!d.originalImageUrl ? 'No original image region to regenerate from' : undefined}
                  >
                    {ds.regenerating ? 'Regenerating…' : 'Regenerate'}
                  </button>
                </div>
                {ds.editing && (
                  <textarea
                    className="input mt-2 min-h-[100px] font-mono text-xs"
                    value={ds.editedSvg}
                    onChange={(e) => onDiagramSvgEdit(d.key, e.target.value)}
                  />
                )}
              </div>
            )
          })}
        </div>
      )}

      {row.expanded && (
        <div className="mt-3 ml-6 space-y-3">
          <div>
            <label className="label">Question Type</label>
            <div className="flex gap-4">
              {(['MCQ', 'SUBJECTIVE', 'INTEGER'] as QuestionType[]).map((t) => (
                <label key={t} className="flex items-center gap-1.5 text-sm">
                  <input type="radio" name={`qtype-${row.tempId}`} checked={row.questionType === t} onChange={() => onUpdate({ questionType: t })} />
                  {t === 'MCQ' ? 'MCQ' : t === 'SUBJECTIVE' ? 'Subjective' : 'Integer'}
                </label>
              ))}
            </div>
          </div>

          <textarea className="input min-h-[80px]" value={row.questionText} onChange={(e) => onUpdate({ questionText: e.target.value })} />

          {row.questionType === 'MCQ' && (
            <>
              <div className="grid grid-cols-2 gap-2">
                {(['optionA', 'optionB', 'optionC', 'optionD'] as const).map((key, idx) => (
                  <input
                    key={key}
                    className="input"
                    placeholder={`Option ${['A', 'B', 'C', 'D'][idx]}`}
                    value={row[key] ?? ''}
                    onChange={(e) => onUpdate({ [key]: e.target.value } as Partial<EditableRow>)}
                  />
                ))}
              </div>
              <input
                className="input"
                placeholder="Correct Answer (e.g. A)"
                value={row.correctAnswer ?? ''}
                onChange={(e) => onUpdate({ correctAnswer: e.target.value })}
              />
              <textarea
                className="input min-h-[60px]"
                placeholder="Explanation"
                value={row.explanation ?? ''}
                onChange={(e) => onUpdate({ explanation: e.target.value })}
              />
            </>
          )}

          {row.questionType === 'INTEGER' && (
            <>
              <input
                className="input"
                placeholder="Integer Answer (e.g. 0, 5, 12, -4 — no decimals)"
                value={row.correctAnswer ?? ''}
                onChange={(e) => onUpdate({ correctAnswer: e.target.value })}
              />
              {row.correctAnswer?.trim() && !/^-?\d+$/.test(row.correctAnswer.trim()) && (
                <p className="text-xs text-danger">Must be a whole number — decimals are not allowed.</p>
              )}
              <textarea
                className="input min-h-[60px]"
                placeholder="Explanation"
                value={row.explanation ?? ''}
                onChange={(e) => onUpdate({ explanation: e.target.value })}
              />
            </>
          )}

          {row.questionType === 'SUBJECTIVE' && (
            <>
              <div>
                <label className="label">Expected Answer</label>
                <p className="mb-1 text-xs text-ink-faint">Internal only — never shown on the student paper.</p>
                <textarea className="input min-h-[60px]" value={row.correctAnswer ?? ''} onChange={(e) => onUpdate({ correctAnswer: e.target.value })} />
              </div>
              <div>
                <label className="label">Marking Scheme</label>
                <p className="mb-1 text-xs text-ink-faint">Internal only — never shown on the student paper.</p>
                <textarea className="input min-h-[60px]" value={row.markingScheme} onChange={(e) => onUpdate({ markingScheme: e.target.value })} />
              </div>
            </>
          )}

          <hr className="border-surface-border" />

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <div>
              <label className="label">2. Subject</label>
              <SearchableSelect options={lookups.subjects} value={row.subjectId} onChange={onSetSubject} required />
            </div>
            <div>
              <label className="label">3. Class / Exam</label>
              <SearchableSelect options={lookups.examClasses} value={row.examClassId} onChange={(v) => onUpdate({ examClassId: v })} required />
            </div>
            <div>
              <label className="label">4. Chapter Name</label>
              <CreatableSelect
                options={chapterOptions}
                value={row.chapterId}
                disabled={!row.subjectId}
                placeholder={row.subjectId ? 'Type a chapter name…' : 'Select a Subject first'}
                onSelectExisting={onSetChapter}
                onClear={() => onSetChapter(null)}
                onCreateNew={(label) => createChapter(row.subjectId!, label)}
              />
            </div>
            <div>
              <label className="label">5. Topic Name</label>
              <CreatableSelect
                options={topicOptions}
                value={row.topicId}
                disabled={!row.chapterId}
                placeholder={row.chapterId ? 'Type a topic name…' : 'Select a Chapter first'}
                onSelectExisting={(v) => onUpdate({ topicId: v })}
                onClear={() => onUpdate({ topicId: null })}
                onCreateNew={(label) => createTopic(row.chapterId!, label)}
              />
            </div>
            <div>
              <label className="label">6. Code</label>
              <SearchableSelect options={lookups.codes} value={row.codeId} onChange={(v) => onUpdate({ codeId: v })} required />
            </div>
            <div>
              <label className="label">7. Difficulty</label>
              <SearchableSelect options={lookups.difficultyLevels} value={row.difficultyId} onChange={(v) => onUpdate({ difficultyId: v })} required />
            </div>
            <div>
              <label className="label">8. Question No</label>
              <input className="input" value={row.questionNumber ?? ''} onChange={(e) => onUpdate({ questionNumber: e.target.value })} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
