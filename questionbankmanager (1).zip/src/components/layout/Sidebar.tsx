'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import type { RoleCode } from '@prisma/client'

type NavItem = { label: string; href: string; roles?: RoleCode[] }
type NavGroup = { label: string; items: NavItem[] }

const NAV: NavGroup[] = [
  { label: '', items: [{ label: 'Dashboard', href: '/dashboard' }] },
  {
    label: 'Question Bank',
    items: [
      { label: 'All Questions', href: '/questions' },
      { label: 'Add Question', href: '/questions/new', roles: ['ADMIN', 'EDITOR'] },
      { label: 'Bulk Upload', href: '/questions/bulk-upload', roles: ['ADMIN', 'EDITOR'] },
      { label: 'Archived', href: '/questions/archived' },
    ],
  },
  {
    label: 'Paper Generator',
    items: [
      { label: 'Create Paper', href: '/papers/new' },
      { label: 'Saved Papers', href: '/papers' },
      { label: 'Templates', href: '/papers/templates', roles: ['ADMIN'] },
    ],
  },
  { label: '', items: [{ label: 'Reports', href: '/reports' }] },
  { label: '', items: [{ label: 'Users', href: '/users', roles: ['ADMIN'] }] },
  { label: '', items: [{ label: 'Audit Logs', href: '/audit-logs', roles: ['ADMIN'] }] },
  { label: '', items: [{ label: 'Settings', href: '/settings', roles: ['ADMIN'] }] },
]

export function Sidebar({ role }: { role: RoleCode }) {
  const pathname = usePathname()

  return (
    <aside className="hidden w-60 shrink-0 border-r border-surface-border bg-white md:flex md:flex-col">
      <div className="flex h-14 items-center gap-2 border-b border-surface-border px-4">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/branding/cubus-logo.png" alt="CUBUS" className="h-8 w-auto" />
        <span className="text-sm font-semibold text-ink">Question Bank</span>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {NAV.map((group, gi) => {
          const items = group.items.filter((item) => !item.roles || item.roles.includes(role))
          if (items.length === 0) return null
          return (
            <div key={gi} className="mb-4">
              {group.label && (
                <div className="mb-1 px-2 text-[11px] font-semibold uppercase tracking-wide text-ink-faint">
                  {group.label}
                </div>
              )}
              <ul className="space-y-0.5">
                {items.map((item) => {
                  const active = pathname === item.href || pathname.startsWith(item.href + '/')
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        className={`block rounded-md px-2.5 py-1.5 text-sm ${
                          active
                            ? 'bg-brand-50 font-medium text-brand-700'
                            : 'text-ink-muted hover:bg-surface-muted hover:text-ink'
                        }`}
                      >
                        {item.label}
                      </Link>
                    </li>
                  )
                })}
              </ul>
            </div>
          )
        })}
      </nav>
    </aside>
  )
}
