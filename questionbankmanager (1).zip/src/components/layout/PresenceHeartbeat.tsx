'use client'

import { useEffect } from 'react'

// Pings /api/presence on mount and every 60s so the Dashboard's "active
// users" count reflects who actually has the app open right now.
export function PresenceHeartbeat() {
  useEffect(() => {
    const ping = () => {
      fetch('/api/presence', { method: 'POST' }).catch(() => {
        // Best-effort only — a missed heartbeat just makes the active-user
        // count slightly stale, never breaks the app.
      })
    }
    ping()
    const interval = setInterval(ping, 60_000)
    return () => clearInterval(interval)
  }, [])

  return null
}
