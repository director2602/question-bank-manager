'use client'

import { useState } from 'react'
import { RoleBadge } from '@/components/ui/Badge'
import type { SessionUser } from '@/types'

export function Topbar({ user }: { user: SessionUser }) {
  const [signingOut, setSigningOut] = useState(false)

  return (
    <header className="flex h-14 items-center justify-between border-b border-surface-border bg-white px-5">
      <div />
      <div className="flex items-center gap-3">
        <div className="text-right">
          <div className="text-sm font-medium text-ink">{user.fullName || user.email}</div>
          <div className="text-xs text-ink-faint">{user.email}</div>
        </div>
        <RoleBadge role={user.role} />
        <form
          action="/api/auth/signout"
          method="post"
          onSubmit={() => setSigningOut(true)}
        >
          <button type="submit" className="btn-ghost" disabled={signingOut}>
            {signingOut ? 'Signing out…' : 'Sign out'}
          </button>
        </form>
      </div>
    </header>
  )
}
