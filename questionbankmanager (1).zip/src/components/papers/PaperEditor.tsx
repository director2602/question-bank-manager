'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { MathText } from '@/components/questions/MathRenderer'
import { AddQuestionModal } from './AddQuestionModal'
import { DownloadMenu } from './DownloadMenu'
import { PaperSettingsPanel } from './PaperSettingsPanel'
import type { RoleCode } from '@prisma/client'

type SnapshotQuestion = {
  questionId: string
  questionVersionId: string
  position: number
  questionNumber: string
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  subject: string
  examClass: string
  code: string
  difficulty: string
  marks: number | null
  images: { url: string; altText: string | null }[]
}

type PaperDetail = {
  id: string
  paperNumber: number
  title: string
  mode: 'RANDOM' | 'MANUAL' | 'HYBRID'
  status: 'DRAFT' | 'FINAL'
  rowVersion: number
  instituteName: string | null
  logoUrl: string | null
  examName: string | null
  subjectLabel: string | null
  classLabel: string | null
  examDate: string | null
  examTime: string | null
  maxMarks: number | null
  instructions: string | null
  headerText: string | null
  footerText: string | null
}

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error'

export function PaperEditor({
  initialPaper,
  initialQuestions,
  role,
}: {
  initialPaper: PaperDetail
  initialQuestions: SnapshotQuestion[]
  role: RoleCode
}) {
  const router = useRouter()
  const { show } = useToast()
  const canEdit = role === 'ADMIN' || role === 'EDITOR'

  const [paper, setPaper] = useState(initialPaper)
  const [questions, setQuestions] = useState(initialQuestions)
  const [rowVersion, setRowVersion] = useState(initialPaper.rowVersion)
  const [saveStatus, setSaveStatus] = useState<SaveStatus>('idle')
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null)
  const [conflict, setConflict] = useState<string | null>(null)
  const [addOpen, setAddOpen] = useState(false)
  const [replacingId, setReplacingId] = useState<string | null>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const dirtyRef = useRef(false)
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const saveNow = useCallback(
    async (createSnapshot: boolean) => {
      if (!canEdit) return
      setSaveStatus('saving')
      try {
        const result = await apiFetch<{ paper: PaperDetail; questions: SnapshotQuestion[] }>(`/api/papers/${paper.id}`, {
          method: 'PATCH',
          body: JSON.stringify({
            rowVersion,
            title: paper.title,
            instituteName: paper.instituteName,
            logoUrl: paper.logoUrl,
            examName: paper.examName,
            subjectLabel: paper.subjectLabel,
            classLabel: paper.classLabel,
            examDate: paper.examDate,
            examTime: paper.examTime,
            maxMarks: paper.maxMarks,
            instructions: paper.instructions,
            headerText: paper.headerText,
            footerText: paper.footerText,
            questionIds: questions.map((q) => q.questionId),
            createSnapshot,
          }),
        })
        setPaper(result.paper)
        setRowVersion(result.paper.rowVersion)
        setQuestions(result.questions)
        setSaveStatus('saved')
        setLastSavedAt(new Date())
        dirtyRef.current = false
        if (createSnapshot) show('success', 'Snapshot saved. This version is now reproducible even if questions change later.')
      } catch (err) {
        setSaveStatus('error')
        if (err instanceof ApiError && err.status === 409) {
          setConflict(err.body.error)
        } else {
          show('error', errorMessage(err))
        }
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [paper, questions, rowVersion, canEdit]
  )

  // Always call the LATEST saveNow even from a stale setTimeout closure —
  // saveNow is recreated every render (it closes over `questions`/`paper`),
  // so a timeout scheduled just before a state update must not fire the
  // version of saveNow captured before that update.
  const saveNowRef = useRef(saveNow)
  useEffect(() => {
    saveNowRef.current = saveNow
  }, [saveNow])

  // Debounced auto-save whenever question order/settings change.
  useEffect(() => {
    if (!dirtyRef.current) return
    if (saveTimer.current) clearTimeout(saveTimer.current)
    saveTimer.current = setTimeout(() => saveNowRef.current(false), 1500)
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [questions, paper.title, paper.instructions, paper.examName, paper.maxMarks])

  function markDirty() {
    dirtyRef.current = true
  }

  function moveQuestion(index: number, direction: -1 | 1) {
    const target = index + direction
    if (target < 0 || target >= questions.length) return
    const next = [...questions]
    ;[next[index], next[target]] = [next[target], next[index]]
    setQuestions(next.map((q, idx) => ({ ...q, position: idx + 1 })))
    markDirty()
  }

  function removeQuestion(questionId: string) {
    setQuestions((prev) => prev.filter((q) => q.questionId !== questionId).map((q, idx) => ({ ...q, position: idx + 1 })))
    markDirty()
  }

  function addQuestions(newOnes: { id: string }[]) {
    // We only have IDs from the picker; refetch full paper to get rendered
    // content for the new questions rather than duplicating snapshot logic
    // client-side.
    const existingIds = new Set(questions.map((q) => q.questionId))
    const toAdd = newOnes.filter((n) => !existingIds.has(n.id))
    if (toAdd.length === 0) return
    setQuestions((prev) => [
      ...prev,
      ...toAdd.map((n, idx) => ({
        questionId: n.id,
        questionVersionId: '',
        position: prev.length + idx + 1,
        questionNumber: '…',
        questionText: 'Loading…',
        optionA: null,
        optionB: null,
        optionC: null,
        optionD: null,
        correctAnswer: null,
        explanation: null,
        subject: '',
        examClass: '',
        code: '',
        difficulty: '',
        marks: null,
        images: [],
      })),
    ])
    markDirty()
    setAddOpen(false)
    // Save immediately (not debounced) so we get full rendered content back.
    setTimeout(() => saveNowRef.current(false), 50)
  }

  async function reload() {
    const result = await apiFetch<{ paper: PaperDetail; questions: SnapshotQuestion[] }>(`/api/papers/${paper.id}`)
    setPaper(result.paper)
    setQuestions(result.questions)
    setRowVersion(result.paper.rowVersion)
    setConflict(null)
  }

  async function handleDuplicate() {
    try {
      const result = await apiFetch<{ item: { id: string } }>(`/api/papers/${paper.id}/duplicate`, { method: 'POST' })
      show('success', 'Paper duplicated.')
      router.push(`/papers/${result.item.id}`)
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-ink">
            #{paper.paperNumber} {paper.title}
          </h1>
          <p className="text-sm text-ink-muted">
            {questions.length} question(s) ·{' '}
            {paper.mode === 'RANDOM' ? 'Randomly generated' : paper.mode === 'HYBRID' ? 'Built with the Advanced Paper Builder' : 'Manually built'}{' '}
            ·{' '}
            <SaveStatusLabel status={saveStatus} lastSavedAt={lastSavedAt} />
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <a href={`/papers/${paper.id}/print?mode=question`} target="_blank" rel="noreferrer" className="btn-secondary">
            Print / Question Paper
          </a>
          <a href={`/papers/${paper.id}/print?mode=answerKey`} target="_blank" rel="noreferrer" className="btn-secondary">
            Answer Key
          </a>
          <a href={`/papers/${paper.id}/print?mode=solutions`} target="_blank" rel="noreferrer" className="btn-secondary">
            Solutions
          </a>
          {canEdit && (
            <button className="btn-secondary" onClick={() => setSettingsOpen(true)}>
              Paper Settings
            </button>
          )}
          <button className="btn-secondary" onClick={() => router.push(`/papers/${paper.id}/cover`)}>
            Design Cover Page
          </button>
          {canEdit && (
            <button className="btn-secondary" onClick={handleDuplicate}>
              Duplicate Paper
            </button>
          )}
          {canEdit && (
            <button className="btn-primary" onClick={() => saveNow(true)}>
              Save Snapshot
            </button>
          )}
        </div>
      </div>

      <div className="card p-4">
        <DownloadMenu paperId={paper.id} />
      </div>

      {conflict && (
        <div className="rounded-md border border-red-300 bg-red-50 px-4 py-3 text-sm text-danger">
          {conflict}{' '}
          <button className="ml-2 font-medium underline" onClick={reload}>
            Reload latest version
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="card space-y-3 p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Questions ({questions.length})</h2>
            {canEdit && (
              <button className="btn-secondary !py-1" onClick={() => setAddOpen(true)}>
                + Add question
              </button>
            )}
          </div>
          <div className="space-y-2">
            {questions.map((q, idx) => (
              <div key={q.questionId} className="rounded-md border border-surface-border p-3 text-sm">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-medium">Q{q.position}.</span> <MathText text={q.questionText} />
                    <div className="mt-1 flex flex-wrap gap-1 text-xs text-ink-faint">
                      <span>{q.subject}</span>·<span>{q.examClass}</span>·<span>{q.code}</span>·<span>{q.difficulty}</span>
                    </div>
                  </div>
                  {canEdit && (
                    <div className="flex shrink-0 gap-1">
                      <button className="btn-ghost !px-1.5 !py-1" disabled={idx === 0} onClick={() => moveQuestion(idx, -1)} aria-label="Move up">
                        ↑
                      </button>
                      <button
                        className="btn-ghost !px-1.5 !py-1"
                        disabled={idx === questions.length - 1}
                        onClick={() => moveQuestion(idx, 1)}
                        aria-label="Move down"
                      >
                        ↓
                      </button>
                      <button className="btn-ghost !px-1.5 !py-1" onClick={() => setReplacingId(q.questionId)}>
                        Replace
                      </button>
                      <button className="btn-ghost !px-1.5 !py-1 text-danger" onClick={() => removeQuestion(q.questionId)}>
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {questions.length === 0 && <p className="py-6 text-center text-sm text-ink-faint">No questions in this paper yet.</p>}
          </div>
        </div>

        <div className="card space-y-3 p-5">
          <h2 className="text-sm font-semibold text-ink">Paper settings</h2>
          <Field label="Title" value={paper.title} onChange={(v) => (setPaper((p) => ({ ...p, title: v })), markDirty())} />
          <Field
            label="Institute Name"
            value={paper.instituteName ?? ''}
            onChange={(v) => (setPaper((p) => ({ ...p, instituteName: v })), markDirty())}
          />
          <Field label="Exam Name" value={paper.examName ?? ''} onChange={(v) => (setPaper((p) => ({ ...p, examName: v })), markDirty())} />
          <Field
            label="Maximum Marks"
            type="number"
            value={paper.maxMarks?.toString() ?? ''}
            onChange={(v) => (setPaper((p) => ({ ...p, maxMarks: v ? Number(v) : null })), markDirty())}
          />
          <Field label="Time" value={paper.examTime ?? ''} onChange={(v) => (setPaper((p) => ({ ...p, examTime: v })), markDirty())} />
          <div>
            <label className="label">Instructions</label>
            <textarea
              className="input min-h-[70px]"
              value={paper.instructions ?? ''}
              onChange={(e) => (setPaper((p) => ({ ...p, instructions: e.target.value })), markDirty())}
            />
          </div>
        </div>
      </div>

      <PaperSettingsPanel paperId={paper.id} open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <AddQuestionModal open={addOpen} onClose={() => setAddOpen(false)} onAdd={addQuestions} excludeIds={questions.map((q) => q.questionId)} />
      <AddQuestionModal
        open={!!replacingId}
        onClose={() => setReplacingId(null)}
        single
        onAdd={(picked) => {
          if (picked[0] && replacingId) {
            setQuestions((prev) =>
              prev.map((q) => (q.questionId === replacingId ? { ...q, questionId: picked[0].id, questionText: 'Loading…' } : q))
            )
            markDirty()
            setTimeout(() => saveNowRef.current(false), 50)
          }
          setReplacingId(null)
        }}
        excludeIds={questions.map((q) => q.questionId)}
      />
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <input className="input" type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  )
}

function SaveStatusLabel({ status, lastSavedAt }: { status: SaveStatus; lastSavedAt: Date | null }) {
  if (status === 'saving') return <span className="text-ink-faint">Saving…</span>
  if (status === 'error') return <span className="text-danger">Save failed — changes may not be persisted</span>
  if (lastSavedAt) return <span className="text-ink-faint">Last saved: {lastSavedAt.toLocaleTimeString()}</span>
  return <span className="text-ink-faint">Saved</span>
}
