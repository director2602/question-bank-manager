'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { FolderSidebar, type FolderSelection } from './FolderSidebar'
import { PaperListClient } from './PaperListClient'
import type { PaperFolderItem } from '@/types'

/**
 * Composes the folder tree with the paper list: selecting a folder on the
 * left filters the table on the right, and the table's per-row "Move to…"
 * control can reassign a paper without leaving the page.
 */
export function PaperFoldersView({ canManage }: { canManage: boolean }) {
  const [selection, setSelection] = useState<FolderSelection>({ kind: 'all' })
  const [refreshToken, setRefreshToken] = useState(0)
  const [folders, setFolders] = useState<PaperFolderItem[]>([])

  useEffect(() => {
    apiFetch<{ items: PaperFolderItem[] }>('/api/folders')
      .then((res) => setFolders(res.items))
      .catch(() => {
        // Non-fatal here — the sidebar itself surfaces the error toast.
      })
  }, [refreshToken])

  return (
    <div className="flex flex-col gap-4 lg:flex-row">
      <FolderSidebar
        selection={selection}
        onSelect={setSelection}
        refreshToken={refreshToken}
        canManage={canManage}
      />
      <div className="min-w-0 flex-1">
        <PaperListClient
          folderFilter={selection}
          folders={folders}
          canMove={canManage}
          onPaperMoved={() => setRefreshToken((t) => t + 1)}
        />
      </div>
    </div>
  )
}
