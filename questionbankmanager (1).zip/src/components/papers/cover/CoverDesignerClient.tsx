'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { Modal } from '@/components/ui/Modal'
import {
  emptyCoverDesign,
  COVER_ELEMENT_TYPES,
  COVER_FONT_FAMILIES,
  COVER_FONT_SIZES,
  COVER_PLACEHOLDER_KEYS,
  type CoverDesign,
  type CoverElement,
} from '@/lib/validation/coverDesign'

// Matches paperHtml.ts's own PAGE_SIZE_MM exactly — duplicated locally
// (rather than importing that server-rendering module into the client
// bundle) same reasoning paperPdf.ts already uses for its own duplicated
// FOOTER_BAND_HEIGHT_MM constant.
const PAGE_SIZE_MM: Record<CoverDesign['pageSize'], { widthMm: number; heightMm: number }> = {
  A4: { widthMm: 210, heightMm: 297 },
  LETTER: { widthMm: 215.9, heightMm: 279.4 },
  LEGAL: { widthMm: 215.9, heightMm: 355.6 },
}

const PX_PER_MM = 3 // base canvas scale before the user's own zoom multiplier

const ELEMENT_TYPE_LABELS: Record<(typeof COVER_ELEMENT_TYPES)[number], string> = {
  text: 'Text',
  heading: 'Heading',
  subheading: 'Subheading',
  logo: 'Logo',
  image: 'Image',
  line: 'Line',
  rectangle: 'Rectangle',
  divider: 'Divider',
  instructions: 'Instructions',
  table: 'Table',
  customField: 'Custom Field',
}

const TEXT_LIKE_TYPES = new Set(['text', 'heading', 'subheading', 'instructions', 'customField', 'table'])
const IMAGE_LIKE_TYPES = new Set(['logo', 'image'])
const SHAPE_LIKE_TYPES = new Set(['line', 'rectangle', 'divider'])

function newId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `el-${Date.now()}-${Math.random().toString(16).slice(2)}`
}

function nextZIndex(elements: CoverElement[]): number {
  return elements.reduce((max, el) => Math.max(max, el.zIndex), 0) + 1
}

function defaultTextForType(type: (typeof COVER_ELEMENT_TYPES)[number]): string {
  switch (type) {
    case 'heading':
      return 'Heading'
    case 'subheading':
      return 'Subheading'
    case 'instructions':
      return 'General Instructions:\n1. All questions are compulsory.'
    case 'table':
      return 'Table'
    case 'customField':
      return ''
    default:
      return 'Text'
  }
}

function createElement(type: (typeof COVER_ELEMENT_TYPES)[number], pageWidthMm: number, zIndex: number): CoverElement {
  const base = {
    id: newId(),
    type,
    x: Math.max(10, pageWidthMm / 2 - 40),
    y: 20,
    width: 80,
    height: type === 'line' ? 1 : type === 'divider' ? 2 : 18,
    zIndex,
    locked: false,
    hidden: false,
    text: defaultTextForType(type),
    placeholderKey: null,
    customFieldKey: null,
    fontFamily: 'Calibri' as const,
    fontSizePt: type === 'heading' ? 20 : type === 'subheading' ? 14 : 12,
    fontWeight: type === 'heading' ? ('bold' as const) : ('normal' as const),
    fontStyle: 'normal' as const,
    alignment: 'left' as const,
    color: '#14161f',
    backgroundColor: null,
    borderColor: type === 'rectangle' || type === 'divider' || type === 'line' ? '#400c4d' : null,
    borderWidthPt: type === 'rectangle' ? 1 : type === 'divider' ? 1 : 0,
    imagePath: null,
    opacity: 100,
    ocrConfidence: null,
    needsReview: false,
  }
  if (type === 'logo') return { ...base, width: 30, height: 30 }
  if (type === 'image') return { ...base, width: 60, height: 40 }
  if (type === 'line') return { ...base, width: 100, height: 1 }
  if (type === 'rectangle' || type === 'divider') return { ...base, width: 100, height: 20 }
  return base
}

type AnalyzeStatus = 'idle' | 'uploading' | 'PENDING' | 'PROCESSING' | 'REVIEW' | 'FAILED'

type AnalyzeResultSummary = {
  textBlocks: unknown[]
  images: unknown[]
  shapes: unknown[]
}

export function CoverDesignerClient({
  paperId,
  paperTitle,
  canEdit,
}: {
  paperId: string
  paperTitle: string
  canEdit: boolean
}) {
  const router = useRouter()
  const { show } = useToast()

  const [loading, setLoading] = useState(true)
  const [design, setDesign] = useState<CoverDesign>(emptyCoverDesign())
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({})
  const [rowVersion, setRowVersion] = useState(0)
  const [separateFrontPage, setSeparateFrontPage] = useState(true)
  const [hasSavedDesign, setHasSavedDesign] = useState(false)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [conflict, setConflict] = useState<string | null>(null)
  const [zoom, setZoom] = useState(1)
  const [addMenuOpen, setAddMenuOpen] = useState(false)
  const [referenceModalOpen, setReferenceModalOpen] = useState(false)
  const [templatesModalOpen, setTemplatesModalOpen] = useState(false)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const result = await apiFetch<{
          coverDesign: CoverDesign
          imagePreviewUrls: Record<string, string>
          hasSavedDesign: boolean
          separateFrontPage: boolean
          rowVersion: number
        }>(`/api/papers/${paperId}/cover`)
        if (cancelled) return
        setDesign(result.coverDesign)
        setPreviewUrls(result.imagePreviewUrls)
        setHasSavedDesign(result.hasSavedDesign)
        setSeparateFrontPage(result.separateFrontPage)
        setRowVersion(result.rowVersion)
      } catch (err) {
        show('error', errorMessage(err))
      } finally {
        if (!cancelled) setLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paperId])

  const { widthMm, heightMm } = PAGE_SIZE_MM[design.pageSize]
  const scale = PX_PER_MM * zoom
  const selected = design.elements.find((el) => el.id === selectedId) ?? null

  const patchDesign = useCallback((patch: Partial<CoverDesign>) => {
    setDesign((prev) => ({ ...prev, ...patch }))
  }, [])

  const updateElement = useCallback((id: string, patch: Partial<CoverElement>) => {
    setDesign((prev) => ({
      ...prev,
      elements: prev.elements.map((el) => (el.id === id ? { ...el, ...patch } : el)),
    }))
  }, [])

  function addElement(type: (typeof COVER_ELEMENT_TYPES)[number]) {
    const el = createElement(type, widthMm, nextZIndex(design.elements))
    setDesign((prev) => ({ ...prev, elements: [...prev.elements, el] }))
    setSelectedId(el.id)
    setAddMenuOpen(false)
  }

  function duplicateElement(id: string) {
    const original = design.elements.find((el) => el.id === id)
    if (!original) return
    const copy: CoverElement = { ...original, id: newId(), x: original.x + 5, y: original.y + 5, zIndex: nextZIndex(design.elements) }
    setDesign((prev) => ({ ...prev, elements: [...prev.elements, copy] }))
    setSelectedId(copy.id)
  }

  function deleteElement(id: string) {
    setDesign((prev) => ({ ...prev, elements: prev.elements.filter((el) => el.id !== id) }))
    if (selectedId === id) setSelectedId(null)
  }

  function reorderZIndex(id: string, mode: 'front' | 'back' | 'forward' | 'backward') {
    setDesign((prev) => {
      const sorted = [...prev.elements].sort((a, b) => a.zIndex - b.zIndex)
      const idx = sorted.findIndex((el) => el.id === id)
      const current = sorted[idx]
      if (idx === -1 || !current) return prev

      if (mode === 'front') {
        sorted.splice(idx, 1)
        sorted.push(current)
      } else if (mode === 'back') {
        sorted.splice(idx, 1)
        sorted.unshift(current)
      } else if (mode === 'forward' && idx < sorted.length - 1) {
        const swapWith = sorted[idx + 1]
        if (swapWith) {
          sorted[idx] = swapWith
          sorted[idx + 1] = current
        }
      } else if (mode === 'backward' && idx > 0) {
        const swapWith = sorted[idx - 1]
        if (swapWith) {
          sorted[idx] = swapWith
          sorted[idx - 1] = current
        }
      }
      return { ...prev, elements: sorted.map((el, i) => ({ ...el, zIndex: i + 1 })) }
    })
  }

  function alignElement(id: string, mode: 'left' | 'centerH' | 'right' | 'top' | 'centerV' | 'bottom') {
    const el = design.elements.find((e) => e.id === id)
    if (!el) return
    const patch: Partial<CoverElement> = {}
    if (mode === 'left') patch.x = 0
    if (mode === 'right') patch.x = widthMm - el.width
    if (mode === 'centerH') patch.x = (widthMm - el.width) / 2
    if (mode === 'top') patch.y = 0
    if (mode === 'bottom') patch.y = heightMm - el.height
    if (mode === 'centerV') patch.y = (heightMm - el.height) / 2
    updateElement(id, patch)
  }

  async function handleSave() {
    if (!canEdit) return
    setSaving(true)
    try {
      const result = await apiFetch<{ rowVersion: number }>(`/api/papers/${paperId}/cover`, {
        method: 'PATCH',
        body: JSON.stringify({ coverDesign: design, separateFrontPage, rowVersion }),
      })
      setRowVersion(result.rowVersion)
      setHasSavedDesign(true)
      show('success', 'Cover design saved.')
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setConflict(err.body.error)
      } else {
        show('error', errorMessage(err))
      }
    } finally {
      setSaving(false)
    }
  }

  async function reload() {
    setConflict(null)
    setLoading(true)
    try {
      const result = await apiFetch<{
        coverDesign: CoverDesign
        imagePreviewUrls: Record<string, string>
        hasSavedDesign: boolean
        separateFrontPage: boolean
        rowVersion: number
      }>(`/api/papers/${paperId}/cover`)
      setDesign(result.coverDesign)
      setPreviewUrls(result.imagePreviewUrls)
      setHasSavedDesign(result.hasSavedDesign)
      setSeparateFrontPage(result.separateFrontPage)
      setRowVersion(result.rowVersion)
    } finally {
      setLoading(false)
    }
  }

  async function handleImageUpload(file: File, elementId: string) {
    try {
      const formData = new FormData()
      formData.append('file', file)
      const result = await apiFetch<{ item: { storagePath: string; url: string } }>('/api/papers/cover/images', {
        method: 'POST',
        body: formData,
      })
      updateElement(elementId, { imagePath: result.item.storagePath })
      setPreviewUrls((prev) => ({ ...prev, [result.item.storagePath]: result.item.url }))
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  if (loading) {
    return <div className="card p-8 text-center text-sm text-ink-faint">Loading cover designer…</div>
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-ink">Cover Page Designer</h1>
          <p className="text-sm text-ink-muted">
            #{paperTitle} · {hasSavedDesign ? 'Custom cover design' : 'No custom design saved yet — using the default cover'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button className="btn-secondary" onClick={() => router.push(`/papers/${paperId}`)}>
            Back to Paper
          </button>
          {canEdit && (
            <button className="btn-secondary" onClick={() => setReferenceModalOpen(true)}>
              Upload Reference Image
            </button>
          )}
          {canEdit && (
            <button className="btn-secondary" onClick={() => setTemplatesModalOpen(true)}>
              Cover Templates
            </button>
          )}
          {canEdit && (
            <button className="btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? 'Saving…' : 'Save Cover Design'}
            </button>
          )}
        </div>
      </div>

      {conflict && (
        <div className="rounded-md border border-red-300 bg-red-50 px-4 py-3 text-sm text-danger">
          {conflict}{' '}
          <button className="ml-2 font-medium underline" onClick={reload}>
            Reload latest version
          </button>
        </div>
      )}

      {!canEdit && (
        <div className="rounded-md border border-surface-border bg-surface-subtle px-4 py-3 text-sm text-ink-muted">
          You have view-only access to the cover designer.
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="card space-y-3 p-4">
          <Toolbar
            design={design}
            canEdit={canEdit}
            zoom={zoom}
            setZoom={setZoom}
            addMenuOpen={addMenuOpen}
            setAddMenuOpen={setAddMenuOpen}
            addElement={addElement}
            patchDesign={patchDesign}
            separateFrontPage={separateFrontPage}
            setSeparateFrontPage={setSeparateFrontPage}
          />
          <div className="overflow-auto rounded-md border border-surface-border bg-surface-subtle p-6">
            <Canvas
              design={design}
              previewUrls={previewUrls}
              scale={scale}
              widthMm={widthMm}
              heightMm={heightMm}
              selectedId={selectedId}
              setSelectedId={setSelectedId}
              updateElement={updateElement}
              canEdit={canEdit}
            />
          </div>
        </div>

        <div className="space-y-4">
          <LayersPanel
            elements={design.elements}
            selectedId={selectedId}
            setSelectedId={setSelectedId}
            reorderZIndex={reorderZIndex}
            updateElement={updateElement}
            deleteElement={deleteElement}
            canEdit={canEdit}
          />
          {selected && (
            <PropertiesPanel
              element={selected}
              design={design}
              canEdit={canEdit}
              updateElement={updateElement}
              patchDesign={patchDesign}
              duplicateElement={duplicateElement}
              deleteElement={deleteElement}
              alignElement={alignElement}
              onUploadImage={handleImageUpload}
              previewUrls={previewUrls}
            />
          )}
        </div>
      </div>

      <ReferenceImageModal
        open={referenceModalOpen}
        onClose={() => setReferenceModalOpen(false)}
        pageSize={design.pageSize}
        onApplyTemplate={(newDesign) => {
          setDesign(newDesign)
          setSelectedId(null)
          setReferenceModalOpen(false)
          show('success', 'Reference image converted to an editable design — review the highlighted fields before saving.')
        }}
        onApplyBackground={(storagePath, previewUrl, opacity) => {
          setDesign((prev) => ({
            ...prev,
            background: { ...prev.background, mode: 'background', referenceImagePath: storagePath, referenceOpacity: opacity },
          }))
          setPreviewUrls((prev) => ({ ...prev, [storagePath]: previewUrl }))
          setReferenceModalOpen(false)
          show('success', 'Reference image set as a background you can trace over.')
        }}
      />

      <CoverTemplatesModal
        open={templatesModalOpen}
        onClose={() => setTemplatesModalOpen(false)}
        canEdit={canEdit}
        currentDesign={design}
        onUseTemplate={(templateDesign) => {
          setDesign(templateDesign)
          setSelectedId(null)
          setTemplatesModalOpen(false)
          show('success', 'Template loaded. Save the cover design to apply it to this paper.')
        }}
      />
    </div>
  )
}

// ── Toolbar ─────────────────────────────────────────────────────────────

function Toolbar({
  design,
  canEdit,
  zoom,
  setZoom,
  addMenuOpen,
  setAddMenuOpen,
  addElement,
  patchDesign,
  separateFrontPage,
  setSeparateFrontPage,
}: {
  design: CoverDesign
  canEdit: boolean
  zoom: number
  setZoom: (z: number) => void
  addMenuOpen: boolean
  setAddMenuOpen: (v: boolean) => void
  addElement: (type: (typeof COVER_ELEMENT_TYPES)[number]) => void
  patchDesign: (patch: Partial<CoverDesign>) => void
  separateFrontPage: boolean
  setSeparateFrontPage: (v: boolean) => void
}) {
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-surface-border pb-3">
      {canEdit && (
        <div className="relative">
          <button className="btn-secondary" onClick={() => setAddMenuOpen(!addMenuOpen)}>
            + Add
          </button>
          {addMenuOpen && (
            <div className="absolute left-0 top-full z-20 mt-1 w-48 rounded-md border border-surface-border bg-white p-1 shadow-lg">
              {COVER_ELEMENT_TYPES.map((type) => (
                <button
                  key={type}
                  className="block w-full rounded px-2 py-1.5 text-left text-sm hover:bg-surface-subtle"
                  onClick={() => addElement(type)}
                >
                  {ELEMENT_TYPE_LABELS[type]}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <select
        className="input !w-auto"
        value={design.pageSize}
        disabled={!canEdit}
        onChange={(e) => patchDesign({ pageSize: e.target.value as CoverDesign['pageSize'] })}
      >
        <option value="A4">A4</option>
        <option value="LETTER">Letter</option>
        <option value="LEGAL">Legal</option>
      </select>

      <label className="flex items-center gap-1 text-sm text-ink-muted">
        <input
          type="checkbox"
          checked={design.settings.showGrid}
          disabled={!canEdit}
          onChange={(e) => patchDesign({ settings: { ...design.settings, showGrid: e.target.checked } })}
        />
        Show Grid
      </label>
      <label className="flex items-center gap-1 text-sm text-ink-muted">
        <input
          type="checkbox"
          checked={design.settings.snapToGrid}
          disabled={!canEdit}
          onChange={(e) => patchDesign({ settings: { ...design.settings, snapToGrid: e.target.checked } })}
        />
        Snap to Grid
      </label>
      <label className="flex items-center gap-1 text-sm text-ink-muted">
        <input type="checkbox" checked={separateFrontPage} disabled={!canEdit} onChange={(e) => setSeparateFrontPage(e.target.checked)} />
        Separate Front Page
      </label>

      <div className="ml-auto flex items-center gap-1 text-sm">
        <button className="btn-ghost !px-2 !py-1" onClick={() => setZoom(Math.max(0.4, zoom - 0.1))}>
          −
        </button>
        <span className="w-12 text-center text-ink-faint">{Math.round(zoom * 100)}%</span>
        <button className="btn-ghost !px-2 !py-1" onClick={() => setZoom(Math.min(2, zoom + 0.1))}>
          +
        </button>
      </div>
    </div>
  )
}

// ── Canvas ──────────────────────────────────────────────────────────────

function Canvas({
  design,
  previewUrls,
  scale,
  widthMm,
  heightMm,
  selectedId,
  setSelectedId,
  updateElement,
  canEdit,
}: {
  design: CoverDesign
  previewUrls: Record<string, string>
  scale: number
  widthMm: number
  heightMm: number
  selectedId: string | null
  setSelectedId: (id: string | null) => void
  updateElement: (id: string, patch: Partial<CoverElement>) => void
  canEdit: boolean
}) {
  const dragState = useRef<{
    id: string
    mode: 'move' | 'resize'
    startClientX: number
    startClientY: number
    startX: number
    startY: number
    startWidth: number
    startHeight: number
    aspectRatio: number
  } | null>(null)

  const snap = useCallback(
    (v: number) => (design.settings.snapToGrid ? Math.round(v / design.settings.gridSizeMm) * design.settings.gridSizeMm : v),
    [design.settings.snapToGrid, design.settings.gridSizeMm]
  )

  useEffect(() => {
    function onMove(e: PointerEvent) {
      const drag = dragState.current
      if (!drag) return
      const dxMm = (e.clientX - drag.startClientX) / scale
      const dyMm = (e.clientY - drag.startClientY) / scale
      if (drag.mode === 'move') {
        updateElement(drag.id, {
          x: Math.max(0, Math.min(widthMm - drag.startWidth, snap(drag.startX + dxMm))),
          y: Math.max(0, Math.min(heightMm - drag.startHeight, snap(drag.startY + dyMm))),
        })
      } else {
        let newWidth = Math.max(4, snap(drag.startWidth + dxMm))
        let newHeight = Math.max(4, snap(drag.startHeight + dyMm))
        if (drag.aspectRatio > 0) {
          // Preserve aspect ratio for image/logo elements — driven by
          // whichever axis moved further, so dragging mostly-horizontally
          // resizes by width and mostly-vertically resizes by height.
          if (Math.abs(dxMm) >= Math.abs(dyMm)) {
            newHeight = newWidth / drag.aspectRatio
          } else {
            newWidth = newHeight * drag.aspectRatio
          }
        }
        updateElement(drag.id, { width: newWidth, height: newHeight })
      }
    }
    function onUp() {
      dragState.current = null
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
    return () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
    }
  }, [scale, widthMm, heightMm, snap, updateElement])

  function startDrag(e: React.PointerEvent, el: CoverElement, mode: 'move' | 'resize') {
    if (!canEdit || el.locked) return
    e.stopPropagation()
    setSelectedId(el.id)
    dragState.current = {
      id: el.id,
      mode,
      startClientX: e.clientX,
      startClientY: e.clientY,
      startX: el.x,
      startY: el.y,
      startWidth: el.width,
      startHeight: el.height,
      aspectRatio: IMAGE_LIKE_TYPES.has(el.type) && el.height > 0 ? el.width / el.height : 0,
    }
  }

  const bg = design.background
  const sortedElements = [...design.elements].sort((a, b) => a.zIndex - b.zIndex)

  return (
    <div
      className="relative bg-white shadow-md"
      style={{
        width: widthMm * scale,
        height: heightMm * scale,
        backgroundColor: bg.color || '#ffffff',
        backgroundImage: design.settings.showGrid
          ? `linear-gradient(to right, #e5e7eb 1px, transparent 1px), linear-gradient(to bottom, #e5e7eb 1px, transparent 1px)`
          : undefined,
        backgroundSize: design.settings.showGrid ? `${design.settings.gridSizeMm * scale}px ${design.settings.gridSizeMm * scale}px` : undefined,
      }}
      onPointerDown={() => setSelectedId(null)}
    >
      {bg.mode === 'background' && bg.referenceImagePath && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={previewUrls[bg.referenceImagePath] || bg.referenceImagePath}
          alt=""
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', opacity: bg.referenceOpacity / 100 }}
        />
      )}

      {sortedElements
        .filter((el) => !el.hidden)
        .map((el) => (
          <div
            key={el.id}
            onPointerDown={(e) => startDrag(e, el, 'move')}
            className={`absolute box-border ${selectedId === el.id ? 'outline outline-2 outline-brand' : 'hover:outline hover:outline-1 hover:outline-brand/50'}`}
            style={{
              left: el.x * scale,
              top: el.y * scale,
              width: el.width * scale,
              height: el.height * scale,
              zIndex: el.zIndex,
              cursor: canEdit && !el.locked ? 'move' : 'default',
              overflow: 'hidden',
              ...elementCssStyle(el),
            }}
          >
            {renderElementContent(el, previewUrls)}
            {canEdit && !el.locked && selectedId === el.id && (
              <div
                onPointerDown={(e) => startDrag(e, el, 'resize')}
                className="absolute -bottom-1 -right-1 h-3 w-3 cursor-nwse-resize rounded-sm border border-white bg-brand"
              />
            )}
          </div>
        ))}
    </div>
  )
}

function elementCssStyle(el: CoverElement): React.CSSProperties {
  if (IMAGE_LIKE_TYPES.has(el.type)) {
    return { opacity: el.opacity / 100 }
  }
  if (el.type === 'line') {
    return { backgroundColor: el.borderColor || el.color || '#14161f' }
  }
  if (SHAPE_LIKE_TYPES.has(el.type)) {
    return {
      border: el.borderWidthPt ? `${el.borderWidthPt}pt solid ${el.borderColor || '#14161f'}` : undefined,
      backgroundColor: el.backgroundColor || undefined,
    }
  }
  return {
    fontFamily: el.fontFamily,
    fontSize: `${el.fontSizePt}pt`,
    fontWeight: el.fontWeight === 'bold' ? 700 : 400,
    fontStyle: el.fontStyle === 'italic' ? 'italic' : 'normal',
    textAlign: el.alignment,
    color: el.color,
    backgroundColor: el.backgroundColor || undefined,
    border: el.borderWidthPt ? `${el.borderWidthPt}pt solid ${el.borderColor || '#14161f'}` : undefined,
    whiteSpace: 'pre-wrap',
    padding: el.type === 'table' ? 4 : 0,
  }
}

function renderElementContent(el: CoverElement, previewUrls: Record<string, string>) {
  if (IMAGE_LIKE_TYPES.has(el.type)) {
    const url = el.imagePath ? previewUrls[el.imagePath] || el.imagePath : null
    if (!url) {
      return <div className="flex h-full w-full items-center justify-center bg-surface-subtle text-[10px] text-ink-faint">{ELEMENT_TYPE_LABELS[el.type]}</div>
    }
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain' }} draggable={false} />
  }
  if (SHAPE_LIKE_TYPES.has(el.type)) return null
  return <>{el.text || <span className="text-ink-faint">{ELEMENT_TYPE_LABELS[el.type]}</span>}</>
}

// ── Layers panel ────────────────────────────────────────────────────────

function LayersPanel({
  elements,
  selectedId,
  setSelectedId,
  reorderZIndex,
  updateElement,
  deleteElement,
  canEdit,
}: {
  elements: CoverElement[]
  selectedId: string | null
  setSelectedId: (id: string | null) => void
  reorderZIndex: (id: string, mode: 'front' | 'back' | 'forward' | 'backward') => void
  updateElement: (id: string, patch: Partial<CoverElement>) => void
  deleteElement: (id: string) => void
  canEdit: boolean
}) {
  const sorted = [...elements].sort((a, b) => b.zIndex - a.zIndex)
  return (
    <div className="card space-y-2 p-4">
      <h2 className="text-sm font-semibold text-ink">Layers ({elements.length})</h2>
      <div className="max-h-80 space-y-1 overflow-y-auto">
        {sorted.map((el) => (
          <div
            key={el.id}
            className={`flex items-center gap-1 rounded px-2 py-1.5 text-xs ${selectedId === el.id ? 'bg-brand/10' : 'hover:bg-surface-subtle'}`}
          >
            <button className="flex-1 truncate text-left" onClick={() => setSelectedId(el.id)}>
              {ELEMENT_TYPE_LABELS[el.type]}
              {el.text ? `: ${el.text.slice(0, 18)}` : ''}
              {el.needsReview && <span className="ml-1 rounded bg-amber-100 px-1 text-amber-700">Needs Review</span>}
            </button>
            {canEdit && (
              <>
                <button className="btn-ghost !px-1 !py-0.5" title="Bring forward" onClick={() => reorderZIndex(el.id, 'forward')}>
                  ↑
                </button>
                <button className="btn-ghost !px-1 !py-0.5" title="Send backward" onClick={() => reorderZIndex(el.id, 'backward')}>
                  ↓
                </button>
                <button
                  className="btn-ghost !px-1 !py-0.5"
                  title={el.hidden ? 'Show' : 'Hide'}
                  onClick={() => updateElement(el.id, { hidden: !el.hidden })}
                >
                  {el.hidden ? '🚫' : '👁'}
                </button>
                <button
                  className="btn-ghost !px-1 !py-0.5"
                  title={el.locked ? 'Unlock' : 'Lock'}
                  onClick={() => updateElement(el.id, { locked: !el.locked })}
                >
                  {el.locked ? '🔒' : '🔓'}
                </button>
                <button className="btn-ghost !px-1 !py-0.5 text-danger" title="Delete" onClick={() => deleteElement(el.id)}>
                  ✕
                </button>
              </>
            )}
          </div>
        ))}
        {elements.length === 0 && <p className="py-4 text-center text-xs text-ink-faint">No elements yet — use + Add above.</p>}
      </div>
    </div>
  )
}

// ── Properties panel ────────────────────────────────────────────────────

function PropertiesPanel({
  element,
  design,
  canEdit,
  updateElement,
  patchDesign,
  duplicateElement,
  deleteElement,
  alignElement,
  onUploadImage,
  previewUrls,
}: {
  element: CoverElement
  design: CoverDesign
  canEdit: boolean
  updateElement: (id: string, patch: Partial<CoverElement>) => void
  patchDesign: (patch: Partial<CoverDesign>) => void
  duplicateElement: (id: string) => void
  deleteElement: (id: string) => void
  alignElement: (id: string, mode: 'left' | 'centerH' | 'right' | 'top' | 'centerV' | 'bottom') => void
  onUploadImage: (file: File, elementId: string) => void
  previewUrls: Record<string, string>
}) {
  const el = element
  const disabled = !canEdit || el.locked

  return (
    <div className="card space-y-3 p-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-ink">{ELEMENT_TYPE_LABELS[el.type]} properties</h2>
        {canEdit && (
          <div className="flex gap-1">
            <button className="btn-ghost !px-2 !py-1 text-xs" onClick={() => duplicateElement(el.id)}>
              Duplicate
            </button>
            <button className="btn-ghost !px-2 !py-1 text-xs text-danger" onClick={() => deleteElement(el.id)}>
              Delete
            </button>
          </div>
        )}
      </div>

      <div>
        <p className="mb-1 text-xs font-medium text-ink-muted">Align to page</p>
        <div className="flex flex-wrap gap-1">
          {(
            [
              ['left', 'Align Left'],
              ['centerH', 'Center Horiz.'],
              ['right', 'Align Right'],
              ['top', 'Align Top'],
              ['centerV', 'Center Vert.'],
              ['bottom', 'Align Bottom'],
            ] as const
          ).map(([mode, label]) => (
            <button key={mode} className="btn-ghost !px-2 !py-1 text-xs" disabled={disabled} onClick={() => alignElement(el.id, mode)}>
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <NumberField label="X (mm)" value={el.x} disabled={disabled} onChange={(v) => updateElement(el.id, { x: v })} />
        <NumberField label="Y (mm)" value={el.y} disabled={disabled} onChange={(v) => updateElement(el.id, { y: v })} />
        <NumberField label="Width (mm)" value={el.width} disabled={disabled} onChange={(v) => updateElement(el.id, { width: v })} />
        <NumberField label="Height (mm)" value={el.height} disabled={disabled} onChange={(v) => updateElement(el.id, { height: v })} />
      </div>

      {TEXT_LIKE_TYPES.has(el.type) && (
        <>
          <div>
            <label className="label">Text</label>
            <textarea
              className="input min-h-[60px]"
              value={el.text}
              disabled={disabled || !!el.placeholderKey}
              onChange={(e) => updateElement(el.id, { text: e.target.value })}
            />
          </div>

          <div>
            <label className="label">Bind to field</label>
            <select
              className="input"
              disabled={disabled}
              value={el.placeholderKey ?? ''}
              onChange={(e) => updateElement(el.id, { placeholderKey: (e.target.value || null) as CoverElement['placeholderKey'] })}
            >
              <option value="">Not bound — use literal text</option>
              {COVER_PLACEHOLDER_KEYS.map((key) => (
                <option key={key} value={key}>
                  {key}
                </option>
              ))}
            </select>
          </div>

          {el.type === 'customField' && (
            <CustomFieldBinding element={el} design={design} disabled={disabled} updateElement={updateElement} patchDesign={patchDesign} />
          )}

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="label">Font</label>
              <select
                className="input"
                disabled={disabled}
                value={el.fontFamily}
                onChange={(e) => updateElement(el.id, { fontFamily: e.target.value as CoverElement['fontFamily'] })}
              >
                {COVER_FONT_FAMILIES.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Size (pt)</label>
              <select
                className="input"
                disabled={disabled}
                value={el.fontSizePt}
                onChange={(e) => updateElement(el.id, { fontSizePt: Number(e.target.value) })}
              >
                {COVER_FONT_SIZES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex gap-1">
            <button
              className={`btn-ghost !px-2 !py-1 text-xs ${el.fontWeight === 'bold' ? 'bg-brand/10' : ''}`}
              disabled={disabled}
              onClick={() => updateElement(el.id, { fontWeight: el.fontWeight === 'bold' ? 'normal' : 'bold' })}
            >
              Bold
            </button>
            <button
              className={`btn-ghost !px-2 !py-1 text-xs ${el.fontStyle === 'italic' ? 'bg-brand/10' : ''}`}
              disabled={disabled}
              onClick={() => updateElement(el.id, { fontStyle: el.fontStyle === 'italic' ? 'normal' : 'italic' })}
            >
              Italic
            </button>
            {(['left', 'center', 'right'] as const).map((a) => (
              <button
                key={a}
                className={`btn-ghost !px-2 !py-1 text-xs ${el.alignment === a ? 'bg-brand/10' : ''}`}
                disabled={disabled}
                onClick={() => updateElement(el.id, { alignment: a })}
              >
                {a}
              </button>
            ))}
          </div>

          <ColorField label="Text color" value={el.color} disabled={disabled} onChange={(v) => updateElement(el.id, { color: v })} />
        </>
      )}

      {IMAGE_LIKE_TYPES.has(el.type) && (
        <>
          <div>
            <label className="label">{el.type === 'logo' ? 'Logo image' : 'Image'}</label>
            {el.imagePath && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={previewUrls[el.imagePath] || el.imagePath}
                alt=""
                className="mb-2 max-h-24 rounded border border-surface-border object-contain"
              />
            )}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp,image/svg+xml"
              disabled={disabled}
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) onUploadImage(file, el.id)
              }}
            />
          </div>
          <div>
            <label className="label">Opacity ({el.opacity}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={el.opacity}
              disabled={disabled}
              onChange={(e) => updateElement(el.id, { opacity: Number(e.target.value) })}
              className="w-full"
            />
          </div>
          <p className="text-xs text-ink-faint">Resizing preserves the image&rsquo;s aspect ratio — it is never stretched or distorted.</p>
        </>
      )}

      {SHAPE_LIKE_TYPES.has(el.type) && (
        <>
          <ColorField label="Border color" value={el.borderColor ?? '#400c4d'} disabled={disabled} onChange={(v) => updateElement(el.id, { borderColor: v })} />
          <NumberField label="Border width (pt)" value={el.borderWidthPt} disabled={disabled} onChange={(v) => updateElement(el.id, { borderWidthPt: v })} />
          {el.type === 'rectangle' && (
            <div className="flex items-center gap-2">
              <ColorField label="Fill color" value={el.backgroundColor ?? '#ffffff'} disabled={disabled} onChange={(v) => updateElement(el.id, { backgroundColor: v })} />
              <button className="btn-ghost !px-2 !py-1 text-xs" disabled={disabled} onClick={() => updateElement(el.id, { backgroundColor: null })}>
                No fill
              </button>
            </div>
          )}
        </>
      )}

      {el.ocrConfidence && (
        <div className={`rounded-md px-3 py-2 text-xs ${el.needsReview ? 'bg-amber-50 text-amber-800' : 'bg-emerald-50 text-emerald-800'}`}>
          Detected from reference image — confidence: {el.ocrConfidence}.{' '}
          {el.needsReview ? 'Please review this before saving.' : ''}
          {el.needsReview && (
            <button className="ml-2 underline" onClick={() => updateElement(el.id, { needsReview: false })}>
              Mark reviewed
            </button>
          )}
        </div>
      )}
    </div>
  )
}

function CustomFieldBinding({
  element,
  design,
  disabled,
  updateElement,
  patchDesign,
}: {
  element: CoverElement
  design: CoverDesign
  disabled: boolean
  updateElement: (id: string, patch: Partial<CoverElement>) => void
  patchDesign: (patch: Partial<CoverDesign>) => void
}) {
  const field = design.settings.customFields.find((f) => f.key === element.customFieldKey)

  function setField(name: string, value: string) {
    if (field) {
      patchDesign({
        settings: {
          ...design.settings,
          customFields: design.settings.customFields.map((f) => (f.key === field.key ? { ...f, label: name, value } : f)),
        },
      })
    } else {
      const key = `custom_${element.id.slice(0, 8)}`
      patchDesign({ settings: { ...design.settings, customFields: [...design.settings.customFields, { key, label: name, value }] } })
      updateElement(element.id, { customFieldKey: key })
    }
  }

  return (
    <div className="grid grid-cols-2 gap-2 rounded-md bg-surface-subtle p-2">
      <div>
        <label className="label">Field name</label>
        <input className="input" disabled={disabled} value={field?.label ?? ''} onChange={(e) => setField(e.target.value, field?.value ?? '')} placeholder="e.g. Academic Session" />
      </div>
      <div>
        <label className="label">Field value</label>
        <input className="input" disabled={disabled} value={field?.value ?? ''} onChange={(e) => setField(field?.label ?? '', e.target.value)} placeholder="e.g. 2026–27" />
      </div>
    </div>
  )
}

function NumberField({ label, value, onChange, disabled }: { label: string; value: number; onChange: (v: number) => void; disabled?: boolean }) {
  return (
    <div>
      <label className="label">{label}</label>
      <input
        className="input"
        type="number"
        value={Number.isFinite(value) ? value : 0}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  )
}

function ColorField({ label, value, onChange, disabled }: { label: string; value: string; onChange: (v: string) => void; disabled?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <label className="label !mb-0">{label}</label>
      <input type="color" value={/^#[0-9a-fA-F]{6}$/.test(value) ? value : '#14161f'} disabled={disabled} onChange={(e) => onChange(e.target.value)} />
    </div>
  )
}

// ── Reference image upload + analysis modal ────────────────────────────

function ReferenceImageModal({
  open,
  onClose,
  pageSize,
  onApplyTemplate,
  onApplyBackground,
}: {
  open: boolean
  onClose: () => void
  pageSize: CoverDesign['pageSize']
  onApplyTemplate: (design: CoverDesign) => void
  onApplyBackground: (storagePath: string, previewUrl: string, opacity: number) => void
}) {
  const { show } = useToast()
  const [status, setStatus] = useState<AnalyzeStatus>('idle')
  const [stage, setStage] = useState<string | null>(null)
  const [jobId, setJobId] = useState<string | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [storagePath, setStoragePath] = useState<string | null>(null)
  const [result, setResult] = useState<AnalyzeResultSummary | null>(null)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [backgroundOpacity, setBackgroundOpacity] = useState(35)
  const pollTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (!open) {
      setStatus('idle')
      setJobId(null)
      setResult(null)
      setErrorMsg(null)
      if (pollTimer.current) clearTimeout(pollTimer.current)
    }
  }, [open])

  useEffect(() => {
    if (!jobId || status === 'REVIEW' || status === 'FAILED') return
    pollTimer.current = setTimeout(async () => {
      try {
        const poll = await apiFetch<{
          status: AnalyzeStatus
          stage: string | null
          errorMessage: string | null
          result: AnalyzeResultSummary | null
          referenceImagePreviewUrl: string
        }>(`/api/papers/cover/analyze/${jobId}`)
        setStatus(poll.status)
        setStage(poll.stage)
        if (poll.status === 'FAILED') setErrorMsg(poll.errorMessage)
        if (poll.status === 'REVIEW') setResult(poll.result)
      } catch (err) {
        setStatus('FAILED')
        setErrorMsg(errorMessage(err))
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, 2000)
    return () => {
      if (pollTimer.current) clearTimeout(pollTimer.current)
    }
  }, [jobId, status])

  async function handleFile(file: File) {
    setStatus('uploading')
    setErrorMsg(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const uploadResult = await apiFetch<{ jobId: string }>('/api/papers/cover/analyze/upload', { method: 'POST', body: formData })
      setJobId(uploadResult.jobId)
      setStatus('PENDING')

      const poll = await apiFetch<{ referenceImagePreviewUrl: string; originalStoragePath: string }>(
        `/api/papers/cover/analyze/${uploadResult.jobId}`
      )
      setPreviewUrl(poll.referenceImagePreviewUrl)
      setStoragePath(poll.originalStoragePath)
    } catch (err) {
      setStatus('FAILED')
      setErrorMsg(errorMessage(err))
    }
  }

  async function handleUseAsTemplate() {
    if (!jobId) return
    try {
      const result = await apiFetch<{ coverDesign: CoverDesign }>(`/api/papers/cover/analyze/${jobId}/convert`, {
        method: 'POST',
        body: JSON.stringify({ pageSize }),
      })
      onApplyTemplate(result.coverDesign)
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Upload Reference Image" wide>
      <div className="space-y-4">
        {status === 'idle' && (
          <div>
            <p className="mb-2 text-sm text-ink-muted">
              Upload a photo, screenshot, or scan of a cover page design you&rsquo;d like to use as a visual reference (PNG, JPG/JPEG, or WEBP).
            </p>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) void handleFile(file)
              }}
            />
          </div>
        )}

        {previewUrl && (
          <div>
            <p className="mb-1 text-xs font-medium text-ink-muted">Uploaded Cover Image</p>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={previewUrl} alt="Uploaded cover reference" className="max-h-64 rounded-md border border-surface-border object-contain" />
          </div>
        )}

        {(status === 'uploading' || status === 'PENDING' || status === 'PROCESSING') && (
          <p className="text-sm text-ink-muted">{stage || 'Analyzing design…'}</p>
        )}

        {status === 'FAILED' && <p className="text-sm text-danger">{errorMsg || 'Design analysis failed.'}</p>}

        {status === 'REVIEW' && result && (
          <div className="space-y-3 rounded-md border border-surface-border bg-surface-subtle p-4">
            <p className="font-medium text-ink">Design Analysis Complete</p>
            <p className="text-sm text-ink-muted">
              Text detected: {result.textBlocks.length} · Images detected: {result.images.length} · Shapes detected: {result.shapes.length}
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <button className="btn-primary" onClick={handleUseAsTemplate}>
                Use as Template
              </button>
              <div className="flex items-center gap-2">
                <label className="text-xs text-ink-muted">Reference Opacity: {backgroundOpacity}%</label>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={backgroundOpacity}
                  onChange={(e) => setBackgroundOpacity(Number(e.target.value))}
                />
                <button
                  className="btn-secondary"
                  onClick={() => storagePath && previewUrl && onApplyBackground(storagePath, previewUrl, backgroundOpacity)}
                >
                  Use as Background
                </button>
              </div>
              <button
                className="btn-ghost"
                onClick={() => {
                  setStatus('idle')
                  setJobId(null)
                  setResult(null)
                  setPreviewUrl(null)
                  setStoragePath(null)
                }}
              >
                Re-analyze (upload again)
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  )
}

// ── Cover templates modal ───────────────────────────────────────────────

type CoverTemplateSummary = { id: string; name: string; isDefault: boolean; updatedAt: string }

function CoverTemplatesModal({
  open,
  onClose,
  canEdit,
  currentDesign,
  onUseTemplate,
}: {
  open: boolean
  onClose: () => void
  canEdit: boolean
  currentDesign: CoverDesign
  onUseTemplate: (design: CoverDesign) => void
}) {
  const { show } = useToast()
  const [items, setItems] = useState<CoverTemplateSummary[]>([])
  const [loading, setLoading] = useState(false)
  const [saveName, setSaveName] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const result = await apiFetch<{ items: CoverTemplateSummary[] }>('/api/papers/cover-templates')
      setItems(result.items)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (open) void load()
  }, [open, load])

  async function handleSaveAsTemplate() {
    if (!saveName.trim()) return
    try {
      await apiFetch('/api/papers/cover-templates', { method: 'POST', body: JSON.stringify({ name: saveName.trim(), design: currentDesign }) })
      setSaveName('')
      show('success', 'Saved as a cover template.')
      void load()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function handleUse(id: string) {
    try {
      const result = await apiFetch<{ item: { design: CoverDesign } }>(`/api/papers/cover-templates/${id}`)
      onUseTemplate(result.item.design)
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function handleDuplicate(id: string) {
    try {
      await apiFetch(`/api/papers/cover-templates/${id}/duplicate`, { method: 'POST' })
      void load()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  async function handleDelete(id: string) {
    try {
      await apiFetch(`/api/papers/cover-templates/${id}`, { method: 'DELETE' })
      void load()
    } catch (err) {
      show('error', errorMessage(err))
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Cover Templates" wide>
      <div className="space-y-4">
        {canEdit && (
          <div className="flex items-end gap-2 rounded-md bg-surface-subtle p-3">
            <div className="flex-1">
              <label className="label">Save current design as a new template</label>
              <input className="input" value={saveName} onChange={(e) => setSaveName(e.target.value)} placeholder="Template name" />
            </div>
            <button className="btn-primary" onClick={handleSaveAsTemplate} disabled={!saveName.trim()}>
              Save as Cover Template
            </button>
          </div>
        )}

        {loading && <p className="text-sm text-ink-faint">Loading templates…</p>}
        {!loading && items.length === 0 && <p className="text-sm text-ink-faint">No cover templates saved yet.</p>}

        <div className="space-y-2">
          {items.map((t) => (
            <div key={t.id} className="flex items-center justify-between rounded-md border border-surface-border px-3 py-2 text-sm">
              <span>{t.name}</span>
              <div className="flex gap-1">
                <button className="btn-ghost !px-2 !py-1" onClick={() => handleUse(t.id)}>
                  Use
                </button>
                {canEdit && (
                  <>
                    <button className="btn-ghost !px-2 !py-1" onClick={() => handleDuplicate(t.id)}>
                      Duplicate
                    </button>
                    <button className="btn-ghost !px-2 !py-1 text-danger" onClick={() => handleDelete(t.id)}>
                      Delete
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Modal>
  )
}
