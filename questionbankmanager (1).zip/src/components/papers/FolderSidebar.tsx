'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { Modal, ConfirmDialog } from '@/components/ui/Modal'
import type { PaperFolderItem } from '@/types'

type FoldersResponse = { items: PaperFolderItem[]; uncategorizedCount: number }

export type FolderSelection = { kind: 'all' } | { kind: 'uncategorized' } | { kind: 'folder'; id: string }

/**
 * Left-hand folder tree for the Saved Papers screen: All Papers /
 * Uncategorized / one row per folder, with create/rename/delete built in.
 * Selecting a row filters the paper list on the right (see
 * PaperFoldersView) — this component owns folder CRUD only, not the list.
 */
export function FolderSidebar({
  selection,
  onSelect,
  refreshToken,
  canManage,
}: {
  selection: FolderSelection
  onSelect: (s: FolderSelection) => void
  refreshToken: number
  canManage: boolean
}) {
  const { show } = useToast()
  const [data, setData] = useState<FoldersResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [createOpen, setCreateOpen] = useState(false)
  const [newName, setNewName] = useState('')
  const [creating, setCreating] = useState(false)
  const [renaming, setRenaming] = useState<PaperFolderItem | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const [renameBusy, setRenameBusy] = useState(false)
  const [deleting, setDeleting] = useState<PaperFolderItem | null>(null)
  const [deleteBusy, setDeleteBusy] = useState(false)

  function load() {
    setLoading(true)
    apiFetch<FoldersResponse>('/api/folders')
      .then(setData)
      .catch((err) => show('error', errorMessage(err)))
      .finally(() => setLoading(false))
  }

  useEffect(load, [refreshToken])

  async function handleCreate() {
    if (!newName.trim()) {
      show('error', 'Folder name is required.')
      return
    }
    setCreating(true)
    try {
      await apiFetch('/api/folders', { method: 'POST', body: JSON.stringify({ name: newName.trim() }) })
      show('success', 'Folder created.')
      setCreateOpen(false)
      setNewName('')
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setCreating(false)
    }
  }

  async function handleRename() {
    if (!renaming) return
    if (!renameValue.trim()) {
      show('error', 'Folder name is required.')
      return
    }
    setRenameBusy(true)
    try {
      await apiFetch(`/api/folders/${renaming.id}`, { method: 'PATCH', body: JSON.stringify({ name: renameValue.trim() }) })
      show('success', 'Folder renamed.')
      setRenaming(null)
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setRenameBusy(false)
    }
  }

  async function handleDelete() {
    if (!deleting) return
    setDeleteBusy(true)
    try {
      await apiFetch(`/api/folders/${deleting.id}`, { method: 'DELETE' })
      show('success', `Folder deleted. ${deleting.paperCount} paper(s) moved to Uncategorized.`)
      if (selection.kind === 'folder' && selection.id === deleting.id) onSelect({ kind: 'all' })
      setDeleting(null)
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setDeleteBusy(false)
    }
  }

  const rowClass = (active: boolean) =>
    `flex items-center justify-between rounded-md px-2.5 py-1.5 text-sm ${
      active ? 'bg-brand-50 font-medium text-brand-800' : 'text-ink hover:bg-surface-subtle'
    }`

  return (
    <div className="card w-full shrink-0 p-3 lg:w-64">
      <div className="mb-2 flex items-center justify-between px-1">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-ink-faint">Folders</h2>
        {canManage && (
          <button className="btn-ghost !px-2 !py-1 text-xs" onClick={() => setCreateOpen(true)}>
            + New Folder
          </button>
        )}
      </div>

      <nav className="space-y-0.5">
        <button className={rowClass(selection.kind === 'all') + ' w-full text-left'} onClick={() => onSelect({ kind: 'all' })}>
          <span>All Papers</span>
        </button>

        {loading && <p className="px-2.5 py-2 text-xs text-ink-faint">Loading…</p>}

        {!loading &&
          data?.items.map((f) => (
            <div key={f.id} className={rowClass(selection.kind === 'folder' && selection.id === f.id) + ' group'}>
              <button className="flex-1 truncate text-left" onClick={() => onSelect({ kind: 'folder', id: f.id })}>
                {f.name}
              </button>
              <span className="ml-2 shrink-0 text-xs text-ink-faint">{f.paperCount}</span>
              {canManage && (
                <span className="ml-1 hidden shrink-0 gap-0.5 group-hover:flex">
                  <button
                    className="rounded px-1 text-xs text-ink-faint hover:text-brand-600"
                    aria-label={`Rename ${f.name}`}
                    onClick={(e) => {
                      e.stopPropagation()
                      setRenaming(f)
                      setRenameValue(f.name)
                    }}
                  >
                    ✎
                  </button>
                  <button
                    className="rounded px-1 text-xs text-ink-faint hover:text-danger"
                    aria-label={`Delete ${f.name}`}
                    onClick={(e) => {
                      e.stopPropagation()
                      setDeleting(f)
                    }}
                  >
                    ✕
                  </button>
                </span>
              )}
            </div>
          ))}

        <button
          className={rowClass(selection.kind === 'uncategorized') + ' w-full text-left'}
          onClick={() => onSelect({ kind: 'uncategorized' })}
        >
          <span>Uncategorized</span>
          <span className="ml-2 shrink-0 text-xs text-ink-faint">{data?.uncategorizedCount ?? ''}</span>
        </button>
      </nav>

      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="New Folder">
        <label className="label">Folder name</label>
        <input
          className="input"
          autoFocus
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
          maxLength={80}
        />
        <div className="mt-6 flex justify-end gap-2">
          <button className="btn-secondary" onClick={() => setCreateOpen(false)} disabled={creating}>
            Cancel
          </button>
          <button className="btn-primary" onClick={handleCreate} disabled={creating}>
            {creating ? 'Creating…' : 'Create Folder'}
          </button>
        </div>
      </Modal>

      <Modal open={!!renaming} onClose={() => setRenaming(null)} title="Rename Folder">
        <label className="label">Folder name</label>
        <input
          className="input"
          autoFocus
          value={renameValue}
          onChange={(e) => setRenameValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleRename()}
          maxLength={80}
        />
        <div className="mt-6 flex justify-end gap-2">
          <button className="btn-secondary" onClick={() => setRenaming(null)} disabled={renameBusy}>
            Cancel
          </button>
          <button className="btn-primary" onClick={handleRename} disabled={renameBusy}>
            {renameBusy ? 'Saving…' : 'Save'}
          </button>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleting}
        title={`Delete this folder?`}
        message={`"${deleting?.name}" will be deleted. ${deleting?.paperCount ? `The ${deleting.paperCount} paper(s) inside it will move to Uncategorized — they will not be deleted.` : 'It has no papers in it.'}`}
        danger
        confirmLabel="Delete"
        loading={deleteBusy}
        onCancel={() => setDeleting(null)}
        onConfirm={handleDelete}
      />
    </div>
  )
}
