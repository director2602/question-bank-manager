'use client'

import { useEffect, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { MathText } from '@/components/questions/MathRenderer'
import type { QuestionListItem } from '@/types'

type QuestionTypeCode = 'MCQ' | 'SUBJECTIVE' | 'INTEGER'
type SelectionMode = 'AUTOMATIC' | 'MANUAL' | 'HYBRID'

type TypeRow = {
  key: string
  questionType: QuestionTypeCode
  count: number
  marksPerQuestion: number
  difficultyId: string | null
}

type SectionState = {
  key: string
  label: string
  title: string
  instructions: string
  numberingMode: 'CONTINUE' | 'RESTART'
  answerSpace: 'NONE' | 'SMALL' | 'MEDIUM' | 'LARGE' | 'CUSTOM'
  customAnswerSpaceMm: number
  chapterScope: 'ALL' | 'SELECTED'
  chapterIds: string[]
  topicScope: 'ALL' | 'SELECTED'
  topicIds: string[]
  selectionMode: SelectionMode
  types: TypeRow[]
  manualQuestionIds: string[]
  expanded: boolean
}

const TYPE_LABELS: Record<QuestionTypeCode, string> = { MCQ: 'MCQ', SUBJECTIVE: 'Subjective', INTEGER: 'Integer' }
const SECTION_LABELS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']

function newKey() {
  return Math.random().toString(36).slice(2)
}

// Swaps two elements by index, returning a new array — used for every
// "reorder via Move Up/Down" control in this file (drag-and-drop's
// keyboard-accessible equivalent, same precedent already established
// elsewhere in this codebase). Returns the input unchanged if either index
// is out of range, so callers never need their own bounds-check.
function arraySwap<T>(arr: T[], i: number, j: number): T[] {
  if (i < 0 || j < 0 || i >= arr.length || j >= arr.length) return arr
  const next = [...arr]
  const a = next[i]
  const b = next[j]
  if (a === undefined || b === undefined) return arr
  next[i] = b
  next[j] = a
  return next
}

function newTypeRow(): TypeRow {
  return { key: newKey(), questionType: 'MCQ', count: 5, marksPerQuestion: 1, difficultyId: null }
}

function newSection(index: number): SectionState {
  return {
    key: newKey(),
    label: SECTION_LABELS[index] ?? String(index + 1),
    title: '',
    instructions: '',
    numberingMode: 'CONTINUE',
    answerSpace: 'MEDIUM',
    customAnswerSpaceMm: 40,
    chapterScope: 'ALL',
    chapterIds: [],
    topicScope: 'ALL',
    topicIds: [],
    selectionMode: 'AUTOMATIC',
    types: [newTypeRow()],
    manualQuestionIds: [],
    expanded: true,
  }
}

function sectionTotals(section: SectionState) {
  if (section.selectionMode === 'AUTOMATIC') {
    const count = section.types.reduce((sum, t) => sum + (t.count || 0), 0)
    const marks = section.types.reduce((sum, t) => sum + (t.count || 0) * (t.marksPerQuestion || 0), 0)
    return { count, marks }
  }
  const marksByType = new Map(section.types.map((t) => [t.questionType, t.marksPerQuestion]))
  // For MANUAL/HYBRID, marks are estimated per selected question using the
  // section's own type-config marks-per-type (the same lookup the server
  // uses) — a real, non-fabricated running total, not a placeholder.
  const count = section.manualQuestionIds.length
  const marks = count * (marksByType.get('MCQ') ?? section.types[0]?.marksPerQuestion ?? 0)
  return { count, marks }
}

/**
 * The Advanced Paper Builder — a flexible, section-based paper creator that
 * extends (does not replace) the original flat PaperGeneratorForm. Every
 * control here maps directly onto a real field consumed by
 * POST /api/papers/sectioned and the section-aware renderer
 * (paperHtml.ts/paperDocx.ts/paperCsvExport.ts) — see README.md § Advanced
 * Paper Builder for the full field-by-field mapping.
 */
export function SectionedPaperBuilder() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()

  const [title, setTitle] = useState('')
  const [subtitle, setSubtitle] = useState('')
  const [subjectId, setSubjectId] = useState<string | null>(null)
  const [examClassId, setExamClassId] = useState<string | null>(null)
  const [codeId, setCodeId] = useState<string | null>(null)
  const [instituteName, setInstituteName] = useState('CUBUS')
  const [examName, setExamName] = useState('')
  const [examDate, setExamDate] = useState('')
  const [examTime, setExamTime] = useState('')
  const [allowReuse, setAllowReuse] = useState(false)

  const [instructions, setInstructions] = useState<string[]>([
    'Answer all questions.',
    'Each question carries the marks indicated next to it.',
  ])

  const [sections, setSections] = useState<SectionState[]>([newSection(0)])
  const [generating, setGenerating] = useState(false)
  const [sectionShortfalls, setSectionShortfalls] = useState<{ message: string }[] | null>(null)
  const [issues, setIssues] = useState<string[] | null>(null)

  const chaptersForSubject = useMemo(
    () => (subjectId ? lookups.chapters.filter((c) => c.subjectId === subjectId) : []),
    [lookups.chapters, subjectId]
  )

  function topicsForChapters(chapterIds: string[]) {
    if (chapterIds.length === 0) return lookups.topics
    return lookups.topics.filter((t) => chapterIds.includes(t.chapterId))
  }

  function updateSection(key: string, patch: Partial<SectionState>) {
    setSections((prev) => prev.map((s) => (s.key === key ? { ...s, ...patch } : s)))
  }

  function moveSection(index: number, dir: -1 | 1) {
    setSections((prev) => {
      const next = [...prev]
      const target = index + dir
      const a = next[index]
      const b = next[target]
      if (target < 0 || target >= next.length || !a || !b) return prev
      next[index] = b
      next[target] = a
      return next
    })
  }

  function duplicateSection(index: number) {
    setSections((prev) => {
      const source = prev[index]
      if (!source) return prev
      const copy: SectionState = {
        ...source,
        key: newKey(),
        label: SECTION_LABELS[prev.length] ?? String(prev.length + 1),
        types: source.types.map((t) => ({ ...t, key: newKey() })),
        manualQuestionIds: [...source.manualQuestionIds],
      }
      return [...prev.slice(0, index + 1), copy, ...prev.slice(index + 1)]
    })
  }

  function removeSection(key: string) {
    setSections((prev) => prev.filter((s) => s.key !== key))
  }

  const grandTotal = useMemo(() => {
    return sections.reduce(
      (acc, s) => {
        const t = sectionTotals(s)
        return { count: acc.count + t.count, marks: acc.marks + t.marks }
      },
      { count: 0, marks: 0 }
    )
  }, [sections])

  async function handleGenerate() {
    setSectionShortfalls(null)
    setIssues(null)

    if (!title.trim()) return show('error', 'Give the paper a title.')
    if (!subjectId || !examClassId || !codeId) return show('error', 'Select Subject, Class/Exam, and Code before generating.')
    if (sections.length === 0) return show('error', 'Add at least one section.')
    for (const s of sections) {
      if (!s.title.trim()) return show('error', `Section "${s.label}" needs a title.`)
      if (s.selectionMode === 'AUTOMATIC' && s.types.every((t) => !t.count)) {
        return show('error', `Section "${s.label}" needs at least one question type with a count.`)
      }
      if (s.selectionMode !== 'AUTOMATIC' && s.manualQuestionIds.length === 0) {
        return show('error', `Section "${s.label}" is Manual/Hybrid — pick at least one question.`)
      }
    }

    setGenerating(true)
    try {
      const result = await apiFetch<{ item: { id: string } }>('/api/papers/sectioned', {
        method: 'POST',
        body: JSON.stringify({
          title,
          subtitle: subtitle || undefined,
          subjectId,
          examClassId,
          codeId,
          allowReuseOfPastQuestions: allowReuse,
          instituteName: instituteName || undefined,
          logoUrl: '/branding/cubus-logo.png',
          examName: examName || undefined,
          examDate: examDate ? new Date(examDate).toISOString() : undefined,
          examTime: examTime || undefined,
          instructions: instructions.filter((i) => i.trim()),
          sections: sections.map((s) => ({
            key: s.key,
            label: s.label,
            title: s.title,
            instructions: s.instructions || undefined,
            numberingMode: s.numberingMode,
            answerSpace: s.answerSpace,
            customAnswerSpaceMm: s.answerSpace === 'CUSTOM' ? s.customAnswerSpaceMm : undefined,
            chapterScope: s.chapterScope,
            chapterIds: s.chapterIds,
            topicScope: s.topicScope,
            topicIds: s.topicIds,
            selectionMode: s.selectionMode,
            types: s.types.map((t) => ({
              key: t.key,
              questionType: t.questionType,
              count: t.count,
              marksPerQuestion: t.marksPerQuestion,
              difficultyId: t.difficultyId,
            })),
            manualQuestionIds: s.manualQuestionIds,
          })),
        }),
      })
      show('success', 'Paper generated with the Advanced Paper Builder.')
      router.push(`/papers/${result.item.id}`)
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.body.code === 'INSUFFICIENT_QUESTIONS' && err.body.sectionShortfalls) {
          setSectionShortfalls(err.body.sectionShortfalls)
        }
        if (err.body.code === 'PAPER_VALIDATION_FAILED' && Array.isArray((err.body as unknown as { issues?: string[] }).issues)) {
          setIssues((err.body as unknown as { issues: string[] }).issues)
        }
      }
      show('error', errorMessage(err))
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="card space-y-4 p-5">
        <h2 className="text-sm font-semibold text-ink">Paper information & heading</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="label">
              Paper Title <span className="text-danger">*</span>
            </label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Half-Yearly Examination 2026" />
          </div>
          <div>
            <label className="label">Subtitle (optional)</label>
            <input className="input" value={subtitle} onChange={(e) => setSubtitle(e.target.value)} placeholder="Falls back to the app default when empty" />
          </div>
          <SearchableSelect label="Subject" required options={lookups.subjects} value={subjectId} onChange={(v) => { setSubjectId(v); setSections((prev) => prev.map((s) => ({ ...s, chapterIds: [], topicIds: [] }))) }} />
          <SearchableSelect label="Class / Exam" required options={lookups.examClasses} value={examClassId} onChange={setExamClassId} />
          <SearchableSelect label="Code" required options={lookups.codes} value={codeId} onChange={setCodeId} />
          <div>
            <label className="label">Institute Name</label>
            <input className="input" value={instituteName} onChange={(e) => setInstituteName(e.target.value)} />
          </div>
          <div>
            <label className="label">Exam Name</label>
            <input className="input" value={examName} onChange={(e) => setExamName(e.target.value)} />
          </div>
          <div>
            <label className="label">Date</label>
            <input className="input" type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} />
          </div>
          <div>
            <label className="label">Time</label>
            <input className="input" value={examTime} onChange={(e) => setExamTime(e.target.value)} placeholder="e.g. 10:00 AM – 1:00 PM" />
          </div>
          <label className="flex items-center gap-1.5 self-end pb-2 text-sm">
            <input type="checkbox" checked={allowReuse} onChange={(e) => setAllowReuse(e.target.checked)} /> Allow reuse of
            questions from previous papers
          </label>
        </div>
        <p className="text-xs text-ink-faint">
          Maximum Marks and Total Questions are auto-calculated from your sections below — you never set them directly.
        </p>
      </div>

      <div className="card space-y-3 p-5">
        <h2 className="text-sm font-semibold text-ink">General instructions</h2>
        <p className="text-xs text-ink-muted">Shown below the heading and before the first section, in this order.</p>
        <div className="space-y-2">
          {instructions.map((line, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="w-5 text-xs text-ink-faint">{i + 1}.</span>
              <input
                className="input flex-1"
                value={line}
                onChange={(e) => setInstructions((prev) => prev.map((l, idx) => (idx === i ? e.target.value : l)))}
              />
              <button className="btn-ghost !px-2 !py-1 text-xs" disabled={i === 0} onClick={() => setInstructions((prev) => arraySwap(prev, i, i - 1))}>
                ↑
              </button>
              <button className="btn-ghost !px-2 !py-1 text-xs" disabled={i === instructions.length - 1} onClick={() => setInstructions((prev) => arraySwap(prev, i, i + 1))}>
                ↓
              </button>
              <button className="btn-ghost !px-2 !py-1 text-xs text-danger" onClick={() => setInstructions((prev) => prev.filter((_, idx) => idx !== i))}>
                Remove
              </button>
            </div>
          ))}
        </div>
        <button className="btn-secondary" onClick={() => setInstructions((prev) => [...prev, ''])}>
          + Add instruction
        </button>
      </div>

      {sectionShortfalls && (
        <div className="rounded-md border border-red-300 bg-red-50 p-3 text-sm text-danger">
          <p className="mb-1 font-medium">Not enough matching questions are available:</p>
          <ul className="ml-4 list-disc space-y-0.5">
            {sectionShortfalls.map((s, i) => (
              <li key={i}>{s.message}</li>
            ))}
          </ul>
        </div>
      )}
      {issues && (
        <div className="rounded-md border border-red-300 bg-red-50 p-3 text-sm text-danger">
          <p className="mb-1 font-medium">This paper cannot be generated as configured:</p>
          <ul className="ml-4 list-disc space-y-0.5">
            {issues.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="card space-y-4 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold text-ink">Sections</h2>
          <div className="text-sm font-medium text-ink">
            Paper total: <span className="text-brand-700">{grandTotal.count}</span> question(s) ·{' '}
            <span className="text-brand-700">{grandTotal.marks}</span> mark(s)
          </div>
        </div>

        <div className="space-y-3">
          {sections.map((section, index) => (
            <SectionCard
              key={section.key}
              section={section}
              index={index}
              total={sections.length}
              subjectId={subjectId}
              examClassId={examClassId}
              codeId={codeId}
              allowReuse={allowReuse}
              chapters={chaptersForSubject}
              topics={topicsForChapters(section.chapterIds)}
              difficulties={lookups.difficultyLevels}
              onChange={(patch) => updateSection(section.key, patch)}
              onMoveUp={() => moveSection(index, -1)}
              onMoveDown={() => moveSection(index, 1)}
              onDuplicate={() => duplicateSection(index)}
              onRemove={() => removeSection(section.key)}
            />
          ))}
        </div>

        <button className="btn-secondary" onClick={() => setSections((prev) => [...prev, newSection(prev.length)])}>
          + Add Section
        </button>
      </div>

      <div className="flex justify-end">
        <button className="btn-primary" onClick={handleGenerate} disabled={generating}>
          {generating ? 'Generating…' : `Generate Paper (${grandTotal.count} questions, ${grandTotal.marks} marks)`}
        </button>
      </div>
    </div>
  )
}

function SectionCard({
  section,
  index,
  total,
  subjectId,
  examClassId,
  codeId,
  allowReuse,
  chapters,
  topics,
  difficulties,
  onChange,
  onMoveUp,
  onMoveDown,
  onDuplicate,
  onRemove,
}: {
  section: SectionState
  index: number
  total: number
  subjectId: string | null
  examClassId: string | null
  codeId: string | null
  allowReuse: boolean
  chapters: { id: string; label: string }[]
  topics: { id: string; label: string; chapterId: string }[]
  difficulties: { id: string; label: string }[]
  onChange: (patch: Partial<SectionState>) => void
  onMoveUp: () => void
  onMoveDown: () => void
  onDuplicate: () => void
  onRemove: () => void
}) {
  const totals = sectionTotals(section)

  function updateType(key: string, patch: Partial<TypeRow>) {
    onChange({ types: section.types.map((t) => (t.key === key ? { ...t, ...patch } : t)) })
  }

  return (
    <div className="rounded-md border border-surface-border">
      <div className="flex flex-wrap items-center justify-between gap-2 bg-surface-subtle px-3 py-2">
        <button className="flex items-center gap-2 text-left text-sm font-semibold text-ink" onClick={() => onChange({ expanded: !section.expanded })}>
          <span>{section.expanded ? '▾' : '▸'}</span>
          Section {section.label}
          {section.title && `: ${section.title}`}
          <span className="text-xs font-normal text-ink-muted">
            ({totals.count} question{totals.count === 1 ? '' : 's'} · {totals.marks} mark{totals.marks === 1 ? '' : 's'})
          </span>
        </button>
        <div className="flex items-center gap-1">
          <button className="btn-ghost !px-2 !py-1 text-xs" disabled={index === 0} onClick={onMoveUp}>
            ↑
          </button>
          <button className="btn-ghost !px-2 !py-1 text-xs" disabled={index === total - 1} onClick={onMoveDown}>
            ↓
          </button>
          <button className="btn-ghost !px-2 !py-1 text-xs" onClick={onDuplicate}>
            Duplicate
          </button>
          <button className="btn-ghost !px-2 !py-1 text-xs text-danger" onClick={onRemove}>
            Delete
          </button>
        </div>
      </div>

      {section.expanded && (
        <div className="space-y-4 p-3">
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-4">
            <div>
              <label className="label">Section Label</label>
              <input className="input" value={section.label} onChange={(e) => onChange({ label: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label">
                Section Title <span className="text-danger">*</span>
              </label>
              <input className="input" value={section.title} onChange={(e) => onChange({ title: e.target.value })} placeholder="e.g. Multiple Choice Questions" />
            </div>
            <div>
              <label className="label">Numbering</label>
              <select className="input" value={section.numberingMode} onChange={(e) => onChange({ numberingMode: e.target.value as SectionState['numberingMode'] })}>
                <option value="CONTINUE">Continue from previous section</option>
                <option value="RESTART">Restart at 1</option>
              </select>
            </div>
          </div>

          <div>
            <label className="label">Section Instructions (optional)</label>
            <textarea className="input min-h-[50px]" value={section.instructions} onChange={(e) => onChange({ instructions: e.target.value })} />
          </div>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            <div>
              <label className="label">Chapters</label>
              <select className="input" value={section.chapterScope} onChange={(e) => onChange({ chapterScope: e.target.value as 'ALL' | 'SELECTED', chapterIds: [] })}>
                <option value="ALL">All Chapters</option>
                <option value="SELECTED">Selected Chapters</option>
              </select>
            </div>
            <div>
              <label className="label">Topics</label>
              <select className="input" value={section.topicScope} onChange={(e) => onChange({ topicScope: e.target.value as 'ALL' | 'SELECTED', topicIds: [] })}>
                <option value="ALL">All Topics</option>
                <option value="SELECTED">Selected Topics</option>
              </select>
            </div>
            <div>
              <label className="label">Selection Mode</label>
              <select className="input" value={section.selectionMode} onChange={(e) => onChange({ selectionMode: e.target.value as SelectionMode })}>
                <option value="AUTOMATIC">Automatic</option>
                <option value="MANUAL">Manual</option>
                <option value="HYBRID">Hybrid</option>
              </select>
            </div>
          </div>

          {section.chapterScope === 'SELECTED' && (
            <CheckboxCloud
              label="Select chapters"
              options={chapters}
              selected={section.chapterIds}
              onChange={(ids) => onChange({ chapterIds: ids, topicIds: [] })}
            />
          )}
          {section.topicScope === 'SELECTED' && (
            <CheckboxCloud label="Select topics" options={topics} selected={section.topicIds} onChange={(ids) => onChange({ topicIds: ids })} />
          )}

          {section.answerSpace !== undefined && (
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <div>
                <label className="label">Subjective Answer Space</label>
                <select className="input" value={section.answerSpace} onChange={(e) => onChange({ answerSpace: e.target.value as SectionState['answerSpace'] })}>
                  <option value="NONE">None</option>
                  <option value="SMALL">Small</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="LARGE">Large</option>
                  <option value="CUSTOM">Custom</option>
                </select>
              </div>
              {section.answerSpace === 'CUSTOM' && (
                <div>
                  <label className="label">Custom Answer Space (mm)</label>
                  <input
                    className="input"
                    type="number"
                    min={5}
                    max={400}
                    value={section.customAnswerSpaceMm}
                    onChange={(e) => onChange({ customAnswerSpaceMm: Number(e.target.value) })}
                  />
                </div>
              )}
            </div>
          )}

          <div className="rounded-md border border-surface-border p-3">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-ink">Question selection</h3>
              <span className="text-xs font-medium text-ink">
                Total in this section: <span className="text-brand-700">{totals.count}</span> question(s) ·{' '}
                <span className="text-brand-700">{totals.marks}</span> mark(s)
              </span>
            </div>

            {section.selectionMode === 'AUTOMATIC' ? (
              <div className="space-y-2">
                {section.types.map((t) => (
                  <div key={t.key} className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                    <div>
                      <label className="label">Question Type</label>
                      <select className="input" value={t.questionType} onChange={(e) => updateType(t.key, { questionType: e.target.value as QuestionTypeCode })}>
                        {(['MCQ', 'SUBJECTIVE', 'INTEGER'] as QuestionTypeCode[]).map((qt) => (
                          <option key={qt} value={qt}>
                            {TYPE_LABELS[qt]}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="label">Difficulty</label>
                      <select className="input" value={t.difficultyId ?? ''} onChange={(e) => updateType(t.key, { difficultyId: e.target.value || null })}>
                        <option value="">Any</option>
                        {difficulties.map((d) => (
                          <option key={d.id} value={d.id}>
                            {d.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="label">Count</label>
                      <input type="number" min={1} className="input" value={t.count} onChange={(e) => updateType(t.key, { count: Math.max(1, Number(e.target.value)) })} />
                    </div>
                    <div>
                      <label className="label">Marks / Question</label>
                      <input
                        type="number"
                        min={0.5}
                        step={0.5}
                        className="input"
                        value={t.marksPerQuestion}
                        onChange={(e) => updateType(t.key, { marksPerQuestion: Math.max(0.5, Number(e.target.value)) })}
                      />
                    </div>
                    <div className="flex items-end justify-between">
                      <div className="text-xs text-ink-muted">= {t.count * t.marksPerQuestion} mark(s)</div>
                      <button className="btn-ghost !px-2 !py-1 text-xs text-danger" onClick={() => onChange({ types: section.types.filter((x) => x.key !== t.key) })}>
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
                <button className="btn-secondary" onClick={() => onChange({ types: [...section.types, newTypeRow()] })}>
                  + Add question type
                </button>
              </div>
            ) : (
              <SectionQuestionPicker
                subjectId={subjectId}
                examClassId={examClassId}
                codeId={codeId}
                chapterIds={section.chapterScope === 'SELECTED' ? section.chapterIds : []}
                topicIds={section.topicScope === 'SELECTED' ? section.topicIds : []}
                allowReuse={allowReuse}
                selected={section.manualQuestionIds}
                onChange={(ids) => onChange({ manualQuestionIds: ids })}
                autoFillCount={section.selectionMode === 'HYBRID' ? section.types.reduce((s, t) => s + t.count, 0) : 0}
                marksPerQuestion={section.types[0]?.marksPerQuestion ?? 1}
              />
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function CheckboxCloud({
  label,
  options,
  selected,
  onChange,
}: {
  label: string
  options: { id: string; label: string }[]
  selected: string[]
  onChange: (ids: string[]) => void
}) {
  function toggle(id: string) {
    onChange(selected.includes(id) ? selected.filter((s) => s !== id) : [...selected, id])
  }
  return (
    <div>
      <label className="label">{label}</label>
      {options.length === 0 ? (
        <p className="text-xs text-ink-faint">None available — choose a Subject first, or none are tagged yet.</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {options.map((o) => (
            <label key={o.id} className={`cursor-pointer rounded-full border px-3 py-1 text-xs ${selected.includes(o.id) ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-surface-border text-ink-muted'}`}>
              <input type="checkbox" className="sr-only" checked={selected.includes(o.id)} onChange={() => toggle(o.id)} />
              {o.label}
            </label>
          ))}
        </div>
      )}
    </div>
  )
}

/**
 * Manual/Hybrid question picker for one section — lists eligible ACTIVE
 * questions matching the section's subject/class/code (+ chapter/topic
 * scope if set) and lets the user check/uncheck them directly from the
 * Question Bank. The checked order IS the paper order (spec: "the final
 * PDF/DOCX must follow exactly this order") — Move Up/Down reorders the
 * already-selected list.
 */
function SectionQuestionPicker({
  subjectId,
  examClassId,
  codeId,
  chapterIds,
  topicIds,
  allowReuse,
  selected,
  onChange,
  autoFillCount,
  marksPerQuestion,
}: {
  subjectId: string | null
  examClassId: string | null
  codeId: string | null
  chapterIds: string[]
  topicIds: string[]
  allowReuse: boolean
  selected: string[]
  onChange: (ids: string[]) => void
  autoFillCount: number
  marksPerQuestion: number
}) {
  const [items, setItems] = useState<QuestionListItem[] | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!subjectId || !examClassId || !codeId) {
      setItems([])
      return
    }
    setLoading(true)
    const params = new URLSearchParams({ subjectId, examClassId, codeId, status: 'ACTIVE', pageSize: '100', excludeUsedInPapers: allowReuse ? 'false' : 'true' })
    if (chapterIds.length === 1 && chapterIds[0]) params.set('chapterId', chapterIds[0])
    if (topicIds.length === 1 && topicIds[0]) params.set('topicId', topicIds[0])
    apiFetch<{ items: QuestionListItem[] }>(`/api/questions?${params.toString()}`)
      .then((res) => {
        const filtered =
          chapterIds.length > 1
            ? res.items.filter((q) => q.chapter && chapterIds.includes(q.chapter.id))
            : res.items
        setItems(topicIds.length > 1 ? filtered.filter((q) => q.topic && topicIds.includes(q.topic.id)) : filtered)
      })
      .catch(() => setItems([]))
      .finally(() => setLoading(false))
  }, [subjectId, examClassId, codeId, chapterIds.join(','), topicIds.join(','), allowReuse])

  function toggle(id: string) {
    onChange(selected.includes(id) ? selected.filter((s) => s !== id) : [...selected, id])
  }

  function move(id: string, dir: -1 | 1) {
    const idx = selected.indexOf(id)
    onChange(arraySwap(selected, idx, idx + dir))
  }

  function autoFill() {
    if (!items) return
    const eligible = items.map((i) => i.id).filter((id) => !selected.includes(id))
    const shuffled = [...eligible].sort(() => Math.random() - 0.5)
    onChange([...selected, ...shuffled.slice(0, Math.max(0, autoFillCount - selected.length))])
  }

  if (!subjectId || !examClassId || !codeId) {
    return <p className="text-xs text-ink-faint">Select Subject, Class/Exam, and Code above first.</p>
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs text-ink-muted">
        <span>
          {selected.length} selected{autoFillCount > 0 ? ` · target ${autoFillCount}` : ''} · ~
          {(selected.length * marksPerQuestion).toFixed(1)} mark(s)
        </span>
        {autoFillCount > 0 && (
          <button className="btn-ghost !px-2 !py-1 text-xs" onClick={autoFill}>
            Auto-fill from eligible questions
          </button>
        )}
      </div>

      {selected.length > 0 && (
        <div className="rounded-md border border-surface-border bg-white">
          {selected.map((id, i) => {
            const q = items?.find((it) => it.id === id)
            return (
              <div key={id} className="flex items-center gap-2 border-b border-surface-border px-2 py-1.5 text-xs last:border-0">
                <span className="w-5 text-ink-faint">{i + 1}.</span>
                <span className="flex-1 truncate">{q ? <MathText text={q.questionText.slice(0, 100)} /> : id}</span>
                <button className="btn-ghost !px-1.5 !py-0.5" disabled={i === 0} onClick={() => move(id, -1)}>
                  ↑
                </button>
                <button className="btn-ghost !px-1.5 !py-0.5" disabled={i === selected.length - 1} onClick={() => move(id, 1)}>
                  ↓
                </button>
                <button className="btn-ghost !px-1.5 !py-0.5 text-danger" onClick={() => toggle(id)}>
                  Remove
                </button>
              </div>
            )
          })}
        </div>
      )}

      <div className="max-h-52 overflow-y-auto rounded-md border border-surface-border bg-surface-subtle">
        {loading && <p className="px-2 py-3 text-xs text-ink-faint">Loading candidates…</p>}
        {items?.length === 0 && !loading && <p className="px-2 py-3 text-xs text-ink-faint">No eligible questions found for this scope.</p>}
        {items?.filter((q) => !selected.includes(q.id)).map((q) => (
          <label key={q.id} className="flex cursor-pointer items-start gap-2 border-b border-surface-border px-2 py-1.5 text-xs last:border-0 hover:bg-white">
            <input type="checkbox" className="mt-0.5" checked={false} onChange={() => toggle(q.id)} />
            <span>
              <span className="font-medium">#{q.questionNumber}</span> <MathText text={q.questionText.slice(0, 120)} />
            </span>
          </label>
        ))}
      </div>
    </div>
  )
}
