'use client'

import { useEffect, useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { apiFetch } from '@/lib/api-client'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { MathText } from '@/components/questions/MathRenderer'
import type { QuestionListItem } from '@/types'

export function AddQuestionModal({
  open,
  onClose,
  onAdd,
  excludeIds,
  single = false,
}: {
  open: boolean
  onClose: () => void
  onAdd: (picked: { id: string }[]) => void
  excludeIds: string[]
  single?: boolean
}) {
  const [query, setQuery] = useState('')
  const debouncedQuery = useDebouncedValue(query, 350)
  const [items, setItems] = useState<QuestionListItem[]>([])
  const [loading, setLoading] = useState(false)
  const [picked, setPicked] = useState<Set<string>>(new Set())

  useEffect(() => {
    if (!open) return
    setLoading(true)
    const params = new URLSearchParams({ status: 'ACTIVE', pageSize: '30' })
    if (debouncedQuery) params.set('q', debouncedQuery)
    apiFetch<{ items: QuestionListItem[] }>(`/api/questions?${params.toString()}`)
      .then((res) => setItems(res.items.filter((i) => !excludeIds.includes(i.id))))
      .finally(() => setLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, debouncedQuery])

  useEffect(() => {
    if (!open) setPicked(new Set())
  }, [open])

  function toggle(id: string) {
    if (single) {
      onAdd([{ id }])
      return
    }
    setPicked((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <Modal open={open} onClose={onClose} title={single ? 'Replace with…' : 'Add questions to paper'} wide>
      <input
        className="input mb-3"
        placeholder="Search by text, ID, or question number…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        autoFocus
      />
      <div className="max-h-96 overflow-y-auto rounded-md border border-surface-border">
        {loading && <p className="p-4 text-sm text-ink-faint">Searching…</p>}
        {!loading && items.length === 0 && <p className="p-4 text-sm text-ink-faint">No matching questions.</p>}
        {items.map((q) => (
          <label key={q.id} className="flex cursor-pointer items-start gap-2 border-b border-surface-border p-2.5 text-sm last:border-0 hover:bg-surface-subtle">
            {!single && (
              <input type="checkbox" className="mt-1" checked={picked.has(q.id)} onChange={() => toggle(q.id)} />
            )}
            <span onClick={() => single && toggle(q.id)}>
              <span className="font-medium">#{q.questionNumber}</span> ({q.subject.label} / {q.examClass.label} / {q.code.label} /{' '}
              {q.difficulty.label}) — <MathText text={q.questionText.slice(0, 140)} />
            </span>
          </label>
        ))}
      </div>
      {!single && (
        <div className="mt-4 flex justify-end gap-2">
          <button className="btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button
            className="btn-primary"
            disabled={picked.size === 0}
            onClick={() => onAdd(Array.from(picked).map((id) => ({ id })))}
          >
            Add {picked.size || ''} question(s)
          </button>
        </div>
      )}
    </Modal>
  )
}
