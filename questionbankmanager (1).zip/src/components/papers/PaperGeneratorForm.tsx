'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { QuestionPickerPanel } from './QuestionPickerPanel'
import type { AvailableCountResult } from '@/types'

type FilterLine = {
  key: string
  subjectId: string | null
  examClassId: string | null
  codeId: string | null
  difficultyId: string | null
  count: number
}

function newLine(): FilterLine {
  return { key: Math.random().toString(36).slice(2), subjectId: null, examClassId: null, codeId: null, difficultyId: null, count: 10 }
}

export function PaperGeneratorForm() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()

  const [title, setTitle] = useState('')
  const [mode, setMode] = useState<'RANDOM' | 'MANUAL'>('RANDOM')
  const [allowReuse, setAllowReuse] = useState(false)
  const [lines, setLines] = useState<FilterLine[]>([newLine()])
  const [availableCounts, setAvailableCounts] = useState<Record<string, AvailableCountResult>>({})
  const [manualSelections, setManualSelections] = useState<Record<string, string[]>>({})

  const [instituteName, setInstituteName] = useState('CUBUS')
  const [examName, setExamName] = useState('')
  const [examDate, setExamDate] = useState('')
  const [examTime, setExamTime] = useState('')
  const [maxMarks, setMaxMarks] = useState<string>('')
  const [instructions, setInstructions] = useState('Answer all questions. Each question carries equal marks unless stated otherwise.')

  const [generating, setGenerating] = useState(false)
  const [shortfalls, setShortfalls] = useState<
    { subject: string; examClass: string; code: string; difficulty: string; requested: number; available: number }[]
    | null
  >(null)

  const completeLine = (l: FilterLine) => l.subjectId && l.examClassId && l.codeId && l.difficultyId

  useEffect(() => {
    const complete = lines.filter(completeLine)
    if (complete.length === 0) {
      setAvailableCounts({})
      return
    }
    const timeout = setTimeout(() => {
      apiFetch<{ items: AvailableCountResult[] }>('/api/papers/available-count', {
        method: 'POST',
        body: JSON.stringify({
          lines: complete.map((l) => ({
            subjectId: l.subjectId,
            examClassId: l.examClassId,
            codeId: l.codeId,
            difficultyId: l.difficultyId,
          })),
          allowReuseOfPastQuestions: allowReuse,
        }),
      })
        .then((res) => {
          const map: Record<string, AvailableCountResult> = {}
          complete.forEach((l, idx) => {
            map[l.key] = res.items[idx]
          })
          setAvailableCounts(map)
        })
        .catch(() => {})
    }, 300)
    return () => clearTimeout(timeout)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(lines.map((l) => [l.subjectId, l.examClassId, l.codeId, l.difficultyId])), allowReuse])

  function updateLine(key: string, patch: Partial<FilterLine>) {
    setLines((prev) => prev.map((l) => (l.key === key ? { ...l, ...patch } : l)))
  }

  function removeLine(key: string) {
    setLines((prev) => prev.filter((l) => l.key !== key))
    setManualSelections((prev) => {
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  async function handleGenerate() {
    setShortfalls(null)
    const complete = lines.filter(completeLine)
    if (complete.length === 0) {
      show('error', 'Add at least one complete Subject/Class/Code/Difficulty filter with a question count.')
      return
    }
    if (!title.trim()) {
      show('error', 'Give the paper a title.')
      return
    }

    let manualQuestionIds: string[] | undefined
    if (mode === 'MANUAL') {
      manualQuestionIds = complete.flatMap((l) => manualSelections[l.key] ?? [])
      const expectedTotal = complete.reduce((sum, l) => sum + l.count, 0)
      if (manualQuestionIds.length !== expectedTotal) {
        show('error', `You've picked ${manualQuestionIds.length} question(s) but specified ${expectedTotal}. Match these before generating.`)
        return
      }
    }

    setGenerating(true)
    try {
      const result = await apiFetch<{ item: { id: string } }>('/api/papers', {
        method: 'POST',
        body: JSON.stringify({
          title,
          mode,
          allowReuseOfPastQuestions: allowReuse,
          lines: complete.map((l) => ({
            subjectId: l.subjectId,
            examClassId: l.examClassId,
            codeId: l.codeId,
            difficultyId: l.difficultyId,
            count: l.count,
          })),
          manualQuestionIds,
          instituteName: instituteName || undefined,
          logoUrl: '/branding/cubus-logo.png',
          examName: examName || undefined,
          examDate: examDate ? new Date(examDate).toISOString() : undefined,
          examTime: examTime || undefined,
          maxMarks: maxMarks ? Number(maxMarks) : undefined,
          instructions: instructions || undefined,
        }),
      })
      show('success', 'Paper generated.')
      router.push(`/papers/${result.item.id}`)
    } catch (err) {
      if (err instanceof ApiError && err.body.code === 'INSUFFICIENT_QUESTIONS' && err.body.shortfalls) {
        setShortfalls(err.body.shortfalls)
      }
      show('error', errorMessage(err))
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="card space-y-4 p-5">
        <h2 className="text-sm font-semibold text-ink">Paper details</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="label">
              Paper Title <span className="text-danger">*</span>
            </label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Physics Unit Test — 11 JEE Code A" />
          </div>
          <div>
            <label className="label">Institute Name</label>
            <input className="input" value={instituteName} onChange={(e) => setInstituteName(e.target.value)} />
          </div>
          <div>
            <label className="label">Exam Name</label>
            <input className="input" value={examName} onChange={(e) => setExamName(e.target.value)} />
          </div>
          <div>
            <label className="label">Maximum Marks</label>
            <input className="input" type="number" value={maxMarks} onChange={(e) => setMaxMarks(e.target.value)} />
          </div>
          <div>
            <label className="label">Date</label>
            <input className="input" type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} />
          </div>
          <div>
            <label className="label">Time</label>
            <input className="input" placeholder="e.g. 10:00 AM – 12:00 PM" value={examTime} onChange={(e) => setExamTime(e.target.value)} />
          </div>
        </div>
        <div>
          <label className="label">Instructions</label>
          <textarea className="input min-h-[70px]" value={instructions} onChange={(e) => setInstructions(e.target.value)} />
        </div>
      </div>

      <div className="card space-y-4 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold text-ink">Question selection</h2>
          <div className="flex items-center gap-4 text-sm">
            <label className="flex items-center gap-1.5">
              <input type="radio" checked={mode === 'RANDOM'} onChange={() => setMode('RANDOM')} /> Random
            </label>
            <label className="flex items-center gap-1.5">
              <input type="radio" checked={mode === 'MANUAL'} onChange={() => setMode('MANUAL')} /> Manual
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={allowReuse} onChange={(e) => setAllowReuse(e.target.checked)} /> Allow
              reuse of questions from previous papers
            </label>
          </div>
        </div>

        {shortfalls && (
          <div className="rounded-md border border-red-300 bg-red-50 p-3 text-sm text-danger">
            <p className="mb-1 font-medium">Not enough questions are available:</p>
            <ul className="ml-4 list-disc space-y-0.5">
              {shortfalls.map((s, i) => (
                <li key={i}>
                  Only {s.available} {s.difficulty.toLowerCase()} {s.subject} questions are available for {s.examClass}{' '}
                  Code {s.code}. You requested {s.requested}.
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="space-y-3">
          {lines.map((line) => {
            const avail = availableCounts[line.key]
            const short = completeLine(line) && avail && avail.available < line.count
            return (
              <div key={line.key} className="rounded-md border border-surface-border p-3">
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-6">
                  <SearchableSelect label="Subject" options={lookups.subjects} value={line.subjectId} onChange={(v) => updateLine(line.key, { subjectId: v })} />
                  <SearchableSelect label="Class / Exam" options={lookups.examClasses} value={line.examClassId} onChange={(v) => updateLine(line.key, { examClassId: v })} />
                  <SearchableSelect label="Code" options={lookups.codes} value={line.codeId} onChange={(v) => updateLine(line.key, { codeId: v })} />
                  <SearchableSelect label="Difficulty" options={lookups.difficultyLevels} value={line.difficultyId} onChange={(v) => updateLine(line.key, { difficultyId: v })} />
                  <div>
                    <label className="label">Count</label>
                    <input
                      type="number"
                      min={0}
                      className="input"
                      value={line.count}
                      onChange={(e) => updateLine(line.key, { count: Math.max(0, Number(e.target.value)) })}
                    />
                  </div>
                  <div className="flex items-end justify-between">
                    <div className={`text-xs ${short ? 'text-danger' : 'text-ink-muted'}`}>
                      {completeLine(line) ? (avail ? `Available: ${avail.available}` : 'Checking…') : '—'}
                    </div>
                    <button className="btn-ghost !px-2 !py-1 text-danger" onClick={() => removeLine(line.key)}>
                      Remove
                    </button>
                  </div>
                </div>

                {mode === 'MANUAL' && completeLine(line) && (
                  <QuestionPickerPanel
                    subjectId={line.subjectId!}
                    examClassId={line.examClassId!}
                    codeId={line.codeId!}
                    difficultyId={line.difficultyId!}
                    count={line.count}
                    allowReuse={allowReuse}
                    selected={manualSelections[line.key] ?? []}
                    onChange={(ids) => setManualSelections((prev) => ({ ...prev, [line.key]: ids }))}
                  />
                )}
              </div>
            )
          })}
        </div>

        <button className="btn-secondary" onClick={() => setLines((prev) => [...prev, newLine()])}>
          + Add filter line
        </button>
      </div>

      <div className="flex justify-end">
        <button className="btn-primary" onClick={handleGenerate} disabled={generating}>
          {generating ? 'Generating…' : 'Generate Paper'}
        </button>
      </div>
    </div>
  )
}
