'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { MathText } from '@/components/questions/MathRenderer'
import type { QuestionListItem } from '@/types'

/**
 * Manual-mode question picker for one filter line. Lists eligible ACTIVE
 * questions matching the line's tags (excluding previously-used ones unless
 * reuse is allowed) and lets the user check exactly `count` of them.
 */
export function QuestionPickerPanel({
  subjectId,
  examClassId,
  codeId,
  difficultyId,
  count,
  allowReuse,
  selected,
  onChange,
}: {
  subjectId: string
  examClassId: string
  codeId: string
  difficultyId: string
  count: number
  allowReuse: boolean
  selected: string[]
  onChange: (ids: string[]) => void
}) {
  const [items, setItems] = useState<QuestionListItem[] | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    const params = new URLSearchParams({
      subjectId,
      examClassId,
      codeId,
      difficultyId,
      status: 'ACTIVE',
      pageSize: '100',
      excludeUsedInPapers: allowReuse ? 'false' : 'true',
    })
    apiFetch<{ items: QuestionListItem[] }>(`/api/questions?${params.toString()}`)
      .then((res) => setItems(res.items))
      .catch(() => setItems([]))
      .finally(() => setLoading(false))
  }, [subjectId, examClassId, codeId, difficultyId, allowReuse])

  function toggle(id: string) {
    if (selected.includes(id)) {
      onChange(selected.filter((s) => s !== id))
    } else {
      if (selected.length >= count) return
      onChange([...selected, id])
    }
  }

  return (
    <div className="mt-3 rounded-md border border-surface-border bg-surface-subtle p-2">
      <div className="mb-1.5 flex items-center justify-between text-xs text-ink-muted">
        <span>Pick exactly {count} question(s)</span>
        <span className={selected.length === count ? 'text-success' : 'text-warning'}>{selected.length} / {count} selected</span>
      </div>
      {loading && <p className="px-2 py-3 text-xs text-ink-faint">Loading candidates…</p>}
      <div className="max-h-52 overflow-y-auto rounded bg-white">
        {items?.length === 0 && <p className="px-2 py-3 text-xs text-ink-faint">No eligible questions found.</p>}
        {items?.map((q) => (
          <label key={q.id} className="flex cursor-pointer items-start gap-2 border-b border-surface-border px-2 py-1.5 text-xs last:border-0 hover:bg-surface-subtle">
            <input
              type="checkbox"
              className="mt-0.5"
              checked={selected.includes(q.id)}
              disabled={!selected.includes(q.id) && selected.length >= count}
              onChange={() => toggle(q.id)}
            />
            <span>
              <span className="font-medium">#{q.questionNumber}</span>{' '}
              <MathText text={q.questionText.slice(0, 120)} />
            </span>
          </label>
        ))}
      </div>
    </div>
  )
}
