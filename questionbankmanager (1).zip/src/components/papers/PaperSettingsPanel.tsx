'use client'

import { useEffect, useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'

// Mirrors prisma/schema.prisma's PaperSettings model — see
// src/lib/validation/paperSettings.ts (server-side validation) and
// src/lib/pdf/paperHtml.ts's PaperLayoutSettings (render-time application)
// for the same shape.
export type PaperSettingsData = {
  pageSize: 'A4' | 'LETTER' | 'LEGAL'
  orientation: 'PORTRAIT' | 'LANDSCAPE'
  marginTopMm: number
  marginBottomMm: number
  marginLeftMm: number
  marginRightMm: number
  columns: number
  columnGapMm: number
  showHeader: boolean
  showFooter: boolean
  showPageNumbers: boolean
  fontFamily: string
  fontSizePt: number
  lineSpacing: number
  questionSpacingPx: number
  imageQualityPercent: number
  maxImageWidthMm: number
  imageAlignment: 'LEFT' | 'CENTER' | 'RIGHT'
  questionNumberingStyle: 'PLAIN' | 'Q_PREFIX' | 'LETTERED'
  marksDisplayStyle: 'BRACKET_MARKS' | 'PAREN_NUMBER' | 'BRACKET_NUMBER'
}

export function PaperSettingsPanel({
  paperId,
  open,
  onClose,
  onSaved,
}: {
  paperId: string
  open: boolean
  onClose: () => void
  onSaved?: (settings: PaperSettingsData) => void
}) {
  const { show } = useToast()
  const [settings, setSettings] = useState<PaperSettingsData | null>(null)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    setLoading(true)
    apiFetch<{ item: PaperSettingsData }>(`/api/papers/${paperId}/settings`)
      .then((res) => {
        if (!cancelled) setSettings(res.item)
      })
      .catch((err) => show('error', errorMessage(err)))
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, paperId])

  function set<K extends keyof PaperSettingsData>(key: K, value: PaperSettingsData[K]) {
    setSettings((s) => (s ? { ...s, [key]: value } : s))
  }

  async function handleSave() {
    if (!settings) return
    setSaving(true)
    try {
      const res = await apiFetch<{ item: PaperSettingsData }>(`/api/papers/${paperId}/settings`, {
        method: 'PATCH',
        body: JSON.stringify(settings),
      })
      setSettings(res.item)
      onSaved?.(res.item)
      show('success', 'Paper settings saved — used the next time this paper is printed or exported.')
      onClose()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Paper Settings" wide>
      {loading || !settings ? (
        <p className="py-8 text-center text-sm text-ink-faint">Loading…</p>
      ) : (
        <div className="space-y-6">
          <Section title="Page">
            <SelectField
              label="Page Size"
              value={settings.pageSize}
              onChange={(v) => set('pageSize', v as PaperSettingsData['pageSize'])}
              options={[
                ['A4', 'A4'],
                ['LETTER', 'Letter'],
                ['LEGAL', 'Legal'],
              ]}
            />
            <SelectField
              label="Orientation"
              value={settings.orientation}
              onChange={(v) => set('orientation', v as PaperSettingsData['orientation'])}
              options={[
                ['PORTRAIT', 'Portrait'],
                ['LANDSCAPE', 'Landscape'],
              ]}
            />
            <NumberField label="Margin Top (mm)" value={settings.marginTopMm} onChange={(v) => set('marginTopMm', v)} min={0} max={60} />
            <NumberField
              label="Margin Bottom (mm)"
              value={settings.marginBottomMm}
              onChange={(v) => set('marginBottomMm', v)}
              min={0}
              max={60}
            />
            <NumberField label="Margin Left (mm)" value={settings.marginLeftMm} onChange={(v) => set('marginLeftMm', v)} min={0} max={60} />
            <NumberField
              label="Margin Right (mm)"
              value={settings.marginRightMm}
              onChange={(v) => set('marginRightMm', v)}
              min={0}
              max={60}
            />
          </Section>

          <Section title="Layout">
            <SelectField
              label="Columns"
              value={String(settings.columns)}
              onChange={(v) => set('columns', Number(v))}
              options={[
                ['1', '1 column'],
                ['2', '2 columns'],
                ['3', '3 columns'],
              ]}
            />
            <NumberField label="Column Gap (mm)" value={settings.columnGapMm} onChange={(v) => set('columnGapMm', v)} min={0} max={30} />
            <CheckboxField label="Show header band" checked={settings.showHeader} onChange={(v) => set('showHeader', v)} />
            <CheckboxField label="Show footer band" checked={settings.showFooter} onChange={(v) => set('showFooter', v)} />
            <CheckboxField
              label="Show page numbers"
              checked={settings.showPageNumbers}
              onChange={(v) => set('showPageNumbers', v)}
            />
          </Section>

          <Section title="Typography">
            <TextField label="Font Family" value={settings.fontFamily} onChange={(v) => set('fontFamily', v)} />
            <NumberField label="Font Size (pt)" value={settings.fontSizePt} onChange={(v) => set('fontSizePt', v)} min={7} max={24} step={0.5} />
            <NumberField label="Line Spacing" value={settings.lineSpacing} onChange={(v) => set('lineSpacing', v)} min={1} max={3} step={0.1} />
            <NumberField
              label="Question Spacing (px)"
              value={settings.questionSpacingPx}
              onChange={(v) => set('questionSpacingPx', v)}
              min={0}
              max={60}
            />
          </Section>

          <Section title="Images">
            <NumberField
              label="Image Quality (%)"
              value={settings.imageQualityPercent}
              onChange={(v) => set('imageQualityPercent', v)}
              min={10}
              max={100}
            />
            <NumberField
              label="Max Image Width (mm)"
              value={settings.maxImageWidthMm}
              onChange={(v) => set('maxImageWidthMm', v)}
              min={10}
              max={180}
            />
            <SelectField
              label="Image Alignment"
              value={settings.imageAlignment}
              onChange={(v) => set('imageAlignment', v as PaperSettingsData['imageAlignment'])}
              options={[
                ['LEFT', 'Left'],
                ['CENTER', 'Center'],
                ['RIGHT', 'Right'],
              ]}
            />
          </Section>

          <Section title="Numbering & Marks (Advanced Paper Builder)">
            <SelectField
              label="Question Numbering"
              value={settings.questionNumberingStyle}
              onChange={(v) => set('questionNumberingStyle', v as PaperSettingsData['questionNumberingStyle'])}
              options={[
                ['PLAIN', '1, 2, 3'],
                ['Q_PREFIX', 'Q1, Q2, Q3'],
                ['LETTERED', '1(a), 1(b), 1(c)'],
              ]}
            />
            <SelectField
              label="Marks Display"
              value={settings.marksDisplayStyle}
              onChange={(v) => set('marksDisplayStyle', v as PaperSettingsData['marksDisplayStyle'])}
              options={[
                ['BRACKET_MARKS', '[2 Marks]'],
                ['PAREN_NUMBER', '(2)'],
                ['BRACKET_NUMBER', '[2]'],
              ]}
            />
          </Section>

          <div className="flex justify-end gap-2 border-t border-surface-border pt-4">
            <button className="btn-secondary" onClick={onClose} disabled={saving}>
              Cancel
            </button>
            <button className="btn-primary" onClick={handleSave} disabled={saving}>
              {saving ? 'Saving…' : 'Save Settings'}
            </button>
          </div>
        </div>
      )}
    </Modal>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-2 text-sm font-semibold text-ink">{title}</h3>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">{children}</div>
    </div>
  )
}

function NumberField({
  label,
  value,
  onChange,
  min,
  max,
  step = 1,
}: {
  label: string
  value: number
  onChange: (v: number) => void
  min?: number
  max?: number
  step?: number
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <input
        className="input"
        type="number"
        value={value}
        min={min}
        max={max}
        step={step}
        onChange={(e) => {
          const v = Number(e.target.value)
          if (!Number.isNaN(v)) onChange(v)
        }}
      />
    </div>
  )
}

function TextField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="label">{label}</label>
      <input className="input" type="text" value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  )
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  options: [string, string][]
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <select className="input" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map(([v, l]) => (
          <option key={v} value={v}>
            {l}
          </option>
        ))}
      </select>
    </div>
  )
}

function CheckboxField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-2 text-sm text-ink">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4" />
      {label}
    </label>
  )
}
