'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { Pagination } from '@/components/ui/Pagination'
import type { PaperFolderItem, PaperListItem } from '@/types'
import type { FolderSelection } from './FolderSidebar'

type ListResponse = { items: PaperListItem[]; page: number; pageSize: number; total: number; totalPages: number }

export function PaperListClient({
  folderFilter,
  folders,
  canMove = false,
  onPaperMoved,
}: {
  /** Undefined = show every paper (folders feature not in use on this screen). */
  folderFilter?: FolderSelection
  /** Needed to populate the per-row "Move to…" dropdown. */
  folders?: PaperFolderItem[]
  canMove?: boolean
  onPaperMoved?: () => void
} = {}) {
  const { show } = useToast()
  const [page, setPage] = useState(1)
  const [data, setData] = useState<ListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [movingId, setMovingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(page) })
      if (folderFilter?.kind === 'folder') params.set('folderId', folderFilter.id)
      else if (folderFilter?.kind === 'uncategorized') params.set('folderId', 'none')
      const result = await apiFetch<ListResponse>(`/api/papers?${params.toString()}`)
      setData(result)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, folderFilter?.kind, folderFilter?.kind === 'folder' ? folderFilter.id : undefined])

  useEffect(() => {
    setPage(1)
  }, [folderFilter?.kind, folderFilter?.kind === 'folder' ? folderFilter.id : undefined])

  useEffect(() => {
    load()
  }, [load])

  async function handleMove(paperId: string, folderId: string | null) {
    setMovingId(paperId)
    try {
      await apiFetch(`/api/papers/${paperId}/move`, { method: 'POST', body: JSON.stringify({ folderId }) })
      show('success', 'Paper moved.')
      load()
      onPaperMoved?.()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setMovingId(null)
    }
  }

  return (
    <div className="card overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-surface-border bg-surface-subtle text-left text-xs uppercase tracking-wide text-ink-faint">
            <tr>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">Title</th>
              <th className="px-3 py-2">Mode</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Questions</th>
              {folders && <th className="px-3 py-2">Folder</th>}
              <th className="px-3 py-2">Created By</th>
              <th className="px-3 py-2">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-surface-border">
            {loading && (
              <tr>
                <td colSpan={8} className="px-3 py-8 text-center text-ink-faint">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && data?.items.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-8 text-center text-ink-faint">
                  No papers here yet.
                </td>
              </tr>
            )}
            {!loading &&
              data?.items.map((p) => (
                <tr key={p.id} className="hover:bg-surface-subtle">
                  <td className="px-3 py-3 text-ink-faint">{p.paperNumber}</td>
                  <td className="px-3 py-3">
                    <Link href={`/papers/${p.id}`} className="font-medium text-ink hover:text-brand-600">
                      {p.title}
                    </Link>
                  </td>
                  <td className="px-3 py-3 text-ink-muted">{p.mode}</td>
                  <td className="px-3 py-3">
                    <span className={`badge ${p.status === 'FINAL' ? 'bg-green-100 text-green-800' : 'bg-surface-muted text-ink-muted'}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-ink-muted">{p.questionCount}</td>
                  {folders && (
                    <td className="px-3 py-3">
                      {canMove ? (
                        <select
                          className="input !h-8 !py-0 text-xs"
                          value={p.folder?.id ?? ''}
                          disabled={movingId === p.id}
                          onChange={(e) => handleMove(p.id, e.target.value || null)}
                        >
                          <option value="">Uncategorized</option>
                          {folders.map((f) => (
                            <option key={f.id} value={f.id}>
                              {f.name}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <span className="text-ink-muted">{p.folder?.name ?? 'Uncategorized'}</span>
                      )}
                    </td>
                  )}
                  <td className="px-3 py-3 text-ink-muted">{p.createdBy.fullName ?? p.createdBy.email}</td>
                  <td className="px-3 py-3 text-ink-faint">{new Date(p.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      {data && (
        <Pagination page={data.page} totalPages={data.totalPages} total={data.total} pageSize={data.pageSize} onPageChange={setPage} />
      )}
    </div>
  )
}
