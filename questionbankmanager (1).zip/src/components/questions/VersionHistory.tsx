'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { MathText } from './MathRenderer'

type VersionItem = {
  id: string
  versionNumber: number
  questionText: string
  changeNote: string | null
  createdAt: string
  createdBy: { fullName: string | null; email: string }
}

export function VersionHistory({ questionId }: { questionId: string }) {
  const [versions, setVersions] = useState<VersionItem[] | null>(null)
  const [expanded, setExpanded] = useState<string | null>(null)

  useEffect(() => {
    apiFetch<{ items: VersionItem[] }>(`/api/questions/${questionId}/versions`)
      .then((res) => setVersions(res.items))
      .catch(() => setVersions([]))
  }, [questionId])

  return (
    <div className="card h-fit p-5">
      <h2 className="mb-3 text-sm font-semibold text-ink">Version History</h2>
      {!versions && <p className="text-sm text-ink-faint">Loading…</p>}
      {versions && versions.length === 0 && <p className="text-sm text-ink-faint">No history yet.</p>}
      <ul className="space-y-2">
        {versions?.map((v) => (
          <li key={v.id} className="rounded-md border border-surface-border p-2.5 text-xs">
            <button
              className="flex w-full items-center justify-between text-left"
              onClick={() => setExpanded(expanded === v.id ? null : v.id)}
            >
              <span className="font-medium text-ink">Version {v.versionNumber}</span>
              <span className="text-ink-faint">{new Date(v.createdAt).toLocaleString()}</span>
            </button>
            <p className="mt-1 text-ink-faint">
              {v.createdBy.fullName ?? v.createdBy.email}
              {v.changeNote ? ` — ${v.changeNote}` : ''}
            </p>
            {expanded === v.id && (
              <div className="mt-2 rounded bg-surface-subtle p-2 text-ink">
                <MathText text={v.questionText} />
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  )
}
