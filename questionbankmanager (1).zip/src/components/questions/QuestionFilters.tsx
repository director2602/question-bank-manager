'use client'

import type { Lookups } from '@/hooks/useLookups'

export type QuestionFilterState = {
  q: string
  subjectId: string
  examClassId: string
  codeId: string
  difficultyId: string
  questionNumber: string
  chapterId: string
  topicId: string
  questionType: string
}

export const EMPTY_FILTERS: QuestionFilterState = {
  q: '',
  subjectId: '',
  examClassId: '',
  codeId: '',
  difficultyId: '',
  questionNumber: '',
  chapterId: '',
  topicId: '',
  questionType: '',
}

export function QuestionFilters({
  lookups,
  value,
  onChange,
}: {
  lookups: Lookups
  value: QuestionFilterState
  onChange: (next: QuestionFilterState) => void
}) {
  const set = <K extends keyof QuestionFilterState>(key: K, v: QuestionFilterState[K]) =>
    onChange({ ...value, [key]: v })

  // Chapter options narrow to the selected Subject; Topic options narrow to
  // the selected Chapter — same cascading relationship as the Add Question
  // form, so filtering follows the same mental model as tagging.
  const chapterOptions = value.subjectId
    ? lookups.chapters.filter((c) => c.subjectId === value.subjectId)
    : lookups.chapters
  const topicOptions = value.chapterId
    ? lookups.topics.filter((t) => t.chapterId === value.chapterId)
    : []

  function setSubject(v: string) {
    onChange({ ...value, subjectId: v, chapterId: '', topicId: '' })
  }
  function setChapter(v: string) {
    onChange({ ...value, chapterId: v, topicId: '' })
  }

  return (
    <div className="card grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-6">
      <div className="lg:col-span-2">
        <label className="label">Search</label>
        <input
          className="input"
          placeholder="Question text, ID, or number…"
          value={value.q}
          onChange={(e) => set('q', e.target.value)}
        />
      </div>
      <div>
        <label className="label">Subject</label>
        <select className="input" value={value.subjectId} onChange={(e) => setSubject(e.target.value)}>
          <option value="">All</option>
          {lookups.subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Class / Exam</label>
        <select className="input" value={value.examClassId} onChange={(e) => set('examClassId', e.target.value)}>
          <option value="">All</option>
          {lookups.examClasses.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Chapter</label>
        <select className="input" value={value.chapterId} onChange={(e) => setChapter(e.target.value)}>
          <option value="">All</option>
          {chapterOptions.map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Topic</label>
        <select className="input" value={value.topicId} onChange={(e) => set('topicId', e.target.value)} disabled={!value.chapterId}>
          <option value="">All</option>
          {topicOptions.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Code</label>
        <select className="input" value={value.codeId} onChange={(e) => set('codeId', e.target.value)}>
          <option value="">All</option>
          {lookups.codes.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Difficulty</label>
        <select className="input" value={value.difficultyId} onChange={(e) => set('difficultyId', e.target.value)}>
          <option value="">All</option>
          {lookups.difficultyLevels.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Question Type</label>
        <select className="input" value={value.questionType} onChange={(e) => set('questionType', e.target.value)}>
          <option value="">All</option>
          <option value="MCQ">MCQ</option>
          <option value="SUBJECTIVE">Subjective</option>
          <option value="INTEGER">Integer</option>
        </select>
      </div>
    </div>
  )
}
