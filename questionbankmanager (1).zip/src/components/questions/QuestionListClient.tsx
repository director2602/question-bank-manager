'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { apiFetch } from '@/lib/api-client'
import { useLookups } from '@/hooks/useLookups'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { QuestionFilters, EMPTY_FILTERS, type QuestionFilterState } from './QuestionFilters'
import { MathText } from './MathRenderer'
import { DifficultyBadge, StatusBadge, Tag } from '@/components/ui/Badge'
import { Pagination } from '@/components/ui/Pagination'
import { ConfirmDialog } from '@/components/ui/Modal'
import { useToast, errorMessage } from '@/components/ui/Toast'
import type { QuestionListItem } from '@/types'
import { BulkTagEditModal } from './BulkTagEditModal'

type ListResponse = {
  items: QuestionListItem[]
  page: number
  pageSize: number
  total: number
  totalPages: number
}

export function QuestionListClient({ status }: { status: 'ACTIVE' | 'ARCHIVED' }) {
  const { lookups } = useLookups()
  const { show } = useToast()
  const [filters, setFilters] = useState<QuestionFilterState>(EMPTY_FILTERS)
  const debouncedQ = useDebouncedValue(filters.q)
  const [page, setPage] = useState(1)
  const [data, setData] = useState<ListResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [confirmTarget, setConfirmTarget] = useState<{ id: string; action: 'archive' | 'restore' | 'delete' } | null>(
    null
  )
  const [bulkEditOpen, setBulkEditOpen] = useState(false)
  const [busyId, setBusyId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('status', status)
      params.set('page', String(page))
      if (debouncedQ) params.set('q', debouncedQ)
      if (filters.subjectId) params.set('subjectId', filters.subjectId)
      if (filters.examClassId) params.set('examClassId', filters.examClassId)
      if (filters.codeId) params.set('codeId', filters.codeId)
      if (filters.difficultyId) params.set('difficultyId', filters.difficultyId)
      const result = await apiFetch<ListResponse>(`/api/questions?${params.toString()}`)
      setData(result)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, page, debouncedQ, filters.subjectId, filters.examClassId, filters.codeId, filters.difficultyId])

  useEffect(() => {
    setPage(1)
  }, [debouncedQ, filters.subjectId, filters.examClassId, filters.codeId, filters.difficultyId, status])

  useEffect(() => {
    load()
  }, [load])

  async function handleConfirmedAction() {
    if (!confirmTarget) return
    setBusyId(confirmTarget.id)
    try {
      if (confirmTarget.action === 'archive') {
        await apiFetch(`/api/questions/${confirmTarget.id}/archive`, { method: 'POST' })
        show('success', 'Question archived.')
      } else if (confirmTarget.action === 'restore') {
        await apiFetch(`/api/questions/${confirmTarget.id}/restore`, { method: 'POST' })
        show('success', 'Question restored.')
      } else {
        await apiFetch(`/api/questions/${confirmTarget.id}`, { method: 'DELETE' })
        show('success', 'Question permanently deleted.')
      }
      setConfirmTarget(null)
      load()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusyId(null)
    }
  }

  async function handleDuplicate(id: string) {
    setBusyId(id)
    try {
      const result = await apiFetch<{ item: { id: string } }>(`/api/questions/${id}/duplicate`, { method: 'POST' })
      show('success', 'Question duplicated. Opening the copy…')
      window.location.href = `/questions/${result.item.id}`
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusyId(null)
    }
  }

  function toggleSelected(id: string) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div className="space-y-4">
      <QuestionFilters lookups={lookups} value={filters} onChange={setFilters} />

      {selected.size > 0 && (
        <div className="flex items-center justify-between rounded-md border border-brand-200 bg-brand-50 px-4 py-2 text-sm">
          <span className="text-brand-800">{selected.size} question(s) selected</span>
          <div className="flex gap-2">
            <button className="btn-secondary !py-1" onClick={() => setBulkEditOpen(true)}>
              Bulk edit tags
            </button>
            <button className="btn-ghost !py-1" onClick={() => setSelected(new Set())}>
              Clear
            </button>
          </div>
        </div>
      )}

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-surface-border bg-surface-subtle text-left text-xs uppercase tracking-wide text-ink-faint">
              <tr>
                <th className="px-3 py-2">
                  <input
                    type="checkbox"
                    checked={!!data && data.items.length > 0 && data.items.every((i) => selected.has(i.id))}
                    onChange={(e) => {
                      if (!data) return
                      setSelected(e.target.checked ? new Set(data.items.map((i) => i.id)) : new Set())
                    }}
                  />
                </th>
                <th className="px-3 py-2">No.</th>
                <th className="px-3 py-2">Question</th>
                <th className="px-3 py-2">Tags</th>
                <th className="px-3 py-2">Status</th>
                <th className="px-3 py-2">Created</th>
                <th className="px-3 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-border">
              {loading && (
                <tr>
                  <td colSpan={7} className="px-3 py-8 text-center text-ink-faint">
                    Loading…
                  </td>
                </tr>
              )}
              {!loading && data?.items.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-3 py-8 text-center text-ink-faint">
                    No questions match your filters.
                  </td>
                </tr>
              )}
              {!loading &&
                data?.items.map((q) => (
                  <tr key={q.id} className="align-top hover:bg-surface-subtle">
                    <td className="px-3 py-3">
                      <input type="checkbox" checked={selected.has(q.id)} onChange={() => toggleSelected(q.id)} />
                    </td>
                    <td className="px-3 py-3 font-medium text-ink">{q.questionNumber}</td>
                    <td className="max-w-md px-3 py-3">
                      <Link href={`/questions/${q.id}`} className="line-clamp-2 text-ink hover:text-brand-600">
                        <MathText text={q.questionText} />
                      </Link>
                      {q.hasImages && <span className="mt-1 block text-xs text-ink-faint">📷 Contains image(s)</span>}
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex flex-wrap gap-1">
                        <Tag>{q.subject.label}</Tag>
                        <Tag>{q.examClass.label}</Tag>
                        <Tag>{q.code.label}</Tag>
                        <DifficultyBadge code={q.difficulty.code} label={q.difficulty.label} />
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <StatusBadge status={q.status} />
                    </td>
                    <td className="px-3 py-3 text-ink-faint">{new Date(q.createdAt).toLocaleDateString()}</td>
                    <td className="px-3 py-3">
                      <div className="flex justify-end gap-1.5 whitespace-nowrap">
                        <Link href={`/questions/${q.id}`} className="btn-ghost !px-2 !py-1">
                          View
                        </Link>
                        <button
                          className="btn-ghost !px-2 !py-1"
                          disabled={busyId === q.id}
                          onClick={() => handleDuplicate(q.id)}
                        >
                          Duplicate
                        </button>
                        {status === 'ACTIVE' ? (
                          <button
                            className="btn-ghost !px-2 !py-1 text-danger"
                            disabled={busyId === q.id}
                            onClick={() => setConfirmTarget({ id: q.id, action: 'archive' })}
                          >
                            Archive
                          </button>
                        ) : (
                          <>
                            <button
                              className="btn-ghost !px-2 !py-1"
                              disabled={busyId === q.id}
                              onClick={() => setConfirmTarget({ id: q.id, action: 'restore' })}
                            >
                              Restore
                            </button>
                            <button
                              className="btn-ghost !px-2 !py-1 text-danger"
                              disabled={busyId === q.id}
                              onClick={() => setConfirmTarget({ id: q.id, action: 'delete' })}
                            >
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        {data && (
          <Pagination
            page={data.page}
            totalPages={data.totalPages}
            total={data.total}
            pageSize={data.pageSize}
            onPageChange={setPage}
          />
        )}
      </div>

      <ConfirmDialog
        open={!!confirmTarget}
        title={
          confirmTarget?.action === 'archive'
            ? 'Archive question?'
            : confirmTarget?.action === 'restore'
              ? 'Restore question?'
              : 'Permanently delete question?'
        }
        message={
          confirmTarget?.action === 'delete'
            ? 'This cannot be undone. Questions used in any paper cannot be deleted — archive them instead.'
            : confirmTarget?.action === 'archive'
              ? 'Archived questions are hidden from search and paper generation but can be restored at any time.'
              : 'This question will become available for search and paper generation again.'
        }
        danger={confirmTarget?.action === 'delete'}
        confirmLabel={
          confirmTarget?.action === 'archive' ? 'Archive' : confirmTarget?.action === 'restore' ? 'Restore' : 'Delete'
        }
        loading={!!busyId}
        onCancel={() => setConfirmTarget(null)}
        onConfirm={handleConfirmedAction}
      />

      <BulkTagEditModal
        open={bulkEditOpen}
        onClose={() => setBulkEditOpen(false)}
        questionIds={Array.from(selected)}
        lookups={lookups}
        onDone={() => {
          setBulkEditOpen(false)
          setSelected(new Set())
          load()
        }}
      />
    </div>
  )
}
