'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { MathText } from './MathRenderer'
import { ImageUploader, type UploadedImage } from './ImageUploader'
import { DifficultyBadge, StatusBadge, Tag } from '@/components/ui/Badge'
import { ConfirmDialog } from '@/components/ui/Modal'
import type { QuestionDetail } from '@/types'
import type { RoleCode } from '@prisma/client'
import { VersionHistory } from './VersionHistory'

export function QuestionDetailClient({ initial, role }: { initial: QuestionDetail; role: RoleCode }) {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()
  const [question, setQuestion] = useState(initial)
  const canEdit = role === 'ADMIN' || role === 'EDITOR'
  const canDelete = role === 'ADMIN'

  const [editingTags, setEditingTags] = useState(false)
  const [tagForm, setTagForm] = useState({
    subjectId: initial.subject.id,
    examClassId: initial.examClass.id,
    codeId: initial.code.id,
    difficultyId: initial.difficulty.id,
    questionNumber: initial.questionNumber,
  })
  const [savingTags, setSavingTags] = useState(false)

  const [editingContent, setEditingContent] = useState(false)
  const [contentForm, setContentForm] = useState({
    questionText: initial.questionText,
    optionA: initial.optionA ?? '',
    optionB: initial.optionB ?? '',
    optionC: initial.optionC ?? '',
    optionD: initial.optionD ?? '',
    correctAnswer: initial.correctAnswer ?? '',
    explanation: initial.explanation ?? '',
    changeNote: '',
  })
  const [newImages, setNewImages] = useState<UploadedImage[]>([])
  const [savingContent, setSavingContent] = useState(false)
  const [conflict, setConflict] = useState<string | null>(null)
  const [confirmArchive, setConfirmArchive] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [busy, setBusy] = useState(false)

  async function reload() {
    const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}`)
    setQuestion(result.item)
    setConflict(null)
  }

  async function saveTags() {
    setSavingTags(true)
    try {
      const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}/tags`, {
        method: 'PATCH',
        body: JSON.stringify({ ...tagForm, rowVersion: question.rowVersion }),
      })
      setQuestion(result.item)
      setEditingTags(false)
      show('success', 'Tags updated.')
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setConflict(err.body.error)
      } else {
        show('error', errorMessage(err))
      }
    } finally {
      setSavingTags(false)
    }
  }

  async function saveContent() {
    setSavingContent(true)
    try {
      const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}/content`, {
        method: 'PATCH',
        body: JSON.stringify({
          ...contentForm,
          rowVersion: question.rowVersion,
          imageIds: newImages.map((i) => i.id),
        }),
      })
      setQuestion(result.item)
      setEditingContent(false)
      setNewImages([])
      show('success', `Saved as version ${result.item.versionNumber}. The previous version remains in history.`)
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setConflict(err.body.error)
      } else {
        show('error', errorMessage(err))
      }
    } finally {
      setSavingContent(false)
    }
  }

  async function handleArchive() {
    setBusy(true)
    try {
      await apiFetch(`/api/questions/${question.id}/archive`, { method: 'POST' })
      show('success', 'Question archived.')
      router.push('/questions')
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusy(false)
      setConfirmArchive(false)
    }
  }

  async function handleDelete() {
    setBusy(true)
    try {
      await apiFetch(`/api/questions/${question.id}`, { method: 'DELETE' })
      show('success', 'Question permanently deleted.')
      router.push('/questions')
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusy(false)
      setConfirmDelete(false)
    }
  }

  async function handleDuplicate() {
    setBusy(true)
    try {
      const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}/duplicate`, {
        method: 'POST',
      })
      show('success', 'Duplicated. Opening the copy…')
      router.push(`/questions/${result.item.id}`)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold text-ink">Question #{question.questionNumber}</h1>
            <StatusBadge status={question.status} />
          </div>
          <p className="text-sm text-ink-muted">
            v{question.versionNumber} · Created by {question.createdBy.fullName ?? question.createdBy.email} on{' '}
            {new Date(question.createdAt).toLocaleDateString()}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/questions" className="btn-secondary">
            Back to list
          </Link>
          {canEdit && (
            <button className="btn-secondary" onClick={handleDuplicate} disabled={busy}>
              Duplicate
            </button>
          )}
          {canEdit && question.status === 'ACTIVE' && (
            <button className="btn-secondary" onClick={() => setConfirmArchive(true)}>
              Archive
            </button>
          )}
          {canDelete && (
            <button className="btn-danger" onClick={() => setConfirmDelete(true)}>
              Delete
            </button>
          )}
        </div>
      </div>

      {conflict && (
        <div className="rounded-md border border-red-300 bg-red-50 px-4 py-3 text-sm text-danger">
          {conflict}{' '}
          <button className="ml-2 font-medium underline" onClick={reload}>
            Reload latest version
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Tags</h2>
            {canEdit && !editingTags && (
              <button className="btn-ghost !px-2 !py-1" onClick={() => setEditingTags(true)}>
                Edit tags
              </button>
            )}
          </div>
          {!editingTags ? (
            <div className="flex flex-wrap gap-1.5">
              <Tag>{question.subject.label}</Tag>
              <Tag>{question.examClass.label}</Tag>
              <Tag>{question.code.label}</Tag>
              <DifficultyBadge code={question.difficulty.code} label={question.difficulty.label} />
            </div>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <SearchableSelect
                  label="Subject"
                  options={lookups.subjects}
                  value={tagForm.subjectId}
                  onChange={(v) => setTagForm((f) => ({ ...f, subjectId: v }))}
                />
                <SearchableSelect
                  label="Class / Exam"
                  options={lookups.examClasses}
                  value={tagForm.examClassId}
                  onChange={(v) => setTagForm((f) => ({ ...f, examClassId: v }))}
                />
                <SearchableSelect
                  label="Code"
                  options={lookups.codes}
                  value={tagForm.codeId}
                  onChange={(v) => setTagForm((f) => ({ ...f, codeId: v }))}
                />
                <SearchableSelect
                  label="Difficulty"
                  options={lookups.difficultyLevels}
                  value={tagForm.difficultyId}
                  onChange={(v) => setTagForm((f) => ({ ...f, difficultyId: v }))}
                />
              </div>
              <div className="w-40">
                <label className="label">Question No.</label>
                <input
                  className="input"
                  value={tagForm.questionNumber}
                  onChange={(e) => setTagForm((f) => ({ ...f, questionNumber: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <button className="btn-secondary" onClick={() => setEditingTags(false)} disabled={savingTags}>
                  Cancel
                </button>
                <button className="btn-primary" onClick={saveTags} disabled={savingTags}>
                  {savingTags ? 'Saving…' : 'Save Tags'}
                </button>
              </div>
            </div>
          )}

          <hr className="my-4 border-surface-border" />

          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Content</h2>
            {canEdit && !editingContent && (
              <button className="btn-ghost !px-2 !py-1" onClick={() => setEditingContent(true)}>
                Edit content manually
              </button>
            )}
          </div>

          {editingContent && (
            <div className="mb-3 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-warning">
              You are manually editing the original question. Saving creates a new version — the current version
              stays in history and any papers already generated keep showing the version they used.
            </div>
          )}

          {!editingContent ? (
            <div className="space-y-3 text-sm">
              <p>
                <MathText text={question.questionText} />
              </p>
              {question.images.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {question.images.map((img) => (
                    <img key={img.id} src={img.url} alt={img.fileName} className="max-h-48 rounded-md border border-surface-border" />
                  ))}
                </div>
              )}
              <ul className="ml-4 space-y-1">
                {(['optionA', 'optionB', 'optionC', 'optionD'] as const).map(
                  (key, idx) =>
                    question[key] && (
                      <li key={key}>
                        <strong>{['A', 'B', 'C', 'D'][idx]}.</strong> <MathText text={question[key]} />
                      </li>
                    )
                )}
              </ul>
              {question.correctAnswer && (
                <p className="text-ink-muted">
                  <strong>Correct answer:</strong> {question.correctAnswer}
                </p>
              )}
              {question.explanation && (
                <p className="text-ink-muted">
                  <strong>Explanation:</strong> <MathText text={question.explanation} />
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="label">Question Text</label>
                <textarea
                  className="input min-h-[100px]"
                  value={contentForm.questionText}
                  onChange={(e) => setContentForm((f) => ({ ...f, questionText: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {(['optionA', 'optionB', 'optionC', 'optionD'] as const).map((key, idx) => (
                  <div key={key}>
                    <label className="label">Option {['A', 'B', 'C', 'D'][idx]}</label>
                    <input
                      className="input"
                      value={contentForm[key]}
                      onChange={(e) => setContentForm((f) => ({ ...f, [key]: e.target.value }))}
                    />
                  </div>
                ))}
              </div>
              <div>
                <label className="label">Correct Answer</label>
                <input
                  className="input w-40"
                  value={contentForm.correctAnswer}
                  onChange={(e) => setContentForm((f) => ({ ...f, correctAnswer: e.target.value }))}
                />
              </div>
              <div>
                <label className="label">Explanation</label>
                <textarea
                  className="input min-h-[70px]"
                  value={contentForm.explanation}
                  onChange={(e) => setContentForm((f) => ({ ...f, explanation: e.target.value }))}
                />
              </div>
              <ImageUploader images={newImages} onChange={setNewImages} />
              <div>
                <label className="label">Reason for this edit (optional, recorded in history)</label>
                <input
                  className="input"
                  value={contentForm.changeNote}
                  onChange={(e) => setContentForm((f) => ({ ...f, changeNote: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <button className="btn-secondary" onClick={() => setEditingContent(false)} disabled={savingContent}>
                  Cancel
                </button>
                <button className="btn-primary" onClick={saveContent} disabled={savingContent}>
                  {savingContent ? 'Saving…' : 'Save New Version'}
                </button>
              </div>
            </div>
          )}
        </div>

        <VersionHistory questionId={question.id} />
      </div>

      <ConfirmDialog
        open={confirmArchive}
        title="Archive this question?"
        message="Archived questions are hidden from search and paper generation but can be restored at any time."
        confirmLabel="Archive"
        loading={busy}
        onCancel={() => setConfirmArchive(false)}
        onConfirm={handleArchive}
      />
      <ConfirmDialog
        open={confirmDelete}
        title="Permanently delete this question?"
        message="This cannot be undone. Questions used in any paper cannot be deleted — archive them instead."
        danger
        confirmLabel="Delete"
        loading={busy}
        onCancel={() => setConfirmDelete(false)}
        onConfirm={handleDelete}
      />
    </div>
  )
}
