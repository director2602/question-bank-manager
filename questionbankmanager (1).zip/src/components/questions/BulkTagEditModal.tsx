'use client'

import { useState } from 'react'
import { Modal } from '@/components/ui/Modal'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import type { Lookups } from '@/hooks/useLookups'

export function BulkTagEditModal({
  open,
  onClose,
  questionIds,
  lookups,
  onDone,
}: {
  open: boolean
  onClose: () => void
  questionIds: string[]
  lookups: Lookups
  onDone: () => void
}) {
  const { show } = useToast()
  const [subjectId, setSubjectId] = useState<string | null>(null)
  const [examClassId, setExamClassId] = useState<string | null>(null)
  const [codeId, setCodeId] = useState<string | null>(null)
  const [difficultyId, setDifficultyId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  async function handleSave() {
    if (!subjectId && !examClassId && !codeId && !difficultyId) {
      show('error', 'Choose at least one tag to apply.')
      return
    }
    setSaving(true)
    try {
      const result = await apiFetch<{ updatedCount: number }>('/api/questions/bulk-tag-edit', {
        method: 'POST',
        body: JSON.stringify({
          questionIds,
          ...(subjectId ? { subjectId } : {}),
          ...(examClassId ? { examClassId } : {}),
          ...(codeId ? { codeId } : {}),
          ...(difficultyId ? { difficultyId } : {}),
        }),
      })
      show('success', `Updated tags on ${result.updatedCount} question(s).`)
      onDone()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={`Bulk edit tags (${questionIds.length} selected)`}>
      <p className="mb-4 text-sm text-ink-muted">
        Only the tags you set below will be changed. This never touches the question text, options, or answers of
        any selected question.
      </p>
      <div className="grid grid-cols-2 gap-3">
        <SearchableSelect label="Subject" options={lookups.subjects} value={subjectId} onChange={setSubjectId} />
        <SearchableSelect
          label="Class / Exam"
          options={lookups.examClasses}
          value={examClassId}
          onChange={setExamClassId}
        />
        <SearchableSelect label="Code" options={lookups.codes} value={codeId} onChange={setCodeId} />
        <SearchableSelect
          label="Difficulty"
          options={lookups.difficultyLevels}
          value={difficultyId}
          onChange={setDifficultyId}
        />
      </div>
      <div className="mt-6 flex justify-end gap-2">
        <button className="btn-secondary" onClick={onClose} disabled={saving}>
          Cancel
        </button>
        <button className="btn-primary" onClick={handleSave} disabled={saving}>
          {saving ? 'Applying…' : 'Apply to selected'}
        </button>
      </div>
    </Modal>
  )
}
