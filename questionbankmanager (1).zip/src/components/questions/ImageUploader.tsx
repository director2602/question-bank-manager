'use client'

import { useRef, useState } from 'react'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'

export type UploadedImage = { id: string; fileName: string; url: string; optionSlot?: 'A' | 'B' | 'C' | 'D' | null }

/**
 * Uploads images as-is (no client-side recompression) ahead of question
 * save. Images are already stored server-side by the time they show up
 * here; removing one before the question is saved deletes the orphaned
 * storage object too (see DELETE /api/questions/images/:imageId).
 *
 * `optionSlot` tags the image as illustrating one specific MCQ option
 * (A/B/C/D) instead of the question as a whole — pass it when rendering
 * this uploader under an individual option, and every uploaded image is
 * tagged at upload time so no other code needs to know about slots at all
 * (question create/edit/CSV/PDF/handwritten-import all just attach by id).
 */
export function ImageUploader({
  images,
  onChange,
  optionSlot,
  compact = false,
  label = 'Images / Diagrams',
}: {
  images: UploadedImage[]
  onChange: (next: UploadedImage[]) => void
  optionSlot?: 'A' | 'B' | 'C' | 'D'
  compact?: boolean
  label?: string
}) {
  const { show } = useToast()
  const inputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const thumbSize = compact ? 'h-14 w-14' : 'h-24 w-24'

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return
    setUploading(true)
    try {
      for (const file of Array.from(files)) {
        const formData = new FormData()
        formData.append('file', file)
        if (optionSlot) formData.append('optionSlot', optionSlot)
        const result = await apiFetch<{ item: UploadedImage }>('/api/questions/images', {
          method: 'POST',
          body: formData,
        })
        onChange([...images, result.item])
      }
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setUploading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  async function handleRemove(id: string) {
    try {
      await apiFetch(`/api/questions/images/${id}`, { method: 'DELETE' })
    } catch (err) {
      if (!(err instanceof ApiError && err.status === 409)) {
        show('error', errorMessage(err))
        return
      }
    }
    onChange(images.filter((i) => i.id !== id))
  }

  return (
    <div>
      {!compact && <label className="label">{label}</label>}
      <div className="flex flex-wrap gap-2">
        {images.map((img) => (
          <div key={img.id} className="relative">
            <img src={img.url} alt={img.fileName} className={`${thumbSize} rounded-md border border-surface-border object-cover`} />
            <button
              type="button"
              onClick={() => handleRemove(img.id)}
              className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-danger text-xs text-white"
              aria-label={`Remove ${img.fileName}`}
            >
              ✕
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className={`flex ${thumbSize} flex-col items-center justify-center rounded-md border border-dashed border-surface-border text-center text-[11px] text-ink-muted hover:border-brand-400 hover:text-brand-600`}
        >
          {uploading ? 'Uploading…' : compact ? '+ Image' : '+ Add image'}
        </button>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/svg+xml"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      {!compact && (
        <p className="mt-1 text-xs text-ink-faint">PNG, JPEG, WEBP, or SVG. Stored at original quality — never recompressed.</p>
      )}
    </div>
  )
}
