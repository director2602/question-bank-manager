'use client'

import { useRef, useState } from 'react'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'

export type UploadedImage = { id: string; fileName: string; url: string }

/**
 * Uploads images as-is (no client-side recompression) ahead of question
 * save. Images are already stored server-side by the time they show up
 * here; removing one before the question is saved deletes the orphaned
 * storage object too (see DELETE /api/questions/images/:imageId).
 */
export function ImageUploader({
  images,
  onChange,
}: {
  images: UploadedImage[]
  onChange: (next: UploadedImage[]) => void
}) {
  const { show } = useToast()
  const inputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return
    setUploading(true)
    try {
      for (const file of Array.from(files)) {
        const formData = new FormData()
        formData.append('file', file)
        const result = await apiFetch<{ item: UploadedImage }>('/api/questions/images', {
          method: 'POST',
          body: formData,
        })
        onChange([...images, result.item])
      }
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setUploading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  async function handleRemove(id: string) {
    try {
      await apiFetch(`/api/questions/images/${id}`, { method: 'DELETE' })
    } catch (err) {
      if (!(err instanceof ApiError && err.status === 409)) {
        show('error', errorMessage(err))
        return
      }
    }
    onChange(images.filter((i) => i.id !== id))
  }

  return (
    <div>
      <label className="label">Images / Diagrams</label>
      <div className="flex flex-wrap gap-3">
        {images.map((img) => (
          <div key={img.id} className="relative">
            <img src={img.url} alt={img.fileName} className="h-24 w-24 rounded-md border border-surface-border object-cover" />
            <button
              type="button"
              onClick={() => handleRemove(img.id)}
              className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-danger text-xs text-white"
              aria-label={`Remove ${img.fileName}`}
            >
              ✕
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="flex h-24 w-24 flex-col items-center justify-center rounded-md border border-dashed border-surface-border text-xs text-ink-muted hover:border-brand-400 hover:text-brand-600"
        >
          {uploading ? 'Uploading…' : '+ Add image'}
        </button>
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/svg+xml"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      <p className="mt-1 text-xs text-ink-faint">PNG, JPEG, WEBP, or SVG. Stored at original quality — never recompressed.</p>
    </div>
  )
}
