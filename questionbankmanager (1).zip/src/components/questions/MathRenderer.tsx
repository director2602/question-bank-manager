'use client'

import { useMemo } from 'react'
import katex from 'katex'
import 'katex/dist/katex.min.css'

/**
 * Renders text that may contain inline LaTeX delimited by $...$ (and
 * \(...\)), using KaTeX. Plain text (the overwhelming majority of
 * questions) passes through completely unchanged — this NEVER alters the
 * underlying stored text, it only affects how it's displayed.
 */
export function MathText({ text, className }: { text: string | null | undefined; className?: string }) {
  const html = useMemo(() => renderMathSegments(text ?? ''), [text])
  return <span className={className} dangerouslySetInnerHTML={{ __html: html }} />
}

function renderMathSegments(text: string): string {
  const escaped = escapeHtml(text)
  const pattern = /\$([^$]+)\$|\\\(([^)]+)\\\)/g
  return escaped.replace(pattern, (match, dollarExpr, parenExpr) => {
    const expr = dollarExpr ?? parenExpr
    try {
      return katex.renderToString(expr, { throwOnError: false, output: 'html' })
    } catch {
      return match
    }
  })
}

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\n/g, '<br/>')
}
