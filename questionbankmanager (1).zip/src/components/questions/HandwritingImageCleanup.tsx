'use client'

import { useRef, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { Modal } from '@/components/ui/Modal'
import type { UploadedImage } from './ImageUploader'

type ProcessResult = { dataUrl: string; mimeType: string; width: number; height: number }

/**
 * Companion to ImageUploader for a specific case: a photo of a handwritten
 * diagram/note taken with a phone camera — uneven lighting, shadows, paper
 * grain — that needs cleaning up before it looks like a proper digital
 * image. Runs the photo through the deterministic image-processing pipeline
 * (see lib/image-processing/localProcessor.ts) server-side, shows Original
 * vs Processed side by side, and only uploads/attaches the result to the
 * question once the user confirms with "Use Image" — reusing the exact same
 * upload endpoint (and therefore the exact same storage/DB record shape)
 * that ImageUploader already uses for a normal image attachment.
 */
export function HandwritingImageCleanup({
  images,
  onChange,
}: {
  images: UploadedImage[]
  onChange: (next: UploadedImage[]) => void
}) {
  const { show } = useToast()
  const inputRef = useRef<HTMLInputElement>(null)
  const [open, setOpen] = useState(false)
  const [originalFile, setOriginalFile] = useState<File | null>(null)
  const [originalPreviewUrl, setOriginalPreviewUrl] = useState<string | null>(null)
  const [processed, setProcessed] = useState<ProcessResult | null>(null)
  const [processing, setProcessing] = useState(false)
  const [saving, setSaving] = useState(false)

  function reset() {
    if (originalPreviewUrl) URL.revokeObjectURL(originalPreviewUrl)
    setOriginalFile(null)
    setOriginalPreviewUrl(null)
    setProcessed(null)
    setProcessing(false)
    setSaving(false)
    if (inputRef.current) inputRef.current.value = ''
  }

  function closeModal() {
    setOpen(false)
    reset()
  }

  async function runProcessing(file: File) {
    setProcessing(true)
    setProcessed(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const result = await apiFetch<{ item: ProcessResult }>('/api/images/process', {
        method: 'POST',
        body: formData,
      })
      setProcessed(result.item)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setProcessing(false)
    }
  }

  async function handlePick(files: FileList | null) {
    const file = files?.[0]
    if (!file) return
    reset()
    setOriginalFile(file)
    setOriginalPreviewUrl(URL.createObjectURL(file))
    setOpen(true)
    await runProcessing(file)
  }

  async function handleUseImage() {
    if (!processed) return
    setSaving(true)
    try {
      const blob = await (await fetch(processed.dataUrl)).blob()
      const cleanedFile = new File([blob], (originalFile?.name || 'handwritten-image').replace(/\.[^.]+$/, '') + '-cleaned.png', {
        type: processed.mimeType,
      })
      const formData = new FormData()
      formData.append('file', cleanedFile)
      const result = await apiFetch<{ item: UploadedImage }>('/api/questions/images', {
        method: 'POST',
        body: formData,
      })
      onChange([...images, result.item])
      show('success', 'Cleaned image added.')
      closeModal()
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="btn-secondary text-xs"
      >
        Clean up a handwritten photo
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => handlePick(e.target.files)}
      />

      <Modal open={open} onClose={closeModal} title="Clean up handwritten image" wide>
        {originalPreviewUrl && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <p className="label mb-1">Original</p>
                <div className="flex h-56 items-center justify-center overflow-hidden rounded-md border border-surface-border bg-surface-subtle">
                  {/* Original file preview — plain object URL, not processed. */}
                  <img src={originalPreviewUrl} alt="Original upload" className="max-h-full max-w-full object-contain" />
                </div>
              </div>
              <div>
                <p className="label mb-1">Processed</p>
                <div className="flex h-56 items-center justify-center overflow-hidden rounded-md border border-surface-border bg-surface-subtle">
                  {processing && <span className="text-xs text-ink-faint">Processing…</span>}
                  {!processing && processed && (
                    <img src={processed.dataUrl} alt="Processed result" className="max-h-full max-w-full object-contain" />
                  )}
                  {!processing && !processed && <span className="text-xs text-ink-faint">Processing failed.</span>}
                </div>
                {processed && (
                  <p className="mt-1 text-xs text-ink-faint">
                    {processed.width} × {processed.height}px
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-2 border-t border-surface-border pt-4">
              <button type="button" className="btn-ghost" onClick={closeModal} disabled={saving}>
                Cancel
              </button>
              <button
                type="button"
                className="btn-secondary"
                disabled={processing || saving || !originalFile}
                onClick={() => originalFile && runProcessing(originalFile)}
              >
                {processing ? 'Regenerating…' : 'Regenerate'}
              </button>
              <button
                type="button"
                className="btn-primary"
                disabled={processing || saving || !processed}
                onClick={handleUseImage}
              >
                {saving ? 'Adding…' : 'Use Image'}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
