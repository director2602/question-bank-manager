'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { useEffect, useMemo } from 'react'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { CreatableSelect } from '@/components/ui/CreatableSelect'
import { slugCode } from '@/lib/slugCode'
import { ImageUploader, type UploadedImage } from './ImageUploader'
import { HandwritingImageCleanup } from './HandwritingImageCleanup'
import { MathText } from './MathRenderer'
import type { QuestionListItem } from '@/types'

type QuestionType = 'MCQ' | 'SUBJECTIVE' | 'INTEGER'

type FormState = {
  // Tags, in the exact required order: Subject → Class/Exam → Chapter →
  // Topic → Code → Difficulty → Question No.
  subjectId: string | null
  examClassId: string | null
  chapterId: string | null
  topicId: string | null
  codeId: string | null
  difficultyId: string | null
  questionNumber: string
  // Content
  questionType: QuestionType
  questionText: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: string
  explanation: string
  markingScheme: string
}

const EMPTY_CONTENT: Pick<
  FormState,
  'questionNumber' | 'questionType' | 'questionText' | 'optionA' | 'optionB' | 'optionC' | 'optionD' | 'correctAnswer' | 'explanation' | 'markingScheme'
> = {
  questionNumber: '',
  questionType: 'MCQ',
  questionText: '',
  optionA: '',
  optionB: '',
  optionC: '',
  optionD: '',
  correctAnswer: '',
  explanation: '',
  markingScheme: '',
}

// Rapid Question Entry: each tag can independently be "kept" across
// "+ Add Another Question" so a teacher entering many questions from one
// topic doesn't have to re-pick it every time — but Code/Difficulty/
// Question No keep their existing always-persist behavior (unchanged),
// since only Subject/Class/Chapter/Topic were called out by name.
type KeepState = { subject: boolean; examClass: boolean; chapter: boolean; topic: boolean }
const DEFAULT_KEEP: KeepState = { subject: true, examClass: true, chapter: true, topic: true }

export function QuestionForm() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()

  const [form, setForm] = useState<FormState>({
    subjectId: null,
    examClassId: null,
    chapterId: null,
    topicId: null,
    codeId: null,
    difficultyId: null,
    ...EMPTY_CONTENT,
  })
  const [keep, setKeep] = useState<KeepState>(DEFAULT_KEEP)
  const [images, setImages] = useState<UploadedImage[]>([])
  // Per-option images (MCQ only) — an option can be a diagram/figure
  // instead of only text. Each slot uploads through the same
  // /api/questions/images endpoint, tagged with its letter at upload time,
  // and all four merge into one imageIds list on submit alongside the
  // general question images — the server doesn't need separate handling.
  const [optionImages, setOptionImages] = useState<Record<'A' | 'B' | 'C' | 'D', UploadedImage[]>>({
    A: [],
    B: [],
    C: [],
    D: [],
  })
  const [showPreview, setShowPreview] = useState(false)
  const [saving, setSaving] = useState(false)
  const [duplicates, setDuplicates] = useState<QuestionListItem[] | null>(null)
  const [checkingDuplicates, setCheckingDuplicates] = useState(false)
  const [suggestingNumber, setSuggestingNumber] = useState(false)

  const debouncedText = useDebouncedValue(form.questionText, 600)

  useEffect(() => {
    if (!debouncedText || debouncedText.trim().length < 12) {
      setDuplicates(null)
      return
    }
    let cancelled = false
    setCheckingDuplicates(true)
    apiFetch<{ hasDuplicates: boolean; candidates: QuestionListItem[] }>('/api/questions/check-duplicate', {
      method: 'POST',
      body: JSON.stringify({ questionText: debouncedText, subjectId: form.subjectId || undefined }),
    })
      .then((res) => {
        if (!cancelled) setDuplicates(res.hasDuplicates ? res.candidates : null)
      })
      .catch(() => {
        // Non-blocking — duplicate detection is a helpful warning, not a
        // hard requirement, so a failed check should never block entry.
      })
      .finally(() => {
        if (!cancelled) setCheckingDuplicates(false)
      })
    return () => {
      cancelled = true
    }
  }, [debouncedText, form.subjectId])

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  // Subject → Class/Exam → Chapter → Topic dependency chain: changing
  // Subject clears Chapter/Topic (a chapter belongs to exactly one
  // subject); changing Chapter clears Topic (a topic belongs to exactly
  // one chapter) — never leaves a stale, mismatched selection in place.
  function setSubject(v: string | null) {
    setForm((f) => ({ ...f, subjectId: v, chapterId: null, topicId: null }))
  }
  function setChapter(v: string | null) {
    setForm((f) => ({ ...f, chapterId: v, topicId: null }))
  }

  const chapterOptions = useMemo(
    () => (form.subjectId ? lookups.chapters.filter((c) => c.subjectId === form.subjectId) : []),
    [lookups.chapters, form.subjectId]
  )
  const topicOptions = useMemo(
    () => (form.chapterId ? lookups.topics.filter((t) => t.chapterId === form.chapterId) : []),
    [lookups.topics, form.chapterId]
  )

  async function createChapter(label: string): Promise<{ id: string; label: string } | null> {
    if (!form.subjectId) return null
    try {
      const res = await apiFetch<{ item: { id: string } }>('/api/chapters', {
        method: 'POST',
        body: JSON.stringify({ subjectId: form.subjectId, code: slugCode(label, 'CH'), label }),
      })
      show('success', `Chapter "${label}" added.`)
      return { id: res.item.id, label }
    } catch (err) {
      show('error', errorMessage(err))
      return null
    }
  }

  async function createTopic(label: string): Promise<{ id: string; label: string } | null> {
    if (!form.chapterId) return null
    try {
      const res = await apiFetch<{ item: { id: string } }>('/api/topics', {
        method: 'POST',
        body: JSON.stringify({ chapterId: form.chapterId, code: slugCode(label, 'TP'), label }),
      })
      show('success', `Topic "${label}" added.`)
      return { id: res.item.id, label }
    } catch (err) {
      show('error', errorMessage(err))
      return null
    }
  }

  async function suggestNumber() {
    if (!form.subjectId) {
      show('error', 'Select a Subject first.')
      return
    }
    setSuggestingNumber(true)
    try {
      const params = new URLSearchParams({ subjectId: form.subjectId })
      if (form.examClassId) params.set('examClassId', form.examClassId)
      if (form.chapterId) params.set('chapterId', form.chapterId)
      if (form.difficultyId) params.set('difficultyId', form.difficultyId)
      const res = await apiFetch<{ suggestion: string }>(`/api/questions/suggest-number?${params.toString()}`)
      set('questionNumber', res.suggestion)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSuggestingNumber(false)
    }
  }

  function validate(): string | null {
    if (!form.subjectId || !form.examClassId || !form.codeId || !form.difficultyId) {
      return 'Please select Subject, Class/Exam, Code, and Difficulty.'
    }
    if (!form.questionNumber.trim()) return 'Question number is required.'
    if (!form.questionText.trim()) return 'Question text is required.'
    if (form.questionType === 'INTEGER' && form.correctAnswer.trim() && !/^-?\d+$/.test(form.correctAnswer.trim())) {
      return 'Integer Answer must be a whole number (e.g. 0, 5, 12, -4) — decimals are not allowed.'
    }
    return null
  }

  async function submit(confirmDespiteDuplicateWarning: boolean, addAnother: boolean) {
    const validationError = validate()
    if (validationError) {
      show('error', validationError)
      return
    }
    setSaving(true)
    try {
      const result = await apiFetch<{ item?: QuestionListItem; duplicateWarning?: boolean; candidates?: QuestionListItem[] }>(
        '/api/questions',
        {
          method: 'POST',
          body: JSON.stringify({
            ...form,
            imageIds: [...images, ...optionImages.A, ...optionImages.B, ...optionImages.C, ...optionImages.D].map(
              (i) => i.id
            ),
            confirmDespiteDuplicateWarning,
          }),
        }
      )

      if (result.duplicateWarning) {
        setDuplicates(result.candidates ?? [])
        show('info', 'Similar question(s) found — review below, then save again to confirm.')
        return
      }

      show('success', `Question ${form.questionNumber} saved.`)

      if (addAnother) {
        setForm((f) => ({
          ...f,
          ...EMPTY_CONTENT,
          subjectId: keep.subject ? f.subjectId : null,
          examClassId: keep.examClass ? f.examClassId : null,
          chapterId: keep.chapter ? f.chapterId : null,
          topicId: keep.topic ? f.topicId : null,
        }))
        setImages([])
        setOptionImages({ A: [], B: [], C: [], D: [] })
        setDuplicates(null)
      } else if (result.item) {
        router.push(`/questions/${result.item.id}`)
      }
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="card space-y-4 p-5 lg:col-span-2">
        {/* ── 1. ADD QUESTION — the question editor ─────────────────── */}
        <h2 className="text-sm font-semibold text-ink">1. Add Question</h2>
        <p className="text-xs text-ink-faint">
          Enter the question exactly as it should appear. Nothing here is auto-corrected or reformatted. Wrap math in
          $...$ for rendering, e.g. <code>$x^2 + 1$</code>.
        </p>

        <div>
          <label className="label">Question Type</label>
          <div className="flex gap-4">
            {(['MCQ', 'SUBJECTIVE', 'INTEGER'] as QuestionType[]).map((t) => (
              <label key={t} className="flex items-center gap-1.5 text-sm">
                <input
                  type="radio"
                  name="questionType"
                  checked={form.questionType === t}
                  onChange={() => set('questionType', t)}
                />
                {t === 'MCQ' ? 'MCQ' : t === 'SUBJECTIVE' ? 'Subjective' : 'Integer'}
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="label">
            Question Text <span className="text-danger">*</span>
          </label>
          <textarea
            className="input min-h-[110px]"
            value={form.questionText}
            onChange={(e) => set('questionText', e.target.value)}
          />
          {checkingDuplicates && <p className="mt-1 text-xs text-ink-faint">Checking for similar questions…</p>}
        </div>

        {duplicates && duplicates.length > 0 && (
          <div className="rounded-md border border-amber-300 bg-amber-50 p-3">
            <p className="text-sm font-medium text-warning">A similar question already exists.</p>
            <ul className="mt-2 space-y-1.5">
              {duplicates.slice(0, 3).map((d) => (
                <li key={d.id} className="text-xs text-ink-muted">
                  <span className="font-medium text-ink">#{d.questionNumber}</span> —{' '}
                  <MathText text={d.questionText.slice(0, 140)} />
                </li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-ink-muted">
              Review the existing question above. If this is genuinely different, click &ldquo;Save anyway&rdquo;
              below.
            </p>
          </div>
        )}

        {form.questionType === 'MCQ' && (
          <>
            <p className="text-xs text-ink-faint">
              An option can be text, an image (a diagram/figure as the option itself), or both.
            </p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {(['A', 'B', 'C', 'D'] as const).map((letter) => {
                const key = `option${letter}` as 'optionA' | 'optionB' | 'optionC' | 'optionD'
                return (
                  <div key={letter}>
                    <label className="label">Option {letter}</label>
                    <input className="input" value={form[key]} onChange={(e) => set(key, e.target.value)} />
                    <div className="mt-1.5">
                      <ImageUploader
                        compact
                        optionSlot={letter}
                        images={optionImages[letter]}
                        onChange={(next) => setOptionImages((prev) => ({ ...prev, [letter]: next }))}
                      />
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Correct Answer</label>
                <input
                  className="input"
                  placeholder="e.g. A"
                  value={form.correctAnswer}
                  onChange={(e) => set('correctAnswer', e.target.value)}
                />
              </div>
              <div>
                <label className="label">Marks</label>
                <p className="pt-2 text-xs text-ink-faint">Set per-paper when this question is placed in a section.</p>
              </div>
            </div>
            <div>
              <label className="label">Explanation</label>
              <textarea className="input min-h-[80px]" value={form.explanation} onChange={(e) => set('explanation', e.target.value)} />
            </div>
          </>
        )}

        {form.questionType === 'INTEGER' && (
          <>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Integer Answer</label>
                <input
                  className="input"
                  placeholder="e.g. 0, 5, 12, -4 (no decimals)"
                  value={form.correctAnswer}
                  onChange={(e) => set('correctAnswer', e.target.value)}
                />
                {form.correctAnswer.trim() && !/^-?\d+$/.test(form.correctAnswer.trim()) && (
                  <p className="mt-1 text-xs text-danger">Must be a whole number — decimals are not allowed.</p>
                )}
              </div>
            </div>
            <div>
              <label className="label">Explanation</label>
              <textarea className="input min-h-[80px]" value={form.explanation} onChange={(e) => set('explanation', e.target.value)} />
            </div>
          </>
        )}

        {form.questionType === 'SUBJECTIVE' && (
          <>
            <div>
              <label className="label">Expected Answer</label>
              <p className="mb-1 text-xs text-ink-faint">Internal only — never shown on the student paper.</p>
              <textarea className="input min-h-[70px]" value={form.correctAnswer} onChange={(e) => set('correctAnswer', e.target.value)} />
            </div>
            <div>
              <label className="label">Marking Scheme</label>
              <p className="mb-1 text-xs text-ink-faint">
                Internal only — never shown on the student paper. Answer space on the printed paper is configured per
                paper section (Advanced Paper Builder), not per question.
              </p>
              <textarea className="input min-h-[70px]" value={form.markingScheme} onChange={(e) => set('markingScheme', e.target.value)} />
            </div>
          </>
        )}

        <ImageUploader images={images} onChange={setImages} />
        <HandwritingImageCleanup images={images} onChange={setImages} />

        <hr className="border-surface-border" />

        {/* ── 2–8. Tag fields, in the exact required order ──────────── */}
        <h2 className="text-sm font-semibold text-ink">Tags</h2>
        <div>
          <label className="label">
            2. Subject <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.subjects} value={form.subjectId} onChange={setSubject} />
        </div>
        <div>
          <label className="label">
            3. Class / Exam <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.examClasses} value={form.examClassId} onChange={(v) => set('examClassId', v)} />
        </div>
        <div>
          <label className="label">4. Chapter Name</label>
          <CreatableSelect
            options={chapterOptions}
            value={form.chapterId}
            disabled={!form.subjectId}
            placeholder={form.subjectId ? 'Type a chapter name…' : 'Select a Subject first'}
            onSelectExisting={setChapter}
            onClear={() => setChapter(null)}
            onCreateNew={createChapter}
          />
          {!form.subjectId && <p className="mt-1 text-xs text-ink-faint">Select a Subject first.</p>}
        </div>
        <div>
          <label className="label">5. Topic Name</label>
          <CreatableSelect
            options={topicOptions}
            value={form.topicId}
            disabled={!form.chapterId}
            placeholder={form.chapterId ? 'Type a topic name…' : 'Select a Chapter first'}
            onSelectExisting={(id) => set('topicId', id)}
            onClear={() => set('topicId', null)}
            onCreateNew={createTopic}
          />
          {!form.chapterId && <p className="mt-1 text-xs text-ink-faint">Select a Chapter first.</p>}
        </div>
        <div>
          <label className="label">
            6. Code <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.codes} value={form.codeId} onChange={(v) => set('codeId', v)} />
        </div>
        <div>
          <label className="label">
            7. Difficulty <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.difficultyLevels} value={form.difficultyId} onChange={(v) => set('difficultyId', v)} />
        </div>
        <div className="sm:w-2/3">
          <label className="label">
            8. Question No <span className="text-danger">*</span>
          </label>
          <div className="flex gap-2">
            <input
              className="input flex-1"
              placeholder="e.g. 27, Q-25, or MATH10-QE-NOR-001"
              value={form.questionNumber}
              onChange={(e) => set('questionNumber', e.target.value)}
            />
            <button type="button" className="btn-secondary whitespace-nowrap" onClick={suggestNumber} disabled={suggestingNumber}>
              {suggestingNumber ? 'Generating…' : 'Auto-generate'}
            </button>
          </div>
        </div>

        <hr className="border-surface-border" />

        <div>
          <h2 className="mb-2 text-sm font-semibold text-ink">Rapid Question Entry</h2>
          <p className="mb-2 text-xs text-ink-faint">
            When checked, this tag stays selected after &ldquo;Save &amp; Add Another&rdquo; — handy for entering many
            questions from the same topic in a row.
          </p>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.subject} onChange={(e) => setKeep((k) => ({ ...k, subject: e.target.checked }))} />
              Keep Subject
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.examClass} onChange={(e) => setKeep((k) => ({ ...k, examClass: e.target.checked }))} />
              Keep Class / Exam
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.chapter} onChange={(e) => setKeep((k) => ({ ...k, chapter: e.target.checked }))} />
              Keep Chapter
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.topic} onChange={(e) => setKeep((k) => ({ ...k, topic: e.target.checked }))} />
              Keep Topic
            </label>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-surface-border pt-4">
          <button type="button" className="btn-ghost" onClick={() => setShowPreview((p) => !p)}>
            {showPreview ? 'Hide preview' : 'Preview'}
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              className="btn-secondary"
              disabled={saving}
              onClick={() => submit(duplicates !== null, true)}
            >
              {saving ? 'Saving…' : duplicates ? 'Save anyway & Add Another' : '+ Add Another Question'}
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={saving}
              onClick={() => submit(duplicates !== null, false)}
            >
              {saving ? 'Saving…' : duplicates ? 'Save anyway' : 'Save Question'}
            </button>
          </div>
        </div>
      </div>

      {showPreview && (
        <div className="card h-fit p-5">
          <h2 className="mb-3 text-sm font-semibold text-ink">Preview</h2>
          <div className="space-y-2 text-sm">
            <p className="font-medium">
              Q{form.questionNumber || '—'}. <MathText text={form.questionText || 'Question text will appear here.'} />
            </p>
            {form.questionType === 'MCQ' && (
              <ul className="ml-4 space-y-1.5">
                {(['A', 'B', 'C', 'D'] as const).map((letter) => {
                  const opt = form[`option${letter}` as 'optionA' | 'optionB' | 'optionC' | 'optionD']
                  const imgs = optionImages[letter]
                  if (!opt && imgs.length === 0) return null
                  return (
                    <li key={letter}>
                      <strong>{letter}.</strong> {opt && <MathText text={opt} />}
                      {imgs.length > 0 && (
                        <div className="mt-1 flex flex-wrap gap-1.5">
                          {imgs.map((img) => (
                            <img key={img.id} src={img.url} alt={img.fileName} className="h-16 w-16 rounded border border-surface-border object-cover" />
                          ))}
                        </div>
                      )}
                    </li>
                  )
                })}
              </ul>
            )}
            {images.map((img) => (
              <img key={img.id} src={img.url} alt={img.fileName} className="max-h-56 rounded-md border border-surface-border" />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
