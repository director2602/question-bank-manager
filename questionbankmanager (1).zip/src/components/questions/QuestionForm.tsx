'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { useEffect, useMemo } from 'react'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { ImageUploader, type UploadedImage } from './ImageUploader'
import { HandwritingImageCleanup } from './HandwritingImageCleanup'
import { MathText } from './MathRenderer'
import type { QuestionListItem } from '@/types'

type QuestionType = 'MCQ' | 'SUBJECTIVE' | 'INTEGER'

type FormState = {
  // Tags, in the exact required order: Subject → Class/Exam → Chapter →
  // Topic → Code → Difficulty → Question No.
  subjectId: string | null
  examClassId: string | null
  chapterId: string | null
  topicId: string | null
  codeId: string | null
  difficultyId: string | null
  questionNumber: string
  // Content
  questionType: QuestionType
  questionText: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: string
  explanation: string
  markingScheme: string
}

const EMPTY_CONTENT: Pick<
  FormState,
  'questionNumber' | 'questionType' | 'questionText' | 'optionA' | 'optionB' | 'optionC' | 'optionD' | 'correctAnswer' | 'explanation' | 'markingScheme'
> = {
  questionNumber: '',
  questionType: 'MCQ',
  questionText: '',
  optionA: '',
  optionB: '',
  optionC: '',
  optionD: '',
  correctAnswer: '',
  explanation: '',
  markingScheme: '',
}

// Rapid Question Entry: each tag can independently be "kept" across
// "+ Add Another Question" so a teacher entering many questions from one
// topic doesn't have to re-pick it every time — but Code/Difficulty/
// Question No keep their existing always-persist behavior (unchanged),
// since only Subject/Class/Chapter/Topic were called out by name.
type KeepState = { subject: boolean; examClass: boolean; chapter: boolean; topic: boolean }
const DEFAULT_KEEP: KeepState = { subject: true, examClass: true, chapter: true, topic: true }

export function QuestionForm() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()

  const [form, setForm] = useState<FormState>({
    subjectId: null,
    examClassId: null,
    chapterId: null,
    topicId: null,
    codeId: null,
    difficultyId: null,
    ...EMPTY_CONTENT,
  })
  const [keep, setKeep] = useState<KeepState>(DEFAULT_KEEP)
  const [images, setImages] = useState<UploadedImage[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [saving, setSaving] = useState(false)
  const [duplicates, setDuplicates] = useState<QuestionListItem[] | null>(null)
  const [checkingDuplicates, setCheckingDuplicates] = useState(false)
  const [suggestingNumber, setSuggestingNumber] = useState(false)

  const [creatingChapter, setCreatingChapter] = useState(false)
  const [newChapterName, setNewChapterName] = useState('')
  const [creatingTopic, setCreatingTopic] = useState(false)
  const [newTopicName, setNewTopicName] = useState('')

  const debouncedText = useDebouncedValue(form.questionText, 600)

  useEffect(() => {
    if (!debouncedText || debouncedText.trim().length < 12) {
      setDuplicates(null)
      return
    }
    let cancelled = false
    setCheckingDuplicates(true)
    apiFetch<{ hasDuplicates: boolean; candidates: QuestionListItem[] }>('/api/questions/check-duplicate', {
      method: 'POST',
      body: JSON.stringify({ questionText: debouncedText, subjectId: form.subjectId || undefined }),
    })
      .then((res) => {
        if (!cancelled) setDuplicates(res.hasDuplicates ? res.candidates : null)
      })
      .catch(() => {
        // Non-blocking — duplicate detection is a helpful warning, not a
        // hard requirement, so a failed check should never block entry.
      })
      .finally(() => {
        if (!cancelled) setCheckingDuplicates(false)
      })
    return () => {
      cancelled = true
    }
  }, [debouncedText, form.subjectId])

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  // Subject → Class/Exam → Chapter → Topic dependency chain: changing
  // Subject clears Chapter/Topic (a chapter belongs to exactly one
  // subject); changing Chapter clears Topic (a topic belongs to exactly
  // one chapter) — never leaves a stale, mismatched selection in place.
  function setSubject(v: string | null) {
    setForm((f) => ({ ...f, subjectId: v, chapterId: null, topicId: null }))
  }
  function setChapter(v: string | null) {
    setForm((f) => ({ ...f, chapterId: v, topicId: null }))
  }

  const chapterOptions = useMemo(
    () => (form.subjectId ? lookups.chapters.filter((c) => c.subjectId === form.subjectId) : []),
    [lookups.chapters, form.subjectId]
  )
  const topicOptions = useMemo(
    () => (form.chapterId ? lookups.topics.filter((t) => t.chapterId === form.chapterId) : []),
    [lookups.topics, form.chapterId]
  )

  async function createChapter() {
    if (!form.subjectId || !newChapterName.trim()) return
    setCreatingChapter(true)
    try {
      const code = newChapterName.trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_').slice(0, 20) || 'CH'
      const res = await apiFetch<{ item: { id: string } }>('/api/chapters', {
        method: 'POST',
        body: JSON.stringify({ subjectId: form.subjectId, code: `${code}_${Date.now().toString(36)}`, label: newChapterName.trim() }),
      })
      show('success', `Chapter "${newChapterName.trim()}" created.`)
      setNewChapterName('')
      set('chapterId', res.item.id)
      // Lookups won't refetch automatically — the newly created chapter
      // simply won't show up in the dropdown list until reload. This is a
      // known trade-off documented in the summary; the selection itself is
      // still correctly saved on the question.
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setCreatingChapter(false)
    }
  }

  async function createTopic() {
    if (!form.chapterId || !newTopicName.trim()) return
    setCreatingTopic(true)
    try {
      const code = newTopicName.trim().toUpperCase().replace(/[^A-Z0-9]+/g, '_').slice(0, 20) || 'TP'
      const res = await apiFetch<{ item: { id: string } }>('/api/topics', {
        method: 'POST',
        body: JSON.stringify({ chapterId: form.chapterId, code: `${code}_${Date.now().toString(36)}`, label: newTopicName.trim() }),
      })
      show('success', `Topic "${newTopicName.trim()}" created.`)
      setNewTopicName('')
      set('topicId', res.item.id)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setCreatingTopic(false)
    }
  }

  async function suggestNumber() {
    if (!form.subjectId) {
      show('error', 'Select a Subject first.')
      return
    }
    setSuggestingNumber(true)
    try {
      const params = new URLSearchParams({ subjectId: form.subjectId })
      if (form.examClassId) params.set('examClassId', form.examClassId)
      if (form.chapterId) params.set('chapterId', form.chapterId)
      if (form.difficultyId) params.set('difficultyId', form.difficultyId)
      const res = await apiFetch<{ suggestion: string }>(`/api/questions/suggest-number?${params.toString()}`)
      set('questionNumber', res.suggestion)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSuggestingNumber(false)
    }
  }

  function validate(): string | null {
    if (!form.subjectId || !form.examClassId || !form.codeId || !form.difficultyId) {
      return 'Please select Subject, Class/Exam, Code, and Difficulty.'
    }
    if (!form.questionNumber.trim()) return 'Question number is required.'
    if (!form.questionText.trim()) return 'Question text is required.'
    if (form.questionType === 'INTEGER' && form.correctAnswer.trim() && !/^-?\d+$/.test(form.correctAnswer.trim())) {
      return 'Integer Answer must be a whole number (e.g. 0, 5, 12, -4) — decimals are not allowed.'
    }
    return null
  }

  async function submit(confirmDespiteDuplicateWarning: boolean, addAnother: boolean) {
    const validationError = validate()
    if (validationError) {
      show('error', validationError)
      return
    }
    setSaving(true)
    try {
      const result = await apiFetch<{ item?: QuestionListItem; duplicateWarning?: boolean; candidates?: QuestionListItem[] }>(
        '/api/questions',
        {
          method: 'POST',
          body: JSON.stringify({
            ...form,
            imageIds: images.map((i) => i.id),
            confirmDespiteDuplicateWarning,
          }),
        }
      )

      if (result.duplicateWarning) {
        setDuplicates(result.candidates ?? [])
        show('info', 'Similar question(s) found — review below, then save again to confirm.')
        return
      }

      show('success', `Question ${form.questionNumber} saved.`)

      if (addAnother) {
        setForm((f) => ({
          ...f,
          ...EMPTY_CONTENT,
          subjectId: keep.subject ? f.subjectId : null,
          examClassId: keep.examClass ? f.examClassId : null,
          chapterId: keep.chapter ? f.chapterId : null,
          topicId: keep.topic ? f.topicId : null,
        }))
        setImages([])
        setDuplicates(null)
      } else if (result.item) {
        router.push(`/questions/${result.item.id}`)
      }
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="card space-y-4 p-5 lg:col-span-2">
        {/* ── 1. ADD QUESTION — the question editor ─────────────────── */}
        <h2 className="text-sm font-semibold text-ink">1. Add Question</h2>
        <p className="text-xs text-ink-faint">
          Enter the question exactly as it should appear. Nothing here is auto-corrected or reformatted. Wrap math in
          $...$ for rendering, e.g. <code>$x^2 + 1$</code>.
        </p>

        <div>
          <label className="label">Question Type</label>
          <div className="flex gap-4">
            {(['MCQ', 'SUBJECTIVE', 'INTEGER'] as QuestionType[]).map((t) => (
              <label key={t} className="flex items-center gap-1.5 text-sm">
                <input
                  type="radio"
                  name="questionType"
                  checked={form.questionType === t}
                  onChange={() => set('questionType', t)}
                />
                {t === 'MCQ' ? 'MCQ' : t === 'SUBJECTIVE' ? 'Subjective' : 'Integer'}
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="label">
            Question Text <span className="text-danger">*</span>
          </label>
          <textarea
            className="input min-h-[110px]"
            value={form.questionText}
            onChange={(e) => set('questionText', e.target.value)}
          />
          {checkingDuplicates && <p className="mt-1 text-xs text-ink-faint">Checking for similar questions…</p>}
        </div>

        {duplicates && duplicates.length > 0 && (
          <div className="rounded-md border border-amber-300 bg-amber-50 p-3">
            <p className="text-sm font-medium text-warning">A similar question already exists.</p>
            <ul className="mt-2 space-y-1.5">
              {duplicates.slice(0, 3).map((d) => (
                <li key={d.id} className="text-xs text-ink-muted">
                  <span className="font-medium text-ink">#{d.questionNumber}</span> —{' '}
                  <MathText text={d.questionText.slice(0, 140)} />
                </li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-ink-muted">
              Review the existing question above. If this is genuinely different, click &ldquo;Save anyway&rdquo;
              below.
            </p>
          </div>
        )}

        {form.questionType === 'MCQ' && (
          <>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Option A</label>
                <input className="input" value={form.optionA} onChange={(e) => set('optionA', e.target.value)} />
              </div>
              <div>
                <label className="label">Option B</label>
                <input className="input" value={form.optionB} onChange={(e) => set('optionB', e.target.value)} />
              </div>
              <div>
                <label className="label">Option C</label>
                <input className="input" value={form.optionC} onChange={(e) => set('optionC', e.target.value)} />
              </div>
              <div>
                <label className="label">Option D</label>
                <input className="input" value={form.optionD} onChange={(e) => set('optionD', e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Correct Answer</label>
                <input
                  className="input"
                  placeholder="e.g. A"
                  value={form.correctAnswer}
                  onChange={(e) => set('correctAnswer', e.target.value)}
                />
              </div>
              <div>
                <label className="label">Marks</label>
                <p className="pt-2 text-xs text-ink-faint">Set per-paper when this question is placed in a section.</p>
              </div>
            </div>
            <div>
              <label className="label">Explanation</label>
              <textarea className="input min-h-[80px]" value={form.explanation} onChange={(e) => set('explanation', e.target.value)} />
            </div>
          </>
        )}

        {form.questionType === 'INTEGER' && (
          <>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="label">Integer Answer</label>
                <input
                  className="input"
                  placeholder="e.g. 0, 5, 12, -4 (no decimals)"
                  value={form.correctAnswer}
                  onChange={(e) => set('correctAnswer', e.target.value)}
                />
                {form.correctAnswer.trim() && !/^-?\d+$/.test(form.correctAnswer.trim()) && (
                  <p className="mt-1 text-xs text-danger">Must be a whole number — decimals are not allowed.</p>
                )}
              </div>
            </div>
            <div>
              <label className="label">Explanation</label>
              <textarea className="input min-h-[80px]" value={form.explanation} onChange={(e) => set('explanation', e.target.value)} />
            </div>
          </>
        )}

        {form.questionType === 'SUBJECTIVE' && (
          <>
            <div>
              <label className="label">Expected Answer</label>
              <p className="mb-1 text-xs text-ink-faint">Internal only — never shown on the student paper.</p>
              <textarea className="input min-h-[70px]" value={form.correctAnswer} onChange={(e) => set('correctAnswer', e.target.value)} />
            </div>
            <div>
              <label className="label">Marking Scheme</label>
              <p className="mb-1 text-xs text-ink-faint">
                Internal only — never shown on the student paper. Answer space on the printed paper is configured per
                paper section (Advanced Paper Builder), not per question.
              </p>
              <textarea className="input min-h-[70px]" value={form.markingScheme} onChange={(e) => set('markingScheme', e.target.value)} />
            </div>
          </>
        )}

        <ImageUploader images={images} onChange={setImages} />
        <HandwritingImageCleanup images={images} onChange={setImages} />

        <hr className="border-surface-border" />

        {/* ── 2–8. Tag fields, in the exact required order ──────────── */}
        <h2 className="text-sm font-semibold text-ink">Tags</h2>
        <div>
          <label className="label">
            2. Subject <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.subjects} value={form.subjectId} onChange={setSubject} />
        </div>
        <div>
          <label className="label">
            3. Class / Exam <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.examClasses} value={form.examClassId} onChange={(v) => set('examClassId', v)} />
        </div>
        <div>
          <label className="label">4. Chapter Name</label>
          <div className="flex items-start gap-2">
            <div className="flex-1">
              <SearchableSelect options={chapterOptions} value={form.chapterId} onChange={setChapter} disabled={!form.subjectId} />
            </div>
            {form.subjectId && (
              <button type="button" className="btn-ghost !px-2 !py-1 text-xs" onClick={() => setCreatingChapter((v) => !v)}>
                + Create
              </button>
            )}
          </div>
          {creatingChapter && (
            <div className="mt-2 flex gap-2">
              <input
                className="input flex-1"
                placeholder="New chapter name"
                value={newChapterName}
                onChange={(e) => setNewChapterName(e.target.value)}
              />
              <button type="button" className="btn-secondary" onClick={createChapter}>
                Add
              </button>
            </div>
          )}
          {!form.subjectId && <p className="mt-1 text-xs text-ink-faint">Select a Subject first.</p>}
        </div>
        <div>
          <label className="label">5. Topic Name</label>
          <div className="flex items-start gap-2">
            <div className="flex-1">
              <SearchableSelect options={topicOptions} value={form.topicId} onChange={(v) => set('topicId', v)} disabled={!form.chapterId} />
            </div>
            {form.chapterId && (
              <button type="button" className="btn-ghost !px-2 !py-1 text-xs" onClick={() => setCreatingTopic((v) => !v)}>
                + Create
              </button>
            )}
          </div>
          {creatingTopic && (
            <div className="mt-2 flex gap-2">
              <input
                className="input flex-1"
                placeholder="New topic name"
                value={newTopicName}
                onChange={(e) => setNewTopicName(e.target.value)}
              />
              <button type="button" className="btn-secondary" onClick={createTopic}>
                Add
              </button>
            </div>
          )}
          {!form.chapterId && <p className="mt-1 text-xs text-ink-faint">Select a Chapter first.</p>}
        </div>
        <div>
          <label className="label">
            6. Code <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.codes} value={form.codeId} onChange={(v) => set('codeId', v)} />
        </div>
        <div>
          <label className="label">
            7. Difficulty <span className="text-danger">*</span>
          </label>
          <SearchableSelect required options={lookups.difficultyLevels} value={form.difficultyId} onChange={(v) => set('difficultyId', v)} />
        </div>
        <div className="sm:w-2/3">
          <label className="label">
            8. Question No <span className="text-danger">*</span>
          </label>
          <div className="flex gap-2">
            <input
              className="input flex-1"
              placeholder="e.g. 27, Q-25, or MATH10-QE-NOR-001"
              value={form.questionNumber}
              onChange={(e) => set('questionNumber', e.target.value)}
            />
            <button type="button" className="btn-secondary whitespace-nowrap" onClick={suggestNumber} disabled={suggestingNumber}>
              {suggestingNumber ? 'Generating…' : 'Auto-generate'}
            </button>
          </div>
        </div>

        <hr className="border-surface-border" />

        <div>
          <h2 className="mb-2 text-sm font-semibold text-ink">Rapid Question Entry</h2>
          <p className="mb-2 text-xs text-ink-faint">
            When checked, this tag stays selected after &ldquo;Save &amp; Add Another&rdquo; — handy for entering many
            questions from the same topic in a row.
          </p>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.subject} onChange={(e) => setKeep((k) => ({ ...k, subject: e.target.checked }))} />
              Keep Subject
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.examClass} onChange={(e) => setKeep((k) => ({ ...k, examClass: e.target.checked }))} />
              Keep Class / Exam
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.chapter} onChange={(e) => setKeep((k) => ({ ...k, chapter: e.target.checked }))} />
              Keep Chapter
            </label>
            <label className="flex items-center gap-1.5">
              <input type="checkbox" checked={keep.topic} onChange={(e) => setKeep((k) => ({ ...k, topic: e.target.checked }))} />
              Keep Topic
            </label>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-surface-border pt-4">
          <button type="button" className="btn-ghost" onClick={() => setShowPreview((p) => !p)}>
            {showPreview ? 'Hide preview' : 'Preview'}
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              className="btn-secondary"
              disabled={saving}
              onClick={() => submit(duplicates !== null, true)}
            >
              {saving ? 'Saving…' : duplicates ? 'Save anyway & Add Another' : '+ Add Another Question'}
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={saving}
              onClick={() => submit(duplicates !== null, false)}
            >
              {saving ? 'Saving…' : duplicates ? 'Save anyway' : 'Save Question'}
            </button>
          </div>
        </div>
      </div>

      {showPreview && (
        <div className="card h-fit p-5">
          <h2 className="mb-3 text-sm font-semibold text-ink">Preview</h2>
          <div className="space-y-2 text-sm">
            <p className="font-medium">
              Q{form.questionNumber || '—'}. <MathText text={form.questionText || 'Question text will appear here.'} />
            </p>
            {form.questionType === 'MCQ' && (
              <ul className="ml-4 space-y-1">
                {[form.optionA, form.optionB, form.optionC, form.optionD].map(
                  (opt, idx) =>
                    opt && (
                      <li key={idx}>
                        <strong>{['A', 'B', 'C', 'D'][idx]}.</strong> <MathText text={opt} />
                      </li>
                    )
                )}
              </ul>
            )}
            {images.map((img) => (
              <img key={img.id} src={img.url} alt={img.fileName} className="max-h-56 rounded-md border border-surface-border" />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
