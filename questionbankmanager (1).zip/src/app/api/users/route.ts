import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createUserSchema } from '@/lib/validation/user'
import { createAdminClient } from '@/lib/supabase/admin'

// GET /api/users — ADMIN only. Full user directory for the Users screen.
export async function GET() {
  try {
    await requireRole(PERMISSIONS.USER_MANAGE)

    const profiles = await prisma.profile.findMany({
      include: { role: true },
      orderBy: { createdAt: 'asc' },
    })

    return NextResponse.json({
      items: profiles.map((p) => ({
        id: p.id,
        email: p.email,
        fullName: p.fullName,
        role: p.role.code,
        roleLabel: p.role.label,
        isActive: p.isActive,
        createdAt: p.createdAt.toISOString(),
      })),
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/users — ADMIN ("Owner") only. Creates a brand-new account
// directly, as an alternative to the self-service /register flow — the
// Owner picks the email/name/password/role up front instead of waiting for
// someone to sign themselves up and then promoting them.
//
// Uses the Supabase service-role admin API (createAdminClient(), already
// used elsewhere for privileged operations) to create the real auth.users
// row; supabase/sql/001_auth_trigger.sql's `on_auth_user_created` trigger
// then auto-inserts the matching `profiles` row (defaulting to EDITOR)
// inside that same database operation, so by the time createUser() resolves
// the profile already exists — this only needs to correct the role
// afterwards when the Owner picked something other than the default.
export async function POST(request: Request) {
  try {
    const admin = await requireRole(PERMISSIONS.USER_MANAGE)
    const body = createUserSchema.parse(await request.json())

    let supabaseAdmin: ReturnType<typeof createAdminClient>
    try {
      supabaseAdmin = createAdminClient()
    } catch {
      return NextResponse.json(
        {
          error:
            'User creation is not configured on this server (missing SUPABASE_SERVICE_ROLE_KEY). Ask the new user to sign up at /register instead, then change their role here.',
        },
        { status: 503 }
      )
    }

    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email: body.email,
      password: body.password,
      email_confirm: true,
      user_metadata: { full_name: body.fullName },
    })
    if (error || !data.user) {
      return NextResponse.json({ error: error?.message || 'Could not create the account.' }, { status: 400 })
    }

    const role = await prisma.role.findUnique({ where: { code: body.roleCode } })
    if (!role) return NextResponse.json({ error: 'Invalid role.' }, { status: 400 })

    const profile = await prisma.$transaction(async (tx) => {
      // The DB trigger already inserted a profiles row (role EDITOR,
      // isActive true) as part of the auth.users insert above — upsert
      // here both covers the (expected) update-to-the-chosen-role case and
      // is a safe no-op-turned-create if the trigger somehow hasn't run yet
      // (e.g. this migration step was skipped in a given environment).
      const updated = await tx.profile.upsert({
        where: { id: data.user!.id },
        update: { roleId: role.id, fullName: body.fullName, isActive: true },
        create: { id: data.user!.id, email: body.email, fullName: body.fullName, roleId: role.id, isActive: true },
        include: { role: true },
      })

      await writeAuditLog(
        {
          userId: admin.id,
          action: 'USER_CREATED',
          entityType: 'USER',
          entityId: updated.id,
          description: `${admin.fullName ?? admin.email} created a new account for ${body.email} (${role.label}).`,
          newValue: { email: body.email, fullName: body.fullName, role: body.roleCode },
        },
        tx
      )

      return updated
    })

    return NextResponse.json(
      {
        item: {
          id: profile.id,
          email: profile.email,
          fullName: profile.fullName,
          role: profile.role.code,
          roleLabel: profile.role.label,
          isActive: profile.isActive,
          createdAt: profile.createdAt.toISOString(),
        },
      },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
