import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateUserStatusSchema } from '@/lib/validation/user'

// PATCH /api/users/:id/status — ADMIN only. Activate/deactivate a user
// (deactivated users are blocked at the auth layer — see lib/auth.ts
// getCurrentUser, which returns null for an inactive profile).
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const admin = await requireRole(PERMISSIONS.USER_MANAGE)
    const { isActive } = updateUserStatusSchema.parse(await request.json())

    if (admin.id === params.id && !isActive) {
      return NextResponse.json({ error: 'You cannot deactivate your own account.' }, { status: 400 })
    }

    const target = await prisma.profile.findUnique({ where: { id: params.id } })
    if (!target) return NextResponse.json({ error: 'User not found.' }, { status: 404 })

    await prisma.$transaction(async (tx) => {
      await tx.profile.update({ where: { id: params.id }, data: { isActive } })
      await writeAuditLog(
        {
          userId: admin.id,
          action: 'USER_STATUS_CHANGED',
          entityType: 'USER',
          entityId: params.id,
          description: `${admin.fullName ?? admin.email} ${isActive ? 'activated' : 'deactivated'} ${target.email}.`,
          previousValue: { isActive: target.isActive },
          newValue: { isActive },
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
