import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateUserRoleSchema } from '@/lib/validation/user'

// PATCH /api/users/:id/role — ADMIN only. Changes a user's role. Server-
// enforced (never trust a client-sent role) and fully audited.
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const admin = await requireRole(PERMISSIONS.USER_MANAGE)
    const { roleCode } = updateUserRoleSchema.parse(await request.json())

    if (admin.id === params.id && roleCode !== 'ADMIN') {
      return NextResponse.json(
        { error: 'You cannot remove your own Owner access. Ask another Owner to do this.' },
        { status: 400 }
      )
    }

    const target = await prisma.profile.findUnique({ where: { id: params.id }, include: { role: true } })
    if (!target) return NextResponse.json({ error: 'User not found.' }, { status: 404 })

    const role = await prisma.role.findUnique({ where: { code: roleCode } })
    if (!role) return NextResponse.json({ error: 'Invalid role.' }, { status: 400 })

    await prisma.$transaction(async (tx) => {
      await tx.profile.update({ where: { id: params.id }, data: { roleId: role.id } })
      await writeAuditLog(
        {
          userId: admin.id,
          action: 'USER_ROLE_CHANGED',
          entityType: 'USER',
          entityId: params.id,
          description: `${admin.fullName ?? admin.email} changed ${target.email}'s role from ${target.role.code} to ${roleCode}.`,
          previousValue: { role: target.role.code },
          newValue: { role: roleCode },
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
