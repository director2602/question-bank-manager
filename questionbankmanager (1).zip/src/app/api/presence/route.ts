import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

// POST /api/presence — heartbeat pinged by the dashboard layout every ~60s
// while a tab is open. Powers the "users currently active" dashboard stat.
export async function POST() {
  try {
    const user = await requireUser()
    await prisma.presence.upsert({
      where: { userId: user.id },
      create: { userId: user.id },
      update: { lastSeenAt: new Date() },
    })
    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
