import { NextResponse } from 'next/server'

// Lightweight liveness endpoint for uptime checks / load balancers. Left
// public deliberately (see middleware.ts PUBLIC_PATHS) and does not touch
// the database so it stays fast even under DB pressure.
export async function GET() {
  return NextResponse.json({ status: 'ok', timestamp: new Date().toISOString() })
}
