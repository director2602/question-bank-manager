import { NextResponse } from 'next/server'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { LocalImageProcessor } from '@/lib/image-processing/localProcessor'
import { MAX_IMAGE_SIZE_BYTES, ALLOWED_HANDWRITING_IMAGE_MIME_TYPES } from '@/lib/constants'

const processor = new LocalImageProcessor()

// A handful of bytes at the front of a file that let us confirm the content
// actually IS the image format its declared MIME type/extension claims —
// browsers/clients can lie about `file.type`, and trusting it blindly would
// let a crafted file smuggle arbitrary bytes through a route that a raster
// image-processing library then parses.
const MAGIC_BYTES: Array<{ mime: string; check: (buf: Buffer) => boolean }> = [
  { mime: 'image/png', check: (buf) => buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 },
  { mime: 'image/jpeg', check: (buf) => buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff },
  {
    mime: 'image/webp',
    check: (buf) =>
      buf.length > 12 &&
      buf[0] === 0x52 &&
      buf[1] === 0x49 &&
      buf[2] === 0x46 &&
      buf[3] === 0x46 &&
      buf[8] === 0x57 &&
      buf[9] === 0x45 &&
      buf[10] === 0x42 &&
      buf[11] === 0x50,
  },
]

// POST /api/images/process — runs a photographed handwritten page through
// the deterministic cleanup pipeline (shading correction, denoise, contrast,
// sharpen — see LocalImageProcessor for the full rationale) and hands back
// the result inline as a data URL. This is a preview/transform step, not a
// save: nothing is written to storage or the database here. The caller is
// expected to let the user compare Original vs Processed and, only once
// they confirm with "Use Image", upload the processed result through the
// existing POST /api/questions/images route — which already owns storage
// upload, the QuestionImage row, and orphan cleanup — rather than this route
// duplicating that persistence logic.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.IMAGE_PROCESS)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!ALLOWED_HANDWRITING_IMAGE_MIME_TYPES.includes(file.type)) {
      return NextResponse.json(
        { error: `Unsupported file type "${file.type}". Allowed: JPEG, PNG, WEBP.` },
        { status: 400 }
      )
    }
    if (file.size === 0) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 })
    }
    if (file.size > MAX_IMAGE_SIZE_BYTES) {
      return NextResponse.json(
        { error: `File is too large. Maximum size is ${MAX_IMAGE_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const inputBuffer = Buffer.from(await file.arrayBuffer())

    if (!MAGIC_BYTES.some((sig) => sig.mime === file.type && sig.check(inputBuffer))) {
      return NextResponse.json(
        { error: 'The file contents do not match a supported image format.' },
        { status: 400 }
      )
    }

    let result
    try {
      result = await processor.process(inputBuffer)
    } catch (err) {
      console.error('[image process] pipeline error', err)
      return NextResponse.json(
        { error: 'We could not process this image. Please try a different photo.' },
        { status: 422 }
      )
    }

    await writeAuditLog({
      userId: user.id,
      action: 'IMAGE_PROCESSED',
      entityType: 'IMAGE',
      description: `${user.fullName ?? user.email} cleaned up a handwritten image (${result.width}x${result.height}).`,
    })

    const dataUrl = `data:${result.mimeType};base64,${result.buffer.toString('base64')}`

    return NextResponse.json(
      { item: { dataUrl, mimeType: result.mimeType, width: result.width, height: result.height } },
      { status: 200 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
