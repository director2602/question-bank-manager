import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createTopicSchema } from '@/lib/validation/chapterTopic'

// GET /api/topics?chapterId=... — full topic list (including inactive),
// used by the Chapters & Topics management screen.
export async function GET(request: Request) {
  try {
    await requireUser()
    const { searchParams } = new URL(request.url)
    const chapterId = searchParams.get('chapterId')

    const topics = await prisma.topic.findMany({
      where: chapterId ? { chapterId } : undefined,
      orderBy: [{ chapterId: 'asc' }, { sortOrder: 'asc' }],
      include: { _count: { select: { questions: true } } },
    })

    return NextResponse.json({
      items: topics.map((t) => ({
        id: t.id,
        chapterId: t.chapterId,
        code: t.code,
        label: t.label,
        sortOrder: t.sortOrder,
        isActive: t.isActive,
        questionCount: t._count.questions,
      })),
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/topics — create a topic under a chapter. Same role set as
// /api/chapters (ADMIN+EDITOR) so it works from the Add Question form's
// inline "+ Create topic" quick-add, always scoped to an existing chapter
// (the Subject → Class/Exam → Chapter → Topic dependency the spec requires
// is enforced here, not just in the UI).
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_CREATE)
    const body = createTopicSchema.parse(await request.json())

    const chapter = await prisma.chapter.findUnique({ where: { id: body.chapterId } })
    if (!chapter) return NextResponse.json({ error: 'Invalid chapter.' }, { status: 400 })

    const existing = await prisma.topic.findUnique({
      where: { chapterId_code: { chapterId: body.chapterId, code: body.code } },
    })
    if (existing) {
      return NextResponse.json({ error: `A topic with code "${body.code}" already exists under "${chapter.label}".` }, { status: 409 })
    }

    const maxOrder = await prisma.topic.aggregate({
      where: { chapterId: body.chapterId },
      _max: { sortOrder: true },
    })

    const topic = await prisma.topic.create({
      data: {
        chapterId: body.chapterId,
        code: body.code,
        label: body.label,
        sortOrder: (maxOrder._max.sortOrder ?? 0) + 1,
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'TOPIC_CREATED',
      entityType: 'SETTINGS',
      entityId: topic.id,
      description: `${user.fullName ?? user.email} created topic "${topic.label}" under chapter "${chapter.label}".`,
      newValue: { chapterId: body.chapterId, code: body.code, label: body.label },
    })

    return NextResponse.json({ item: topic }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
