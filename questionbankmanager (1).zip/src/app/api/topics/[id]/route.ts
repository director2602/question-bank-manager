import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateTopicSchema } from '@/lib/validation/chapterTopic'

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)
    const body = updateTopicSchema.parse(await request.json())

    const existing = await prisma.topic.findUnique({ where: { id: params.id } })
    if (!existing) return NextResponse.json({ error: 'Topic not found.' }, { status: 404 })

    if (body.code && body.code !== existing.code) {
      const dup = await prisma.topic.findUnique({
        where: { chapterId_code: { chapterId: existing.chapterId, code: body.code } },
      })
      if (dup) return NextResponse.json({ error: `A topic with code "${body.code}" already exists.` }, { status: 409 })
    }

    const updated = await prisma.topic.update({
      where: { id: params.id },
      data: { code: body.code, label: body.label, isActive: body.isActive },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'TOPIC_UPDATED',
      entityType: 'SETTINGS',
      entityId: updated.id,
      description: `${user.fullName ?? user.email} updated topic "${updated.label}".`,
      previousValue: { code: existing.code, label: existing.label, isActive: existing.isActive },
      newValue: { code: updated.code, label: updated.label, isActive: updated.isActive },
    })

    return NextResponse.json({ item: updated })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE — only when no questions reference it; deactivate otherwise.
export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)

    const existing = await prisma.topic.findUnique({
      where: { id: params.id },
      include: { _count: { select: { questions: true } } },
    })
    if (!existing) return NextResponse.json({ error: 'Topic not found.' }, { status: 404 })

    if (existing._count.questions > 0) {
      return NextResponse.json(
        {
          error: `"${existing.label}" has ${existing._count.questions} question(s) attached and cannot be deleted. Deactivate it instead.`,
        },
        { status: 409 }
      )
    }

    await prisma.topic.delete({ where: { id: params.id } })

    await writeAuditLog({
      userId: user.id,
      action: 'TOPIC_UPDATED',
      entityType: 'SETTINGS',
      entityId: params.id,
      description: `${user.fullName ?? user.email} deleted topic "${existing.label}".`,
      previousValue: { code: existing.code, label: existing.label },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
