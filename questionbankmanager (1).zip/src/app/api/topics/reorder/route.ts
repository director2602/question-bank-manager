import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { reorderTopicsSchema } from '@/lib/validation/chapterTopic'

export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)
    const body = reorderTopicsSchema.parse(await request.json())

    const topics = await prisma.topic.findMany({ where: { chapterId: body.chapterId }, select: { id: true } })
    const validIds = new Set(topics.map((t) => t.id))
    if (body.orderedIds.length !== validIds.size || !body.orderedIds.every((id) => validIds.has(id))) {
      return NextResponse.json(
        { error: 'The topic list is out of date — reload and try reordering again.' },
        { status: 409 }
      )
    }

    await prisma.$transaction([
      ...body.orderedIds.map((id, index) => prisma.topic.update({ where: { id }, data: { sortOrder: index } })),
      prisma.auditLog.create({
        data: {
          userId: user.id,
          action: 'TOPIC_REORDERED',
          entityType: 'SETTINGS',
          entityId: null,
          description: `${user.fullName ?? user.email} reordered topics.`,
          newValue: { chapterId: body.chapterId, orderedIds: body.orderedIds },
        },
      }),
    ])

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
