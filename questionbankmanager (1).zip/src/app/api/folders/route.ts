import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createFolderSchema } from '@/lib/validation/folder'

// GET /api/folders — every folder with its paper count, plus the count of
// papers that have no folder ("Uncategorized" — a virtual bucket, not a
// real row, so it can never be renamed/deleted by accident).
export async function GET() {
  try {
    await requireUser()

    const [folders, uncategorizedCount] = await Promise.all([
      prisma.paperFolder.findMany({
        orderBy: { name: 'asc' },
        include: { _count: { select: { papers: true } } },
      }),
      prisma.paper.count({ where: { folderId: null } }),
    ])

    return NextResponse.json({
      items: folders.map((f) => ({
        id: f.id,
        name: f.name,
        paperCount: f._count.papers,
        createdAt: f.createdAt.toISOString(),
      })),
      uncategorizedCount,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/folders — create a folder. Name uniqueness is enforced by both
// the DB unique index (paper_folders.name) and this pre-check, so the
// caller gets a clear message instead of a raw constraint-violation error.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.FOLDER_MANAGE)
    const { name } = createFolderSchema.parse(await request.json())

    const existing = await prisma.paperFolder.findUnique({ where: { name } })
    if (existing) {
      return NextResponse.json({ error: `A folder named "${name}" already exists.` }, { status: 409 })
    }

    const folder = await prisma.$transaction(async (tx) => {
      const created = await tx.paperFolder.create({
        data: { name, createdById: user.id },
      })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'FOLDER_CREATED',
          entityType: 'FOLDER',
          entityId: created.id,
          description: `${user.fullName ?? user.email} created folder "${name}".`,
        },
        tx
      )
      return created
    })

    return NextResponse.json({ item: { id: folder.id, name: folder.name, paperCount: 0 } }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
