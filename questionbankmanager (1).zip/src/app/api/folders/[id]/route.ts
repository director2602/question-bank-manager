import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { renameFolderSchema } from '@/lib/validation/folder'

// PATCH /api/folders/:id — rename. Same uniqueness pre-check as create.
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.FOLDER_MANAGE)
    const { name } = renameFolderSchema.parse(await request.json())

    const folder = await prisma.paperFolder.findUnique({ where: { id: params.id } })
    if (!folder) return NextResponse.json({ error: 'Folder not found.' }, { status: 404 })

    if (name !== folder.name) {
      const clash = await prisma.paperFolder.findUnique({ where: { name } })
      if (clash) {
        return NextResponse.json({ error: `A folder named "${name}" already exists.` }, { status: 409 })
      }
    }

    await prisma.$transaction(async (tx) => {
      await tx.paperFolder.update({ where: { id: params.id }, data: { name } })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'FOLDER_RENAMED',
          entityType: 'FOLDER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} renamed folder "${folder.name}" to "${name}".`,
          previousValue: { name: folder.name },
          newValue: { name },
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE /api/folders/:id — deletes the folder ONLY. Papers inside it are
// never deleted: papers.folder_id is ON DELETE SET NULL at the database
// level, so they fall straight back to "Uncategorized" automatically as
// part of the same delete statement — no separate update step needed (and
// none of the deleted papers' history/versions/questions are touched).
export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.FOLDER_MANAGE)

    const folder = await prisma.paperFolder.findUnique({
      where: { id: params.id },
      include: { _count: { select: { papers: true } } },
    })
    if (!folder) return NextResponse.json({ error: 'Folder not found.' }, { status: 404 })

    await prisma.$transaction(async (tx) => {
      await tx.paperFolder.delete({ where: { id: params.id } })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'FOLDER_DELETED',
          entityType: 'FOLDER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} deleted folder "${folder.name}" (${folder._count.papers} paper(s) moved to Uncategorized).`,
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
