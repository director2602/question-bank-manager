import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET } from '@/lib/storage'

// DELETE — only allowed while an image is still "orphaned" (not yet linked
// to a saved question version), i.e. the user removed it during the Add
// Question form before submitting. Once linked, an image is part of an
// immutable question_versions snapshot and cannot be deleted through this
// route (delete/replace the question content instead, which creates a new
// version).
export async function DELETE(_request: Request, { params }: { params: { imageId: string } }) {
  try {
    await requireRole(PERMISSIONS.QUESTION_CREATE)

    const image = await prisma.questionImage.findUnique({ where: { id: params.imageId } })
    if (!image) return NextResponse.json({ error: 'Image not found.' }, { status: 404 })
    if (image.questionVersionId) {
      return NextResponse.json(
        { error: 'This image is already attached to a saved question and cannot be deleted here.' },
        { status: 409 }
      )
    }

    const supabase = createAdminClient()
    await supabase.storage.from(STORAGE_BUCKET).remove([image.storagePath])
    await prisma.questionImage.delete({ where: { id: params.imageId } })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
