import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET, getSignedImageUrl } from '@/lib/storage'
import { MAX_IMAGE_SIZE_BYTES, ALLOWED_IMAGE_MIME_TYPES } from '@/lib/constants'

// POST /api/questions/images — uploads ONE image ahead of question
// creation/edit. Images are stored as-is (no recompression, so quality is
// never reduced) at their original resolution. Returns an image record the
// client attaches to the question by ID when it saves.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_CREATE)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!ALLOWED_IMAGE_MIME_TYPES.includes(file.type)) {
      return NextResponse.json(
        { error: `Unsupported file type "${file.type}". Allowed: PNG, JPEG, WEBP, SVG.` },
        { status: 400 }
      )
    }
    if (file.size > MAX_IMAGE_SIZE_BYTES) {
      return NextResponse.json(
        { error: `File is too large. Maximum size is ${MAX_IMAGE_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const arrayBuffer = await file.arrayBuffer()
    const ext = file.name.split('.').pop() || 'bin'
    const storagePath = `question-images/${user.id}/${uuidv4()}.${ext}`

    const supabase = createAdminClient()
    const { error: uploadError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(storagePath, Buffer.from(arrayBuffer), {
        contentType: file.type,
        upsert: false,
      })

    if (uploadError) {
      console.error('[image upload] storage error', uploadError)
      return NextResponse.json(
        { error: 'Image upload failed. Please try again.' },
        { status: 502 }
      )
    }

    const image = await prisma.questionImage.create({
      data: {
        storagePath,
        fileName: file.name,
        mimeType: file.type,
        sizeBytes: file.size,
        uploadedById: user.id,
      },
    })

    return NextResponse.json(
      { item: { id: image.id, fileName: image.fileName, url: await getSignedImageUrl(storagePath) } },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
