import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { bulkQuestionIdsSchema } from '@/lib/validation/question'

// POST /api/questions/bulk-delete — ADMIN only, permanent. Mirrors the
// safety rule enforced by DELETE /api/questions/:id: a question used in ANY
// paper can never be hard-deleted (that would corrupt paper_questions and
// break historical paper reproducibility), so it's silently skipped here
// rather than aborting the whole batch — the response reports exactly which
// ids were deleted vs. skipped so the UI can tell the user precisely what
// happened. Runs as two set-based queries (find referenced ids, then
// deleteMany the rest) instead of N per-row requests.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_DELETE)
    const { questionIds } = bulkQuestionIdsSchema.parse(await request.json())

    const result = await prisma.$transaction(async (tx) => {
      const found = await tx.question.findMany({
        where: { id: { in: questionIds } },
        select: { id: true, questionNumber: true },
      })
      const foundIds = new Set(found.map((q) => q.id))
      const notFoundIds = questionIds.filter((id) => !foundIds.has(id))

      const referenced = await tx.paperQuestion.findMany({
        where: { questionId: { in: Array.from(foundIds) } },
        select: { questionId: true },
        distinct: ['questionId'],
      })
      const referencedIds = new Set(referenced.map((r) => r.questionId))

      const deletableIds = Array.from(foundIds).filter((id) => !referencedIds.has(id))

      const deleteResult =
        deletableIds.length > 0
          ? await tx.question.deleteMany({ where: { id: { in: deletableIds } } })
          : { count: 0 }

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_BULK_DELETED',
          entityType: 'QUESTION',
          entityId: null,
          description: `${user.fullName ?? user.email} permanently deleted ${deleteResult.count} question(s) in bulk.`,
          previousValue: { questionIds: deletableIds },
        },
        tx
      )

      return {
        deletedCount: deleteResult.count,
        skippedInUse: found.filter((q) => referencedIds.has(q.id)).map((q) => q.questionNumber),
        skippedNotFound: notFoundIds,
      }
    })

    return NextResponse.json(result)
  } catch (error) {
    return handleApiError(error)
  }
}
