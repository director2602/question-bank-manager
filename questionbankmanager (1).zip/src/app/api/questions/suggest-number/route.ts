import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

// GET /api/questions/suggest-number?subjectId&examClassId&chapterId&difficultyId
// Returns a suggested (NOT forced) auto-generated code/question-number in
// the SUBJECT+CLASS-CHAPTER-DIFFICULTY-### shape the spec asks for — the
// user can accept it as-is or type their own; either way the field stays
// a plain editable text input, and the actual save-time duplicate check
// (in POST /api/questions) is what really guards against collisions, since
// two people can request a suggestion at the same moment.
export async function GET(request: Request) {
  try {
    await requireUser()
    const { searchParams } = new URL(request.url)
    const subjectId = searchParams.get('subjectId')
    const examClassId = searchParams.get('examClassId')
    const chapterId = searchParams.get('chapterId')
    const difficultyId = searchParams.get('difficultyId')

    if (!subjectId) {
      return NextResponse.json({ error: 'subjectId is required.' }, { status: 400 })
    }

    const [subject, examClass, chapter, difficulty, count] = await Promise.all([
      prisma.subject.findUnique({ where: { id: subjectId } }),
      examClassId ? prisma.examClass.findUnique({ where: { id: examClassId } }) : Promise.resolve(null),
      chapterId ? prisma.chapter.findUnique({ where: { id: chapterId } }) : Promise.resolve(null),
      difficultyId ? prisma.difficultyLevel.findUnique({ where: { id: difficultyId } }) : Promise.resolve(null),
      prisma.question.count({
        where: {
          subjectId,
          ...(chapterId ? { chapterId } : {}),
        },
      }),
    ])
    if (!subject) return NextResponse.json({ error: 'Invalid subject.' }, { status: 400 })

    const parts = [
      `${subject.code}${examClass ? examClass.code.replace(/[^A-Za-z0-9]/g, '') : ''}`,
      chapter ? chapter.code : 'GEN',
      difficulty ? difficulty.code : null,
      String(count + 1).padStart(3, '0'),
    ].filter(Boolean)

    return NextResponse.json({ suggestion: parts.join('-').toUpperCase() })
  } catch (error) {
    return handleApiError(error)
  }
}
