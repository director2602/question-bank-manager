import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

// GET /api/questions/:id/versions — full, append-only content history.
// Nothing here is ever deleted or edited, so this is a reliable audit trail
// of exactly what the question said at any point in time.
export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireUser()

    const versions = await prisma.questionVersion.findMany({
      where: { questionId: params.id },
      include: {
        images: true,
        createdBy: { select: { id: true, fullName: true, email: true } },
      },
      orderBy: { versionNumber: 'desc' },
    })

    return NextResponse.json({ items: versions })
  } catch (error) {
    return handleApiError(error)
  }
}
