import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError, ConflictError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateQuestionTagsSchema } from '@/lib/validation/question'
import { questionWithRelations, toQuestionDetail } from '@/lib/serializers'

// PATCH /api/questions/:id/tags — updates ONLY subject/class/code/difficulty
// /questionNumber. Never touches question_versions, so the underlying
// content is guaranteed untouched by this endpoint (business rule §2/§7).
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_EDIT_TAGS)
    const body = updateQuestionTagsSchema.parse(await request.json())

    const existing = await prisma.question.findUnique({
      where: { id: params.id },
      include: questionWithRelations,
    })
    if (!existing) {
      return NextResponse.json({ error: 'Question not found.' }, { status: 404 })
    }

    // Optimistic lock: if someone else changed this question since the
    // client last read it, reject rather than silently overwrite.
    if (existing.rowVersion !== body.rowVersion) {
      throw new ConflictError(
        'This question was changed by another user while you were editing. Reload to see the latest version before saving.',
        await toQuestionDetail(existing)
      )
    }

    const [subject, examClass, code, difficulty] = await Promise.all([
      prisma.subject.findUnique({ where: { id: body.subjectId } }),
      prisma.examClass.findUnique({ where: { id: body.examClassId } }),
      prisma.code.findUnique({ where: { id: body.codeId } }),
      prisma.difficultyLevel.findUnique({ where: { id: body.difficultyId } }),
    ])
    if (!subject || !examClass || !code || !difficulty) {
      return NextResponse.json({ error: 'One or more selected tags are invalid.' }, { status: 400 })
    }

    const updated = await prisma.$transaction(async (tx) => {
      const result = await tx.question.updateMany({
        where: { id: params.id, rowVersion: body.rowVersion },
        data: {
          questionNumber: body.questionNumber,
          subjectId: body.subjectId,
          examClassId: body.examClassId,
          codeId: body.codeId,
          difficultyId: body.difficultyId,
          questionType: body.questionType,
          chapterId: body.chapterId ?? null,
          topicId: body.topicId ?? null,
          rowVersion: { increment: 1 },
        },
      })

      if (result.count === 0) {
        // Lost the race between our read above and this write.
        throw new ConflictError(
          'This question was changed by another user while you were editing. Reload to see the latest version before saving.'
        )
      }

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_TAGS_EDITED',
          entityType: 'QUESTION',
          entityId: params.id,
          description: `${user.fullName ?? user.email} updated tags for question ${body.questionNumber}.`,
          previousValue: {
            questionNumber: existing.questionNumber,
            subject: existing.subject.label,
            examClass: existing.examClass.label,
            code: existing.code.label,
            difficulty: existing.difficulty.label,
          },
          newValue: {
            questionNumber: body.questionNumber,
            subject: subject.label,
            examClass: examClass.label,
            code: code.label,
            difficulty: difficulty.label,
          },
        },
        tx
      )

      return tx.question.findUniqueOrThrow({ where: { id: params.id }, include: questionWithRelations })
    })

    return NextResponse.json({ item: await toQuestionDetail(updated) })
  } catch (error) {
    return handleApiError(error)
  }
}
