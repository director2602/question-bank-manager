import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { questionWithRelations, toQuestionDetail } from '@/lib/serializers'

// POST /api/questions/:id/duplicate — creates a brand-new question record
// (new ID, new question_versions v1) pre-filled from this one, so the user
// can tweak it into a variant without touching the original. This is the
// ONLY supported way to "clone" a question — it never shares a version
// chain with the source.
export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_CREATE)

    const source = await prisma.question.findUnique({
      where: { id: params.id },
      include: questionWithRelations,
    })
    if (!source || !source.currentVersion) {
      return NextResponse.json({ error: 'Question not found.' }, { status: 404 })
    }

    const created = await prisma.$transaction(async (tx) => {
      const question = await tx.question.create({
        data: {
          questionNumber: `${source.questionNumber}-copy`,
          subjectId: source.subjectId,
          examClassId: source.examClassId,
          codeId: source.codeId,
          difficultyId: source.difficultyId,
          normalizedTextHash: source.normalizedTextHash,
          createdById: user.id,
        },
      })

      const version = await tx.questionVersion.create({
        data: {
          questionId: question.id,
          versionNumber: 1,
          questionText: source.currentVersion!.questionText,
          optionA: source.currentVersion!.optionA,
          optionB: source.currentVersion!.optionB,
          optionC: source.currentVersion!.optionC,
          optionD: source.currentVersion!.optionD,
          correctAnswer: source.currentVersion!.correctAnswer,
          explanation: source.currentVersion!.explanation,
          changeNote: `Duplicated from question ${source.questionNumber}`,
          createdById: user.id,
        },
      })

      await tx.question.update({ where: { id: question.id }, data: { currentVersionId: version.id } })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_DUPLICATED',
          entityType: 'QUESTION',
          entityId: question.id,
          description: `${user.fullName ?? user.email} duplicated question ${source.questionNumber} into a new question.`,
          previousValue: { sourceQuestionId: source.id },
        },
        tx
      )

      return tx.question.findUniqueOrThrow({ where: { id: question.id }, include: questionWithRelations })
    })

    return NextResponse.json({ item: await toQuestionDetail(created) }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
