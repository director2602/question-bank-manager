import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'

export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_ARCHIVE)

    const question = await prisma.question.findUnique({ where: { id: params.id } })
    if (!question) return NextResponse.json({ error: 'Question not found.' }, { status: 404 })
    if (question.status === 'ARCHIVED') {
      return NextResponse.json({ error: 'This question is already archived.' }, { status: 409 })
    }

    await prisma.$transaction(async (tx) => {
      await tx.question.update({
        where: { id: params.id },
        data: { status: 'ARCHIVED', rowVersion: { increment: 1 } },
      })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_ARCHIVED',
          entityType: 'QUESTION',
          entityId: params.id,
          description: `${user.fullName ?? user.email} archived question ${question.questionNumber}.`,
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
