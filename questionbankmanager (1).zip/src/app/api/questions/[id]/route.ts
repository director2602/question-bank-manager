import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { questionWithRelations, toQuestionDetail } from '@/lib/serializers'

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireUser()

    const question = await prisma.question.findUnique({
      where: { id: params.id },
      include: questionWithRelations,
    })
    if (!question) {
      return NextResponse.json({ error: 'Question not found.' }, { status: 404 })
    }

    return NextResponse.json({ item: await toQuestionDetail(question) })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE — hard delete. ADMIN only, and only for questions never used in any
// paper (deleting a question referenced by a historical paper would break
// reproducibility guarantees — archiving is the safe path for those).
export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_DELETE)

    const question = await prisma.question.findUnique({
      where: { id: params.id },
      include: { paperQuestions: { take: 1 } },
    })
    if (!question) {
      return NextResponse.json({ error: 'Question not found.' }, { status: 404 })
    }
    if (question.paperQuestions.length > 0) {
      return NextResponse.json(
        {
          error:
            'This question has been used in one or more papers and cannot be permanently deleted. Archive it instead to keep historical papers intact.',
        },
        { status: 409 }
      )
    }

    await prisma.$transaction(async (tx) => {
      await tx.question.delete({ where: { id: params.id } })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_DELETED',
          entityType: 'QUESTION',
          entityId: params.id,
          description: `${user.fullName ?? user.email} permanently deleted question ${question.questionNumber}.`,
          previousValue: { questionNumber: question.questionNumber },
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
