import { NextResponse } from 'next/server'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { parseAndValidateCsv } from '@/lib/csv/parseTemplate'

// POST /api/questions/bulk-import/preview — parses + validates a CSV
// without writing anything. The frontend renders this as a review screen;
// nothing is committed until the user calls /confirm.
export async function POST(request: Request) {
  try {
    await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!file.name.toLowerCase().endsWith('.csv')) {
      return NextResponse.json(
        { error: 'Only CSV files are supported. Export your spreadsheet as CSV and try again.' },
        { status: 400 }
      )
    }

    const text = await file.text()
    if (!text.trim()) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 })
    }

    const preview = await parseAndValidateCsv(text)

    return NextResponse.json(preview)
  } catch (error) {
    return handleApiError(error)
  }
}
