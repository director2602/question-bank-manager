import { NextResponse } from 'next/server'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { parseAndValidateCsv, parseAndValidateXlsx } from '@/lib/csv/parseTemplate'
import { decodeCsvBuffer } from '@/lib/csv/decodeCsvText'

const MAX_XLSX_SIZE_BYTES = 25 * 1024 * 1024 // 25 MB

// POST /api/questions/bulk-import/preview — parses + validates a CSV OR a
// real Excel (.xlsx) file without writing anything. The frontend renders
// this as a review screen; nothing is committed until the user calls
// /confirm. Either source format goes through the exact same validation +
// LaTeX auto-fix pipeline (see validateRows in lib/csv/parseTemplate.ts).
export async function POST(request: Request) {
  try {
    await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }

    const lowerName = file.name.toLowerCase()
    const isXlsx = lowerName.endsWith('.xlsx')
    if (!lowerName.endsWith('.csv') && !isXlsx) {
      return NextResponse.json(
        { error: 'Only CSV (.csv) or Excel (.xlsx) files are supported here.' },
        { status: 400 }
      )
    }

    if (isXlsx) {
      if (file.size > MAX_XLSX_SIZE_BYTES) {
        return NextResponse.json(
          { error: `Excel file is too large. Maximum size is ${MAX_XLSX_SIZE_BYTES / (1024 * 1024)} MB.` },
          { status: 400 }
        )
      }
      const buffer = Buffer.from(await file.arrayBuffer())
      let preview
      try {
        preview = await parseAndValidateXlsx(buffer)
      } catch (err) {
        console.error('[bulk-import/preview] xlsx parsing failed', err)
        return NextResponse.json(
          { error: 'This Excel file could not be read. It may be corrupted, password-protected, or not a real .xlsx file.' },
          { status: 422 }
        )
      }
      return NextResponse.json(preview)
    }

    // Not file.text() — that always assumes UTF-8 and silently corrupts
    // CSVs saved in a legacy Windows codepage (very common for exam
    // question banks authored in Word/Excel). decodeCsvBuffer detects and
    // recovers from that instead of mangling every special character.
    const csvBuffer = Buffer.from(await file.arrayBuffer())
    const text = decodeCsvBuffer(csvBuffer)
    if (!text.trim()) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 })
    }

    const preview = await parseAndValidateCsv(text)

    return NextResponse.json(preview)
  } catch (error) {
    return handleApiError(error)
  }
}
