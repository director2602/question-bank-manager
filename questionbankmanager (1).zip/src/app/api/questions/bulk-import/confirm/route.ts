import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { confirmImportSchema } from '@/lib/validation/bulkImport'
import { hashNormalizedText } from '@/lib/duplicate-detection'

// POST /api/questions/bulk-import/confirm — commits the rows the user
// selected from the preview screen. Runs entirely inside ONE database
// transaction: if any row fails validation against the live lookup tables
// (e.g. a tag was deactivated between preview and confirm), the ENTIRE
// import is rolled back and nothing is partially saved — the response lists
// exactly which rows failed and why, so the user can fix and retry.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)
    const body = confirmImportSchema.parse(await request.json())

    const selected = body.rows.filter((r) => body.rowIndexes.includes(r.rowIndex))
    if (selected.length === 0) {
      return NextResponse.json({ error: 'No rows were selected to import.' }, { status: 400 })
    }

    const [subjectIds, examClassIds, codeIds, difficultyIds] = await Promise.all([
      prisma.subject.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.examClass.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.code.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.difficultyLevel.findMany({ where: { isActive: true }, select: { id: true } }),
    ])
    const validSubjects = new Set(subjectIds.map((s) => s.id))
    const validClasses = new Set(examClassIds.map((s) => s.id))
    const validCodes = new Set(codeIds.map((s) => s.id))
    const validDifficulties = new Set(difficultyIds.map((s) => s.id))

    const rowErrors: Array<{ rowIndex: number; message: string }> = []
    for (const row of selected) {
      if (!validSubjects.has(row.subjectId)) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid subject.' })
      if (!validClasses.has(row.examClassId)) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid class/exam.' })
      if (!validCodes.has(row.codeId)) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid code.' })
      if (!validDifficulties.has(row.difficultyId))
        rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid difficulty.' })
      if (!row.questionText.trim()) rowErrors.push({ rowIndex: row.rowIndex, message: 'Question text is empty.' })
    }

    if (rowErrors.length > 0) {
      return NextResponse.json(
        {
          error: 'Some rows failed validation. No questions were imported — fix the rows below and try again.',
          rowErrors,
        },
        { status: 422 }
      )
    }

    // Larger timeout than Prisma's 5s default: a big-but-legal batch (up to
    // MAX_BULK_IMPORT_ROWS) needs more time to insert transactionally. For
    // very large recurring imports, move this to a background queue (see
    // README.md § Known Limitations & Future Work) instead of raising this
    // further.
    const importedIds = await prisma.$transaction(async (tx) => {
      const ids: string[] = []
      for (const row of selected) {
        const question = await tx.question.create({
          data: {
            questionNumber: row.questionNumber,
            subjectId: row.subjectId,
            examClassId: row.examClassId,
            codeId: row.codeId,
            difficultyId: row.difficultyId,
            normalizedTextHash: hashNormalizedText(row.questionText),
            createdById: user.id,
          },
        })
        const version = await tx.questionVersion.create({
          data: {
            questionId: question.id,
            versionNumber: 1,
            questionText: row.questionText,
            optionA: row.optionA ?? null,
            optionB: row.optionB ?? null,
            optionC: row.optionC ?? null,
            optionD: row.optionD ?? null,
            correctAnswer: row.correctAnswer ?? null,
            explanation: row.explanation ?? null,
            changeNote: 'Imported via bulk CSV upload',
            createdById: user.id,
          },
        })
        await tx.question.update({ where: { id: question.id }, data: { currentVersionId: version.id } })

        if (row.imageIds && row.imageIds.length > 0) {
          await tx.questionImage.updateMany({
            where: { id: { in: row.imageIds } },
            data: { questionVersionId: version.id },
          })
        }

        ids.push(question.id)
      }

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_BULK_IMPORTED',
          entityType: 'QUESTION',
          entityId: null,
          description: `${user.fullName ?? user.email} bulk-imported ${ids.length} question(s) via CSV.`,
          newValue: { count: ids.length },
        },
        tx
      )

      return ids
    }, { timeout: 60_000, maxWait: 10_000 })

    return NextResponse.json({ importedCount: importedIds.length, questionIds: importedIds }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
