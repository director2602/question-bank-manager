import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { splitIntoQuestions } from '@/lib/pdf/extractQuestions'
import { extractDocxContent, type DocxImage } from '@/lib/docx/extractQuestions'
import { prisma } from '@/lib/prisma'
import { hashNormalizedText, normalizeQuestionText } from '@/lib/duplicate-detection'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET, getSignedImageUrl } from '@/lib/storage'

const MAX_DOCX_SIZE_BYTES = 25 * 1024 * 1024 // 25 MB

// Mirrors the question-boundary rule inside splitIntoQuestions (see
// QUESTION_START in src/lib/pdf/extractQuestions.ts) on purpose — this lets
// us know which extracted-question block each Word paragraph (and any image
// embedded in it) falls into, without splitIntoQuestions itself needing to
// expose that internal mapping. If the two rules ever drift apart, an image
// simply stops being auto-attached (never mis-attached to the wrong
// question) — splitIntoQuestions remains the single source of truth for the
// text extraction itself.
const QUESTION_START_LINE = /^\s*(?:Q(?:uestion)?\.?\s*)?(\d{1,4}[A-Za-z]?)\s*[.):\-]\s+\S/i

function assignLinesToBlocks(lines: string[]): number[] {
  const map: number[] = []
  let blockIdx = -1
  for (const line of lines) {
    if (QUESTION_START_LINE.test(line)) blockIdx++
    map.push(blockIdx) // -1 for lines before the first detected question (discarded, same as splitIntoQuestions)
  }
  return map
}

// POST /api/questions/bulk-import/docx-preview — extracts candidate
// questions (and any embedded images) from an uploaded Word (.docx)
// document. Nothing is written to the database except already-uploaded
// orphan QuestionImage rows for embedded images (mirroring the PDF import's
// diagram handling) — the actual questions are only ever committed once the
// user reviews and confirms via the shared /bulk-import/confirm endpoint,
// exactly like CSV/PDF/handwritten import.
//
// A .docx is machine-readable text (unlike a scanned PDF), so this always
// uses the same plain-text heuristic splitter the PDF import falls back to
// when AI transcription isn't available — no OCR or AI step is needed here.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!file.name.toLowerCase().endsWith('.docx')) {
      return NextResponse.json(
        { error: 'Only Word .docx files are supported here (the older .doc format is not — save as .docx first).' },
        { status: 400 }
      )
    }
    if (file.size > MAX_DOCX_SIZE_BYTES) {
      return NextResponse.json(
        { error: `Word document is too large. Maximum size is ${MAX_DOCX_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const buffer = Buffer.from(await file.arrayBuffer())

    let content: { lines: string[]; images: DocxImage[] }
    try {
      content = await extractDocxContent(buffer)
    } catch (err) {
      console.error('[docx-preview] extraction failed', err)
      return NextResponse.json(
        { error: 'This Word document could not be read. It may be corrupted or not a real .docx file.' },
        { status: 422 }
      )
    }

    const fullText = content.lines.join('\n')
    if (!fullText.trim()) {
      return NextResponse.json({ error: 'No extractable text was found in this document.' }, { status: 422 })
    }

    const questions = splitIntoQuestions(fullText)
    if (questions.length === 0) {
      return NextResponse.json(
        {
          error:
            'No individual questions could be identified in this document. Question numbering (e.g. "1.", "Q1.") is used to detect boundaries — if this file uses a different style, use CSV import instead, or add questions individually.',
        },
        { status: 422 }
      )
    }

    // Attach embedded images to whichever question's paragraph range they
    // fall within — best-effort, same spirit as the PDF import's page-based
    // diagram attachment.
    const lineToBlock = assignLinesToBlocks(content.lines)
    const imagesByBlock = new Map<number, DocxImage[]>()
    for (const img of content.images) {
      const blockIdx = lineToBlock[img.paragraphIndex]
      if (blockIdx === undefined || blockIdx < 0 || blockIdx >= questions.length) continue
      const list = imagesByBlock.get(blockIdx) ?? []
      list.push(img)
      imagesByBlock.set(blockIdx, list)
    }

    const diagramsByRow = new Map<string, Array<{ id: string; url: string }>>()
    let diagramWarning: string | null = null

    if (content.images.length > 0) {
      if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
        diagramWarning =
          'This document contains embedded images, but image storage is not configured on the server yet — questions were extracted, but images were not attached. Attach them manually after import.'
      } else {
        try {
          const supabase = createAdminClient()
          for (const [blockIdx, imgs] of imagesByBlock) {
            const tempId = questions[blockIdx].tempId
            for (const img of imgs) {
              const ext = img.mimeType === 'image/jpeg' ? 'jpg' : img.mimeType.split('/')[1] || 'png'
              const storagePath = `question-images/docx-import/${uuidv4()}.${ext}`

              const { error: uploadError } = await supabase.storage
                .from(STORAGE_BUCKET)
                .upload(storagePath, img.buffer, { contentType: img.mimeType, upsert: false })
              if (uploadError) {
                console.error('[docx-preview] image upload failed', uploadError)
                continue
              }

              const image = await prisma.questionImage.create({
                data: {
                  storagePath,
                  fileName: img.fileName,
                  mimeType: img.mimeType,
                  sizeBytes: img.buffer.byteLength,
                  uploadedById: user.id,
                },
              })

              const url = await getSignedImageUrl(storagePath)
              const list = diagramsByRow.get(tempId) ?? []
              list.push({ id: image.id, url })
              diagramsByRow.set(tempId, list)
            }
          }
        } catch (err) {
          console.error('[docx-preview] image extraction failed', err)
          diagramWarning =
            'Attaching embedded images hit an error for this file — questions were still extracted. Attach images manually after import if needed.'
        }
      }
    }

    // Flag likely duplicates against the live bank, same as CSV/PDF import.
    const existing = await prisma.question.findMany({
      where: { status: 'ACTIVE' },
      select: { questionNumber: true, normalizedTextHash: true },
    })
    const existingHashes = new Map(existing.map((q) => [q.normalizedTextHash, q.questionNumber]))
    const seenInFile = new Set<string>()

    const rows = questions.map((q) => {
      const hash = q.questionText ? hashNormalizedText(q.questionText) : null
      const normalized = q.questionText ? normalizeQuestionText(q.questionText) : ''
      const isDuplicateInFile = normalized ? seenInFile.has(normalized) : false
      if (normalized) seenInFile.add(normalized)
      const isDuplicateInBank = hash ? existingHashes.has(hash) : false

      return {
        ...q,
        isDuplicateInFile,
        isDuplicateInBank,
        duplicateOfQuestionNumber: hash ? existingHashes.get(hash) : undefined,
        images: diagramsByRow.get(q.tempId) ?? [],
      }
    })

    return NextResponse.json({
      totalDetected: rows.length,
      lowConfidenceCount: rows.filter((r) => r.lowConfidence).length,
      duplicateCount: rows.filter((r) => r.isDuplicateInBank || r.isDuplicateInFile).length,
      imageCount: content.images.length,
      diagramWarning,
      rows,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
