import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { PDFDocument } from 'pdf-lib'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { prisma } from '@/lib/prisma'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET } from '@/lib/storage'
import { processHandwrittenImportJob } from '@/lib/pdf/handwritingPipeline'

const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024 // 25 MB — same ceiling as the typed-PDF importer
const ALLOWED_TYPES = ['application/pdf', 'image/png', 'image/jpeg']

// POST /api/questions/bulk-import/handwritten/upload — accepts a
// handwritten exam PDF (or a single handwritten PNG/JPG/JPEG page, wrapped
// into a one-page PDF so the rest of the pipeline only has one code path),
// validates it, stores the ORIGINAL untouched, creates an ImportJob, and
// kicks off processing WITHOUT waiting for it to finish — the browser gets
// a jobId back immediately and polls GET .../handwritten/[jobId] for
// progress, per "do not make the browser wait indefinitely".
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json(
        { error: 'Unsupported file type. Upload a PDF, PNG, or JPG/JPEG.' },
        { status: 400 }
      )
    }
    if (file.size === 0) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 })
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      return NextResponse.json(
        { error: `File is too large. Maximum size is ${MAX_FILE_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    let buffer = Buffer.from(await file.arrayBuffer())
    let mimeType = file.type
    let ext = file.type === 'application/pdf' ? 'pdf' : file.type === 'image/png' ? 'png' : 'jpg'

    if (file.type === 'application/pdf') {
      // Corrupt / password-protected detection up front, so the job is
      // never created for a file we already know can't be processed.
      try {
        await PDFDocument.load(buffer, { ignoreEncryption: false })
      } catch (err) {
        const message = err instanceof Error ? err.message : ''
        if (/encrypt/i.test(message)) {
          return NextResponse.json(
            { error: 'This PDF is password-protected. Remove the password and re-upload.' },
            { status: 422 }
          )
        }
        return NextResponse.json(
          { error: 'This PDF could not be read — it may be corrupted. Try re-exporting or re-scanning it.' },
          { status: 422 }
        )
      }
    } else {
      // Wrap a single handwritten image into a one-page PDF so the rest of
      // the pipeline (page counting, Claude document upload, page-image
      // extraction for diagram crops) only has to handle one format.
      try {
        const pdfDoc = await PDFDocument.create()
        const embedded = file.type === 'image/png' ? await pdfDoc.embedPng(buffer) : await pdfDoc.embedJpg(buffer)
        const page = pdfDoc.addPage([embedded.width, embedded.height])
        page.drawImage(embedded, { x: 0, y: 0, width: embedded.width, height: embedded.height })
        buffer = Buffer.from(await pdfDoc.save())
        mimeType = 'application/pdf'
        ext = 'pdf'
      } catch {
        return NextResponse.json({ error: 'This image could not be read. Try re-saving it as PNG or JPG and re-uploading.' }, { status: 422 })
      }
    }

    const supabase = createAdminClient()
    const jobId = uuidv4()
    const storagePath = `handwritten-import/${jobId}/original.${ext}`
    const { error: uploadError } = await supabase.storage.from(STORAGE_BUCKET).upload(storagePath, buffer, {
      contentType: mimeType,
      upsert: false,
    })
    if (uploadError) {
      console.error('[handwritten upload] storage upload failed', uploadError)
      return NextResponse.json({ error: 'Could not store the uploaded file. Please try again.' }, { status: 500 })
    }

    const job = await prisma.importJob.create({
      data: {
        id: jobId,
        kind: 'HANDWRITTEN_PDF',
        status: 'PENDING',
        originalFileName: file.name,
        originalStoragePath: storagePath,
        createdById: user.id,
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'HANDWRITTEN_IMPORT_STARTED',
      entityType: 'IMPORT_JOB',
      entityId: job.id,
      description: `${user.fullName ?? user.email} uploaded a handwritten PDF ("${file.name}") for processing.`,
    })

    // Fire-and-forget: this Next.js app runs as a persistent Node server
    // (`next start`), not ephemeral serverless, so this promise safely
    // keeps running after the response below is sent. Errors are caught
    // and written to the job row inside processHandwrittenImportJob
    // itself — nothing here can throw an unhandled rejection.
    void processHandwrittenImportJob(job.id)

    return NextResponse.json({ jobId: job.id }, { status: 202 })
  } catch (error) {
    return handleApiError(error)
  }
}
