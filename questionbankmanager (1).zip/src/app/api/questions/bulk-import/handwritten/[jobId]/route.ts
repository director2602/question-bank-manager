import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import type { HandwrittenReviewResult } from '@/lib/pdf/handwritingPipeline'

// GET /api/questions/bulk-import/handwritten/[jobId] — polled by the
// browser after upload to show discrete progress ("Uploading…",
// "Processing page 1 of 8…", "Reading handwriting…", "Detecting
// diagrams…", "Generating professional diagrams…", "Creating
// questions…", "Ready for review.") without making the browser wait on
// one long request. Once status is REVIEW, resultJson (the full
// HandwrittenReviewResult) is returned for the review screen; once
// FAILED, errorMessage is returned with a clear, specific reason.
export async function GET(request: Request, { params }: { params: Promise<{ jobId: string }> }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)
    const { jobId } = await params

    const job = await prisma.importJob.findUnique({ where: { id: jobId } })
    if (!job) {
      return NextResponse.json({ error: 'Import job not found.' }, { status: 404 })
    }
    // Ownership check — a job's original file and extracted content are
    // scoped to whoever uploaded it (plus Owners, who can see everything).
    if (job.createdById !== user.id && user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'You do not have access to this import job.' }, { status: 403 })
    }

    return NextResponse.json({
      jobId: job.id,
      status: job.status,
      stage: job.stage,
      totalPages: job.totalPages,
      errorMessage: job.status === 'FAILED' ? job.errorMessage : null,
      result: job.status === 'REVIEW' ? (job.resultJson as unknown as HandwrittenReviewResult) : null,
      confirmedAt: job.confirmedAt,
      confirmedQuestionCount: job.confirmedQuestionCount,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
