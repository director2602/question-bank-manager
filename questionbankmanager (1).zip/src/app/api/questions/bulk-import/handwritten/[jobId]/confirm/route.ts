import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET } from '@/lib/storage'
import { confirmHandwrittenImportSchema } from '@/lib/validation/handwrittenImport'
import { validateAnswerForQuestionType } from '@/lib/validation/question'
import { hashNormalizedText } from '@/lib/duplicate-detection'
import type { HandwrittenReviewResult, ReviewDiagram } from '@/lib/pdf/handwritingPipeline'
import type { Prisma } from '@prisma/client'

// POST /api/questions/bulk-import/handwritten/[jobId]/confirm — persists
// the user-reviewed rows as real Question + QuestionVersion rows, using
// the SAME tagging sequence and the SAME database as manually created
// questions (Part 7/17 of the spec) — there is no separate/incompatible
// system for handwritten imports.
//
// For each row's chosen diagrams, the finally-picked version (the
// generated SVG reconstruction, a hand-edited SVG, or the original
// cropped photo — "never automatically overwrite the original without
// retaining it") is attached as a real QuestionImage, so diagrams
// automatically flow into the paper generator like any other question
// image (Part 16).
export async function POST(request: Request, { params }: { params: Promise<{ jobId: string }> }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)
    const { jobId } = await params
    const body = confirmHandwrittenImportSchema.parse(await request.json())

    const job = await prisma.importJob.findUnique({ where: { id: jobId } })
    if (!job) {
      return NextResponse.json({ error: 'Import job not found.' }, { status: 404 })
    }
    if (job.createdById !== user.id && user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'You do not have access to this import job.' }, { status: 403 })
    }
    if (job.status !== 'REVIEW') {
      return NextResponse.json(
        { error: `This import is not ready to confirm yet (status: ${job.status}).` },
        { status: 409 }
      )
    }
    if (job.confirmedAt) {
      return NextResponse.json(
        { error: 'This import has already been confirmed and imported into the Question Bank.' },
        { status: 409 }
      )
    }
    const reviewResult = job.resultJson as unknown as HandwrittenReviewResult | null
    if (!reviewResult) {
      return NextResponse.json({ error: 'This import has no extracted content to confirm.' }, { status: 409 })
    }
    const diagramsByKey = new Map<string, ReviewDiagram>(reviewResult.diagrams.map((d) => [d.key, d]))

    // Validate every tag FK server-side — never trust the client's
    // selections, even though they were populated from server-fetched
    // lookup lists on the review screen.
    const [subjectIds, examClassIds, codeIds, difficultyIds, chapterIds, topicIds] = await Promise.all([
      prisma.subject.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.examClass.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.code.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.difficultyLevel.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.chapter.findMany({ where: { isActive: true }, select: { id: true, subjectId: true } }),
      prisma.topic.findMany({ where: { isActive: true }, select: { id: true, chapterId: true } }),
    ])
    const validSubjects = new Set(subjectIds.map((s) => s.id))
    const validClasses = new Set(examClassIds.map((s) => s.id))
    const validCodes = new Set(codeIds.map((s) => s.id))
    const validDifficulties = new Set(difficultyIds.map((s) => s.id))
    const chapterById = new Map(chapterIds.map((c) => [c.id, c]))
    const topicById = new Map(topicIds.map((t) => [t.id, t]))

    const rowErrors: Array<{ tempId: string; message: string }> = []
    for (const row of body.rows) {
      if (!validSubjects.has(row.subjectId)) rowErrors.push({ tempId: row.tempId, message: 'Invalid subject.' })
      if (!validClasses.has(row.examClassId)) rowErrors.push({ tempId: row.tempId, message: 'Invalid class/exam.' })
      if (!validCodes.has(row.codeId)) rowErrors.push({ tempId: row.tempId, message: 'Invalid code.' })
      if (!validDifficulties.has(row.difficultyId)) rowErrors.push({ tempId: row.tempId, message: 'Invalid difficulty.' })
      if (row.chapterId) {
        const chapter = chapterById.get(row.chapterId)
        if (!chapter) rowErrors.push({ tempId: row.tempId, message: 'Invalid chapter.' })
        else if (chapter.subjectId !== row.subjectId) rowErrors.push({ tempId: row.tempId, message: 'Chapter does not belong to the selected subject.' })
      }
      if (row.topicId) {
        const topic = topicById.get(row.topicId)
        if (!topic) rowErrors.push({ tempId: row.tempId, message: 'Invalid topic.' })
        else if (row.chapterId && topic.chapterId !== row.chapterId) rowErrors.push({ tempId: row.tempId, message: 'Topic does not belong to the selected chapter.' })
      }
      if (!row.questionText.trim()) rowErrors.push({ tempId: row.tempId, message: 'Question text is empty.' })
      const answerError = validateAnswerForQuestionType(row.questionType, row.correctAnswer ?? null)
      if (answerError) rowErrors.push({ tempId: row.tempId, message: answerError })
      for (const sel of row.diagramSelections) {
        if (!diagramsByKey.has(sel.key)) rowErrors.push({ tempId: row.tempId, message: `Unknown diagram "${sel.key}".` })
      }
    }

    if (rowErrors.length > 0) {
      return NextResponse.json(
        { error: 'Some rows failed validation. Nothing was imported — fix the rows below and try again.', rowErrors },
        { status: 422 }
      )
    }

    // Upload the final chosen diagram artwork OUTSIDE the DB transaction
    // (storage writes cannot be rolled back by Prisma) — each upload path
    // is unique (uuid-suffixed) so a retry after a partial failure never
    // collides or double-saves.
    const supabase = createAdminClient()
    type PreparedImage = { storagePath: string; fileName: string; mimeType: string; sizeBytes: number }
    const preparedImagesByTempId = new Map<string, PreparedImage[]>()

    for (const row of body.rows) {
      const images: PreparedImage[] = []
      for (const sel of row.diagramSelections) {
        const diagram = diagramsByKey.get(sel.key)
        if (!diagram) continue

        if (sel.choice === 'original') {
          // Reuse the already-uploaded original crop — never re-upload or
          // mutate it, so "Use Original" always retains the untouched source.
          if (diagram.originalStoragePath) {
            images.push({
              storagePath: diagram.originalStoragePath,
              fileName: `${sel.key}-original.png`,
              mimeType: 'image/png',
              sizeBytes: 0,
            })
          }
          continue
        }

        // "generated" (optionally hand-edited on the review screen).
        const svg = sel.editedSvg && sel.editedSvg.trim() ? sel.editedSvg : diagram.generatedSvg
        const svgBuffer = Buffer.from(svg, 'utf-8')
        const path = `question-images/handwritten-import/${jobId}/${sel.key}-final-${uuidv4().slice(0, 8)}.svg`
        const { error: upErr } = await supabase.storage.from(STORAGE_BUCKET).upload(path, svgBuffer, {
          contentType: 'image/svg+xml',
          upsert: false,
        })
        if (upErr) {
          console.error('[handwritten confirm] failed to store diagram svg', sel.key, upErr)
          return NextResponse.json({ error: 'Could not save one of the diagrams. Please try again.' }, { status: 502 })
        }
        images.push({ storagePath: path, fileName: `${sel.key}.svg`, mimeType: 'image/svg+xml', sizeBytes: svgBuffer.byteLength })
      }
      if (images.length > 0) preparedImagesByTempId.set(row.tempId, images)
    }

    const importedIds = await prisma.$transaction(async (tx) => {
      const ids: string[] = []
      for (const row of body.rows) {
        const question = await tx.question.create({
          data: {
            questionNumber: row.questionNumber,
            subjectId: row.subjectId,
            examClassId: row.examClassId,
            codeId: row.codeId,
            difficultyId: row.difficultyId,
            questionType: row.questionType,
            chapterId: row.chapterId ?? null,
            topicId: row.topicId ?? null,
            normalizedTextHash: hashNormalizedText(row.questionText),
            createdById: user.id,
          },
        })
        const version = await tx.questionVersion.create({
          data: {
            questionId: question.id,
            versionNumber: 1,
            questionText: row.questionText,
            optionA: row.optionA ?? null,
            optionB: row.optionB ?? null,
            optionC: row.optionC ?? null,
            optionD: row.optionD ?? null,
            correctAnswer: row.correctAnswer ?? null,
            explanation: row.explanation ?? null,
            markingScheme: row.markingScheme ?? null,
            changeNote: 'Imported via handwritten PDF import',
            createdById: user.id,
          },
        })
        await tx.question.update({ where: { id: question.id }, data: { currentVersionId: version.id } })

        const images = preparedImagesByTempId.get(row.tempId)
        if (images && images.length > 0) {
          for (let i = 0; i < images.length; i++) {
            const img = images[i]
            await tx.questionImage.create({
              data: {
                questionVersionId: version.id,
                storagePath: img.storagePath,
                fileName: img.fileName,
                mimeType: img.mimeType,
                sizeBytes: img.sizeBytes,
                sortOrder: i,
                uploadedById: user.id,
              },
            })
          }
        }

        ids.push(question.id)
      }

      // Mark this import consumed so it can't be double-confirmed; the
      // job stays status=REVIEW and resultJson/original file remain
      // intact and inspectable — only confirmedAt/confirmedQuestionCount
      // change, which is what the review screen and confirm route check.
      await tx.importJob.update({
        where: { id: jobId },
        data: { confirmedAt: new Date(), confirmedQuestionCount: ids.length, stage: `Imported ${ids.length} question(s).` },
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'HANDWRITTEN_IMPORT_CONFIRMED',
          entityType: 'IMPORT_JOB',
          entityId: jobId,
          description: `${user.fullName ?? user.email} confirmed ${ids.length} question(s) from a handwritten PDF import.`,
          newValue: { count: ids.length } as Prisma.InputJsonValue,
        },
        tx
      )

      return ids
    }, { timeout: 60_000, maxWait: 10_000 })

    return NextResponse.json({ importedCount: importedIds.length, questionIds: importedIds }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
