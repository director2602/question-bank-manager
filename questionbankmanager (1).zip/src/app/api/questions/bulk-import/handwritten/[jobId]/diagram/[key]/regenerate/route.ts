import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET } from '@/lib/storage'
import { regenerateDiagramWithAI } from '@/lib/pdf/extractHandwrittenAI'
import { renderDiagramSvg } from '@/lib/pdf/diagramSvgRenderer'
import type { HandwrittenReviewResult, ReviewDiagram } from '@/lib/pdf/handwritingPipeline'
import type { Prisma } from '@prisma/client'

// POST .../handwritten/[jobId]/diagram/[key]/regenerate — the review
// screen's "Regenerate" control (Part 6). Re-runs recognition on just the
// ORIGINAL cropped region for this one diagram (never the whole document),
// in case the first pass got it wrong, and re-renders it deterministically.
// The original crop itself is untouched either way — "never automatically
// overwrite the original without retaining it".
export async function POST(request: Request, { params }: { params: Promise<{ jobId: string; key: string }> }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)
    const { jobId, key } = await params

    const job = await prisma.importJob.findUnique({ where: { id: jobId } })
    if (!job) {
      return NextResponse.json({ error: 'Import job not found.' }, { status: 404 })
    }
    if (job.createdById !== user.id && user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'You do not have access to this import job.' }, { status: 403 })
    }
    if (job.status !== 'REVIEW') {
      return NextResponse.json({ error: `This import is not ready for review yet (status: ${job.status}).` }, { status: 409 })
    }

    const result = job.resultJson as unknown as HandwrittenReviewResult | null
    const diagram = result?.diagrams.find((d) => d.key === key)
    if (!result || !diagram) {
      return NextResponse.json({ error: 'Diagram not found on this import.' }, { status: 404 })
    }
    if (!diagram.originalStoragePath) {
      return NextResponse.json(
        { error: 'No original image region is available for this diagram, so it cannot be regenerated.' },
        { status: 422 }
      )
    }

    const supabase = createAdminClient()
    const { data: fileData, error: downloadError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .download(diagram.originalStoragePath)
    if (downloadError || !fileData) {
      return NextResponse.json({ error: 'Could not re-read the original diagram image.' }, { status: 502 })
    }
    const buffer = Buffer.from(await fileData.arrayBuffer())

    const reExtracted = await regenerateDiagramWithAI(buffer, 'image/png', diagram.diagramType)
    const newSvg = renderDiagramSvg(reExtracted.shapes, { widthPx: 500, heightPx: 500 })

    const updatedDiagram: ReviewDiagram = {
      ...diagram,
      diagramType: reExtracted.diagramType,
      confidence: reExtracted.confidence,
      needsReview: reExtracted.needsReview,
      reviewReason: reExtracted.reviewReason,
      generatedSvg: newSvg,
    }
    const updatedResult: HandwrittenReviewResult = {
      ...result,
      diagrams: result.diagrams.map((d) => (d.key === key ? updatedDiagram : d)),
    }

    await prisma.importJob.update({
      where: { id: jobId },
      data: { resultJson: updatedResult as unknown as Prisma.InputJsonValue },
    })

    return NextResponse.json({ diagram: updatedDiagram })
  } catch (error) {
    return handleApiError(error)
  }
}
