import { NextResponse } from 'next/server'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { extractPdfText, splitIntoQuestions } from '@/lib/pdf/extractQuestions'
import { prisma } from '@/lib/prisma'
import { hashNormalizedText, normalizeQuestionText } from '@/lib/duplicate-detection'

const MAX_PDF_SIZE_BYTES = 25 * 1024 * 1024 // 25 MB

// POST /api/questions/bulk-import/pdf-preview — extracts text from an
// uploaded PDF and splits it into individual candidate questions. Nothing is
// written to the database here; the frontend shows every detected question
// in an editable review list (merge/split/edit text, assign tags) and only
// commits via /bulk-import/confirm once the user explicitly confirms —
// exactly the same review-before-commit flow as CSV import.
export async function POST(request: Request) {
  try {
    await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
      return NextResponse.json({ error: 'Only PDF files are supported here.' }, { status: 400 })
    }
    if (file.size > MAX_PDF_SIZE_BYTES) {
      return NextResponse.json(
        { error: `PDF is too large. Maximum size is ${MAX_PDF_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const buffer = Buffer.from(await file.arrayBuffer())

    let extracted: { text: string; pageCount: number }
    try {
      extracted = await extractPdfText(buffer)
    } catch (err) {
      console.error('[pdf-preview] extraction failed', err)
      return NextResponse.json(
        {
          error:
            'This PDF could not be read. It may be corrupted, password-protected, or an image/scanned document with no extractable text (scanned PDFs need OCR first).',
        },
        { status: 422 }
      )
    }

    if (!extracted.text.trim()) {
      return NextResponse.json(
        {
          error:
            'No extractable text was found in this PDF. If it is a scanned document, run it through OCR first and re-upload, or use the CSV import instead.',
        },
        { status: 422 }
      )
    }

    const questions = splitIntoQuestions(extracted.text)

    if (questions.length === 0) {
      return NextResponse.json(
        {
          error:
            'No individual questions could be identified in this PDF. Question numbering (e.g. "1.", "Q1.") is used to detect boundaries — if this file uses a different style, use CSV import instead, or add questions individually.',
        },
        { status: 422 }
      )
    }

    // Flag likely duplicates against the live bank, same as CSV import.
    const existing = await prisma.question.findMany({
      where: { status: 'ACTIVE' },
      select: { questionNumber: true, normalizedTextHash: true },
    })
    const existingHashes = new Map(existing.map((q) => [q.normalizedTextHash, q.questionNumber]))
    const seenInFile = new Set<string>()

    const rows = questions.map((q) => {
      const hash = q.questionText ? hashNormalizedText(q.questionText) : null
      const normalized = q.questionText ? normalizeQuestionText(q.questionText) : ''
      const isDuplicateInFile = normalized ? seenInFile.has(normalized) : false
      if (normalized) seenInFile.add(normalized)
      const isDuplicateInBank = hash ? existingHashes.has(hash) : false

      return {
        ...q,
        isDuplicateInFile,
        isDuplicateInBank,
        duplicateOfQuestionNumber: hash ? existingHashes.get(hash) : undefined,
      }
    })

    return NextResponse.json({
      pageCount: extracted.pageCount,
      totalDetected: rows.length,
      lowConfidenceCount: rows.filter((r) => r.lowConfidence).length,
      duplicateCount: rows.filter((r) => r.isDuplicateInBank || r.isDuplicateInFile).length,
      rows,
    })
  } catch (error) {
    return handleApiError(error)
  }
}
