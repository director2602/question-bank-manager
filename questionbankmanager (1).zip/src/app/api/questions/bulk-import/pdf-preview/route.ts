import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { extractPdfText, splitIntoQuestions, type ExtractedQuestion } from '@/lib/pdf/extractQuestions'
import { extractQuestionsWithAI, type AIExtractedQuestion } from '@/lib/pdf/extractQuestionsAI'
import { extractDiagramsFromPdf } from '@/lib/pdf/extractDiagrams'
import { prisma } from '@/lib/prisma'
import { hashNormalizedText, normalizeQuestionText } from '@/lib/duplicate-detection'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET, getSignedImageUrl } from '@/lib/storage'

const MAX_PDF_SIZE_BYTES = 25 * 1024 * 1024 // 25 MB

type AnyExtractedQuestion = (ExtractedQuestion | AIExtractedQuestion) & { pageNumber?: number }

// POST /api/questions/bulk-import/pdf-preview — extracts candidate
// questions from an uploaded PDF. Nothing is written to the database here;
// the frontend shows every detected question in an editable review list
// (merge/split/edit text, assign tags, keep/discard diagrams) and only
// commits via /bulk-import/confirm once the user explicitly confirms.
//
// Two extraction paths:
//  - AI mode (when ANTHROPIC_API_KEY is configured): Claude reads the PDF
//    directly, transcribes every question with proper LaTeX for math, and
//    flags which questions have an associated diagram/figure. Actual
//    diagram images are then pulled out of the PDF (best-effort, via
//    poppler's pdfimages) and attached to the nearest question.
//  - Fallback heuristic mode (no API key configured, or the AI call
//    failed): plain-text regex-based splitting, same as before — always
//    available so the feature never fully breaks.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!file.name.toLowerCase().endsWith('.pdf') && file.type !== 'application/pdf') {
      return NextResponse.json({ error: 'Only PDF files are supported here.' }, { status: 400 })
    }
    if (file.size > MAX_PDF_SIZE_BYTES) {
      return NextResponse.json(
        { error: `PDF is too large. Maximum size is ${MAX_PDF_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const buffer = Buffer.from(await file.arrayBuffer())

    let questions: AnyExtractedQuestion[] = []
    let pageCount = 0
    let aiMode = false
    let aiModeError: string | null = null

    if (process.env.ANTHROPIC_API_KEY) {
      try {
        const [aiQuestions, textMeta] = await Promise.all([
          extractQuestionsWithAI(buffer, file.name),
          extractPdfText(buffer).catch(() => ({ text: '', pageCount: 0 })),
        ])
        questions = aiQuestions
        pageCount = textMeta.pageCount
        aiMode = true
      } catch (err) {
        console.error('[pdf-preview] AI extraction failed, falling back to text heuristic', err)
        aiModeError = err instanceof Error ? err.message : 'AI transcription failed for this file.'
      }
    }

    if (!aiMode) {
      let extracted: { text: string; pageCount: number }
      try {
        extracted = await extractPdfText(buffer)
      } catch (err) {
        console.error('[pdf-preview] extraction failed', err)
        return NextResponse.json(
          {
            error:
              'This PDF could not be read. It may be corrupted, password-protected, or an image/scanned document with no extractable text (scanned PDFs need OCR first).',
          },
          { status: 422 }
        )
      }

      if (!extracted.text.trim()) {
        return NextResponse.json(
          {
            error:
              'No extractable text was found in this PDF. If it is a scanned document, run it through OCR first and re-upload, or use the CSV import instead.',
          },
          { status: 422 }
        )
      }

      questions = splitIntoQuestions(extracted.text)
      pageCount = extracted.pageCount
    }

    if (questions.length === 0) {
      return NextResponse.json(
        {
          error:
            'No individual questions could be identified in this PDF. Question numbering (e.g. "1.", "Q1.") is used to detect boundaries — if this file uses a different style, use CSV import instead, or add questions individually.',
        },
        { status: 422 }
      )
    }

    // Diagram extraction: only in AI mode (only there do we know which
    // questions actually have a diagram), and only if a service-role key
    // is configured (needed to upload into Supabase Storage). Missing
    // either of those degrades gracefully — text/LaTeX transcription still
    // works, diagrams just aren't attached automatically.
    const diagramsByRow = new Map<string, Array<{ id: string; url: string }>>()
    let diagramWarning: string | null = null

    if (aiMode && (questions as AIExtractedQuestion[]).some((q) => q.hasDiagram)) {
      if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
        diagramWarning =
          'Diagrams were detected but image storage is not configured on the server yet — questions were transcribed, but diagrams were not attached. Attach them manually after import.'
      } else {
        try {
          const diagrams = await extractDiagramsFromPdf(buffer)
          if (diagrams.length > 0) {
            const aiQuestions = questions as AIExtractedQuestion[]
            const supabase = createAdminClient()
            for (const diagram of diagrams) {
              const target = nearestQuestionForPage(aiQuestions, diagram.pageNumber)
              if (!target) continue
              const ext = diagram.mimeType === 'image/jpeg' ? 'jpg' : 'png'
              const storagePath = `question-images/pdf-import/${uuidv4()}.${ext}`

              const { error: uploadError } = await supabase.storage
                .from(STORAGE_BUCKET)
                .upload(storagePath, diagram.buffer, { contentType: diagram.mimeType, upsert: false })
              if (uploadError) {
                console.error('[pdf-preview] diagram upload failed', uploadError)
                continue
              }

              const image = await prisma.questionImage.create({
                data: {
                  storagePath,
                  fileName: diagram.fileName,
                  mimeType: diagram.mimeType,
                  sizeBytes: diagram.buffer.byteLength,
                  uploadedById: user.id,
                },
              })

              const url = await getSignedImageUrl(storagePath)
              const list = diagramsByRow.get(target.tempId) ?? []
              list.push({ id: image.id, url })
              diagramsByRow.set(target.tempId, list)
            }
          }
        } catch (err) {
          console.error('[pdf-preview] diagram extraction failed', err)
          diagramWarning =
            'Diagram extraction hit an error for this file — questions were still transcribed. Attach diagrams manually after import if needed.'
        }
      }
    }

    // Flag likely duplicates against the live bank, same as CSV import.
    const existing = await prisma.question.findMany({
      where: { status: 'ACTIVE' },
      select: { questionNumber: true, normalizedTextHash: true },
    })
    const existingHashes = new Map(existing.map((q) => [q.normalizedTextHash, q.questionNumber]))
    const seenInFile = new Set<string>()

    const rows = questions.map((q) => {
      const hash = q.questionText ? hashNormalizedText(q.questionText) : null
      const normalized = q.questionText ? normalizeQuestionText(q.questionText) : ''
      const isDuplicateInFile = normalized ? seenInFile.has(normalized) : false
      if (normalized) seenInFile.add(normalized)
      const isDuplicateInBank = hash ? existingHashes.has(hash) : false

      return {
        ...q,
        isDuplicateInFile,
        isDuplicateInBank,
        duplicateOfQuestionNumber: hash ? existingHashes.get(hash) : undefined,
        images: diagramsByRow.get(q.tempId) ?? [],
      }
    })

    return NextResponse.json({
      pageCount,
      totalDetected: rows.length,
      lowConfidenceCount: rows.filter((r) => r.lowConfidence).length,
      duplicateCount: rows.filter((r) => r.isDuplicateInBank || r.isDuplicateInFile).length,
      aiMode,
      aiModeError,
      diagramWarning,
      rows,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// Diagrams don't come with an explicit "belongs to question X" label from
// the PDF itself — only a page number. Prefer a question that starts on
// the exact same page; otherwise fall back to the closest preceding
// question (a diagram on page 4 almost always belongs to the question that
// started there or just before it, not one several pages later).
function nearestQuestionForPage(
  questions: AIExtractedQuestion[],
  pageNumber: number
): AIExtractedQuestion | null {
  const samePage = questions.find((q) => q.pageNumber === pageNumber)
  if (samePage) return samePage

  let best: AIExtractedQuestion | null = null
  for (const q of questions) {
    if (q.pageNumber <= pageNumber && (!best || q.pageNumber > best.pageNumber)) {
      best = q
    }
  }
  return best ?? questions[0] ?? null
}
