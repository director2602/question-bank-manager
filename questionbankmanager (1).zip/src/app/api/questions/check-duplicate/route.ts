import { NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { hashNormalizedText, tokenOverlapSimilarity, SIMILARITY_WARNING_THRESHOLD } from '@/lib/duplicate-detection'
import { questionWithRelations, toQuestionListItem } from '@/lib/serializers'

const schema = z.object({
  questionText: z.string().min(1),
  subjectId: z.string().uuid().optional(),
})

// Live "as-you-type" duplicate check used by the Add Question form, so a
// user sees a warning before they even submit.
export async function POST(request: Request) {
  try {
    await requireUser()
    const { questionText, subjectId } = schema.parse(await request.json())

    const hash = hashNormalizedText(questionText)
    let candidates = await prisma.question.findMany({
      where: { status: 'ACTIVE', normalizedTextHash: hash },
      include: questionWithRelations,
      take: 5,
    })

    if (candidates.length === 0 && subjectId) {
      const sameSubject = await prisma.question.findMany({
        where: { status: 'ACTIVE', subjectId },
        include: questionWithRelations,
        take: 200,
        orderBy: { createdAt: 'desc' },
      })
      candidates = sameSubject
        .filter(
          (c) =>
            tokenOverlapSimilarity(c.currentVersion?.questionText ?? '', questionText) >=
            SIMILARITY_WARNING_THRESHOLD
        )
        .slice(0, 5)
    }

    return NextResponse.json({
      hasDuplicates: candidates.length > 0,
      candidates: candidates.map(toQuestionListItem),
    })
  } catch (error) {
    return handleApiError(error)
  }
}
