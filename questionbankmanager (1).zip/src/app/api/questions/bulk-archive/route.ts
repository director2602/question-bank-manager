import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { bulkQuestionIdsSchema } from '@/lib/validation/question'

// POST /api/questions/bulk-archive — soft-deletes many ACTIVE questions at
// once via a single updateMany (not one request per row). Archiving is
// always safe: it never touches paper_questions, so every paper that used
// these questions keeps rendering exactly as before — only new search/paper
// generation stops surfacing them, exactly like the single-question Archive
// action already does.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_ARCHIVE)
    const { questionIds } = bulkQuestionIdsSchema.parse(await request.json())

    const archivedCount = await prisma.$transaction(async (tx) => {
      const result = await tx.question.updateMany({
        where: { id: { in: questionIds }, status: 'ACTIVE' },
        data: { status: 'ARCHIVED', rowVersion: { increment: 1 } },
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_BULK_ARCHIVED',
          entityType: 'QUESTION',
          entityId: null,
          description: `${user.fullName ?? user.email} bulk-archived ${result.count} question(s).`,
          newValue: { questionIds },
        },
        tx
      )

      return result.count
    })

    return NextResponse.json({ archivedCount })
  } catch (error) {
    return handleApiError(error)
  }
}
