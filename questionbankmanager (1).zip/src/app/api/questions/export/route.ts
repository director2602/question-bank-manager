import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { questionWithRelations } from '@/lib/serializers'
import { CSV_TEMPLATE_HEADERS } from '@/lib/validation/bulkImport'

// GET /api/questions/export — ADMIN only. Exports the full active question
// bank as CSV, in the same column layout as the bulk-import template (so
// it can be re-imported elsewhere). Streams from the database rather than
// holding everything in memory at once — safe for a large bank.
export async function GET(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_EXPORT)
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') === 'ALL' ? undefined : (searchParams.get('status') as 'ACTIVE' | 'ARCHIVED') || 'ACTIVE'

    const questions = await prisma.question.findMany({
      where: status ? { status } : {},
      include: questionWithRelations, // already includes chapter/topic
      orderBy: { createdAt: 'asc' },
    })

    // Column order MUST match CSV_TEMPLATE_HEADERS exactly — this is what
    // makes the export directly re-importable (Backup & Recovery / "get
    // data out" flow).
    const rows = [
      [...CSV_TEMPLATE_HEADERS],
      ...questions.map((q) => [
        q.currentVersion?.questionText ?? '',
        q.questionType,
        q.currentVersion?.optionA ?? '',
        q.currentVersion?.optionB ?? '',
        q.currentVersion?.optionC ?? '',
        q.currentVersion?.optionD ?? '',
        q.currentVersion?.correctAnswer ?? '',
        q.currentVersion?.markingScheme ?? '',
        q.currentVersion?.explanation ?? '',
        q.subject.label,
        q.examClass.label,
        q.chapter?.label ?? '',
        q.topic?.label ?? '',
        q.code.label,
        q.difficulty.label,
        q.questionNumber,
      ]),
    ]

    const csv = rows.map((row) => row.map(csvEscape).join(',')).join('\r\n')

    await writeAuditLog({
      userId: user.id,
      action: 'QUESTION_EXPORTED',
      entityType: 'QUESTION',
      entityId: null,
      description: `${user.fullName ?? user.email} exported ${questions.length} question(s) as CSV.`,
    })

    return new NextResponse(csv, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="question-bank-export-${new Date().toISOString().slice(0, 10)}.csv"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}

function csvEscape(value: string): string {
  if (value == null) return ''
  const str = String(value)
  if (/[",\n\r]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`
  }
  return str
}
