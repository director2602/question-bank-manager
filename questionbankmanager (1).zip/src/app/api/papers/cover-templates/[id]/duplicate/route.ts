import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'

// POST /api/papers/cover-templates/:id/duplicate — "Duplicate Template"
// (spec §25): creates a fully independent copy (own id, own design JSON) so
// editing the copy can never affect the original.
export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const original = await prisma.coverTemplate.findUnique({ where: { id: params.id } })
    if (!original) return NextResponse.json({ error: 'Cover template not found.' }, { status: 404 })

    const copy = await prisma.coverTemplate.create({
      data: {
        name: `${original.name} (Copy)`,
        design: original.design as unknown as Prisma.InputJsonValue,
        isDefault: false,
        createdById: user.id,
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'COVER_TEMPLATE_DUPLICATED',
      entityType: 'COVER_TEMPLATE',
      entityId: copy.id,
      description: `${user.fullName ?? user.email} duplicated cover template "${original.name}".`,
    })

    return NextResponse.json({ item: copy }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
