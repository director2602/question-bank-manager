import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateCoverTemplateSchema } from '@/lib/validation/coverDesign'

// GET /api/papers/cover-templates/:id — the full design JSON, used by
// "Use" (loads it straight into the designer for a paper) and "Edit".
export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireUser()
    const template = await prisma.coverTemplate.findUnique({ where: { id: params.id } })
    if (!template) return NextResponse.json({ error: 'Cover template not found.' }, { status: 404 })
    return NextResponse.json({ item: template })
  } catch (error) {
    return handleApiError(error)
  }
}

// PATCH /api/papers/cover-templates/:id — rename and/or replace the saved
// design (re-saving after further edits to an already-named template).
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = updateCoverTemplateSchema.parse(await request.json())

    const existing = await prisma.coverTemplate.findUnique({ where: { id: params.id }, select: { id: true, name: true } })
    if (!existing) return NextResponse.json({ error: 'Cover template not found.' }, { status: 404 })

    const template = await prisma.coverTemplate.update({
      where: { id: params.id },
      data: {
        ...(body.name !== undefined ? { name: body.name } : {}),
        ...(body.design !== undefined ? { design: body.design as unknown as Prisma.InputJsonValue } : {}),
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'COVER_TEMPLATE_UPDATED',
      entityType: 'COVER_TEMPLATE',
      entityId: template.id,
      description: `${user.fullName ?? user.email} updated cover template "${existing.name}".`,
    })

    return NextResponse.json({ item: template })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE /api/papers/cover-templates/:id — never touches PaperTemplate or
// any paper's own saved coverDesign (a paper that used "Use Template" got
// an independent COPY of the design at that moment, not a live reference).
export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const existing = await prisma.coverTemplate.findUnique({ where: { id: params.id }, select: { id: true, name: true } })
    if (!existing) return NextResponse.json({ error: 'Cover template not found.' }, { status: 404 })

    await prisma.coverTemplate.delete({ where: { id: params.id } })

    await writeAuditLog({
      userId: user.id,
      action: 'COVER_TEMPLATE_DELETED',
      entityType: 'COVER_TEMPLATE',
      entityId: params.id,
      description: `${user.fullName ?? user.email} deleted cover template "${existing.name}".`,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
