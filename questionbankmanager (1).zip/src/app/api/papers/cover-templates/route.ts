import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createCoverTemplateSchema } from '@/lib/validation/coverDesign'

// GET /api/papers/cover-templates — "Cover Templates" list (spec §24):
// every saved reusable cover layout, most recently updated first. Deliberately
// a SEPARATE model/list from PaperTemplate (the original flat
// institute-letterhead picker) — see CoverTemplate's own schema.prisma doc
// comment for why the two must not be merged.
export async function GET() {
  try {
    await requireUser()
    const templates = await prisma.coverTemplate.findMany({
      orderBy: [{ isDefault: 'desc' }, { updatedAt: 'desc' }],
      select: { id: true, name: true, isDefault: true, createdAt: true, updatedAt: true, createdById: true },
    })
    return NextResponse.json({ items: templates })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/papers/cover-templates — "Save as Cover Template" (spec §23).
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = createCoverTemplateSchema.parse(await request.json())

    const template = await prisma.coverTemplate.create({
      data: {
        name: body.name,
        design: body.design as unknown as Prisma.InputJsonValue,
        createdById: user.id,
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'COVER_TEMPLATE_CREATED',
      entityType: 'COVER_TEMPLATE',
      entityId: template.id,
      description: `${user.fullName ?? user.email} saved a new cover template "${body.name}".`,
    })

    return NextResponse.json({ item: template }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
