import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { movePaperSchema } from '@/lib/validation/folder'

// POST /api/papers/:id/move — move a paper into a folder, or back to
// "Uncategorized" by passing folderId: null.
export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const { folderId } = movePaperSchema.parse(await request.json())

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    let folderName = 'Uncategorized'
    if (folderId) {
      const folder = await prisma.paperFolder.findUnique({ where: { id: folderId } })
      if (!folder) return NextResponse.json({ error: 'Folder not found.' }, { status: 404 })
      folderName = folder.name
    }

    await prisma.$transaction(async (tx) => {
      await tx.paper.update({ where: { id: params.id }, data: { folderId } })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_MOVED_TO_FOLDER',
          entityType: 'PAPER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} moved paper "${paper.title}" to "${folderName}".`,
        },
        tx
      )
    })

    return NextResponse.json({ success: true, folderId })
  } catch (error) {
    return handleApiError(error)
  }
}
