import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { buildPaperCsvRows, paperRowsToCsv } from '@/lib/csv/paperCsvExport'

// GET /api/papers/:id/export/csv — a flat, one-row-per-question CSV of the
// paper's real data (Paper, Folder, Question Number, Section, Question,
// Question Type, Option A-D, Correct Answer, Marks, Difficulty, Image
// Reference) — no PDF/DOCX rendering involved, so this always works even
// if Puppeteer or image fetches are unavailable.
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    // CSV has no concept of an "answer key" layout — correct answers are
    // just another column — so unlike PDF/DOCX, mode only controls
    // whether the Correct Answer column is included at all (a paper handed
    // to students as a raw question list shouldn't leak answers).
    const includeAnswers = searchParams.get('mode') !== 'question'

    const paper = await prisma.paper.findUnique({
      where: { id: params.id },
      include: { folder: { select: { name: true } } },
    })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const questions = await buildPaperSnapshot(params.id)
    if (questions.length === 0) {
      return NextResponse.json({ error: 'This paper has no questions to export.' }, { status: 422 })
    }

    const rows = buildPaperCsvRows(paper.title, paper.folder?.name ?? null, questions).map((row) =>
      includeAnswers ? row : { ...row, correctAnswer: null }
    )
    const csv = paperRowsToCsv(rows)

    await writeAuditLog({
      userId: user.id,
      action: 'PAPER_EXPORTED_CSV',
      entityType: 'PAPER',
      entityId: params.id,
      description: `${user.fullName ?? user.email} exported paper "${paper.title}" (#${paper.paperNumber}) as CSV.`,
    })

    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="paper-${paper.paperNumber}.csv"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
