import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError, ConflictError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updatePaperSchema } from '@/lib/validation/paper'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'

async function serializePaper(paperId: string) {
  const paper = await prisma.paper.findUnique({
    where: { id: paperId },
    include: { createdBy: { select: { id: true, fullName: true, email: true } } },
  })
  if (!paper) return null
  const snapshot = await buildPaperSnapshot(paperId)
  const latestVersion = await prisma.paperVersion.findFirst({
    where: { paperId },
    orderBy: { versionNumber: 'desc' },
    select: { versionNumber: true, createdAt: true },
  })
  return { paper, questions: snapshot, latestVersionNumber: latestVersion?.versionNumber ?? 0 }
}

// GET /api/papers/:id — the paper's CURRENT live composition (used by the
// Paper Builder). For a stable historical view use
// /api/papers/:id/versions/:versionNumber instead.
export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireUser()
    const result = await serializePaper(params.id)
    if (!result) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })
    return NextResponse.json(result)
  } catch (error) {
    return handleApiError(error)
  }
}

// PATCH /api/papers/:id — the Paper Builder's single save endpoint. Accepts
// the full ordered `questionIds` list (covers reorder/remove/add/replace in
// one atomic operation), settings fields, and an optimistic-lock
// `rowVersion`. Optionally creates an immutable PaperVersion snapshot in the
// same transaction when `createSnapshot` is true (used by "Save", "Export",
// and "Finalize").
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = updatePaperSchema.parse(await request.json())

    const existing = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!existing) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    if (existing.rowVersion !== body.rowVersion) {
      throw new ConflictError(
        'This paper was changed by another user while you were editing. Reload to see the latest version before saving.'
      )
    }

    if (body.questionIds) {
      const uniqueIds = new Set(body.questionIds)
      if (uniqueIds.size !== body.questionIds.length) {
        return NextResponse.json(
          { error: 'The same question cannot appear twice in one paper.' },
          { status: 400 }
        )
      }
      const found = await prisma.question.findMany({
        where: { id: { in: body.questionIds } },
        select: { id: true, status: true, currentVersionId: true },
      })
      if (found.length !== body.questionIds.length) {
        return NextResponse.json({ error: 'One or more questions could not be found.' }, { status: 400 })
      }
      const archived = found.filter((f) => f.status !== 'ACTIVE')
      if (archived.length > 0) {
        return NextResponse.json(
          { error: 'One or more selected questions are archived and cannot be added to a paper.' },
          { status: 400 }
        )
      }
    }

    await prisma.$transaction(async (tx) => {
      const lock = await tx.paper.updateMany({
        where: { id: params.id, rowVersion: body.rowVersion },
        data: {
          rowVersion: { increment: 1 },
          ...(body.title !== undefined ? { title: body.title } : {}),
          ...(body.subtitle !== undefined ? { subtitle: body.subtitle } : {}),
          ...(body.instituteName !== undefined ? { instituteName: body.instituteName } : {}),
          ...(body.logoUrl !== undefined ? { logoUrl: body.logoUrl } : {}),
          ...(body.examName !== undefined ? { examName: body.examName } : {}),
          ...(body.subjectLabel !== undefined ? { subjectLabel: body.subjectLabel } : {}),
          ...(body.classLabel !== undefined ? { classLabel: body.classLabel } : {}),
          ...(body.examDate !== undefined ? { examDate: body.examDate ? new Date(body.examDate) : null } : {}),
          ...(body.examTime !== undefined ? { examTime: body.examTime } : {}),
          ...(body.maxMarks !== undefined ? { maxMarks: body.maxMarks } : {}),
          ...(body.instructions !== undefined ? { instructions: body.instructions } : {}),
          ...(body.headerText !== undefined ? { headerText: body.headerText } : {}),
          ...(body.footerText !== undefined ? { footerText: body.footerText } : {}),
          ...(body.status !== undefined ? { status: body.status } : {}),
        },
      })
      if (lock.count === 0) {
        throw new ConflictError(
          'This paper was changed by another user while you were editing. Reload to see the latest version before saving.'
        )
      }

      if (body.questionIds) {
        const questions = await tx.question.findMany({
          where: { id: { in: body.questionIds } },
          select: { id: true, currentVersionId: true },
        })
        const versionMap = new Map(questions.map((q) => [q.id, q.currentVersionId]))

        await tx.paperQuestion.deleteMany({ where: { paperId: params.id } })
        await tx.paperQuestion.createMany({
          data: body.questionIds.map((qId, idx) => ({
            paperId: params.id,
            questionId: qId,
            questionVersionId: versionMap.get(qId)!,
            position: idx + 1,
          })),
        })
      }

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_EDITED',
          entityType: 'PAPER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} edited paper "${existing.title}".`,
        },
        tx
      )

      if (body.createSnapshot) {
        const snapshot = await buildPaperSnapshot(params.id)
        const last = await tx.paperVersion.findFirst({
          where: { paperId: params.id },
          orderBy: { versionNumber: 'desc' },
        })
        const nextVersionNumber = (last?.versionNumber ?? 0) + 1
        const currentPaper = await tx.paper.findUniqueOrThrow({ where: { id: params.id } })

        await tx.paperVersion.create({
          data: {
            paperId: params.id,
            versionNumber: nextVersionNumber,
            snapshot,
            settings: {
              title: currentPaper.title,
              instituteName: currentPaper.instituteName,
              logoUrl: currentPaper.logoUrl,
              examName: currentPaper.examName,
              subjectLabel: currentPaper.subjectLabel,
              classLabel: currentPaper.classLabel,
              examDate: currentPaper.examDate,
              examTime: currentPaper.examTime,
              maxMarks: currentPaper.maxMarks,
              instructions: currentPaper.instructions,
              headerText: currentPaper.headerText,
              footerText: currentPaper.footerText,
            },
            createdById: user.id,
          },
        })

        await writeAuditLog(
          {
            userId: user.id,
            action: 'PAPER_SNAPSHOT_SAVED',
            entityType: 'PAPER',
            entityId: params.id,
            description: `${user.fullName ?? user.email} saved snapshot v${nextVersionNumber} of paper "${currentPaper.title}".`,
          },
          tx
        )
      }
    })

    const result = await serializePaper(params.id)
    return NextResponse.json(result)
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE /api/papers/:id — ADMIN only. Deletes the paper and its versions;
// the underlying questions in the bank are completely unaffected.
export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(['ADMIN'])
    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    await prisma.$transaction(async (tx) => {
      await tx.paper.delete({ where: { id: params.id } })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_DELETED',
          entityType: 'PAPER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} deleted paper "${paper.title}" (#${paper.paperNumber}).`,
        },
        tx
      )
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
