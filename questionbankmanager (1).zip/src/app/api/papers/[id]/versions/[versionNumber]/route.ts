import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

// GET /api/papers/:id/versions/:versionNumber — a fully stable, historical
// rendering of the paper exactly as it was at snapshot time. This is what
// "Open Paper #100 six months later" resolves to: the embedded snapshot
// JSON, never the live (possibly since-edited) question content.
export async function GET(
  _request: Request,
  { params }: { params: { id: string; versionNumber: string } }
) {
  try {
    await requireUser()
    const versionNumber = Number(params.versionNumber)
    if (!Number.isInteger(versionNumber)) {
      return NextResponse.json({ error: 'Invalid version number.' }, { status: 400 })
    }

    const version = await prisma.paperVersion.findUnique({
      where: { paperId_versionNumber: { paperId: params.id, versionNumber } },
      include: { createdBy: { select: { id: true, fullName: true, email: true } } },
    })
    if (!version) return NextResponse.json({ error: 'Paper version not found.' }, { status: 404 })

    const paper = await prisma.paper.findUnique({
      where: { id: params.id },
      select: { paperNumber: true, title: true, mode: true, status: true, generationFilters: true },
    })

    return NextResponse.json({
      paper,
      versionNumber: version.versionNumber,
      settings: version.settings,
      questions: version.snapshot,
      createdBy: version.createdBy,
      createdAt: version.createdAt.toISOString(),
    })
  } catch (error) {
    return handleApiError(error)
  }
}
