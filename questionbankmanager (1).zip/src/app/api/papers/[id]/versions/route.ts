import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireUser()
    const versions = await prisma.paperVersion.findMany({
      where: { paperId: params.id },
      orderBy: { versionNumber: 'desc' },
      include: { createdBy: { select: { id: true, fullName: true, email: true } } },
    })
    return NextResponse.json({
      items: versions.map((v) => ({
        versionNumber: v.versionNumber,
        createdBy: v.createdBy,
        createdAt: v.createdAt.toISOString(),
        questionCount: Array.isArray(v.snapshot) ? v.snapshot.length : 0,
      })),
    })
  } catch (error) {
    return handleApiError(error)
  }
}
