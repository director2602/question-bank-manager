import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError, ConflictError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { saveCoverDesignSchema, emptyCoverDesign } from '@/lib/validation/coverDesign'
import { parseCoverDesignJson, buildCoverImagePreviewUrls } from '@/lib/pdf/coverDesignPipeline'

// GET /api/papers/:id/cover — the Cover Page Designer's own load endpoint.
// Returns the paper's saved CoverDesign EXACTLY as stored (imagePath/
// referenceImagePath are real Supabase Storage paths, safe to save straight
// back unchanged) plus a separate `imagePreviewUrls` map (path → signed
// URL) for the canvas to actually render — keeping "what gets saved" and
// "what gets displayed" as two distinct things is what stops an edit
// session from ever accidentally persisting an expiring signed URL into
// the design JSON (see coverDesignPipeline.ts's doc comments).
export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireUser()

    const paper = await prisma.paper.findUnique({
      where: { id: params.id },
      select: { id: true, coverDesign: true, separateFrontPage: true, rowVersion: true },
    })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const design = parseCoverDesignJson(paper.coverDesign)
    const coverDesign = design ?? emptyCoverDesign()
    const imagePreviewUrls = design ? await buildCoverImagePreviewUrls(design) : {}

    return NextResponse.json({
      coverDesign,
      imagePreviewUrls,
      hasSavedDesign: design !== null,
      separateFrontPage: paper.separateFrontPage,
      rowVersion: paper.rowVersion,
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// PATCH /api/papers/:id/cover — "Save Cover Design" (spec §22). Stores the
// full editable CoverDesign JSON (never a screenshot) plus the
// separateFrontPage toggle onto the paper's existing coverDesign/
// separateFrontPage columns. Image paths in the submitted design are
// expected to already be Supabase Storage PATHS (never signed URLs — those
// expire; the designer UI is responsible for converting a displayed signed
// URL back to its underlying path before saving, same convention as
// QuestionImage.storagePath elsewhere in this app).
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = saveCoverDesignSchema.parse(await request.json())

    const existing = await prisma.paper.findUnique({ where: { id: params.id }, select: { id: true, title: true, rowVersion: true } })
    if (!existing) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    if (existing.rowVersion !== body.rowVersion) {
      throw new ConflictError(
        'This paper was changed by another user while you were editing the cover. Reload to see the latest version before saving.'
      )
    }

    const updated = await prisma.$transaction(async (tx) => {
      const lock = await tx.paper.updateMany({
        where: { id: params.id, rowVersion: body.rowVersion },
        data: {
          rowVersion: { increment: 1 },
          coverDesign: body.coverDesign as unknown as Prisma.InputJsonValue,
          separateFrontPage: body.separateFrontPage,
        },
      })
      if (lock.count === 0) {
        throw new ConflictError(
          'This paper was changed by another user while you were editing the cover. Reload to see the latest version before saving.'
        )
      }

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_COVER_DESIGN_SAVED',
          entityType: 'PAPER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} saved a custom cover design for paper "${existing.title}".`,
        },
        tx
      )

      return tx.paper.findUniqueOrThrow({ where: { id: params.id }, select: { rowVersion: true } })
    })

    return NextResponse.json({ rowVersion: updated.rowVersion })
  } catch (error) {
    return handleApiError(error)
  }
}
