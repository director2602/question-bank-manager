import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError, ConflictError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { paperQuestionImageActionSchema } from '@/lib/validation/paper'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET } from '@/lib/storage'

// PATCH /api/papers/:id/questions/:paperQuestionId/images — add, replace,
// remove, hide, or restore an image on ONE question as displayed in THIS
// paper only. Mirrors the text/options override endpoint one level up:
// writes only ever touch question_images.paper_question_id/
// overrides_image_id or the paper_image_removals table — never
// question_versions or a master question_images row — so the master
// Question Bank and every other paper referencing the same question are
// completely unaffected. See buildPaperSnapshot for exactly how these are
// merged when rendering.
//
// Every image referenced by `imageId` here must already exist as an
// orphaned QuestionImage row (uploaded via the existing, unchanged
// POST /api/questions/images — the same endpoint the Question Bank's own
// forms use) — this route only ever re-labels an already-uploaded image,
// never accepts raw file bytes itself.
export async function PATCH(
  request: Request,
  { params }: { params: { id: string; paperQuestionId: string } }
) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = paperQuestionImageActionSchema.parse(await request.json())

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    // Optimistic lock on the PAPER (same rowVersion PaperEditor already
    // tracks for every other save) — never on the question itself, since
    // none of this touches Question/QuestionVersion.
    if (paper.rowVersion !== body.rowVersion) {
      throw new ConflictError(
        'This paper was changed by another user while you were editing. Reload to see the latest version before saving.'
      )
    }

    const pq = await prisma.paperQuestion.findUnique({
      where: { id: params.paperQuestionId },
      include: {
        question: { select: { questionNumber: true } },
        questionVersion: { include: { images: true } },
        overrideImages: true,
        imageRemovals: true,
      },
    })
    if (!pq || pq.paperId !== params.id) {
      return NextResponse.json({ error: 'This question is not part of this paper.' }, { status: 404 })
    }

    // Storage objects to delete once the transaction has committed — never
    // deleted first, so a mid-transaction failure never leaves a dangling
    // DB reference to an already-removed file.
    const storagePathsToDelete: string[] = []
    let auditAction: 'PAPER_QUESTION_IMAGE_OVERRIDDEN' | 'PAPER_QUESTION_IMAGE_OVERRIDE_CLEARED'
    let auditDetail: string

    if (body.action === 'add' || body.action === 'replace') {
      const image = await prisma.questionImage.findUnique({ where: { id: body.imageId } })
      if (!image) return NextResponse.json({ error: 'Image not found.' }, { status: 404 })
      if (image.paperQuestionId || image.questionVersionId) {
        return NextResponse.json(
          { error: 'This image is already attached elsewhere and cannot be reused here.' },
          { status: 409 }
        )
      }
    }

    let masterImage: (typeof pq.questionVersion.images)[number] | undefined
    if (body.action === 'replace' || body.action === 'hideMaster' || body.action === 'restoreMaster') {
      masterImage = pq.questionVersion.images.find((img) => img.id === body.masterImageId)
      if (!masterImage) {
        return NextResponse.json({ error: 'That image does not belong to this question.' }, { status: 400 })
      }
    }

    if (body.action === 'replace') {
      // Swap out any prior replacement of this exact master image first, so
      // a master image never ends up with two competing overrides.
      const priorReplacement = pq.overrideImages.find((img) => img.overridesImageId === body.masterImageId)
      if (priorReplacement) storagePathsToDelete.push(priorReplacement.storagePath)
      auditAction = 'PAPER_QUESTION_IMAGE_OVERRIDDEN'
      auditDetail = `replaced an image for question ${pq.question.questionNumber} in paper "${paper.title}" — this paper only`
    } else if (body.action === 'add') {
      auditAction = 'PAPER_QUESTION_IMAGE_OVERRIDDEN'
      auditDetail = `added an image to question ${pq.question.questionNumber} in paper "${paper.title}" — this paper only`
    } else if (body.action === 'removeOverride') {
      const override = pq.overrideImages.find((img) => img.id === body.overrideImageId)
      if (!override) return NextResponse.json({ error: 'That image override was not found.' }, { status: 404 })
      storagePathsToDelete.push(override.storagePath)
      auditAction = 'PAPER_QUESTION_IMAGE_OVERRIDE_CLEARED'
      auditDetail = override.overridesImageId
        ? `reverted an image for question ${pq.question.questionNumber} in paper "${paper.title}" back to the original Question Bank image`
        : `removed a paper-only image from question ${pq.question.questionNumber} in paper "${paper.title}"`
    } else if (body.action === 'hideMaster') {
      auditAction = 'PAPER_QUESTION_IMAGE_OVERRIDDEN'
      auditDetail = `hid a Question Bank image on question ${pq.question.questionNumber} in paper "${paper.title}" — this paper only; the Question Bank image itself is unchanged`
    } else {
      auditAction = 'PAPER_QUESTION_IMAGE_OVERRIDE_CLEARED'
      auditDetail = `restored a hidden image on question ${pq.question.questionNumber} in paper "${paper.title}"`
    }

    await prisma.$transaction(async (tx) => {
      const lock = await tx.paper.updateMany({
        where: { id: params.id, rowVersion: body.rowVersion },
        data: { rowVersion: { increment: 1 } },
      })
      if (lock.count === 0) {
        throw new ConflictError(
          'This paper was changed by another user while you were editing. Reload to see the latest version before saving.'
        )
      }

      if (body.action === 'add') {
        await tx.questionImage.update({
          where: { id: body.imageId },
          data: { paperQuestionId: pq.id, overridesImageId: null },
        })
      } else if (body.action === 'replace') {
        const priorReplacement = pq.overrideImages.find((img) => img.overridesImageId === body.masterImageId)
        if (priorReplacement) await tx.questionImage.delete({ where: { id: priorReplacement.id } })
        await tx.questionImage.update({
          where: { id: body.imageId },
          data: { paperQuestionId: pq.id, overridesImageId: body.masterImageId },
        })
      } else if (body.action === 'removeOverride') {
        await tx.questionImage.delete({ where: { id: body.overrideImageId } })
      } else if (body.action === 'hideMaster') {
        await tx.paperImageRemoval.upsert({
          where: { paperQuestionId_questionImageId: { paperQuestionId: pq.id, questionImageId: body.masterImageId } },
          create: { paperQuestionId: pq.id, questionImageId: body.masterImageId, removedById: user.id },
          update: {},
        })
      } else {
        await tx.paperImageRemoval.deleteMany({
          where: { paperQuestionId: pq.id, questionImageId: body.masterImageId },
        })
      }

      await writeAuditLog(
        {
          userId: user.id,
          action: auditAction,
          entityType: 'PAPER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} ${auditDetail}.`,
        },
        tx
      )
    })

    if (storagePathsToDelete.length > 0) {
      const supabase = createAdminClient()
      await supabase.storage.from(STORAGE_BUCKET).remove(storagePathsToDelete)
    }

    const [updatedPaper, questions] = await Promise.all([
      prisma.paper.findUniqueOrThrow({ where: { id: params.id } }),
      buildPaperSnapshot(params.id),
    ])

    return NextResponse.json({ paper: updatedPaper, questions })
  } catch (error) {
    return handleApiError(error)
  }
}
