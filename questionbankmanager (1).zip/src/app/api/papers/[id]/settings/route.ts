import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { paperSettingsSchema } from '@/lib/validation/paperSettings'

// GET /api/papers/:id/settings
//
// Every paper has at most one PaperSettings row (schema: `paperId String
// @unique`). Rather than requiring a separate "initialize settings" step,
// the row is created lazily here with the app defaults (2 columns / Calibri
// / 11pt — see the Prisma column @default()s, the single source of truth
// for those numbers) the first time anyone asks for it, so the Paper
// Builder UI, the print view, and the PDF/DOCX exporters can all always
// assume a settings row exists once a paper does.
export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireRole(PERMISSIONS.PAPER_GENERATE)

    const paper = await prisma.paper.findUnique({ where: { id: params.id }, select: { id: true } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    let settings = await prisma.paperSettings.findUnique({ where: { paperId: params.id } })
    if (!settings) {
      settings = await prisma.paperSettings.create({ data: { paperId: params.id } })
    }

    return NextResponse.json({ item: settings })
  } catch (error) {
    return handleApiError(error)
  }
}

// PATCH /api/papers/:id/settings — partial update, upserts the row if it
// somehow doesn't exist yet. No rowVersion/optimistic-locking here (unlike
// the paper content itself): this is low-stakes per-user-session layout
// config, not shared question content, so last-write-wins is an acceptable,
// simple, and consistent choice — mirrors how /api/papers/:id/move and
// other single-field paper mutations behave.
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = paperSettingsSchema.parse(await request.json())

    const paper = await prisma.paper.findUnique({ where: { id: params.id }, select: { id: true, title: true } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const settings = await prisma.$transaction(async (tx) => {
      const updated = await tx.paperSettings.upsert({
        where: { paperId: params.id },
        create: { paperId: params.id, ...body },
        update: body,
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_SETTINGS_UPDATED',
          entityType: 'PAPER',
          entityId: params.id,
          description: `${user.fullName ?? user.email} updated layout/typography settings for paper "${paper.title}".`,
          newValue: body,
        },
        tx
      )

      return updated
    })

    return NextResponse.json({ item: settings })
  } catch (error) {
    return handleApiError(error)
  }
}
