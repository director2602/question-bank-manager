import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'

// POST /api/papers/:id/duplicate — creates a brand-new DRAFT paper with the
// same current question composition and settings, so a user can produce a
// fresh variant (e.g. a re-sit paper) without touching the original.
export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)

    const source = await prisma.paper.findUnique({
      where: { id: params.id },
      include: {
        questions: { orderBy: { position: 'asc' } },
        // Advanced Paper Builder papers carry their section structure in
        // PaperSection, not on each PaperQuestion — pull it along so a
        // duplicated section-based paper keeps its sections, not just a
        // flat question list.
        sections: { orderBy: { position: 'asc' } },
      },
    })
    if (!source) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const created = await prisma.$transaction(async (tx) => {
      const newPaper = await tx.paper.create({
        data: {
          title: `${source.title} (Copy)`,
          subtitle: source.subtitle,
          mode: source.mode,
          status: 'DRAFT',
          generationFilters: source.generationFilters as any,
          headingConfig: source.headingConfig as any,
          allowReuseOfPastQuestions: source.allowReuseOfPastQuestions,
          instituteName: source.instituteName,
          logoUrl: source.logoUrl,
          examName: source.examName,
          subjectLabel: source.subjectLabel,
          classLabel: source.classLabel,
          examDate: source.examDate,
          examTime: source.examTime,
          maxMarks: source.maxMarks,
          instructions: source.instructions,
          headerText: source.headerText,
          footerText: source.footerText,
          createdById: user.id,
        },
      })

      // Recreate each PaperSection under the new paper first, so the
      // duplicated questions below can point their sectionId at the *new*
      // paper's sections rather than the original paper's.
      const sectionIdMap = new Map<string, string>()
      for (const section of source.sections) {
        const newSection = await tx.paperSection.create({
          data: {
            paperId: newPaper.id,
            position: section.position,
            label: section.label,
            title: section.title,
            instructions: section.instructions,
            numberingMode: section.numberingMode,
            answerSpace: section.answerSpace,
            customAnswerSpaceMm: section.customAnswerSpaceMm,
            typeConfig: section.typeConfig as any,
          },
        })
        sectionIdMap.set(section.id, newSection.id)
      }

      await tx.paperQuestion.createMany({
        data: source.questions.map((q) => ({
          paperId: newPaper.id,
          questionId: q.questionId,
          questionVersionId: q.questionVersionId,
          position: q.position,
          sectionId: q.sectionId ? (sectionIdMap.get(q.sectionId) ?? null) : null,
          marks: q.marks,
        })),
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_DUPLICATED',
          entityType: 'PAPER',
          entityId: newPaper.id,
          description: `${user.fullName ?? user.email} duplicated paper "${source.title}" (#${source.paperNumber}) into a new draft.`,
        },
        tx
      )

      return newPaper
    })

    return NextResponse.json({ item: { id: created.id, paperNumber: created.paperNumber } }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
