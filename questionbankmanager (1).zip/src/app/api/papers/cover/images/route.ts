import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET, getSignedImageUrl } from '@/lib/storage'
import { MAX_IMAGE_SIZE_BYTES, ALLOWED_IMAGE_MIME_TYPES } from '@/lib/constants'

// POST /api/papers/cover/images — uploads one image/logo for use inside the
// Cover Page Designer (spec §12-13). Mirrors POST /api/questions/images'
// storage-upload mechanics exactly, but returns a bare storagePath instead
// of creating a QuestionImage row: a cover element's imagePath IS the
// storage path (see coverDesign.ts's own doc comment on why — same
// "path, not signed URL" convention QuestionImage.storagePath already
// uses), and the design JSON that references it is the only "ownership"
// record this feature needs, matching how Paper.logoUrl already works with
// no separate tracking table either.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    if (!ALLOWED_IMAGE_MIME_TYPES.includes(file.type)) {
      return NextResponse.json(
        { error: `Unsupported file type "${file.type}". Allowed: PNG, JPEG, WEBP, SVG.` },
        { status: 400 }
      )
    }
    if (file.size === 0) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 })
    }
    if (file.size > MAX_IMAGE_SIZE_BYTES) {
      return NextResponse.json(
        { error: `File is too large. Maximum size is ${MAX_IMAGE_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const arrayBuffer = await file.arrayBuffer()
    const ext = file.name.split('.').pop() || 'bin'
    const storagePath = `cover-images/${user.id}/${uuidv4()}.${ext}`

    const supabase = createAdminClient()
    const { error: uploadError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(storagePath, Buffer.from(arrayBuffer), {
        contentType: file.type,
        upsert: false,
      })

    if (uploadError) {
      console.error('[cover image upload] storage error', uploadError)
      return NextResponse.json({ error: 'Image upload failed. Please try again.' }, { status: 502 })
    }

    return NextResponse.json(
      { item: { storagePath, url: await getSignedImageUrl(storagePath), fileName: file.name } },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
