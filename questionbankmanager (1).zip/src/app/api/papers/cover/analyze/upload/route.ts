import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { prisma } from '@/lib/prisma'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET } from '@/lib/storage'
import { processCoverDesignAnalysisJob } from '@/lib/pdf/coverDesignPipeline'

// Cover Page Designer — "Upload Reference Image" (spec §1). Same
// fire-and-forget ImportJob pattern as the Handwritten PDF importer (see
// src/app/api/questions/bulk-import/handwritten/upload/route.ts): store the
// original untouched, create a job, kick off analysis without waiting, and
// let the browser poll GET /api/papers/cover/analyze/[jobId] for progress.
const MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024 // 15 MB — a cover photo/screenshot, not a whole scanned PDF
const ALLOWED_TYPES: Record<string, string> = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
}

export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)

    const formData = await request.formData()
    const file = formData.get('file')
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'No file was provided.' }, { status: 400 })
    }
    const ext = ALLOWED_TYPES[file.type]
    if (!ext) {
      return NextResponse.json(
        { error: 'Unsupported file type. Upload a PNG, JPG/JPEG, or WEBP image.' },
        { status: 400 }
      )
    }
    if (file.size === 0) {
      return NextResponse.json({ error: 'The uploaded file is empty.' }, { status: 400 })
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      return NextResponse.json(
        { error: `File is too large. Maximum size is ${MAX_FILE_SIZE_BYTES / (1024 * 1024)} MB.` },
        { status: 400 }
      )
    }

    const buffer = Buffer.from(await file.arrayBuffer())
    const supabase = createAdminClient()
    const jobId = uuidv4()
    const storagePath = `cover-reference/${jobId}/original.${ext}`
    const { error: uploadError } = await supabase.storage.from(STORAGE_BUCKET).upload(storagePath, buffer, {
      contentType: file.type,
      upsert: false,
    })
    if (uploadError) {
      console.error('[cover analyze upload] storage upload failed', uploadError)
      return NextResponse.json({ error: 'Could not store the uploaded image. Please try again.' }, { status: 500 })
    }

    const job = await prisma.importJob.create({
      data: {
        id: jobId,
        kind: 'COVER_DESIGN_ANALYSIS',
        status: 'PENDING',
        originalFileName: file.name,
        originalStoragePath: storagePath,
        createdById: user.id,
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'COVER_DESIGN_ANALYSIS_STARTED',
      entityType: 'IMPORT_JOB',
      entityId: job.id,
      description: `${user.fullName ?? user.email} uploaded a cover reference image ("${file.name}") for design analysis.`,
    })

    // Fire-and-forget — see handwritingPipeline.ts's identical note: this
    // app runs as a persistent Node server, so this promise safely keeps
    // running after the response is sent, and any error is caught and
    // written to the job row inside processCoverDesignAnalysisJob itself.
    void processCoverDesignAnalysisJob(job.id)

    return NextResponse.json({ jobId: job.id }, { status: 202 })
  } catch (error) {
    return handleApiError(error)
  }
}
