import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { getSignedImageUrl } from '@/lib/storage'
import type { CoverDesignAnalysisResult } from '@/lib/ai/coverDesignAnalysis'

// GET /api/papers/cover/analyze/:jobId — polled by the Cover Page
// Designer's "Analyze Design" flow (spec §4's "Design Analysis Complete /
// Text detected: N / Images detected: N / Shapes detected: N / Sections
// detected: N" summary is derived client-side from `result` below).
export async function GET(_request: Request, { params }: { params: { jobId: string } }) {
  try {
    const user = await requireUser()

    const job = await prisma.importJob.findUnique({ where: { id: params.jobId } })
    if (!job || job.kind !== 'COVER_DESIGN_ANALYSIS') {
      return NextResponse.json({ error: 'Cover analysis job not found.' }, { status: 404 })
    }
    if (job.createdById !== user.id && user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'You do not have access to this job.' }, { status: 403 })
    }

    return NextResponse.json({
      jobId: job.id,
      status: job.status,
      stage: job.stage,
      errorMessage: job.status === 'FAILED' ? job.errorMessage : null,
      result: job.status === 'REVIEW' ? (job.resultJson as unknown as CoverDesignAnalysisResult) : null,
      // The raw storage path — saved verbatim onto CoverDesign.background.
      // referenceImagePath if the user picks "Use Reference as Background"
      // (never a signed URL, which expires; see coverDesign.ts).
      originalStoragePath: job.originalStoragePath,
      // A short-lived signed URL for immediately PREVIEWING the uploaded
      // reference image in the designer UI — display only, never saved.
      referenceImagePreviewUrl: await getSignedImageUrl(job.originalStoragePath),
    })
  } catch (error) {
    return handleApiError(error)
  }
}
