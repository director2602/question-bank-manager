import { NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { convertAnalysisToCoverDesign } from '@/lib/pdf/coverDesignPipeline'
import type { CoverDesignAnalysisResult } from '@/lib/ai/coverDesignAnalysis'

const bodySchema = z.object({
  pageSize: z.enum(['A4', 'LETTER', 'LEGAL']).default('A4'),
})

// POST /api/papers/cover/analyze/:jobId/convert — "Use as Template"
// (spec §14): turns the bounded analysis result into REAL, individually
// editable CoverElements (never a flat background image) and hands the
// resulting CoverDesign straight back to open in the designer. Nothing is
// persisted here — the design only saves when the user explicitly hits
// "Save Cover Design" via PATCH /api/papers/:id/cover.
export async function POST(request: Request, { params }: { params: { jobId: string } }) {
  try {
    const user = await requireUser()
    const body = bodySchema.parse(await request.json().catch(() => ({})))

    const job = await prisma.importJob.findUnique({ where: { id: params.jobId } })
    if (!job || job.kind !== 'COVER_DESIGN_ANALYSIS') {
      return NextResponse.json({ error: 'Cover analysis job not found.' }, { status: 404 })
    }
    if (job.createdById !== user.id && user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'You do not have access to this job.' }, { status: 403 })
    }
    if (job.status !== 'REVIEW' || !job.resultJson) {
      return NextResponse.json({ error: 'This design analysis has not finished yet.' }, { status: 422 })
    }

    const analysis = job.resultJson as unknown as CoverDesignAnalysisResult
    const design = convertAnalysisToCoverDesign(analysis, body.pageSize)

    return NextResponse.json({ coverDesign: design })
  } catch (error) {
    return handleApiError(error)
  }
}
