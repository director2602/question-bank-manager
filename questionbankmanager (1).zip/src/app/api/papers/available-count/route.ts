import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { availableCountQuerySchema } from '@/lib/validation/paper'
import { computeAvailableCounts } from '@/lib/paper-generation'

// POST /api/papers/available-count — live "Available: 84" indicator shown
// as the user configures a paper in the generator, before they click
// Generate. Recomputed on every filter-line change.
export async function POST(request: Request) {
  try {
    await requireUser()
    const body = availableCountQuerySchema.parse(await request.json())

    const results = await computeAvailableCounts(body.lines, body.allowReuseOfPastQuestions)

    return NextResponse.json({ items: results })
  } catch (error) {
    return handleApiError(error)
  }
}
