import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError, InsufficientQuestionsError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { generatePaperSchema } from '@/lib/validation/paper'
import { selectRandomQuestions } from '@/lib/paper-generation'
import { PAGE_SIZE_DEFAULT } from '@/lib/constants'

// GET /api/papers — paginated paper history (Saved Papers screen).
export async function GET(request: Request) {
  try {
    await requireUser()
    const { searchParams } = new URL(request.url)
    const page = Math.max(1, Number(searchParams.get('page') ?? 1))
    const pageSize = Math.min(100, Math.max(1, Number(searchParams.get('pageSize') ?? PAGE_SIZE_DEFAULT)))

    const [total, papers] = await prisma.$transaction([
      prisma.paper.count(),
      prisma.paper.findMany({
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          createdBy: { select: { id: true, fullName: true, email: true } },
          _count: { select: { questions: true } },
        },
      }),
    ])

    return NextResponse.json({
      items: papers.map((p) => ({
        id: p.id,
        paperNumber: p.paperNumber,
        title: p.title,
        mode: p.mode,
        status: p.status,
        questionCount: p._count.questions,
        createdBy: p.createdBy,
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      })),
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/papers — generates a new paper.
//
// RANDOM mode: server picks questions per filter line, enforcing "no
// duplicate questions" and (unless allowReuseOfPastQuestions) "no reuse of
// questions from earlier papers". If any line comes up short, the request
// fails with 422 + a precise shortfall list rather than silently returning
// fewer questions than asked for.
//
// MANUAL mode: the caller supplies the exact question IDs they picked in
// the UI; we still validate them server-side (active, not duplicated, and —
// unless reuse is allowed — not already used in a previous paper) since
// client-side selection can never be trusted for authorization or
// correctness.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_GENERATE)
    const body = generatePaperSchema.parse(await request.json())

    let selectedQuestionIds: string[] = []

    if (body.mode === 'RANDOM') {
      const result = await selectRandomQuestions(body.lines, body.allowReuseOfPastQuestions)
      if (result.shortfalls.length > 0) {
        throw new InsufficientQuestionsError(
          'Not enough questions are available to fully generate this paper. Adjust the counts below or add more questions to the bank.',
          result.shortfalls
        )
      }
      selectedQuestionIds = result.selectedQuestionIds
    } else {
      const ids = body.manualQuestionIds ?? []
      const uniqueIds = new Set(ids)
      if (uniqueIds.size !== ids.length) {
        return NextResponse.json(
          { error: 'The same question was selected more than once. Each question can only appear once per paper.' },
          { status: 400 }
        )
      }
      const requestedTotal = body.lines.reduce((sum, l) => sum + l.count, 0)
      if (ids.length !== requestedTotal) {
        return NextResponse.json(
          { error: `You selected ${ids.length} question(s) but specified ${requestedTotal} in your filters. These must match.` },
          { status: 400 }
        )
      }

      const questions = await prisma.question.findMany({ where: { id: { in: ids } } })
      if (questions.length !== ids.length) {
        return NextResponse.json({ error: 'One or more selected questions could not be found.' }, { status: 400 })
      }
      if (questions.some((q) => q.status !== 'ACTIVE')) {
        return NextResponse.json(
          { error: 'One or more selected questions are archived and cannot be used in a paper.' },
          { status: 400 }
        )
      }

      if (!body.allowReuseOfPastQuestions) {
        const usedElsewhere = await prisma.paperQuestion.findMany({
          where: { questionId: { in: ids } },
          select: { questionId: true },
        })
        if (usedElsewhere.length > 0) {
          return NextResponse.json(
            {
              error:
                'One or more selected questions have already been used in a previous paper. Enable "allow reuse" or choose different questions.',
              code: 'REUSE_NOT_ALLOWED',
              questionIds: usedElsewhere.map((u) => u.questionId),
            },
            { status: 409 }
          )
        }
      }

      selectedQuestionIds = ids
    }

    if (selectedQuestionIds.length === 0) {
      return NextResponse.json({ error: 'No questions were selected for this paper.' }, { status: 400 })
    }

    const questionsWithVersions = await prisma.question.findMany({
      where: { id: { in: selectedQuestionIds } },
      select: { id: true, currentVersionId: true },
    })
    const versionByQuestionId = new Map(questionsWithVersions.map((q) => [q.id, q.currentVersionId]))

    const paper = await prisma.$transaction(async (tx) => {
      const createdPaper = await tx.paper.create({
        data: {
          title: body.title,
          mode: body.mode,
          status: 'DRAFT',
          generationFilters: body.lines,
          allowReuseOfPastQuestions: body.allowReuseOfPastQuestions,
          instituteName: body.instituteName,
          logoUrl: body.logoUrl || null,
          examName: body.examName,
          subjectLabel: body.subjectLabel,
          classLabel: body.classLabel,
          examDate: body.examDate ? new Date(body.examDate) : null,
          examTime: body.examTime,
          maxMarks: body.maxMarks,
          instructions: body.instructions,
          headerText: body.headerText,
          footerText: body.footerText,
          createdById: user.id,
        },
      })

      await tx.paperQuestion.createMany({
        data: selectedQuestionIds.map((qId, idx) => ({
          paperId: createdPaper.id,
          questionId: qId,
          questionVersionId: versionByQuestionId.get(qId)!,
          position: idx + 1,
        })),
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_GENERATED',
          entityType: 'PAPER',
          entityId: createdPaper.id,
          description: `${user.fullName ?? user.email} generated paper "${body.title}" (#${createdPaper.paperNumber}) with ${selectedQuestionIds.length} question(s) in ${body.mode.toLowerCase()} mode.`,
          newValue: { filters: body.lines, questionCount: selectedQuestionIds.length },
        },
        tx
      )

      return createdPaper
    })

    return NextResponse.json(
      { item: { id: paper.id, paperNumber: paper.paperNumber, title: paper.title } },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
