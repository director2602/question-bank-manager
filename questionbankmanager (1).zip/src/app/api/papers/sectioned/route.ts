import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError, SectionedInsufficientQuestionsError, PaperValidationError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createSectionedPaperSchema } from '@/lib/validation/paperBuilder'
import { selectSectionedQuestions, type SectionSelectionInput } from '@/lib/paper-generation'
import type { Prisma } from '@prisma/client'

// POST /api/papers/sectioned — the Advanced Paper Builder's generation
// endpoint. Deliberately a SEPARATE route from POST /api/papers (the
// original flat generator) rather than a branch inside it, per the
// project's binding instruction to extend the existing architecture
// without touching working functionality — the flat generator's contract
// (request shape, response shape, error codes) is completely unchanged.
//
// Supports all three selection modes described in the spec:
//   AUTOMATIC — the server picks questions per section/type/chapter/topic.
//   MANUAL    — the caller supplies the exact, already-ordered question ids.
//   HYBRID    — same as MANUAL at the API layer: the client auto-filled a
//               section then let the user replace individual questions, so
//               by submission time it's already just "the final list".
//
// Every question ends up with a real Paper + PaperSection + PaperQuestion
// row (sectionId set, contiguous global `position` across all sections in
// section order) inside one transaction, matching the pattern established
// by POST /api/papers.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_GENERATE)
    const body = createSectionedPaperSchema.parse(await request.json())

    const [subject, examClass, code] = await Promise.all([
      prisma.subject.findUnique({ where: { id: body.subjectId } }),
      prisma.examClass.findUnique({ where: { id: body.examClassId } }),
      prisma.code.findUnique({ where: { id: body.codeId } }),
    ])
    if (!subject || !examClass || !code) {
      return NextResponse.json({ error: 'One or more selected tags are invalid.' }, { status: 400 })
    }

    // Duplicate-question check across the WHOLE request, before any
    // selection runs — a manually/hybrid-picked question repeated across
    // two sections must be reported clearly, never silently deduplicated
    // (spec §23 "duplicate questions").
    const manualIdCounts = new Map<string, number>()
    for (const section of body.sections) {
      for (const id of section.manualQuestionIds) {
        manualIdCounts.set(id, (manualIdCounts.get(id) ?? 0) + 1)
      }
    }
    const duplicateManualIds = Array.from(manualIdCounts.entries())
      .filter(([, count]) => count > 1)
      .map(([id]) => id)
    if (duplicateManualIds.length > 0) {
      return NextResponse.json(
        {
          error: `${duplicateManualIds.length} question(s) were selected more than once across your sections. Each question can only appear once per paper.`,
          code: 'DUPLICATE_QUESTIONS',
          questionIds: duplicateManualIds,
        },
        { status: 400 }
      )
    }

    const selectionInput: SectionSelectionInput[] = body.sections.map((s) => ({
      key: s.key,
      label: s.label,
      selectionMode: s.selectionMode,
      chapterScope: s.chapterScope,
      chapterIds: s.chapterIds,
      topicScope: s.topicScope,
      topicIds: s.topicIds,
      types: s.types.map((t) => ({
        key: t.key,
        questionType: t.questionType,
        count: t.count,
        marksPerQuestion: t.marksPerQuestion,
        difficultyId: t.difficultyId ?? null,
      })),
      manualQuestionIds: s.manualQuestionIds,
    }))

    const selection = await selectSectionedQuestions(
      body.subjectId,
      body.examClassId,
      body.codeId,
      selectionInput,
      body.allowReuseOfPastQuestions
    )

    if (selection.shortfalls.length > 0) {
      throw new SectionedInsufficientQuestionsError(
        'Not enough matching questions are available to fully generate this paper. Adjust the section/type counts or chapter/topic scope below.',
        selection.shortfalls
      )
    }

    const selectedIdsBySectionKey = new Map(selection.perSection.map((p) => [p.key, p.selectedQuestionIds]))
    const allSelectedIds = selection.perSection.flatMap((p) => p.selectedQuestionIds)

    if (allSelectedIds.length === 0) {
      return NextResponse.json({ error: 'No questions were selected for this paper.' }, { status: 400 })
    }

    // Re-validate every MANUAL/HYBRID-supplied id against the real DB —
    // client-side selection is never trusted for authorization/correctness
    // (same rule the flat generator's MANUAL mode already follows).
    const manuallySpecifiedIds = body.sections.filter((s) => s.selectionMode !== 'AUTOMATIC').flatMap((s) => s.manualQuestionIds)
    if (manuallySpecifiedIds.length > 0) {
      const found = await prisma.question.findMany({ where: { id: { in: manuallySpecifiedIds } }, select: { id: true, status: true } })
      const foundIds = new Set(found.map((f) => f.id))
      const missing = manuallySpecifiedIds.filter((id) => !foundIds.has(id))
      if (missing.length > 0) {
        return NextResponse.json({ error: 'One or more selected questions could not be found.', questionIds: missing }, { status: 400 })
      }
      const archived = found.filter((f) => f.status !== 'ACTIVE').map((f) => f.id)
      if (archived.length > 0) {
        return NextResponse.json(
          { error: 'One or more selected questions are archived and cannot be used in a paper.', questionIds: archived },
          { status: 400 }
        )
      }
      if (!body.allowReuseOfPastQuestions) {
        const usedElsewhere = await prisma.paperQuestion.findMany({
          where: { questionId: { in: manuallySpecifiedIds } },
          select: { questionId: true },
        })
        if (usedElsewhere.length > 0) {
          return NextResponse.json(
            {
              error: 'One or more selected questions have already been used in a previous paper. Enable "allow reuse" or choose different questions.',
              code: 'REUSE_NOT_ALLOWED',
              questionIds: usedElsewhere.map((u) => u.questionId),
            },
            { status: 409 }
          )
        }
      }
    }

    // ── Content validation (spec §23) ────────────────────────────────
    // Missing MCQ options, invalid Integer answers, and missing marks all
    // require looking at real question content — done here, once, over
    // the FULL final selection (automatic + manual + hybrid together).
    const questionsWithVersions = await prisma.question.findMany({
      where: { id: { in: allSelectedIds } },
      select: { id: true, questionType: true, currentVersionId: true, currentVersion: { select: { optionA: true, optionB: true, optionC: true, optionD: true, correctAnswer: true } } },
    })
    const questionById = new Map(questionsWithVersions.map((q) => [q.id, q]))

    const issues: string[] = []
    const paperQuestionRows: Array<{
      questionId: string
      questionVersionId: string
      sectionKey: string
      marks: number
    }> = []

    for (const section of body.sections) {
      const ids = selectedIdsBySectionKey.get(section.key) ?? []
      const marksByType = new Map(section.types.map((t) => [t.questionType, t.marksPerQuestion]))
      for (const id of ids) {
        const q = questionById.get(id)
        if (!q || !q.currentVersionId) {
          issues.push(`A selected question in section "${section.label}" has no content and cannot be used.`)
          continue
        }
        if (q.questionType === 'MCQ') {
          const v = q.currentVersion
          if (!v?.optionA || !v?.optionB || !v?.optionC || !v?.optionD) {
            issues.push(`An MCQ question in section "${section.label}" is missing one or more options (A–D).`)
          }
          if (!v?.correctAnswer) {
            issues.push(`An MCQ question in section "${section.label}" has no correct answer set.`)
          }
        }
        if (q.questionType === 'INTEGER') {
          const answer = q.currentVersion?.correctAnswer?.trim()
          if (!answer || !/^-?\d+(\.\d+)?$/.test(answer)) {
            issues.push(`An Integer-type question in section "${section.label}" does not have a valid numeric answer.`)
          }
        }
        const marks = marksByType.get(q.questionType)
        if (!marks || marks <= 0) {
          issues.push(`Missing marks configuration for ${q.questionType} questions in section "${section.label}".`)
          continue
        }
        paperQuestionRows.push({ questionId: id, questionVersionId: q.currentVersionId, sectionKey: section.key, marks })
      }
    }

    if (issues.length > 0) {
      throw new PaperValidationError(
        'This paper cannot be generated as configured — fix the issues below and try again. No paper was created.',
        Array.from(new Set(issues))
      )
    }

    const computedMaxMarks = paperQuestionRows.reduce((sum, r) => sum + r.marks, 0)
    const computedTotalQuestions = paperQuestionRows.length

    const created = await prisma.$transaction(async (tx) => {
      const paper = await tx.paper.create({
        data: {
          title: body.title,
          subtitle: body.subtitle || null,
          mode: 'HYBRID',
          status: 'DRAFT',
          generationFilters: { subjectId: body.subjectId, examClassId: body.examClassId, codeId: body.codeId, sections: body.sections },
          headingConfig: (body.headingConfig ?? undefined) as Prisma.InputJsonValue | undefined,
          allowReuseOfPastQuestions: body.allowReuseOfPastQuestions,
          instituteName: body.instituteName,
          logoUrl: body.logoUrl || null,
          examName: body.examName,
          subjectLabel: subject.label,
          classLabel: examClass.label,
          examDate: body.examDate ? new Date(body.examDate) : null,
          examTime: body.examTime,
          maxMarks: computedMaxMarks,
          instructions: body.instructions.length > 0 ? body.instructions.join('\n') : null,
          headerText: body.headerText,
          footerText: body.footerText,
          folderId: body.folderId || null,
          createdById: user.id,
        },
      })

      const sectionIdByKey = new Map<string, string>()
      for (let i = 0; i < body.sections.length; i++) {
        const s = body.sections[i]
        const createdSection = await tx.paperSection.create({
          data: {
            paperId: paper.id,
            position: i + 1,
            label: s.label,
            title: s.title,
            instructions: s.instructions || null,
            numberingMode: s.numberingMode,
            answerSpace: s.answerSpace,
            customAnswerSpaceMm: s.answerSpace === 'CUSTOM' ? s.customAnswerSpaceMm : null,
            typeConfig: s.types as unknown as Prisma.InputJsonValue,
          },
        })
        sectionIdByKey.set(s.key, createdSection.id)
      }

      let position = 0
      const createManyData: Prisma.PaperQuestionCreateManyInput[] = []
      for (const section of body.sections) {
        const ids = selectedIdsBySectionKey.get(section.key) ?? []
        const sectionId = sectionIdByKey.get(section.key)!
        for (const id of ids) {
          const row = paperQuestionRows.find((r) => r.questionId === id && r.sectionKey === section.key)
          if (!row) continue
          position += 1
          createManyData.push({
            paperId: paper.id,
            questionId: row.questionId,
            questionVersionId: row.questionVersionId,
            sectionId,
            position,
            marks: row.marks,
          })
        }
      }
      await tx.paperQuestion.createMany({ data: createManyData })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_GENERATED',
          entityType: 'PAPER',
          entityId: paper.id,
          description: `${user.fullName ?? user.email} generated paper "${body.title}" (#${paper.paperNumber}) via the Advanced Paper Builder with ${computedTotalQuestions} question(s) across ${body.sections.length} section(s).`,
          newValue: { sectionCount: body.sections.length, questionCount: computedTotalQuestions, maxMarks: computedMaxMarks },
        },
        tx
      )

      return paper
    })

    return NextResponse.json(
      { item: { id: created.id, paperNumber: created.paperNumber, title: created.title, questionCount: computedTotalQuestions, maxMarks: computedMaxMarks } },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
