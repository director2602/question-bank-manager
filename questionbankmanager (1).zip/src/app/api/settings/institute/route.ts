import { NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'

const templateSchema = z.object({
  name: z.string().trim().min(1).max(100),
  instituteName: z.string().trim().min(1).max(200),
  logoUrl: z.string().trim().max(2000).optional().nullable(),
  headerText: z.string().trim().max(2000).optional().nullable(),
  footerText: z.string().trim().max(2000).optional().nullable(),
  instructions: z.string().trim().max(5000).optional().nullable(),
  isDefault: z.boolean().optional().default(false),
})

// GET — any authenticated user (used to prefill the Paper Generator with
// the default template). POST — ADMIN only, creates/updates a template.
export async function GET() {
  try {
    await requireUser()
    const templates = await prisma.paperTemplate.findMany({ orderBy: [{ isDefault: 'desc' }, { name: 'asc' }] })
    return NextResponse.json({ items: templates })
  } catch (error) {
    return handleApiError(error)
  }
}

export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)
    const body = templateSchema.parse(await request.json())

    const template = await prisma.$transaction(async (tx) => {
      if (body.isDefault) {
        await tx.paperTemplate.updateMany({ where: { isDefault: true }, data: { isDefault: false } })
      }
      const created = await tx.paperTemplate.create({ data: body })
      await writeAuditLog(
        {
          userId: user.id,
          action: 'SETTINGS_UPDATED',
          entityType: 'SETTINGS',
          entityId: created.id,
          description: `${user.fullName ?? user.email} created paper template "${body.name}".`,
          newValue: body,
        },
        tx
      )
      return created
    })

    return NextResponse.json({ item: template }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
