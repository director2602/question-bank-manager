import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { createChapterSchema } from '@/lib/validation/chapterTopic'

// GET /api/chapters?subjectId=... — full chapter list (including inactive)
// for the Chapters & Topics management screen. The lightweight
// active-only version used by dropdowns everywhere else stays at
// GET /api/lookups — this route is only for the admin management UI.
export async function GET(request: Request) {
  try {
    await requireUser()
    const { searchParams } = new URL(request.url)
    const subjectId = searchParams.get('subjectId')

    const chapters = await prisma.chapter.findMany({
      where: subjectId ? { subjectId } : undefined,
      orderBy: [{ subjectId: 'asc' }, { sortOrder: 'asc' }],
      include: { _count: { select: { questions: true, topics: true } } },
    })

    return NextResponse.json({
      items: chapters.map((c) => ({
        id: c.id,
        subjectId: c.subjectId,
        code: c.code,
        label: c.label,
        sortOrder: c.sortOrder,
        isActive: c.isActive,
        questionCount: c._count.questions,
        topicCount: c._count.topics,
      })),
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/chapters — create a chapter. Available to ADMIN + EDITOR (same
// role set as QUESTION_CREATE) so a teacher can add a missing chapter
// inline from the Add Question form, not only from the admin screen.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_CREATE)
    const body = createChapterSchema.parse(await request.json())

    const subject = await prisma.subject.findUnique({ where: { id: body.subjectId } })
    if (!subject) return NextResponse.json({ error: 'Invalid subject.' }, { status: 400 })

    const existing = await prisma.chapter.findUnique({
      where: { subjectId_code: { subjectId: body.subjectId, code: body.code } },
    })
    if (existing) {
      return NextResponse.json({ error: `A chapter with code "${body.code}" already exists for ${subject.label}.` }, { status: 409 })
    }

    const maxOrder = await prisma.chapter.aggregate({
      where: { subjectId: body.subjectId },
      _max: { sortOrder: true },
    })

    const chapter = await prisma.chapter.create({
      data: {
        subjectId: body.subjectId,
        code: body.code,
        label: body.label,
        sortOrder: (maxOrder._max.sortOrder ?? 0) + 1,
      },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'CHAPTER_CREATED',
      entityType: 'SETTINGS',
      entityId: chapter.id,
      description: `${user.fullName ?? user.email} created chapter "${chapter.label}" under ${subject.label}.`,
      newValue: { subjectId: body.subjectId, code: body.code, label: body.label },
    })

    return NextResponse.json({ item: chapter }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
