import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { reorderChaptersSchema } from '@/lib/validation/chapterTopic'

// POST /api/chapters/reorder — persists a drag-and-drop (or up/down arrow)
// reorder: the client sends the chapter ids for one subject in their new
// display order, and each one's sortOrder is set to its index. All-or-
// nothing inside one transaction so a partial drag never leaves a mixed
// ordering.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)
    const body = reorderChaptersSchema.parse(await request.json())

    const chapters = await prisma.chapter.findMany({ where: { subjectId: body.subjectId }, select: { id: true } })
    const validIds = new Set(chapters.map((c) => c.id))
    if (body.orderedIds.length !== validIds.size || !body.orderedIds.every((id) => validIds.has(id))) {
      return NextResponse.json(
        { error: 'The chapter list is out of date — reload and try reordering again.' },
        { status: 409 }
      )
    }

    await prisma.$transaction([
      ...body.orderedIds.map((id, index) =>
        prisma.chapter.update({ where: { id }, data: { sortOrder: index } })
      ),
      prisma.auditLog.create({
        data: {
          userId: user.id,
          action: 'CHAPTER_REORDERED',
          entityType: 'SETTINGS',
          entityId: null,
          description: `${user.fullName ?? user.email} reordered chapters.`,
          newValue: { subjectId: body.subjectId, orderedIds: body.orderedIds },
        },
      }),
    ])

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
