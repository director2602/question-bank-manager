import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateChapterSchema } from '@/lib/validation/chapterTopic'

// PATCH /api/chapters/:id — edit label/code or toggle active. Admin-only
// (full management screen), distinct from the ADMIN+EDITOR create route
// used for the Add Question form's inline "+ Create chapter" quick-add.
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)
    const body = updateChapterSchema.parse(await request.json())

    const existing = await prisma.chapter.findUnique({ where: { id: params.id } })
    if (!existing) return NextResponse.json({ error: 'Chapter not found.' }, { status: 404 })

    if (body.code && body.code !== existing.code) {
      const dup = await prisma.chapter.findUnique({
        where: { subjectId_code: { subjectId: existing.subjectId, code: body.code } },
      })
      if (dup) return NextResponse.json({ error: `A chapter with code "${body.code}" already exists.` }, { status: 409 })
    }

    const updated = await prisma.chapter.update({
      where: { id: params.id },
      data: { code: body.code, label: body.label, isActive: body.isActive },
    })

    await writeAuditLog({
      userId: user.id,
      action: 'CHAPTER_UPDATED',
      entityType: 'SETTINGS',
      entityId: updated.id,
      description: `${user.fullName ?? user.email} updated chapter "${updated.label}".`,
      previousValue: { code: existing.code, label: existing.label, isActive: existing.isActive },
      newValue: { code: updated.code, label: updated.label, isActive: updated.isActive },
    })

    return NextResponse.json({ item: updated })
  } catch (error) {
    return handleApiError(error)
  }
}

// DELETE /api/chapters/:id — only allowed when nothing depends on it
// (no questions tagged with it, no topics under it), matching this
// project's existing "guard, don't cascade-destroy" pattern (see
// PaperFolder). Otherwise deactivate it instead (PATCH isActive:false).
export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.SETTINGS_MANAGE)

    const existing = await prisma.chapter.findUnique({
      where: { id: params.id },
      include: { _count: { select: { questions: true, topics: true } } },
    })
    if (!existing) return NextResponse.json({ error: 'Chapter not found.' }, { status: 404 })

    if (existing._count.questions > 0 || existing._count.topics > 0) {
      return NextResponse.json(
        {
          error: `"${existing.label}" has ${existing._count.questions} question(s) and ${existing._count.topics} topic(s) attached and cannot be deleted. Deactivate it instead so it's hidden from new tagging but existing questions stay intact.`,
        },
        { status: 409 }
      )
    }

    await prisma.chapter.delete({ where: { id: params.id } })

    await writeAuditLog({
      userId: user.id,
      action: 'CHAPTER_UPDATED',
      entityType: 'SETTINGS',
      entityId: params.id,
      description: `${user.fullName ?? user.email} deleted chapter "${existing.label}".`,
      previousValue: { code: existing.code, label: existing.label },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error)
  }
}
