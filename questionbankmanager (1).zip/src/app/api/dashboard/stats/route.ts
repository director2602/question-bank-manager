import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { getDashboardStats } from '@/lib/dashboard-stats'

// GET /api/dashboard/stats — every figure the Dashboard cards/charts need,
// computed with efficient grouped counts (never by loading all questions
// into memory). Used by the client to refresh stats without a full page
// reload; the initial page load fetches the same data directly via Prisma
// (see src/lib/dashboard-stats.ts) for a faster first paint.
export async function GET() {
  try {
    await requireUser()
    const stats = await getDashboardStats()
    return NextResponse.json(stats)
  } catch (error) {
    return handleApiError(error)
  }
}
