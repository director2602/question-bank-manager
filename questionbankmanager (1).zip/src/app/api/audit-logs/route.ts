import { NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

const querySchema = z.object({
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(100).optional().default(50),
  entityType: z.enum(['QUESTION', 'PAPER', 'USER', 'SETTINGS', 'AUTH']).optional(),
  action: z.string().optional(),
  userId: z.string().uuid().optional(),
})

// GET /api/audit-logs — ADMIN only. Paginated, filterable audit trail.
export async function GET(request: Request) {
  try {
    await requireRole(PERMISSIONS.AUDIT_VIEW)
    const { searchParams } = new URL(request.url)
    const q = querySchema.parse(Object.fromEntries(searchParams))

    const where = {
      ...(q.entityType ? { entityType: q.entityType } : {}),
      ...(q.action ? { action: q.action } : {}),
      ...(q.userId ? { userId: q.userId } : {}),
    }

    const [total, items] = await prisma.$transaction([
      prisma.auditLog.count({ where }),
      prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (q.page - 1) * q.pageSize,
        take: q.pageSize,
        include: { user: { select: { id: true, fullName: true, email: true } } },
      }),
    ])

    return NextResponse.json({
      items: items.map((log) => ({
        id: log.id,
        action: log.action,
        entityType: log.entityType,
        entityId: log.entityId,
        description: log.description,
        previousValue: log.previousValue,
        newValue: log.newValue,
        user: log.user,
        createdAt: log.createdAt.toISOString(),
      })),
      page: q.page,
      pageSize: q.pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / q.pageSize)),
    })
  } catch (error) {
    return handleApiError(error)
  }
}
