export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-surface-subtle px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/branding/cubus-logo.png" alt="CUBUS" className="mx-auto mb-3 h-16 w-auto" />
          <h1 className="text-lg font-semibold text-ink">Question Bank Manager</h1>
          <p className="text-sm text-ink-muted">CUBUS &middot; NEET &middot; IIT-JEE &middot; Foundation</p>
        </div>
        <div className="card p-6">{children}</div>
      </div>
    </div>
  )
}
