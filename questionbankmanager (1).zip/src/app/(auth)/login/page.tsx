'use client'

import { Suspense, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

function LoginForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const supabase = createClient()
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password })

    setLoading(false)

    if (signInError) {
      setError(
        signInError.message.includes('Invalid login')
          ? 'Incorrect email or password.'
          : signInError.message
      )
      return
    }

    const redirectedFrom = searchParams.get('redirectedFrom')
    router.replace(redirectedFrom || '/dashboard')
    router.refresh()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="label" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          type="email"
          required
          autoComplete="email"
          className="input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div>
        <label className="label" htmlFor="password">
          Password
        </label>
        <input
          id="password"
          type="password"
          required
          autoComplete="current-password"
          className="input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      {error && (
        <p role="alert" className="rounded-md bg-red-50 px-3 py-2 text-sm text-danger">
          {error}
        </p>
      )}

      <button type="submit" disabled={loading} className="btn-primary w-full">
        {loading ? 'Signing in…' : 'Sign in'}
      </button>

      <p className="text-center text-sm text-ink-muted">
        Don&rsquo;t have an account?{' '}
        <Link href="/register" className="font-medium text-brand-600 hover:underline">
          Create one
        </Link>
      </p>
    </form>
  ) // close LoginForm's return
}

// NOTE: kept as an explicit-return-type declaration (and the trailing
// comment above) deliberately, not just for style — Render's build command
// for this project does a blind string-replace against a legacy unwrapped
// version of this file to inject a Suspense boundary (older deploys had
// `export default function LoginPage()` directly wrapping the form, which
// broke `useSearchParams()` outside Suspense). This file already has that
// fix applied at the source, but the build command's `.replace()` still
// runs unconditionally on every build and matches on exact substrings — if
// this line read the plain, unannotated `export default function
// LoginPage() {`, the old patch would find a false match here (and against
// the plain `</form>\n  )\n}` above) and inject a SECOND `LoginForm`/
// `LoginPage` definition, breaking the build with "defined multiple times".
// Changing these two exact strings is what keeps the legacy patch a true
// no-op. If that build command is ever updated/removed, this comment (and
// the one above) can be removed too.
export default function LoginPage(): JSX.Element {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  )
}
