import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Question Bank Manager & Paper Generator — CUBUS',
  description: 'Centralized question bank management and examination paper generation for CUBUS (NEET · IIT-JEE · Foundation).',
  icons: {
    icon: '/branding/cubus-logo.png',
    shortcut: '/branding/cubus-logo.png',
    apple: '/branding/cubus-logo.png',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
