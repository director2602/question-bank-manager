import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { renderPaperHtml, DEFAULT_PAPER_LAYOUT_SETTINGS, type PaperExportMode } from '@/lib/pdf/paperHtml'
import type { SnapshotQuestion } from '@/lib/paper-snapshot'

// GET /papers/:id/versions/:versionNumber/print — renders a PAST snapshot
// exactly as it was generated, regardless of any edits made to the paper or
// underlying questions since. This is the reproducibility guarantee in
// practice: Paper #100 opened six months later looks identical.
export async function GET(
  request: Request,
  { params }: { params: { id: string; versionNumber: string } }
) {
  try {
    await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    const mode = (searchParams.get('mode') as PaperExportMode) || 'question'
    // Deliberately NOT reading the paper's live PaperSettings row here —
    // this route's whole point is reproducibility ("Paper #100 opened six
    // months later looks identical"), and layout settings can change after
    // a version snapshot was saved. The app defaults are used instead,
    // with the same `?columns=` override the print/export routes accept,
    // preserving this route's pre-existing behavior.
    const columnsParam = searchParams.get('columns')
    const columnsOverride = columnsParam ? Number(columnsParam) : null
    const layout =
      columnsOverride && Number.isInteger(columnsOverride) && columnsOverride >= 1 && columnsOverride <= 3
        ? { ...DEFAULT_PAPER_LAYOUT_SETTINGS, columns: columnsOverride }
        : DEFAULT_PAPER_LAYOUT_SETTINGS
    const versionNumber = Number(params.versionNumber)

    const [paper, version] = await Promise.all([
      prisma.paper.findUnique({ where: { id: params.id } }),
      prisma.paperVersion.findUnique({
        where: { paperId_versionNumber: { paperId: params.id, versionNumber } },
      }),
    ])
    if (!paper || !version) return NextResponse.json({ error: 'Paper version not found.' }, { status: 404 })

    const settings = version.settings as Record<string, unknown>
    const html = renderPaperHtml(
      {
        title: String(settings.title ?? paper.title),
        paperNumber: paper.paperNumber,
        instituteName: (settings.instituteName as string) ?? null,
        logoUrl: (settings.logoUrl as string) ?? null,
        examName: (settings.examName as string) ?? null,
        subjectLabel: (settings.subjectLabel as string) ?? null,
        classLabel: (settings.classLabel as string) ?? null,
        examDate: (settings.examDate as string) ?? null,
        examTime: (settings.examTime as string) ?? null,
        maxMarks: (settings.maxMarks as number) ?? null,
        instructions: (settings.instructions as string) ?? null,
        headerText: (settings.headerText as string) ?? null,
        footerText: (settings.footerText as string) ?? null,
      },
      version.snapshot as unknown as SnapshotQuestion[],
      mode,
      layout
    )

    return new NextResponse(html, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })
  } catch (error) {
    return handleApiError(error)
  }
}
