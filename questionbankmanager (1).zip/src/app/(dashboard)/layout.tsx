import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth'
import { Sidebar } from '@/components/layout/Sidebar'
import { Topbar } from '@/components/layout/Topbar'
import { PresenceHeartbeat } from '@/components/layout/PresenceHeartbeat'
import { ToastProvider } from '@/components/ui/Toast'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser()
  if (!user) redirect('/login')

  return (
    <ToastProvider>
      <div className="flex min-h-screen bg-surface-subtle">
        <Sidebar role={user.role} />
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar user={user} />
          <main className="flex-1 overflow-x-hidden p-6">{children}</main>
        </div>
      </div>
      <PresenceHeartbeat />
    </ToastProvider>
  )
}
