import { QuestionForm } from '@/components/questions/QuestionForm'

export default function NewQuestionPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Add Question</h1>
        <p className="text-sm text-ink-muted">
          Enter the question exactly as it should appear — nothing is auto-corrected. Use &ldquo;Save &amp; Add
          Another&rdquo; to keep tags selected for fast sequential entry.
        </p>
      </div>
      <QuestionForm />
    </div>
  )
}
