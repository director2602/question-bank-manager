import Link from 'next/link'
import { QuestionListClient } from '@/components/questions/QuestionListClient'
import { getCurrentUser } from '@/lib/auth'

export default async function QuestionsPage() {
  const user = await getCurrentUser()
  const canCreate = user && (user.role === 'ADMIN' || user.role === 'EDITOR')
  const canExport = user && user.role === 'ADMIN'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-ink">All Questions</h1>
          <p className="text-sm text-ink-muted">Search, filter, and manage the active question bank.</p>
        </div>
        <div className="flex gap-2">
          {canExport && (
            <a href="/api/questions/export" className="btn-secondary">
              Export CSV
            </a>
          )}
          {canCreate && (
            <>
              <Link href="/questions/bulk-upload" className="btn-secondary">
                Bulk Upload
              </Link>
              <Link href="/questions/new" className="btn-primary">
                + Add Question
              </Link>
            </>
          )}
        </div>
      </div>
      <QuestionListClient status="ACTIVE" />
    </div>
  )
}
