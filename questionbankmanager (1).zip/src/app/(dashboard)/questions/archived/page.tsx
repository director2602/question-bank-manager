import { QuestionListClient } from '@/components/questions/QuestionListClient'

export default function ArchivedQuestionsPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Archived Questions</h1>
        <p className="text-sm text-ink-muted">
          Archived questions are hidden from search and the Paper Generator but can be restored at any time.
        </p>
      </div>
      <QuestionListClient status="ARCHIVED" />
    </div>
  )
}
