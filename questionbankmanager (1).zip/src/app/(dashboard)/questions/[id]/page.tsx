import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { questionWithRelations, toQuestionDetail } from '@/lib/serializers'
import { getCurrentUser } from '@/lib/auth'
import { QuestionDetailClient } from '@/components/questions/QuestionDetailClient'

export default async function QuestionDetailPage({ params }: { params: { id: string } }) {
  const [question, user] = await Promise.all([
    prisma.question.findUnique({ where: { id: params.id }, include: questionWithRelations }),
    getCurrentUser(),
  ])

  if (!question || !user) notFound()

  const detail = await toQuestionDetail(question)

  return <QuestionDetailClient initial={detail} role={user.role} />
}
