import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth'
import { AuditLogClient } from '@/components/audit/AuditLogClient'

export default async function AuditLogsPage() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'ADMIN') redirect('/dashboard')

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Audit Logs</h1>
        <p className="text-sm text-ink-muted">Full accountability trail of who changed what, and when.</p>
      </div>
      <AuditLogClient />
    </div>
  )
}
