import Link from 'next/link'
import { getDashboardStats } from '@/lib/dashboard-stats'
import { StatCard, BarList, DifficultyBreakdownTable } from '@/components/dashboard/StatCard'

export const dynamic = 'force-dynamic'

const CHAPTER_TOPIC_DISPLAY_LIMIT = 10

export default async function DashboardPage() {
  const stats = await getDashboardStats()
  const topChapters = stats.byChapter.slice(0, CHAPTER_TOPIC_DISPLAY_LIMIT)
  const chapterMoreCount = Math.max(0, stats.byChapter.length - CHAPTER_TOPIC_DISPLAY_LIMIT)
  const topTopics = stats.byTopic.slice(0, CHAPTER_TOPIC_DISPLAY_LIMIT)
  const topicMoreCount = Math.max(0, stats.byTopic.length - CHAPTER_TOPIC_DISPLAY_LIMIT)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-ink">Dashboard</h1>
        <p className="text-sm text-ink-muted">Question bank and paper generation overview.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        <StatCard label="Total Questions" value={stats.totalQuestions} />
        <StatCard label="Active Questions" value={stats.activeQuestions} />
        <StatCard label="Archived" value={stats.archivedQuestions} />
        <StatCard label="Papers Generated" value={stats.totalPapers} />
        <StatCard label="Users" value={stats.totalUsers} />
        <StatCard label="Active Now" value={stats.activeUsersNow} hint="Last 5 minutes" />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="card p-4">
          <h2 className="mb-3 text-sm font-semibold text-ink">Questions by Subject</h2>
          <BarList items={stats.bySubject} />
        </div>
        <div className="card p-4">
          <h2 className="mb-3 text-sm font-semibold text-ink">Questions by Class / Exam</h2>
          <BarList items={stats.byClass} />
        </div>
        <div className="card p-4">
          <h2 className="mb-3 text-sm font-semibold text-ink">Questions by Question Type</h2>
          <BarList items={stats.byQuestionType} />
        </div>
        <div className="card p-4">
          <h2 className="mb-3 text-sm font-semibold text-ink">Questions by Chapter</h2>
          <BarList items={topChapters} />
          {chapterMoreCount > 0 && (
            <p className="mt-2 text-xs text-ink-faint">
              +{chapterMoreCount} more chapter(s) with questions — see{' '}
              <Link href="/reports" className="text-brand-600 hover:underline">
                Reports
              </Link>{' '}
              for the full breakdown.
            </p>
          )}
        </div>
        <div className="card p-4">
          <h2 className="mb-3 text-sm font-semibold text-ink">Questions by Topic</h2>
          <BarList items={topTopics} />
          {topicMoreCount > 0 && (
            <p className="mt-2 text-xs text-ink-faint">
              +{topicMoreCount} more topic(s) with questions — see{' '}
              <Link href="/reports" className="text-brand-600 hover:underline">
                Reports
              </Link>{' '}
              for the full breakdown.
            </p>
          )}
        </div>
        <div className="card p-4">
          <h2 className="mb-3 text-sm font-semibold text-ink">Questions by Code</h2>
          <BarList items={stats.byCode} />
        </div>
      </div>

      <div className="card p-4">
        <h2 className="text-sm font-semibold text-ink">Difficulty Level Breakdown</h2>
        <p className="mb-3 text-sm text-ink-muted">
          What share of the bank sits at each difficulty, and how much of that has actually been pulled into a
          generated paper at least once.
        </p>
        <DifficultyBreakdownTable rows={stats.difficultyBreakdown} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Recently Uploaded Questions</h2>
            <Link href="/questions" className="text-sm text-brand-600 hover:underline">
              View all
            </Link>
          </div>
          <ul className="divide-y divide-surface-border">
            {stats.recentQuestions.length === 0 && <p className="py-4 text-sm text-ink-faint">No questions yet.</p>}
            {stats.recentQuestions.map((q) => (
              <li key={q.id} className="flex items-center justify-between py-2 text-sm">
                <div>
                  <Link href={`/questions/${q.id}`} className="font-medium text-ink hover:text-brand-600">
                    #{q.questionNumber}
                  </Link>
                  <span className="ml-2 text-ink-faint">
                    {q.subject} · {q.examClass}
                  </span>
                </div>
                <span className="text-ink-faint">{q.createdBy}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Recently Generated Papers</h2>
            <Link href="/papers" className="text-sm text-brand-600 hover:underline">
              View all
            </Link>
          </div>
          <ul className="divide-y divide-surface-border">
            {stats.recentPapers.length === 0 && <p className="py-4 text-sm text-ink-faint">No papers yet.</p>}
            {stats.recentPapers.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-2 text-sm">
                <div>
                  <Link href={`/papers/${p.id}`} className="font-medium text-ink hover:text-brand-600">
                    #{p.paperNumber} {p.title}
                  </Link>
                  <span className="ml-2 text-ink-faint">{p.questionCount} questions</span>
                </div>
                <span className="text-ink-faint">{p.createdBy}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
