'use client'

import { useState } from 'react'
import { PaperGeneratorForm } from '@/components/papers/PaperGeneratorForm'
import { SectionedPaperBuilder } from '@/components/papers/SectionedPaperBuilder'

// Two independent ways to create a paper — the original flat generator
// (unchanged, still the default tab) and the Advanced Paper Builder
// (multi-section, multi-type, chapter/topic-aware). Extending, not
// replacing: switching tabs never touches the other tab's state, and both
// ultimately create ordinary Paper rows viewable/editable the same way.
export default function NewPaperPage() {
  const [tab, setTab] = useState<'quick' | 'advanced'>('quick')

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Create Paper</h1>
        <p className="text-sm text-ink-muted">
          {tab === 'quick'
            ? 'Select the tag combinations and quantities you need. Available question counts update live as you configure filters.'
            : 'Build a fully custom, multi-section paper — mix MCQ/Subjective/Integer questions, scope by chapter/topic, and configure heading, numbering, and marks display.'}
        </p>
      </div>

      <div className="flex gap-2 border-b border-surface-border">
        <button
          className={`px-3 py-2 text-sm font-medium ${tab === 'quick' ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-muted'}`}
          onClick={() => setTab('quick')}
        >
          Quick Generator
        </button>
        <button
          className={`px-3 py-2 text-sm font-medium ${tab === 'advanced' ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-muted'}`}
          onClick={() => setTab('advanced')}
        >
          Advanced Paper Builder
        </button>
      </div>

      {tab === 'quick' ? <PaperGeneratorForm /> : <SectionedPaperBuilder />}
    </div>
  )
}
