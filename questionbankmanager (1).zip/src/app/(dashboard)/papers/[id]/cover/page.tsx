import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'
import { CoverDesignerClient } from '@/components/papers/cover/CoverDesignerClient'

// The Cover Page Designer's entry point (spec §5) — a dedicated page rather
// than a modal, since a page-sized drag/resize canvas needs real screen
// space. All actual data loading happens client-side via GET
// /api/papers/:id/cover (see CoverDesignerClient) so this page only needs
// to confirm the paper exists and resolve the viewer's edit permission.
export default async function PaperCoverDesignerPage({ params }: { params: { id: string } }) {
  const [paper, user] = await Promise.all([
    prisma.paper.findUnique({ where: { id: params.id }, select: { id: true, title: true, paperNumber: true } }),
    getCurrentUser(),
  ])
  if (!paper || !user) notFound()

  const canEdit = user.role === 'ADMIN' || user.role === 'EDITOR'

  return <CoverDesignerClient paperId={paper.id} paperTitle={`${paper.paperNumber} ${paper.title}`} canEdit={canEdit} />
}
