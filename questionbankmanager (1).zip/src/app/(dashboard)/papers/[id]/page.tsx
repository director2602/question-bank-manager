import { notFound } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { PaperEditor } from '@/components/papers/PaperEditor'

export default async function PaperDetailPage({ params }: { params: { id: string } }) {
  const [paper, user] = await Promise.all([
    prisma.paper.findUnique({ where: { id: params.id } }),
    getCurrentUser(),
  ])
  if (!paper || !user) notFound()

  const questions = await buildPaperSnapshot(params.id)

  return (
    <PaperEditor
      initialPaper={{
        id: paper.id,
        paperNumber: paper.paperNumber,
        title: paper.title,
        mode: paper.mode,
        status: paper.status,
        rowVersion: paper.rowVersion,
        instituteName: paper.instituteName,
        logoUrl: paper.logoUrl,
        examName: paper.examName,
        subjectLabel: paper.subjectLabel,
        classLabel: paper.classLabel,
        examDate: paper.examDate ? paper.examDate.toISOString() : null,
        examTime: paper.examTime,
        maxMarks: paper.maxMarks,
        instructions: paper.instructions,
        headerText: paper.headerText,
        footerText: paper.footerText,
      }}
      initialQuestions={questions}
      role={user.role}
    />
  )
}
