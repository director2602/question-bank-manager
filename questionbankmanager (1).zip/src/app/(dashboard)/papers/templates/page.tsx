import { PaperTemplateManager } from '@/components/settings/PaperTemplateManager'

export default function TemplatesPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Paper Templates</h1>
        <p className="text-sm text-ink-muted">
          Configure reusable institute name, logo, header/footer, and default instructions for generated papers.
        </p>
      </div>
      <PaperTemplateManager />
    </div>
  )
}
