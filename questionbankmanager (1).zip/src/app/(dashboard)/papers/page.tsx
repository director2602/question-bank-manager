import Link from 'next/link'
import { PaperFoldersView } from '@/components/papers/PaperFoldersView'
import { getCurrentUser } from '@/lib/auth'

export default async function PapersPage() {
  const user = await getCurrentUser()
  const canManage = user?.role === 'ADMIN' || user?.role === 'EDITOR'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-ink">Saved Papers</h1>
          <p className="text-sm text-ink-muted">Every paper ever generated, organized into folders, with full history.</p>
        </div>
        <Link href="/papers/new" className="btn-primary">
          + Create Paper
        </Link>
      </div>
      <PaperFoldersView canManage={!!canManage} />
    </div>
  )
}
