import Link from 'next/link'
import { PaperListClient } from '@/components/papers/PaperListClient'

export default function PapersPage() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-ink">Saved Papers</h1>
          <p className="text-sm text-ink-muted">Every paper ever generated, with full history.</p>
        </div>
        <Link href="/papers/new" className="btn-primary">
          + Create Paper
        </Link>
      </div>
      <PaperListClient />
    </div>
  )
}
