import { redirect } from 'next/navigation'
import { getCurrentUser } from '@/lib/auth'
import { UserManagementClient } from '@/components/users/UserManagementClient'

export default async function UsersPage() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'ADMIN') redirect('/dashboard')

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Users</h1>
        <p className="text-sm text-ink-muted">Manage roles and access. Permissions are always enforced server-side.</p>
      </div>
      <UserManagementClient currentUserId={user.id} />
    </div>
  )
}
