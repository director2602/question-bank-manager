import { ChapterTopicManager } from '@/components/settings/ChapterTopicManager'

export default function ChaptersSettingsPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Chapters &amp; Topics</h1>
        <p className="text-sm text-ink-muted">
          Manage the chapter/topic taxonomy used to tag questions and scope the Advanced Paper Builder. Drag rows (or
          use the arrows) to set the sequence used everywhere chapters/topics are listed.
        </p>
      </div>
      <ChapterTopicManager />
    </div>
  )
}
