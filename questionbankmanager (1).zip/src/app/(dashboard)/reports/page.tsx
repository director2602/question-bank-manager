import { getDashboardStats } from '@/lib/dashboard-stats'

export const dynamic = 'force-dynamic'

function ReportTable({ title, rows }: { title: string; rows: { label: string; count: number }[] }) {
  const total = rows.reduce((s, r) => s + r.count, 0)
  return (
    <div className="card overflow-hidden">
      <div className="border-b border-surface-border bg-surface-subtle px-4 py-2 text-sm font-semibold text-ink">{title}</div>
      <table className="w-full text-sm">
        <tbody className="divide-y divide-surface-border">
          {rows.map((r) => (
            <tr key={r.label}>
              <td className="px-4 py-2 text-ink-muted">{r.label}</td>
              <td className="px-4 py-2 text-right font-medium text-ink">{r.count}</td>
              <td className="px-4 py-2 text-right text-ink-faint">{total ? Math.round((r.count / total) * 100) : 0}%</td>
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={3} className="px-4 py-4 text-center text-ink-faint">
                No data.
              </td>
            </tr>
          )}
        </tbody>
        <tfoot>
          <tr className="border-t border-surface-border font-medium">
            <td className="px-4 py-2">Total</td>
            <td className="px-4 py-2 text-right">{total}</td>
            <td />
          </tr>
        </tfoot>
      </table>
    </div>
  )
}

export default async function ReportsPage() {
  const stats = await getDashboardStats()

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Reports</h1>
        <p className="text-sm text-ink-muted">Question bank composition, computed from the live database.</p>
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ReportTable title="By Subject" rows={stats.bySubject} />
        <ReportTable title="By Class / Exam" rows={stats.byClass} />
        <ReportTable title="By Difficulty" rows={stats.byDifficulty} />
        <ReportTable title="By Code" rows={stats.byCode} />
      </div>
    </div>
  )
}
