import 'server-only'
import { prisma } from '@/lib/prisma'
import type { Prisma, QuestionType } from '@prisma/client'
import type { PaperFilterLine, AvailableCountResult } from '@/types'

/**
 * Question IDs that have ever appeared in ANY paper (paper_questions), used
 * to enforce "do not reuse questions from previous papers" when the caller
 * has not explicitly opted into reuse.
 */
async function getGlobalUsedQuestionIds(): Promise<Set<string>> {
  const rows = await prisma.paperQuestion.findMany({ select: { questionId: true }, distinct: ['questionId'] })
  return new Set(rows.map((r) => r.questionId))
}

async function getLookupLabels() {
  const [subjects, examClasses, codes, difficulties] = await Promise.all([
    prisma.subject.findMany(),
    prisma.examClass.findMany(),
    prisma.code.findMany(),
    prisma.difficultyLevel.findMany(),
  ])
  return {
    subject: new Map(subjects.map((s) => [s.id, s.label])),
    examClass: new Map(examClasses.map((s) => [s.id, s.label])),
    code: new Map(codes.map((s) => [s.id, s.label])),
    difficulty: new Map(difficulties.map((s) => [s.id, s.label])),
  }
}

/**
 * For every requested (subject, examClass, code, difficulty) combination,
 * counts how many ACTIVE questions currently qualify — optionally excluding
 * questions already used in a previous paper. This powers both the live
 * "Available: 84" indicator in the Paper Generator UI and the server-side
 * check performed at generation time.
 */
export async function computeAvailableCounts(
  lines: Array<Pick<PaperFilterLine, 'subjectId' | 'examClassId' | 'codeId' | 'difficultyId'>>,
  allowReuseOfPastQuestions: boolean
): Promise<AvailableCountResult[]> {
  const [labels, usedIds] = await Promise.all([
    getLookupLabels(),
    allowReuseOfPastQuestions ? Promise.resolve(new Set<string>()) : getGlobalUsedQuestionIds(),
  ])

  const results: AvailableCountResult[] = []
  for (const line of lines) {
    const matches = await prisma.question.findMany({
      where: {
        status: 'ACTIVE',
        subjectId: line.subjectId,
        examClassId: line.examClassId,
        codeId: line.codeId,
        difficultyId: line.difficultyId,
      },
      select: { id: true },
    })
    const available = allowReuseOfPastQuestions
      ? matches.length
      : matches.filter((m) => !usedIds.has(m.id)).length

    results.push({
      subjectId: line.subjectId,
      examClassId: line.examClassId,
      codeId: line.codeId,
      difficultyId: line.difficultyId,
      count: 0,
      available,
      labels: {
        subject: labels.subject.get(line.subjectId) ?? 'Unknown',
        examClass: labels.examClass.get(line.examClassId) ?? 'Unknown',
        code: labels.code.get(line.codeId) ?? 'Unknown',
        difficulty: labels.difficulty.get(line.difficultyId) ?? 'Unknown',
      },
    })
  }
  return results
}

export type ShortfallLine = {
  subject: string
  examClass: string
  code: string
  difficulty: string
  requested: number
  available: number
}

export type RandomSelectionResult = {
  shortfalls: ShortfallLine[]
  selectedQuestionIds: string[]
  perLine: Array<{ line: PaperFilterLine; selectedQuestionIds: string[] }>
}

/**
 * Randomly selects the requested number of questions per filter line,
 * WITHOUT replacement and WITHOUT ever selecting the same question twice
 * across the whole paper. Uses a Fisher–Yates shuffle over each line's
 * eligible ID pool so selection is unbiased.
 */
export async function selectRandomQuestions(
  lines: PaperFilterLine[],
  allowReuseOfPastQuestions: boolean
): Promise<RandomSelectionResult> {
  const [labels, usedIds] = await Promise.all([
    getLookupLabels(),
    allowReuseOfPastQuestions ? Promise.resolve(new Set<string>()) : getGlobalUsedQuestionIds(),
  ])

  const shortfalls: ShortfallLine[] = []
  const perLine: RandomSelectionResult['perLine'] = []
  const alreadySelected = new Set<string>()

  for (const line of lines) {
    if (line.count === 0) {
      perLine.push({ line, selectedQuestionIds: [] })
      continue
    }

    const pool = await prisma.question.findMany({
      where: {
        status: 'ACTIVE',
        subjectId: line.subjectId,
        examClassId: line.examClassId,
        codeId: line.codeId,
        difficultyId: line.difficultyId,
        ...(allowReuseOfPastQuestions ? {} : { id: { notIn: Array.from(usedIds) } }),
      },
      select: { id: true },
    })

    const eligible = pool.map((p) => p.id).filter((id) => !alreadySelected.has(id))
    shuffleInPlace(eligible)

    const take = Math.min(line.count, eligible.length)
    const chosen = eligible.slice(0, take)
    chosen.forEach((id) => alreadySelected.add(id))

    perLine.push({ line, selectedQuestionIds: chosen })

    if (take < line.count) {
      shortfalls.push({
        subject: labels.subject.get(line.subjectId) ?? 'Unknown',
        examClass: labels.examClass.get(line.examClassId) ?? 'Unknown',
        code: labels.code.get(line.codeId) ?? 'Unknown',
        difficulty: labels.difficulty.get(line.difficultyId) ?? 'Unknown',
        requested: line.count,
        available: eligible.length,
      })
    }
  }

  return {
    shortfalls,
    selectedQuestionIds: perLine.flatMap((p) => p.selectedQuestionIds),
    perLine,
  }
}

// ── Advanced Paper Builder: section/type/chapter/topic-aware selection ────

function questionTypeLabel(t: QuestionType): string {
  return t === 'MCQ' ? 'MCQ' : t === 'SUBJECTIVE' ? 'Subjective' : 'Integer'
}

export type SectionTypeSelectionInput = {
  key: string
  questionType: QuestionType
  count: number
  marksPerQuestion: number
  difficultyId: string | null
}

export type SectionSelectionInput = {
  key: string
  label: string
  selectionMode: 'AUTOMATIC' | 'MANUAL' | 'HYBRID'
  chapterScope: 'ALL' | 'SELECTED'
  chapterIds: string[]
  topicScope: 'ALL' | 'SELECTED'
  topicIds: string[]
  types: SectionTypeSelectionInput[]
  // Final, explicit, ORDERED question-id list for MANUAL/HYBRID sections —
  // trusted for ORDER (drag-and-drop reordering already happened
  // client-side) but never trusted for eligibility, which the caller
  // (api/papers/sectioned) re-validates against the real DB rows.
  manualQuestionIds: string[]
}

export type SectionShortfall = {
  sectionLabel: string
  questionType: string
  chapterLabel: string | null
  requested: number
  available: number
  message: string
}

export type SectionSelectionResult = {
  shortfalls: SectionShortfall[]
  perSection: Array<{ key: string; selectedQuestionIds: string[] }>
}

/**
 * The Advanced Paper Builder's selection engine — extends (does not
 * replace) selectRandomQuestions above with awareness of sections, mixed
 * question types within one section, and chapter/topic scoping.
 *
 * AUTOMATIC sections: for each per-type row, randomly picks `count`
 * eligible ACTIVE questions (same Fisher–Yates-over-eligible-pool approach
 * as selectRandomQuestions, same global `alreadySelected` set so no
 * question is ever picked twice across the WHOLE paper, across sections).
 *
 * MANUAL/HYBRID sections: the caller has already resolved the exact,
 * ordered question-id list (HYBRID starts from an auto-fill the user then
 * edited client-side — by submission time both are just "the final list").
 * This function only participates in the shared global-dedup bookkeeping
 * for those IDs; the caller is responsible for validating they're real,
 * ACTIVE, non-duplicated questions (see api/papers/sectioned/route.ts).
 *
 * Never silently substitutes: any per-type shortfall is reported with the
 * exact wording the spec requires, e.g. "You requested 5 Integer questions
 * from Chapter 3, but only 3 matching questions are available."
 */
export async function selectSectionedQuestions(
  subjectId: string,
  examClassId: string,
  codeId: string,
  sections: SectionSelectionInput[],
  allowReuseOfPastQuestions: boolean
): Promise<SectionSelectionResult> {
  const usedIds = allowReuseOfPastQuestions ? new Set<string>() : await getGlobalUsedQuestionIds()
  const alreadySelected = new Set<string>()
  const shortfalls: SectionShortfall[] = []
  const perSection: SectionSelectionResult['perSection'] = []

  const chapterIdsNeeded = Array.from(
    new Set(sections.flatMap((s) => (s.chapterScope === 'SELECTED' ? s.chapterIds : [])))
  )
  const chapters = chapterIdsNeeded.length > 0 ? await prisma.chapter.findMany({ where: { id: { in: chapterIdsNeeded } } }) : []
  const chapterLabelById = new Map(chapters.map((c) => [c.id, c.label]))

  for (const section of sections) {
    if (section.selectionMode !== 'AUTOMATIC') {
      const ids = section.manualQuestionIds.filter((id) => !alreadySelected.has(id))
      ids.forEach((id) => alreadySelected.add(id))
      perSection.push({ key: section.key, selectedQuestionIds: ids })
      continue
    }

    const sectionSelected: string[] = []
    for (const type of section.types) {
      const where: Prisma.QuestionWhereInput = {
        status: 'ACTIVE',
        subjectId,
        examClassId,
        codeId,
        questionType: type.questionType,
        ...(type.difficultyId ? { difficultyId: type.difficultyId } : {}),
        ...(section.chapterScope === 'SELECTED' && section.chapterIds.length > 0
          ? { chapterId: { in: section.chapterIds } }
          : {}),
        ...(section.topicScope === 'SELECTED' && section.topicIds.length > 0 ? { topicId: { in: section.topicIds } } : {}),
        ...(allowReuseOfPastQuestions ? {} : { id: { notIn: Array.from(usedIds) } }),
      }

      const pool = await prisma.question.findMany({ where, select: { id: true } })
      const eligible = pool.map((p) => p.id).filter((id) => !alreadySelected.has(id))
      shuffleInPlace(eligible)

      const take = Math.min(type.count, eligible.length)
      const chosen = eligible.slice(0, take)
      chosen.forEach((id) => alreadySelected.add(id))
      sectionSelected.push(...chosen)

      if (take < type.count) {
        const chapterLabel =
          section.chapterScope === 'SELECTED' && section.chapterIds.length === 1
            ? (chapterLabelById.get(section.chapterIds[0]) ?? null)
            : null
        const chapterPhrase = chapterLabel ? ` from ${chapterLabel}` : ''
        const typeLabel = questionTypeLabel(type.questionType)
        shortfalls.push({
          sectionLabel: section.label,
          questionType: type.questionType,
          chapterLabel,
          requested: type.count,
          available: eligible.length,
          message: `You requested ${type.count} ${typeLabel} question${type.count === 1 ? '' : 's'}${chapterPhrase}, but only ${eligible.length} matching question${eligible.length === 1 ? '' : 's'} ${eligible.length === 1 ? 'is' : 'are'} available.`,
        })
      }
    }
    perSection.push({ key: section.key, selectedQuestionIds: sectionSelected })
  }

  return { shortfalls, perSection }
}

function shuffleInPlace<T>(arr: T[]): void {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
}
