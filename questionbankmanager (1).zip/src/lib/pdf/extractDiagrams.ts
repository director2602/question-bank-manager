// Best-effort extraction of the actual embedded raster images from a PDF
// (diagrams, graphs, figures) using poppler's `pdfimages` CLI. This pulls
// out the image bytes AS STORED in the PDF — nothing is redrawn, cropped,
// or regenerated — and reports which page each one came from so the caller
// can attach it to the nearest question.
//
// This is deliberately defensive: `pdfimages` may not be installed on every
// hosting platform's build image. Any failure (binary missing, PDF has no
// images, timeout) degrades to an empty result rather than breaking the
// import — LaTeX/text transcription still works even when diagram
// extraction can't run.

import { spawn } from 'child_process'
import { mkdtemp, readdir, readFile, rm, writeFile } from 'fs/promises'
import { tmpdir } from 'os'
import path from 'path'

export type ExtractedDiagram = {
  pageNumber: number
  buffer: Buffer
  mimeType: string
  fileName: string
}

// Pixel-dimension floor, not a byte-size floor: real diagrams vary hugely
// in how well they compress, but decorative bullets/icons/rules are almost
// always small on BOTH axes. `pdfimages -list` reports each embedded
// image's actual width/height, so we filter on that instead of file size.
const MIN_IMAGE_DIMENSION_PX = 40
const EXTRACTION_TIMEOUT_MS = 30_000

export async function extractDiagramsFromPdf(pdfBuffer: Buffer): Promise<ExtractedDiagram[]> {
  let dir: string | null = null
  try {
    dir = await mkdtemp(path.join(tmpdir(), 'pdf-diagrams-'))
    const pdfPath = path.join(dir, 'input.pdf')
    await writeFile(pdfPath, pdfBuffer)
    const prefix = path.join(dir, 'img')

    const sizeByPageAndNum = await listImageSizes(pdfPath)

    // -png: normalize output to PNG. -p: include the page number in each
    // output filename so we can correlate images back to questions.
    await runCommand('pdfimages', ['-png', '-p', pdfPath, prefix], EXTRACTION_TIMEOUT_MS)

    const files = await readdir(dir)
    const results: ExtractedDiagram[] = []
    for (const file of files) {
      if (file === 'input.pdf') continue
      const match = file.match(/-(\d+)-(\d+)\.(png|jpg|jpeg|ppm|pbm)$/i)
      if (!match) continue
      const pageNumber = parseInt(match[1], 10)
      const imageNum = parseInt(match[2], 10)

      const size = sizeByPageAndNum.get(`${pageNumber}-${imageNum}`)
      if (size && (size.width < MIN_IMAGE_DIMENSION_PX || size.height < MIN_IMAGE_DIMENSION_PX)) {
        continue // too small to be a real diagram — a bullet, rule, or icon
      }

      const filePath = path.join(dir, file)
      const buffer = await readFile(filePath)
      const ext = path.extname(file).slice(1).toLowerCase()
      results.push({
        pageNumber,
        buffer,
        mimeType: ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' : 'image/png',
        fileName: file,
      })
    }
    return results
  } catch (err) {
    console.warn('[extractDiagrams] pdfimages extraction unavailable or failed, skipping diagrams', err)
    return []
  } finally {
    if (dir) {
      try {
        await rm(dir, { recursive: true, force: true })
      } catch {
        // best-effort cleanup only
      }
    }
  }
}

// Maps "page-num" -> { width, height } using `pdfimages -list`, so we can
// filter out decorative images before spending storage/DB writes on them.
// Best-effort: if the list command fails or its output doesn't parse, the
// caller just skips the size filter for those entries rather than failing.
async function listImageSizes(pdfPath: string): Promise<Map<string, { width: number; height: number }>> {
  const map = new Map<string, { width: number; height: number }>()
  try {
    const output = await runCommandCapture('pdfimages', ['-list', pdfPath], EXTRACTION_TIMEOUT_MS)
    const rowPattern = /^\s*(\d+)\s+(\d+)\s+\S+\s+(\d+)\s+(\d+)\s+/
    for (const line of output.split('\n')) {
      const m = line.match(rowPattern)
      if (!m) continue
      const [, page, num, width, height] = m
      map.set(`${page}-${num}`, { width: parseInt(width, 10), height: parseInt(height, 10) })
    }
  } catch (err) {
    console.warn('[extractDiagrams] pdfimages -list unavailable, skipping size filter', err)
  }
  return map
}

function runCommand(cmd: string, args: string[], timeoutMs: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args)
    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      reject(new Error(`${cmd} timed out`))
    }, timeoutMs)
    let stderr = ''
    child.stderr?.on('data', (d) => {
      stderr += d.toString()
    })
    child.on('error', (err) => {
      clearTimeout(timer)
      reject(err)
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      if (code === 0) resolve()
      else reject(new Error(`${cmd} exited with code ${code}: ${stderr}`))
    })
  })
}

function runCommandCapture(cmd: string, args: string[], timeoutMs: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args)
    const timer = setTimeout(() => {
      child.kill('SIGKILL')
      reject(new Error(`${cmd} timed out`))
    }, timeoutMs)
    let stdout = ''
    let stderr = ''
    child.stdout?.on('data', (d) => {
      stdout += d.toString()
    })
    child.stderr?.on('data', (d) => {
      stderr += d.toString()
    })
    child.on('error', (err) => {
      clearTimeout(timer)
      reject(err)
    })
    child.on('close', (code) => {
      clearTimeout(timer)
      if (code === 0) resolve(stdout)
      else reject(new Error(`${cmd} exited with code ${code}: ${stderr}`))
    })
  })
}
