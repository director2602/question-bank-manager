import 'server-only'
import type { PaperSettings as PaperContentSettings } from '@/lib/pdf/paperHtml'
import type { CoverDesign, CoverElement } from '@/lib/validation/coverDesign'

// Cover Page Designer — data binding (spec §28: {{schoolName}} etc. resolve
// to the paper's real data at generation time). Two ways an element's text
// resolves, both landing here so PDF/print/DOCX-flatten all agree:
//   1. `placeholderKey` set — the element IS that field; its live value
//      always wins over whatever literal text was last saved as a preview.
//   2. Plain `{{token}}` markers anywhere inside literal `text` — resolved
//      by substitution, so a single text box can mix literal words with one
//      or more bound fields (e.g. "{{examName}} — {{academicYear}}").
// An unrecognized `{{token}}` is left as-is rather than silently deleted,
// so a typo is visibly wrong instead of invisibly wrong.
export function buildCoverPlaceholderMap(
  content: PaperContentSettings,
  design: Pick<CoverDesign, 'settings'>
): Record<string, string> {
  const map: Record<string, string> = {
    schoolName: content.instituteName ?? '',
    examName: content.examName ?? '',
    paperTitle: content.title ?? '',
    subject: content.subjectLabel ?? '',
    class: content.classLabel ?? '',
    academicYear: design.settings.academicYear ?? '',
    date: content.examDate ?? '',
    time: content.examTime ?? '',
    maximumMarks: content.maxMarks != null ? String(content.maxMarks) : '',
    instructions: content.instructions ?? '',
  }
  for (const field of design.settings.customFields) {
    map[field.key] = field.value ?? ''
  }
  return map
}

function substituteTokens(text: string, map: Record<string, string>): string {
  return text.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (whole: string, key: string) => map[key] ?? whole)
}

// The final display text for one element — never mutates the saved design,
// just computes what should be shown right now.
export function resolveCoverElementText(el: Pick<CoverElement, 'text' | 'placeholderKey' | 'customFieldKey'>, map: Record<string, string>): string {
  const customFieldValue = el.customFieldKey ? map[el.customFieldKey] : undefined
  if (customFieldValue !== undefined) return customFieldValue
  const placeholderValue = el.placeholderKey ? map[el.placeholderKey] : undefined
  if (placeholderValue !== undefined) return placeholderValue
  return substituteTokens(el.text ?? '', map)
}
