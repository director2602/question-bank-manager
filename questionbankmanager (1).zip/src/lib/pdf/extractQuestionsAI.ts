// AI-vision based PDF question extractor. Sends the whole PDF straight to
// Claude (which reads/renders PDF pages internally — no local rasterization
// needed) and asks it to transcribe every question exactly as printed, with
// proper LaTeX for any math. Like the heuristic splitter in
// extractQuestions.ts, this NEVER writes to the database — it only produces
// candidate rows for the bulk-import "review before save" screen.
//
// Requires ANTHROPIC_API_KEY. When that isn't configured, the pdf-preview
// route falls back to the plain-text heuristic splitter instead of calling
// this module at all.

import Anthropic from '@anthropic-ai/sdk'

export type AIExtractedQuestion = {
  tempId: string
  questionNumber: string | null
  pageNumber: number
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  hasDiagram: boolean
  rawBlock: string
  lowConfidence: boolean
}

const MODEL = 'claude-sonnet-5'
const MAX_OUTPUT_TOKENS = 32000

const SYSTEM_PROMPT = `You are transcribing an exam/question-bank PDF into structured data, exactly as printed. This is a transcription task, not a solving task.

Rules:
- Go through the PDF page by page, in order, and report every distinct question you find via the report_questions tool.
- Transcribe question text VERBATIM. Do not solve, answer, correct, or rephrase anything.
- Any mathematical notation (fractions, exponents, roots, integrals, summations, Greek letters, matrices, subscripts/superscripts, chemical formulas, vectors, limits, etc.) MUST be transcribed as proper LaTeX, wrapped in $...$ for inline math or $$...$$ for a standalone/display equation. Plain prose stays as plain text — only wrap the actual math expressions.
- If a question references, contains, or depends on a diagram, figure, graph, chart, or table, set hasDiagram to true. Do NOT try to describe or redraw it in text — the original image will be attached separately by another process.
- Preserve the original question numbering exactly as printed (e.g. "12", "Q.7", "3a"). If a question has no visible number, leave questionNumber empty.
- Record the 1-indexed PDF page number the question STARTS on.
- Only fill optionA-D if the question is multiple-choice with lettered options actually printed. Only fill correctAnswer/explanation if an answer key or explanation is actually printed somewhere in this document — otherwise leave them empty. Never invent or compute an answer that isn't already in the document.
- If the PDF contains no extractable questions (e.g. a cover page only), report an empty questions array.`

export async function extractQuestionsWithAI(
  buffer: Buffer,
  fileName: string
): Promise<AIExtractedQuestion[]> {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    throw new Error('AI extraction is not configured on the server (missing ANTHROPIC_API_KEY).')
  }

  const client = new Anthropic({ apiKey })

  const tool: Anthropic.Tool = {
    name: 'report_questions',
    description: 'Report every question transcribed from the PDF, in the order they appear.',
    input_schema: {
      type: 'object',
      properties: {
        questions: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              questionNumber: {
                type: 'string',
                description: 'Original printed number/label, e.g. "12" or "Q.7a". Empty string if none.',
              },
              pageNumber: { type: 'integer', description: '1-indexed page this question starts on.' },
              questionText: {
                type: 'string',
                description: 'Verbatim question text, with any math transcribed as LaTeX ($...$ or $$...$$).',
              },
              optionA: { type: 'string' },
              optionB: { type: 'string' },
              optionC: { type: 'string' },
              optionD: { type: 'string' },
              correctAnswer: {
                type: 'string',
                description: 'Letter A-D, only if explicitly printed in this document. Empty string otherwise.',
              },
              explanation: { type: 'string', description: 'Only if explicitly printed in this document.' },
              hasDiagram: {
                type: 'boolean',
                description: 'True if a figure/diagram/graph/chart/table is part of this question.',
              },
            },
            required: ['pageNumber', 'questionText', 'hasDiagram'],
          },
        },
      },
      required: ['questions'],
    },
  }

  let response
  try {
    response = await client.messages.create({
      model: MODEL,
      max_tokens: MAX_OUTPUT_TOKENS,
      system: SYSTEM_PROMPT,
      tools: [tool],
      tool_choice: { type: 'tool', name: 'report_questions' },
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'document',
              source: { type: 'base64', media_type: 'application/pdf', data: buffer.toString('base64') },
              title: fileName,
            },
            {
              type: 'text',
              text: 'Transcribe every question in this document using the report_questions tool, following the system instructions exactly.',
            },
          ],
        },
      ],
    })
  } catch (err) {
    console.error('[extractQuestionsAI] Claude API call failed', err)
    throw new Error(
      'The AI transcription service could not process this PDF. It may be too large or briefly unavailable — please try again shortly.'
    )
  }

  if (response.stop_reason === 'max_tokens') {
    throw new Error(
      'This PDF has too much content for a single AI pass. Split it into smaller files (roughly 15-20 pages each) and upload them one at a time.'
    )
  }

  const toolUse = response.content.find(
    (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use' && block.name === 'report_questions'
  )
  if (!toolUse) {
    throw new Error('The AI transcription service did not return structured results for this PDF. Please try again.')
  }

  const parsed = toolUse.input as { questions?: Array<Record<string, unknown>> }
  const questions = Array.isArray(parsed.questions) ? parsed.questions : []

  return questions.map((q, idx) => {
    const questionText = typeof q.questionText === 'string' ? q.questionText.trim() : ''
    const optionA = nullableString(q.optionA)
    const optionB = nullableString(q.optionB)
    const optionC = nullableString(q.optionC)
    const optionD = nullableString(q.optionD)
    const hasAnyOption = Boolean(optionA || optionB || optionC || optionD)
    return {
      tempId: `pdf-ai-q-${idx}-${Date.now()}`,
      questionNumber: nullableString(q.questionNumber),
      pageNumber: typeof q.pageNumber === 'number' && q.pageNumber > 0 ? Math.floor(q.pageNumber) : 1,
      questionText,
      optionA,
      optionB,
      optionC,
      optionD,
      correctAnswer: nullableString(q.correctAnswer),
      explanation: nullableString(q.explanation),
      hasDiagram: q.hasDiagram === true,
      rawBlock: questionText,
      lowConfidence: questionText.length < 8 || (!hasAnyOption && questionText.length < 40),
    }
  })
}

function nullableString(v: unknown): string | null {
  if (typeof v !== 'string') return null
  const t = v.trim()
  return t ? t : null
}
