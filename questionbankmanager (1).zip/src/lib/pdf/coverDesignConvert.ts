// "Use as Template" (spec §14) conversion logic, split out of
// coverDesignPipeline.ts into its own dependency-free module: this file
// touches no Prisma/Supabase/network code at all (pure data transformation
// only), which is what lets it be unit-tested directly — coverDesignPipeline.ts
// re-exports convertAnalysisToCoverDesign from here so every existing
// import path (API routes, etc.) keeps working unchanged.
import { v4 as uuidv4 } from 'uuid'
import { emptyCoverDesign, type CoverDesign, type CoverElement } from '@/lib/validation/coverDesign'
import type { CoverDesignAnalysisResult } from '@/lib/ai/coverDesignAnalysis'

function pageSizeMm(pageSize: CoverDesign['pageSize']): { widthMm: number; heightMm: number } {
  if (pageSize === 'LETTER') return { widthMm: 215.9, heightMm: 279.4 }
  if (pageSize === 'LEGAL') return { widthMm: 215.9, heightMm: 355.6 }
  return { widthMm: 210, heightMm: 297 }
}

// Turns a bounded analysis result into REAL, individually editable
// CoverElement rows — never a single flat background image. Every element
// created this way carries ocrConfidence/needsReview straight from the
// analysis, so the review UI can flag anything uncertain before the user
// trusts it (spec §3/§31: "never silently invent, mark uncertain content
// Needs Review").
export function convertAnalysisToCoverDesign(
  analysis: CoverDesignAnalysisResult,
  pageSize: CoverDesign['pageSize'] = 'A4'
): CoverDesign {
  const design = emptyCoverDesign(pageSize)
  const { widthMm, heightMm } = pageSizeMm(pageSize)
  const toMm = (v: number, span: number) => Math.round(((v / 1000) * span) * 10) / 10

  let zIndex = 1
  const elements: CoverElement[] = []

  for (const b of analysis.textBlocks) {
    elements.push({
      id: uuidv4(),
      type: b.fieldGuess === 'instructions' ? 'instructions' : 'text',
      x: toMm(b.boundingBox.x, widthMm),
      y: toMm(b.boundingBox.y, heightMm),
      width: Math.max(5, toMm(b.boundingBox.width, widthMm)),
      height: Math.max(5, toMm(b.boundingBox.height, heightMm)),
      zIndex: zIndex++,
      locked: false,
      hidden: false,
      text: b.text,
      placeholderKey: b.fieldGuess && b.fieldGuess !== 'custom' ? b.fieldGuess : null,
      customFieldKey: null,
      fontFamily: 'Calibri',
      fontSizePt: b.fontSizeGuessPt ?? 12,
      fontWeight: b.fontWeightGuess ?? 'normal',
      fontStyle: b.fontStyleGuess ?? 'normal',
      alignment: b.alignmentGuess ?? 'left',
      color: b.colorGuess ?? '#14161f',
      backgroundColor: null,
      borderColor: null,
      borderWidthPt: 0,
      imagePath: null,
      opacity: 100,
      ocrConfidence: b.confidence,
      needsReview: b.needsReview,
    })
  }

  for (const b of analysis.images) {
    elements.push({
      id: uuidv4(),
      type: b.kind === 'logo' ? 'logo' : 'image',
      x: toMm(b.boundingBox.x, widthMm),
      y: toMm(b.boundingBox.y, heightMm),
      width: Math.max(5, toMm(b.boundingBox.width, widthMm)),
      height: Math.max(5, toMm(b.boundingBox.height, heightMm)),
      zIndex: zIndex++,
      locked: false,
      hidden: false,
      text: '',
      placeholderKey: null,
      customFieldKey: null,
      fontFamily: 'Calibri',
      fontSizePt: 12,
      fontWeight: 'normal',
      fontStyle: 'normal',
      alignment: 'left',
      color: '#14161f',
      backgroundColor: null,
      borderColor: null,
      borderWidthPt: 0,
      // No imagePath yet — detecting WHERE a logo/image sits doesn't
      // extract the pixels themselves (spec never asks for image
      // extraction from the reference, only layout detection), so this
      // slot is created empty and flagged for the user to fill in via
      // "Upload Image"/"Add Logo", positioned exactly where the reference
      // had it.
      imagePath: null,
      opacity: 100,
      ocrConfidence: b.confidence,
      needsReview: true,
    })
  }

  for (const b of analysis.shapes) {
    elements.push({
      id: uuidv4(),
      type: b.kind === 'line' || b.kind === 'divider' ? 'line' : 'rectangle',
      x: toMm(b.boundingBox.x, widthMm),
      y: toMm(b.boundingBox.y, heightMm),
      width: Math.max(2, toMm(b.boundingBox.width, widthMm)),
      height: Math.max(1, toMm(b.boundingBox.height, heightMm)),
      zIndex: zIndex++,
      locked: false,
      hidden: false,
      text: '',
      placeholderKey: null,
      customFieldKey: null,
      fontFamily: 'Calibri',
      fontSizePt: 12,
      fontWeight: 'normal',
      fontStyle: 'normal',
      alignment: 'left',
      color: '#14161f',
      backgroundColor: null,
      borderColor: b.colorGuess ?? '#14161f',
      borderWidthPt: 1,
      imagePath: null,
      opacity: 100,
      ocrConfidence: b.confidence,
      needsReview: b.needsReview,
    })
  }

  design.background.color = analysis.backgroundColorGuess ?? null
  design.elements = elements
  return design
}
