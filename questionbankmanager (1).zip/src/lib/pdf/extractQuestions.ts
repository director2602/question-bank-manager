// NOTE: deliberately NOT `import 'server-only'` here (unlike most of
// src/lib) — that guard throws unconditionally outside Next.js's bundler
// (e.g. under Vitest), which would make splitIntoQuestions() impossible to
// unit test in isolation. Safety is preserved anyway: this module is only
// ever imported from src/app/api/questions/bulk-import/pdf-preview/route.ts
// (a server route handler) and uses Node-only APIs (Buffer, a dynamic
// import of pdf-parse) that simply do not work in a browser bundle.

// pdf-parse has no ESM types-friendly default export shape, so we require it
// lazily inside the function — this also avoids pulling its (large) test
// fixtures into the Next.js build graph.
type PdfParseFn = (buffer: Buffer) => Promise<{ text: string; numpages: number }>

export type ExtractedQuestion = {
  tempId: string
  questionNumber: string | null
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  rawBlock: string
  lowConfidence: boolean // true when the splitter is unsure of the boundary — surfaced to the user for extra scrutiny
}

export async function extractPdfText(buffer: Buffer): Promise<{ text: string; pageCount: number }> {
  const pdfParse = (await import('pdf-parse')).default as unknown as PdfParseFn
  const result = await pdfParse(buffer)
  return { text: result.text, pageCount: result.numpages }
}

// Matches a line that starts a new question: optional "Q"/"Question", a
// number (1-4 digits, optionally with a trailing letter like "12a"), then a
// separator. Deliberately anchored to the START of a line (after trimming)
// so it doesn't fire mid-sentence.
const QUESTION_START = /^\s*(?:Q(?:uestion)?\.?\s*)?(\d{1,4}[A-Za-z]?)\s*[.):\-]\s+(?=\S)/i

// Matches an option line: "A)" "(A)" "A." "A:" — single letter A-D.
const OPTION_START = /^\s*[(\[]?([A-Da-d])[)\].:\-]\s+(?=\S)/

const ANSWER_LINE = /^\s*(?:Ans(?:wer)?|Correct\s*Answer)\s*[:\-]\s*\(?([A-Da-d])\)?\s*$/i
const EXPLANATION_START = /^\s*(?:Explanation|Solution)\s*[:\-]\s*/i

/**
 * Best-effort, heuristic splitter that turns raw PDF text into individual
 * question blocks based on numbering patterns. This NEVER rewrites the
 * extracted text itself — it only decides where one question ends and the
 * next begins, and which lines look like options/answer/explanation. Every
 * result is surfaced in a review screen before anything is saved, and
 * `lowConfidence` is set whenever the heuristic had to guess, so reviewers
 * know exactly which blocks need a closer look or manual correction.
 *
 * Works well for text-based PDFs with clear "1.", "Q1.", "Q.1" style
 * numbering. Scanned/image-only PDFs contain no extractable text at all and
 * will yield zero questions — those need OCR first (see README § Known
 * Limitations). Equations rendered as embedded images inside the PDF will
 * not appear in the extracted text either; re-attach them as question
 * images after import.
 */
export function splitIntoQuestions(fullText: string): ExtractedQuestion[] {
  const lines = fullText
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => l.replace(/ /g, ' ')) // non-breaking spaces from some PDF exports

  type Block = { questionNumber: string | null; lines: string[] }
  const blocks: Block[] = []
  let current: Block | null = null

  for (const rawLine of lines) {
    const match = rawLine.match(QUESTION_START)
    if (match) {
      if (current) blocks.push(current)
      current = { questionNumber: match[1], lines: [rawLine.slice(match[0].length)] }
    } else if (current) {
      current.lines.push(rawLine)
    }
    // Lines before the first detected question number are discarded
    // (typically a page header/instructions block, not question content).
  }
  if (current) blocks.push(current)

  return blocks.map((block, idx) => {
    let questionText = ''
    let optionA: string | null = null
    let optionB: string | null = null
    let optionC: string | null = null
    let optionD: string | null = null
    let correctAnswer: string | null = null
    let explanation: string | null = null

    let mode: 'question' | 'option' | 'explanation' = 'question'
    let currentOptionLetter: string | null = null

    const setOption = (letter: string, text: string) => {
      const L = letter.toUpperCase()
      if (L === 'A') optionA = appendText(optionA, text)
      else if (L === 'B') optionB = appendText(optionB, text)
      else if (L === 'C') optionC = appendText(optionC, text)
      else if (L === 'D') optionD = appendText(optionD, text)
    }

    for (const line of block.lines) {
      const answerMatch = line.match(ANSWER_LINE)
      if (answerMatch) {
        correctAnswer = answerMatch[1].toUpperCase()
        mode = 'question'
        continue
      }
      if (EXPLANATION_START.test(line)) {
        explanation = line.replace(EXPLANATION_START, '')
        mode = 'explanation'
        continue
      }
      const optionMatch = line.match(OPTION_START)
      if (optionMatch) {
        currentOptionLetter = optionMatch[1]
        setOption(currentOptionLetter, line.slice(optionMatch[0].length))
        mode = 'option'
        continue
      }

      if (mode === 'question') {
        questionText = appendText(questionText, line) ?? ''
      } else if (mode === 'option' && currentOptionLetter) {
        setOption(currentOptionLetter, line)
      } else if (mode === 'explanation') {
        explanation = appendText(explanation, line)
      }
    }

    questionText = questionText.trim()
    const hasAnyOption = Boolean(optionA || optionB || optionC || optionD)
    const lowConfidence = questionText.length < 8 || (!hasAnyOption && block.lines.length < 2)

    return {
      tempId: `pdf-q-${idx}-${Date.now()}`,
      questionNumber: block.questionNumber,
      questionText,
      optionA: cleanOrNull(optionA),
      optionB: cleanOrNull(optionB),
      optionC: cleanOrNull(optionC),
      optionD: cleanOrNull(optionD),
      correctAnswer,
      explanation: cleanOrNull(explanation),
      rawBlock: block.lines.join('\n').trim(),
      lowConfidence,
    }
  })
}

function appendText(existing: string | null, addition: string): string | null {
  const trimmedAddition = addition.trim()
  if (!trimmedAddition) return existing
  return existing ? `${existing} ${trimmedAddition}` : trimmedAddition
}

function cleanOrNull(v: string | null): string | null {
  const t = v?.trim()
  return t ? t : null
}
