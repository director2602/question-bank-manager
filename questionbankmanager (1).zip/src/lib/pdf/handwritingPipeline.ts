import 'server-only'
import { v4 as uuidv4 } from 'uuid'
import sharp from 'sharp'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET, getSignedImageUrl } from '@/lib/storage'
import { extractPdfText } from '@/lib/pdf/extractQuestions'
import { extractDiagramsFromPdf } from '@/lib/pdf/extractDiagrams'
import { extractHandwrittenWithAI } from '@/lib/pdf/extractHandwrittenAI'
import { renderDiagramSvg } from '@/lib/pdf/diagramSvgRenderer'
import type { ExtractedDiagram } from '@/lib/ai/ocrProvider'

export type ReviewDiagram = {
  key: string
  diagramType: ExtractedDiagram['diagramType']
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
  generatedSvg: string
  // Original page-region crop, when one could be produced — always kept so
  // "Use Original" is a real option, never fabricated as a fallback.
  originalImageUrl: string | null
  originalStoragePath: string | null
  // "generated" | "original" | "edited" — which the user has chosen to
  // keep, defaulting to the generated reconstruction. "edited" means the
  // user replaced generatedSvg by hand on the review screen.
  choice: 'generated' | 'original'
}

export type ReviewQuestion = {
  tempId: string
  pageNumber: number
  questionNumber: string | null
  questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER'
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  diagramKeys: string[]
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
}

export type HandwrittenReviewResult = {
  totalPages: number
  questions: ReviewQuestion[]
  diagrams: ReviewDiagram[]
}

async function setStage(jobId: string, stage: string) {
  await prisma.importJob.update({ where: { id: jobId }, data: { stage } }).catch((err) => {
    console.error('[handwritingPipeline] failed to update stage', err)
  })
}

/**
 * Drives one ImportJob from PENDING through PROCESSING to REVIEW/FAILED.
 * Called fire-and-forget from the upload route (this app runs as a
 * persistent Node server on Render — `next start`, not ephemeral
 * serverless — so a promise kept running after the response is sent is
 * safe here; see README § Handwritten PDF Import for why this is the
 * right "safe asynchronous processing pattern" for this stack).
 */
export async function processHandwrittenImportJob(jobId: string): Promise<void> {
  try {
    const job = await prisma.importJob.findUnique({ where: { id: jobId } })
    if (!job) return

    await prisma.importJob.update({ where: { id: jobId }, data: { status: 'PROCESSING', stage: 'Uploading…' } })

    const supabase = createAdminClient()
    const { data: fileData, error: downloadError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .download(job.originalStoragePath)
    if (downloadError || !fileData) {
      throw new Error('Could not re-read the uploaded file from storage.')
    }
    const buffer = Buffer.from(await fileData.arrayBuffer())

    await setStage(jobId, 'Detecting pages…')
    const { pageCount } = await extractPdfText(buffer).catch(() => ({ pageCount: 0, text: '' }))
    await prisma.importJob.update({ where: { id: jobId }, data: { totalPages: pageCount || null } })

    await setStage(jobId, 'Reading handwriting…')
    const extraction = await extractHandwrittenWithAI(buffer, job.originalFileName, pageCount || 1)

    await setStage(jobId, 'Detecting diagrams…')
    // Full-page raster images (a handwritten/scanned PDF page is almost
    // always stored as one embedded image) — used as the crop source for
    // each diagram's "Original" comparison. Best-effort: if extraction
    // fails or finds nothing, diagrams simply have no original crop and
    // the review screen shows the generated reconstruction alone with
    // that noted, never blocking the rest of the import.
    const pageImages = await extractDiagramsFromPdf(buffer).catch(() => [])
    const pageImageByPage = new Map(pageImages.map((p) => [p.pageNumber, p]))

    await setStage(jobId, 'Generating professional diagrams…')
    const diagrams: ReviewDiagram[] = []
    for (const d of extraction.diagrams) {
      const svg = renderDiagramSvg(d.shapes, { widthPx: 500, heightPx: 500 })
      let originalImageUrl: string | null = null
      let originalStoragePath: string | null = null

      const pageImage = pageImageByPage.get(d.pageNumber)
      if (pageImage) {
        try {
          const meta = await sharp(pageImage.buffer).metadata()
          const w = meta.width ?? 1000
          const h = meta.height ?? 1000
          const left = Math.max(0, Math.round((d.boundingBox.x / 1000) * w))
          const top = Math.max(0, Math.round((d.boundingBox.y / 1000) * h))
          const cropWidth = Math.max(1, Math.min(w - left, Math.round((d.boundingBox.width / 1000) * w)))
          const cropHeight = Math.max(1, Math.min(h - top, Math.round((d.boundingBox.height / 1000) * h)))
          const cropped = await sharp(pageImage.buffer).extract({ left, top, width: cropWidth, height: cropHeight }).png().toBuffer()

          const path = `question-images/handwritten-import/${jobId}/${d.key}-original.png`
          const { error: upErr } = await supabase.storage.from(STORAGE_BUCKET).upload(path, cropped, {
            contentType: 'image/png',
            upsert: true,
          })
          if (!upErr) {
            originalStoragePath = path
            originalImageUrl = await getSignedImageUrl(path)
          }
        } catch (err) {
          console.warn('[handwritingPipeline] could not crop original diagram region', err)
        }
      }

      diagrams.push({
        key: d.key,
        diagramType: d.diagramType,
        confidence: d.confidence,
        needsReview: d.needsReview,
        reviewReason: d.reviewReason,
        generatedSvg: svg,
        originalImageUrl,
        originalStoragePath,
        choice: 'generated',
      })
    }

    await setStage(jobId, 'Creating questions…')
    const questions: ReviewQuestion[] = extraction.questions.map((q) => ({
      tempId: q.tempId,
      pageNumber: q.pageNumber,
      questionNumber: q.questionNumber,
      questionType: q.questionType,
      questionText: q.questionText,
      optionA: q.optionA,
      optionB: q.optionB,
      optionC: q.optionC,
      optionD: q.optionD,
      correctAnswer: q.correctAnswer,
      explanation: q.explanation,
      diagramKeys: q.diagramKeys,
      confidence: q.confidence,
      needsReview: q.needsReview,
      reviewReason: q.reviewReason,
    }))

    const result: HandwrittenReviewResult = { totalPages: pageCount || extraction.totalPages, questions, diagrams }

    await setStage(jobId, 'Ready for review.')
    await prisma.importJob.update({
      where: { id: jobId },
      data: { status: 'REVIEW', resultJson: result as unknown as Prisma.InputJsonValue, stage: 'Ready for review.' },
    })
  } catch (err) {
    console.error('[handwritingPipeline] job failed', jobId, err)
    const message =
      err instanceof Error
        ? err.message
        : 'Something went wrong while processing this PDF. No content was saved — the original file is still available.'
    await prisma.importJob
      .update({ where: { id: jobId }, data: { status: 'FAILED', errorMessage: message } })
      .catch(() => {})
  }
}

export function newTempKey(prefix: string): string {
  return `${prefix}-${uuidv4().slice(0, 8)}`
}
