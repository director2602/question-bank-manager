import 'server-only'
import { prisma } from '@/lib/prisma'
import { DEFAULT_PAPER_LAYOUT_SETTINGS, type PaperLayoutSettings } from './paperHtml'

/**
 * Loads the persisted PaperSettings row for a paper (falling back to the
 * app defaults when one doesn't exist yet — e.g. a paper created before
 * this feature, or one nobody has opened the settings panel for) and
 * applies it identically wherever a paper is rendered: the print view, the
 * PDF exporter, and the DOCX exporter (feature spec: "one source of truth,
 * not three").
 *
 * This deliberately does NOT create the row if missing — that lazy-create
 * happens once, explicitly, in GET /api/papers/:id/settings (the endpoint
 * the Paper Settings panel calls), so a paper nobody has ever opened
 * settings for doesn't get a settings row written just because someone
 * printed or exported it.
 *
 * `columnsOverride` preserves the pre-existing `?columns=` query-string
 * behavior on the print/export routes as an explicit one-off override of
 * the persisted setting, without it being the source of truth.
 */
export async function resolvePaperLayoutSettings(
  paperId: string,
  columnsOverride?: number | null
): Promise<PaperLayoutSettings> {
  const row = await prisma.paperSettings.findUnique({ where: { paperId } })

  const base: PaperLayoutSettings = row
    ? {
        pageSize: row.pageSize,
        orientation: row.orientation,
        marginTopMm: row.marginTopMm,
        marginBottomMm: row.marginBottomMm,
        marginLeftMm: row.marginLeftMm,
        marginRightMm: row.marginRightMm,
        columns: row.columns,
        columnGapMm: row.columnGapMm,
        showHeader: row.showHeader,
        showFooter: row.showFooter,
        showPageNumbers: row.showPageNumbers,
        fontFamily: row.fontFamily,
        fontSizePt: row.fontSizePt,
        lineSpacing: row.lineSpacing,
        questionSpacingPx: row.questionSpacingPx,
        imageQualityPercent: row.imageQualityPercent,
        maxImageWidthMm: row.maxImageWidthMm,
        imageAlignment: row.imageAlignment,
        questionNumberingStyle: row.questionNumberingStyle,
        marksDisplayStyle: row.marksDisplayStyle,
      }
    : DEFAULT_PAPER_LAYOUT_SETTINGS

  if (columnsOverride && Number.isInteger(columnsOverride) && columnsOverride >= 1 && columnsOverride <= 3) {
    return { ...base, columns: columnsOverride }
  }
  return base
}
