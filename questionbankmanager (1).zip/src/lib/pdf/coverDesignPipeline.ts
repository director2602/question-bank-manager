import 'server-only'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { createAdminClient } from '@/lib/supabase/admin'
import { STORAGE_BUCKET, getSignedImageUrls } from '@/lib/storage'
import { analyzeCoverReferenceImage, type CoverDesignAnalysisResult } from '@/lib/ai/coverDesignAnalysis'
import { coverDesignSchema, type CoverDesign } from '@/lib/validation/coverDesign'
import { convertAnalysisToCoverDesign } from '@/lib/pdf/coverDesignConvert'

// Re-exported so every existing import of `convertAnalysisToCoverDesign`
// from this module (API routes, etc.) keeps working unchanged — the actual
// implementation lives in coverDesignConvert.ts, split out specifically so
// it has zero Prisma/Supabase dependency and can be unit-tested directly.
export { convertAnalysisToCoverDesign }

// Drives one ImportJob (kind: COVER_DESIGN_ANALYSIS) from PENDING through
// PROCESSING to REVIEW/FAILED — the exact same fire-and-forget async-job
// pattern as processHandwrittenImportJob (see that function's doc comment
// for why this is safe on this specific deployment: a persistent Node
// server, not ephemeral serverless). The browser polls
// GET /api/papers/cover/analyze/[jobId] for status/stage.
export async function processCoverDesignAnalysisJob(jobId: string): Promise<void> {
  try {
    const job = await prisma.importJob.findUnique({ where: { id: jobId } })
    if (!job) return

    await prisma.importJob.update({ where: { id: jobId }, data: { status: 'PROCESSING', stage: 'Reading reference image…' } })

    const supabase = createAdminClient()
    const { data: fileData, error: downloadError } = await supabase.storage
      .from(STORAGE_BUCKET)
      .download(job.originalStoragePath)
    if (downloadError || !fileData) {
      throw new Error('Could not re-read the uploaded reference image from storage.')
    }
    const buffer = Buffer.from(await fileData.arrayBuffer())
    const mimeType = mimeTypeFromFileName(job.originalFileName)

    await prisma.importJob.update({ where: { id: jobId }, data: { stage: 'Analyzing design…' } })
    const result: CoverDesignAnalysisResult = await analyzeCoverReferenceImage(buffer, mimeType)

    await prisma.importJob.update({
      where: { id: jobId },
      data: {
        status: 'REVIEW',
        stage: 'Analysis complete.',
        resultJson: result as unknown as Prisma.InputJsonValue,
      },
    })
  } catch (err) {
    console.error('[coverDesignPipeline] job failed', jobId, err)
    const message =
      err instanceof Error
        ? err.message
        : 'Something went wrong while analyzing this image. The original upload is still available.'
    await prisma.importJob
      .update({ where: { id: jobId }, data: { status: 'FAILED', errorMessage: message } })
      .catch(() => {})
  }
}

function mimeTypeFromFileName(fileName: string): 'image/png' | 'image/jpeg' | 'image/webp' {
  const ext = fileName.toLowerCase().split('.').pop()
  if (ext === 'webp') return 'image/webp'
  if (ext === 'jpg' || ext === 'jpeg') return 'image/jpeg'
  return 'image/png'
}

// Every PDF/print/DOCX rendering call site loads a Paper's raw
// `coverDesign` JSON column and needs the SAME resolution step before
// handing it to renderPaperHtml()/buildPaperDocxBuffer(): validate it back
// into a real CoverDesign (a malformed/legacy JSON blob renders as "no
// cover design" rather than throwing and blocking the whole export), then
// swap every stored Supabase Storage `imagePath`/`referenceImagePath` for a
// freshly-signed URL — signed URLs expire in 1 hour, so they're never the
// thing that gets persisted (see coverDesign.ts's own doc comment), only
// ever generated fresh right before rendering. Returns null when there's
// nothing to render, so callers can `coverDesign ?? null` straight into
// the renderer without an extra branch.
export async function resolveCoverDesignForRender(coverDesignJson: unknown): Promise<CoverDesign | null> {
  const design = parseCoverDesignJson(coverDesignJson)
  if (!design) return null

  const signedUrls = await buildCoverImagePreviewUrls(design)
  if (Object.keys(signedUrls).length === 0) return design

  return {
    ...design,
    elements: design.elements.map((el) =>
      (el.type === 'logo' || el.type === 'image') && el.imagePath && signedUrls[el.imagePath]
        ? { ...el, imagePath: signedUrls[el.imagePath] }
        : el
    ),
    background:
      design.background.mode === 'background' &&
      design.background.referenceImagePath &&
      signedUrls[design.background.referenceImagePath]
        ? { ...design.background, referenceImagePath: signedUrls[design.background.referenceImagePath] }
        : design.background,
  }
}

// Validates a Paper's raw stored `coverDesign` JSON WITHOUT touching any
// image path — used by the designer's own GET /api/papers/:id/cover, which
// needs to hand the editor back the real, savable storage paths (never
// signed URLs — see resolveCoverDesignForRender's doc comment above) plus a
// SEPARATE preview-URL map (buildCoverImagePreviewUrls) for what to
// actually display. A malformed/legacy JSON blob returns null rather than
// throwing.
export function parseCoverDesignJson(coverDesignJson: unknown): CoverDesign | null {
  if (!coverDesignJson) return null
  const parsed = coverDesignSchema.safeParse(coverDesignJson)
  if (!parsed.success) {
    console.error('[coverDesignPipeline] stored coverDesign failed validation, falling back to no cover design', parsed.error)
    return null
  }
  return parsed.data
}

// Every Supabase Storage path referenced by a design (image/logo elements'
// imagePath, plus the background reference image when in use), signed
// fresh — this is the ONE place that decides which paths need signing, so
// resolveCoverDesignForRender (render paths) and the designer's own GET
// route (edit path) can never disagree about what counts as "an image this
// design uses".
export async function buildCoverImagePreviewUrls(design: Pick<CoverDesign, 'elements' | 'background'>): Promise<Record<string, string>> {
  const paths = new Set<string>()
  for (const el of design.elements) {
    if ((el.type === 'logo' || el.type === 'image') && el.imagePath) paths.add(el.imagePath)
  }
  if (design.background.mode === 'background' && design.background.referenceImagePath) {
    paths.add(design.background.referenceImagePath)
  }
  if (paths.size === 0) return {}
  return getSignedImageUrls(Array.from(paths))
}
