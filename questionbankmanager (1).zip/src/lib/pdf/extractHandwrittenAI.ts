// Handwriting-specific vision extraction. Sends the whole PDF to Claude
// (same approach as extractQuestionsAI.ts's typed-PDF transcription — no
// local page rasterization needed, Claude reads PDF pages internally) with
// a system prompt tuned for HANDWRITING recognition plus structured
// diagram reconstruction: for every diagram, Claude reports a bounded list
// of geometric primitives (lines/circles/polygons/text labels) in a fixed
// 0-1000 coordinate space rather than trying to generate an image directly
// — src/lib/pdf/diagramSvgRenderer.ts then deterministically draws exactly
// those primitives as a clean SVG. This keeps every rendered diagram
// traceable back to a checkable, bounded JSON structure instead of an
// opaque AI-generated raster.
//
// Per the spec's explicit anti-hallucination rules: this function NEVER
// invents question content or diagram geometry it isn't reasonably
// confident about — every question and every diagram carries a
// HIGH/MEDIUM/LOW confidence and a needsReview flag+reason, surfaced
// as-is to the review screen. Requires ANTHROPIC_API_KEY; throws a clear,
// user-facing error (never a mocked/fake result) when it isn't configured.

import Anthropic from '@anthropic-ai/sdk'
import type {
  DiagramShape,
  ExtractedDiagram,
  ExtractedHandwrittenQuestion,
  HandwritingExtractionResult,
} from '@/lib/ai/ocrProvider'

const MODEL = 'claude-sonnet-5'
const MAX_OUTPUT_TOKENS = 32000

const SYSTEM_PROMPT = `You are converting a HANDWRITTEN exam/question-paper PDF into clean, professional digital question-bank content. This is a careful transcription + reconstruction task, not a solving task.

CRITICAL RULES:
- Preserve the original academic meaning exactly. Do NOT rewrite, rephrase, "improve", solve, or correct the question content.
- Do NOT invent information that is not actually legible in the handwriting. If a word, number, or symbol is genuinely illegible, represent your best reading but set confidence to LOW and needsReview to true with a specific reason (e.g. "third digit of the answer is illegible").
- Transcribe mathematics as LaTeX ($...$ inline, $$...$$ display): fractions, exponents, roots, integrals, Greek letters, subscripts/superscripts, units, chemical formulas, vectors.
- Detect individual questions (numbered like "Q1.", "1)", "2.") and report each as a separate entry via the report_extraction tool.
- For MCQ questions, only fill optionA-D if lettered options are actually handwritten; leave correctAnswer/explanation empty unless an answer is actually marked/written somewhere.
- For diagrams (geometry figures, graphs, coordinate systems, physics/circuit diagrams, chemistry structures, flowcharts, tables, timelines, simple maps): report each as a SEPARATE entry with a bounded list of geometric primitives (lines, circles, polygons, text labels) in a 0-1000 x 0-1000 coordinate space matching the diagram's own layout as closely as you can tell — do not arbitrarily redesign the geometry, and preserve every meaningful label/number exactly as handwritten. If you cannot confidently reconstruct part of a diagram's geometry, still report whatever primitives you ARE confident about, and set needsReview=true with a specific reason — never silently guess a shape you can't actually make out.
- Also report the page's approximate bounding box (0-1000 space) of each diagram, so the original page region can be cropped for a side-by-side review.
- Record the 1-indexed page number each question/diagram appears on.
- If the whole document (or a page) is too illegible to extract anything with any confidence, still report what little you can, all flagged needsReview=true — never fabricate a clean-looking question from illegible input.`

export async function extractHandwrittenWithAI(
  buffer: Buffer,
  fileName: string,
  totalPages: number
): Promise<HandwritingExtractionResult> {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    throw new Error(
      'Handwriting recognition is not configured on this server (missing ANTHROPIC_API_KEY). Ask an administrator to add it in the deployment environment variables.'
    )
  }

  const client = new Anthropic({ apiKey })

  const shapeSchema = {
    type: 'object',
    properties: {
      type: { type: 'string', enum: ['line', 'circle', 'polygon', 'text'] },
      x1: { type: 'number' },
      y1: { type: 'number' },
      x2: { type: 'number' },
      y2: { type: 'number' },
      arrow: { type: 'boolean' },
      cx: { type: 'number' },
      cy: { type: 'number' },
      r: { type: 'number' },
      points: {
        type: 'array',
        items: { type: 'object', properties: { x: { type: 'number' }, y: { type: 'number' } }, required: ['x', 'y'] },
      },
      closed: { type: 'boolean' },
      x: { type: 'number' },
      y: { type: 'number' },
      text: { type: 'string' },
      fontSize: { type: 'number' },
    },
    required: ['type'],
  }

  const tool: Anthropic.Tool = {
    name: 'report_extraction',
    description: 'Report every handwritten question and diagram extracted from the PDF.',
    input_schema: {
      type: 'object',
      properties: {
        questions: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              pageNumber: { type: 'integer' },
              questionNumber: { type: 'string', description: 'As handwritten, e.g. "1" or "Q.3". Empty if none visible.' },
              questionType: { type: 'string', enum: ['MCQ', 'SUBJECTIVE', 'INTEGER'] },
              questionText: { type: 'string' },
              optionA: { type: 'string' },
              optionB: { type: 'string' },
              optionC: { type: 'string' },
              optionD: { type: 'string' },
              correctAnswer: { type: 'string' },
              explanation: { type: 'string' },
              diagramKeys: { type: 'array', items: { type: 'string' }, description: 'Keys of diagrams (from the diagrams array) that belong to this question.' },
              confidence: { type: 'string', enum: ['HIGH', 'MEDIUM', 'LOW'] },
              needsReview: { type: 'boolean' },
              reviewReason: { type: 'string' },
            },
            required: ['pageNumber', 'questionType', 'questionText', 'confidence', 'needsReview'],
          },
        },
        diagrams: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              key: { type: 'string', description: 'Short unique key, e.g. "d1", "d2".' },
              pageNumber: { type: 'integer' },
              diagramType: { type: 'string', enum: ['geometry', 'graph', 'circuit', 'chemistry', 'flowchart', 'table', 'other'] },
              shapes: { type: 'array', items: shapeSchema },
              boundingBox: {
                type: 'object',
                properties: { x: { type: 'number' }, y: { type: 'number' }, width: { type: 'number' }, height: { type: 'number' } },
                required: ['x', 'y', 'width', 'height'],
              },
              confidence: { type: 'string', enum: ['HIGH', 'MEDIUM', 'LOW'] },
              needsReview: { type: 'boolean' },
              reviewReason: { type: 'string' },
            },
            required: ['key', 'pageNumber', 'diagramType', 'shapes', 'boundingBox', 'confidence', 'needsReview'],
          },
        },
      },
      required: ['questions', 'diagrams'],
    },
  }

  let response
  try {
    response = await client.messages.create({
      model: MODEL,
      max_tokens: MAX_OUTPUT_TOKENS,
      system: SYSTEM_PROMPT,
      tools: [tool],
      tool_choice: { type: 'tool', name: 'report_extraction' },
      messages: [
        {
          role: 'user',
          content: [
            { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: buffer.toString('base64') }, title: fileName },
            {
              type: 'text',
              text: 'Extract every handwritten question and diagram from this document using the report_extraction tool, following the system instructions exactly.',
            },
          ],
        },
      ],
    })
  } catch (err) {
    console.error('[extractHandwrittenAI] Claude API call failed', err)
    throw new Error(
      'The handwriting recognition service could not process this PDF. It may be too large, too low quality, or briefly unavailable — please try again shortly.'
    )
  }

  if (response.stop_reason === 'max_tokens') {
    throw new Error(
      'This PDF has too much content for a single pass. Split it into smaller files (roughly 10-15 pages each) and upload them one at a time.'
    )
  }

  const toolUse = response.content.find(
    (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use' && block.name === 'report_extraction'
  )
  if (!toolUse) {
    throw new Error('The handwriting recognition service did not return structured results for this PDF. Please try again.')
  }

  const parsed = toolUse.input as { questions?: Array<Record<string, unknown>>; diagrams?: Array<Record<string, unknown>> }

  const diagrams: ExtractedDiagram[] = (Array.isArray(parsed.diagrams) ? parsed.diagrams : []).map((d, idx) => ({
    key: typeof d.key === 'string' && d.key ? d.key : `d${idx + 1}`,
    pageNumber: positiveInt(d.pageNumber, 1),
    diagramType: isDiagramType(d.diagramType) ? d.diagramType : 'other',
    shapes: (Array.isArray(d.shapes) ? d.shapes : []).map(coerceShape).filter((s): s is DiagramShape => s !== null),
    boundingBox: coerceBoundingBox(d.boundingBox),
    confidence: isConfidence(d.confidence) ? d.confidence : 'LOW',
    needsReview: d.needsReview === true,
    reviewReason: nullableString(d.reviewReason),
  }))

  const questions: ExtractedHandwrittenQuestion[] = (Array.isArray(parsed.questions) ? parsed.questions : []).map((q, idx) => ({
    tempId: `hw-q-${idx}-${Math.round(Math.random() * 1e9)}`,
    pageNumber: positiveInt(q.pageNumber, 1),
    questionNumber: nullableString(q.questionNumber),
    questionType: isQuestionType(q.questionType) ? q.questionType : 'MCQ',
    questionText: typeof q.questionText === 'string' ? q.questionText.trim() : '',
    optionA: nullableString(q.optionA),
    optionB: nullableString(q.optionB),
    optionC: nullableString(q.optionC),
    optionD: nullableString(q.optionD),
    correctAnswer: nullableString(q.correctAnswer),
    explanation: nullableString(q.explanation),
    diagramKeys: Array.isArray(q.diagramKeys) ? q.diagramKeys.filter((k): k is string => typeof k === 'string') : [],
    confidence: isConfidence(q.confidence) ? q.confidence : 'LOW',
    needsReview: q.needsReview === true,
    reviewReason: nullableString(q.reviewReason),
  }))

  return { totalPages, questions, diagrams }
}

function positiveInt(v: unknown, fallback: number): number {
  return typeof v === 'number' && v > 0 ? Math.floor(v) : fallback
}
function nullableString(v: unknown): string | null {
  if (typeof v !== 'string') return null
  const t = v.trim()
  return t ? t : null
}
function isConfidence(v: unknown): v is 'HIGH' | 'MEDIUM' | 'LOW' {
  return v === 'HIGH' || v === 'MEDIUM' || v === 'LOW'
}
function isQuestionType(v: unknown): v is 'MCQ' | 'SUBJECTIVE' | 'INTEGER' {
  return v === 'MCQ' || v === 'SUBJECTIVE' || v === 'INTEGER'
}
function isDiagramType(v: unknown): v is ExtractedDiagram['diagramType'] {
  return v === 'geometry' || v === 'graph' || v === 'circuit' || v === 'chemistry' || v === 'flowchart' || v === 'table' || v === 'other'
}
function coerceBoundingBox(v: unknown): ExtractedDiagram['boundingBox'] {
  const box = (v ?? {}) as Record<string, unknown>
  return {
    x: typeof box.x === 'number' ? box.x : 0,
    y: typeof box.y === 'number' ? box.y : 0,
    width: typeof box.width === 'number' ? box.width : 1000,
    height: typeof box.height === 'number' ? box.height : 1000,
  }
}
function coerceShape(raw: unknown): DiagramShape | null {
  const s = raw as Record<string, unknown>
  if (s.type === 'line' && isNum(s.x1) && isNum(s.y1) && isNum(s.x2) && isNum(s.y2)) {
    return { type: 'line', x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2, arrow: s.arrow === true }
  }
  if (s.type === 'circle' && isNum(s.cx) && isNum(s.cy) && isNum(s.r)) {
    return { type: 'circle', cx: s.cx, cy: s.cy, r: s.r }
  }
  if (s.type === 'polygon' && Array.isArray(s.points)) {
    const points = s.points
      .map((p) => (p && typeof p === 'object' ? (p as Record<string, unknown>) : null))
      .filter((p): p is Record<string, unknown> => p !== null && isNum(p.x) && isNum(p.y))
      .map((p) => ({ x: p.x as number, y: p.y as number }))
    if (points.length >= 2) return { type: 'polygon', points, closed: s.closed !== false }
  }
  if (s.type === 'text' && isNum(s.x) && isNum(s.y) && typeof s.text === 'string') {
    return { type: 'text', x: s.x, y: s.y, text: s.text, fontSize: isNum(s.fontSize) ? s.fontSize : undefined }
  }
  return null
}
function isNum(v: unknown): v is number {
  return typeof v === 'number' && !Number.isNaN(v)
}

// Focused single-diagram re-extraction for the review screen's
// "Regenerate" control (Part 6) — re-runs recognition on just the ORIGINAL
// cropped region (never the whole document again), in case the first pass
// missed the geometry. Same anti-hallucination contract as the full
// extraction: a bounded, checkable shape list, honestly confidence-scored,
// never a silently-invented "improved" guess.
export async function regenerateDiagramWithAI(
  imageBuffer: Buffer,
  imageMimeType: 'image/png' | 'image/jpeg',
  currentDiagramType: ExtractedDiagram['diagramType']
): Promise<Pick<ExtractedDiagram, 'shapes' | 'diagramType' | 'confidence' | 'needsReview' | 'reviewReason'>> {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    throw new Error(
      'Handwriting recognition is not configured on this server (missing ANTHROPIC_API_KEY). Ask an administrator to add it in the deployment environment variables.'
    )
  }
  const client = new Anthropic({ apiKey })

  const shapeSchema = {
    type: 'object',
    properties: {
      type: { type: 'string', enum: ['line', 'circle', 'polygon', 'text'] },
      x1: { type: 'number' },
      y1: { type: 'number' },
      x2: { type: 'number' },
      y2: { type: 'number' },
      arrow: { type: 'boolean' },
      cx: { type: 'number' },
      cy: { type: 'number' },
      r: { type: 'number' },
      points: {
        type: 'array',
        items: { type: 'object', properties: { x: { type: 'number' }, y: { type: 'number' } }, required: ['x', 'y'] },
      },
      closed: { type: 'boolean' },
      x: { type: 'number' },
      y: { type: 'number' },
      text: { type: 'string' },
      fontSize: { type: 'number' },
    },
    required: ['type'],
  }

  const tool: Anthropic.Tool = {
    name: 'report_diagram',
    description: 'Report this single diagram as a bounded list of geometric primitives.',
    input_schema: {
      type: 'object',
      properties: {
        diagramType: { type: 'string', enum: ['geometry', 'graph', 'circuit', 'chemistry', 'flowchart', 'table', 'other'] },
        shapes: { type: 'array', items: shapeSchema },
        confidence: { type: 'string', enum: ['HIGH', 'MEDIUM', 'LOW'] },
        needsReview: { type: 'boolean' },
        reviewReason: { type: 'string' },
      },
      required: ['diagramType', 'shapes', 'confidence', 'needsReview'],
    },
  }

  let response
  try {
    response = await client.messages.create({
      model: MODEL,
      max_tokens: 8000,
      system:
        'You are re-examining ONE cropped diagram image from a handwritten exam paper, reconstructing it as a bounded list of geometric primitives (lines/circles/polygons/text) in a 0-1000 x 0-1000 coordinate space matching the image layout. Preserve every meaningful label/number exactly as handwritten. Do not redesign or "improve" the geometry — reproduce what is actually drawn. If part of it is illegible, report what you ARE confident about and set needsReview=true with a specific reason rather than guessing.',
      tools: [tool],
      tool_choice: { type: 'tool', name: 'report_diagram' },
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: imageMimeType, data: imageBuffer.toString('base64') } },
            { type: 'text', text: `This was previously classified as a "${currentDiagramType}" diagram. Re-examine it carefully and report it via report_diagram.` },
          ],
        },
      ],
    })
  } catch (err) {
    console.error('[extractHandwrittenAI] regenerate call failed', err)
    throw new Error('The handwriting recognition service could not re-process this diagram. Please try again shortly.')
  }

  const toolUse = response.content.find(
    (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use' && block.name === 'report_diagram'
  )
  if (!toolUse) {
    throw new Error('The handwriting recognition service did not return a structured result for this diagram. Please try again.')
  }
  const d = toolUse.input as Record<string, unknown>

  return {
    diagramType: isDiagramType(d.diagramType) ? d.diagramType : currentDiagramType,
    shapes: (Array.isArray(d.shapes) ? d.shapes : []).map(coerceShape).filter((s): s is DiagramShape => s !== null),
    confidence: isConfidence(d.confidence) ? d.confidence : 'LOW',
    needsReview: d.needsReview === true,
    reviewReason: nullableString(d.reviewReason),
  }
}
