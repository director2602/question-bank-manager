import type { DiagramShape } from '@/lib/ai/ocrProvider'

// Deterministically renders a structured shape list (lines/circles/
// polygons/text — see OCRProvider) into a clean, professional SVG. This is
// plain code, not AI-generated pixels: the AI's job (extractHandwrittenAI)
// is only to report WHAT shapes are in the diagram and WHERE (a bounded,
// checkable JSON structure); this function is what actually draws them,
// so the output is always crisp vector line art at any print resolution,
// never a blurry re-hallucinated image.
//
// Coordinates are in a fixed 0-1000 x 0-1000 space; the SVG's viewBox maps
// that 1:1, and the caller sizes the outer <svg> to fit the paper's column
// width, so it scales cleanly without distorting aspect ratio (the viewBox
// preserves it via preserveAspectRatio="xMidYMid meet", the SVG default).
const CANVAS = 1000
const STROKE = '#1a1a1a'
const STROKE_WIDTH = 2.5

export function renderDiagramSvg(shapes: DiagramShape[], opts?: { widthPx?: number; heightPx?: number }): string {
  const width = opts?.widthPx ?? 400
  const height = opts?.heightPx ?? 400

  const defs = `<defs><marker id="arrowhead" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto"><polygon points="0 0, 10 4, 0 8" fill="${STROKE}" /></marker></defs>`

  const body = shapes
    .map((shape) => renderShape(shape))
    .filter(Boolean)
    .join('\n  ')

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${CANVAS} ${CANVAS}" width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet">
  ${defs}
  <rect x="0" y="0" width="${CANVAS}" height="${CANVAS}" fill="white" />
  ${body}
</svg>`
}

function renderShape(shape: DiagramShape): string {
  switch (shape.type) {
    case 'line': {
      const markerAttr = shape.arrow ? ' marker-end="url(#arrowhead)"' : ''
      return `<line x1="${n(shape.x1)}" y1="${n(shape.y1)}" x2="${n(shape.x2)}" y2="${n(shape.y2)}" stroke="${STROKE}" stroke-width="${STROKE_WIDTH}" stroke-linecap="round"${markerAttr} />`
    }
    case 'circle':
      return `<circle cx="${n(shape.cx)}" cy="${n(shape.cy)}" r="${n(shape.r)}" fill="none" stroke="${STROKE}" stroke-width="${STROKE_WIDTH}" />`
    case 'polygon': {
      if (!shape.points || shape.points.length < 2) return ''
      const pts = shape.points.map((p) => `${n(p.x)},${n(p.y)}`).join(' ')
      const tag = shape.closed === false ? 'polyline' : 'polygon'
      return `<${tag} points="${pts}" fill="none" stroke="${STROKE}" stroke-width="${STROKE_WIDTH}" stroke-linejoin="round" />`
    }
    case 'text':
      return `<text x="${n(shape.x)}" y="${n(shape.y)}" font-size="${shape.fontSize ?? 28}" font-family="Calibri, Arial, sans-serif" fill="${STROKE}">${escapeXml(shape.text)}</text>`
    default:
      return ''
  }
}

function n(v: number): number {
  return Math.round(Math.max(0, Math.min(1000, v)) * 100) / 100
}

function escapeXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}
