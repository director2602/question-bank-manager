import type { SnapshotQuestion } from '@/lib/paper-snapshot'

export type PaperSettings = {
  title: string
  paperNumber: number
  instituteName: string | null
  logoUrl: string | null
  examName: string | null
  subjectLabel: string | null
  classLabel: string | null
  examDate: string | null
  examTime: string | null
  maxMarks: number | null
  instructions: string | null
  headerText: string | null
  footerText: string | null
}

export type PaperExportMode = 'question' | 'answerKey' | 'solutions'

function escapeHtml(input: string | null | undefined): string {
  if (!input) return ''
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

// Preserves the verbatim question text exactly as stored — this function
// only escapes it for safe HTML embedding and converts literal newlines to
// <br>, it never rewrites, corrects, or reformats the content itself.
function textToHtml(text: string | null | undefined): string {
  return escapeHtml(text).replace(/\n/g, '<br/>')
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const

/**
 * Renders a paper (question paper, answer key, or detailed solutions) as a
 * fully self-contained, print-ready HTML document. Used both for the
 * in-browser "Print / Save as PDF" flow and as the input to the
 * server-side Puppeteer PDF export (see /api/papers/[id]/export/pdf) — same
 * markup, same visual result, either path.
 *
 * Math/scientific notation: question/option/explanation text may contain
 * LaTeX delimited by $...$ or \(...\)/\[...\]; MathJax (loaded from CDN)
 * typesets it client-side after the page loads.
 */
export function renderPaperHtml(
  settings: PaperSettings,
  questions: SnapshotQuestion[],
  mode: PaperExportMode
): string {
  const heading =
    mode === 'answerKey' ? 'Answer Key' : mode === 'solutions' ? 'Detailed Solutions' : 'Question Paper'

  const bodyContent =
    mode === 'answerKey' ? renderAnswerKey(questions) : renderQuestions(questions, mode === 'solutions')

  // Relative asset URLs (e.g. a logo at /branding/logo.png) only resolve
  // correctly when this HTML is loaded as a real page in the browser
  // (Print view). The server-side PDF export renders this same HTML via
  // Puppeteer's page.setContent(), which has NO base URL (about:blank) —
  // without an explicit <base>, any relative <img src> would silently fail
  // to load. Setting NEXT_PUBLIC_APP_URL as the base makes both paths work
  // identically.
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${escapeHtml(settings.title)} — ${heading}</title>
${baseUrl ? `<base href="${escapeHtml(baseUrl)}/" />` : ''}
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script>
  window.MathJax = {
    tex: { inlineMath: [['$', '$'], ['\\\\(', '\\\\)']], displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']] },
    svg: { fontCache: 'global' },
  };
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" id="MathJax-script" async></script>
<style>
  @page { size: A4; margin: 18mm 16mm; }
  * { box-sizing: border-box; }
  body {
    font-family: 'Georgia', 'Times New Roman', serif;
    color: #14161f;
    font-size: 12.5pt;
    line-height: 1.5;
    max-width: 820px;
    margin: 0 auto;
    padding: 24px;
  }
  .paper-header { text-align: center; border-bottom: 2px solid #14161f; padding-bottom: 12px; margin-bottom: 18px; }
  .paper-header img.logo { max-height: 56px; margin-bottom: 8px; }
  .institute-name { font-size: 18pt; font-weight: 700; letter-spacing: 0.02em; }
  .exam-name { font-size: 13pt; margin-top: 2px; font-weight: 600; }
  .meta-row { display: flex; justify-content: space-between; font-size: 11pt; margin-top: 10px; flex-wrap: wrap; gap: 6px 18px; }
  .heading-badge { display: inline-block; font-size: 11pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 6px; color: #2547ea; }
  .instructions { font-size: 10.5pt; background: #f7f8fa; border: 1px solid #e2e5eb; border-radius: 6px; padding: 10px 14px; margin-bottom: 20px; white-space: pre-wrap; }
  .instructions-title { font-weight: 700; margin-bottom: 4px; }
  .question { margin-bottom: 16px; page-break-inside: avoid; }
  .question-number { font-weight: 700; margin-right: 6px; }
  .question-text { display: inline; }
  .options { margin: 6px 0 0 22px; }
  .options .option { margin-bottom: 3px; }
  .option-letter { font-weight: 600; margin-right: 6px; }
  .question-image { display: block; max-width: 100%; max-height: 320px; margin: 8px 0; }
  .explanation { margin-top: 6px; margin-left: 22px; font-size: 11pt; color: #333a4d; font-style: italic; }
  .answer-key-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px 20px; }
  .answer-key-item { font-size: 12pt; }
  .paper-footer { margin-top: 28px; padding-top: 10px; border-top: 1px solid #e2e5eb; font-size: 9.5pt; color: #565d72; text-align: center; }
  @media print {
    body { padding: 0; }
    .no-print { display: none !important; }
  }
</style>
</head>
<body>
  <div class="paper-header">
    ${settings.logoUrl ? `<img class="logo" src="${escapeHtml(settings.logoUrl)}" alt="Institute logo" />` : ''}
    <div class="institute-name">${escapeHtml(settings.instituteName || 'CUBUS')}</div>
    ${settings.examName ? `<div class="exam-name">${escapeHtml(settings.examName)}</div>` : ''}
    <div class="meta-row">
      <span>${settings.subjectLabel ? `Subject: ${escapeHtml(settings.subjectLabel)}` : ''}</span>
      <span>${settings.classLabel ? `Class/Exam: ${escapeHtml(settings.classLabel)}` : ''}</span>
      <span>${settings.examDate ? `Date: ${escapeHtml(settings.examDate)}` : ''}</span>
      <span>${settings.examTime ? `Time: ${escapeHtml(settings.examTime)}` : ''}</span>
      <span>${settings.maxMarks ? `Maximum Marks: ${settings.maxMarks}` : ''}</span>
    </div>
    <div class="heading-badge">${heading}</div>
  </div>

  ${
    settings.instructions && mode === 'question'
      ? `<div class="instructions"><div class="instructions-title">Instructions</div>${textToHtml(settings.instructions)}</div>`
      : ''
  }

  ${bodyContent}

  <div class="paper-footer">
    ${escapeHtml(settings.footerText) || `Paper #${settings.paperNumber} — ${escapeHtml(settings.title)}`}
  </div>

  <button class="no-print" onclick="window.print()" style="position:fixed;top:16px;right:16px;padding:10px 16px;background:#2547ea;color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;">Print / Save as PDF</button>
</body>
</html>`
}

function renderQuestions(questions: SnapshotQuestion[], includeSolutions: boolean): string {
  return questions
    .map((q) => {
      const options = OPTION_LETTERS.map((letter) => {
        const key = `option${letter}` as 'optionA' | 'optionB' | 'optionC' | 'optionD'
        const value = q[key]
        if (!value) return ''
        return `<div class="option"><span class="option-letter">${letter}.</span>${textToHtml(value)}</div>`
      }).join('')

      const images = q.images
        .map((img) => (img.url ? `<img class="question-image" src="${escapeHtml(img.url)}" alt="${escapeHtml(img.altText || 'Question image')}" />` : ''))
        .join('')

      const solution =
        includeSolutions && (q.correctAnswer || q.explanation)
          ? `<div class="explanation">${q.correctAnswer ? `<strong>Answer: ${escapeHtml(q.correctAnswer)}</strong><br/>` : ''}${textToHtml(q.explanation)}</div>`
          : ''

      return `<div class="question">
        <span class="question-number">Q${q.position}.</span><span class="question-text">${textToHtml(q.questionText)}</span>
        ${images}
        ${options ? `<div class="options">${options}</div>` : ''}
        ${solution}
      </div>`
    })
    .join('\n')
}

function renderAnswerKey(questions: SnapshotQuestion[]): string {
  const items = questions
    .map(
      (q) =>
        `<div class="answer-key-item"><strong>${q.position}.</strong> ${escapeHtml(q.correctAnswer) || '<em>Not specified</em>'}</div>`
    )
    .join('\n')
  return `<div class="answer-key-grid">${items}</div>`
}
