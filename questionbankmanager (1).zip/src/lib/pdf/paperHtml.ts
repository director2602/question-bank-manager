import type { SnapshotQuestion } from '@/lib/paper-snapshot'
import { SCUBUS_LOGO_FULL_DATA_URI, SCUBUS_LOGO_ICON_DATA_URI, CUBUS_WATERMARK_LOGO_DATA_URI } from './brandAssets'
import type { CoverDesign, CoverElement } from '@/lib/validation/coverDesign'
import { buildCoverPlaceholderMap, resolveCoverElementText } from './coverPlaceholders'

export type PaperSettings = {
  title: string
  // Optional subtitle shown under the main title on the cover — Advanced
  // Paper Builder's custom-heading addition (Paper.subtitle). Null for
  // every paper from the original flat generator, which never sets it.
  subtitle?: string | null
  paperNumber: number
  instituteName: string | null
  logoUrl: string | null
  examName: string | null
  subjectLabel: string | null
  classLabel: string | null
  examDate: string | null
  examTime: string | null
  maxMarks: number | null
  instructions: string | null
  headerText: string | null
  footerText: string | null
}

export type PaperExportMode = 'question' | 'answerKey' | 'solutions'

// Mirrors prisma/schema.prisma's PaperSettings model (minus id/paperId/
// timestamps) — the one source of truth for layout/typography/image
// export config, applied identically by the print view and the PDF/DOCX
// exporters (see the model's own doc comment in schema.prisma).
export type PaperLayoutSettings = {
  pageSize: 'A4' | 'LETTER' | 'LEGAL'
  orientation: 'PORTRAIT' | 'LANDSCAPE'
  marginTopMm: number
  marginBottomMm: number
  marginLeftMm: number
  marginRightMm: number
  columns: number
  columnGapMm: number
  showHeader: boolean
  showFooter: boolean
  showPageNumbers: boolean
  fontFamily: string
  fontSizePt: number
  lineSpacing: number
  questionSpacingPx: number
  imageQualityPercent: number
  maxImageWidthMm: number
  imageAlignment: 'LEFT' | 'CENTER' | 'RIGHT'
  // Advanced Paper Builder additions — applied consistently across the
  // whole document by renderQuestions() below, same one-source-of-truth
  // pattern as every other layout field.
  questionNumberingStyle: 'PLAIN' | 'Q_PREFIX' | 'LETTERED'
  marksDisplayStyle: 'BRACKET_MARKS' | 'PAREN_NUMBER' | 'BRACKET_NUMBER'
}

// Matches the Prisma column @default()s exactly — used whenever a caller
// hasn't loaded (or doesn't need) a real PaperSettings row, e.g. legacy
// callers or a paper that predates this feature.
export const DEFAULT_PAPER_LAYOUT_SETTINGS: PaperLayoutSettings = {
  pageSize: 'A4',
  orientation: 'PORTRAIT',
  marginTopMm: 18,
  marginBottomMm: 18,
  marginLeftMm: 16,
  marginRightMm: 16,
  columns: 2,
  columnGapMm: 8,
  showHeader: true,
  showFooter: true,
  showPageNumbers: true,
  fontFamily: 'Calibri',
  fontSizePt: 11,
  lineSpacing: 1.5,
  questionSpacingPx: 16,
  imageQualityPercent: 90,
  maxImageWidthMm: 85,
  imageAlignment: 'LEFT',
  questionNumberingStyle: 'Q_PREFIX',
  marksDisplayStyle: 'BRACKET_MARKS',
}

// Fixed heights for the subjective-answer-space presets — CUSTOM uses the
// section's own customAnswerSpaceMm instead. Rendered as a normal block
// element (not absolutely positioned), so ordinary CSS flow guarantees it
// can never overlap the next question — spec's "never let answer space
// overlap another question" is satisfied structurally, not by measurement.
export const ANSWER_SPACE_MM: Record<'NONE' | 'SMALL' | 'MEDIUM' | 'LARGE', number> = {
  NONE: 0,
  SMALL: 20,
  MEDIUM: 40,
  LARGE: 70,
}

const PAGE_SIZE_MM: Record<PaperLayoutSettings['pageSize'], { widthMm: number; heightMm: number }> = {
  A4: { widthMm: 210, heightMm: 297 },
  LETTER: { widthMm: 215.9, heightMm: 279.4 },
  LEGAL: { widthMm: 215.9, heightMm: 355.6 },
}

/**
 * Physical page dimensions in mm for a layout's pageSize + orientation —
 * shared by the DOCX exporter (needs real twip measurements) and the PDF
 * page-number stamper (needs real point measurements), so page-size
 * geometry has exactly one source of truth rather than being recomputed
 * per export format.
 */
export function getPageDimensionsMm(layout: Pick<PaperLayoutSettings, 'pageSize' | 'orientation'>): {
  widthMm: number
  heightMm: number
} {
  const { widthMm, heightMm } = PAGE_SIZE_MM[layout.pageSize]
  return layout.orientation === 'LANDSCAPE' ? { widthMm: heightMm, heightMm: widthMm } : { widthMm, heightMm }
}

// The brand palette this whole letterhead is built around. The primary
// color is the user-specified brand color #400c4d (deep aubergine/maroon),
// used for banners/badges/rules/watermark; the mauve accent (#d7bcd2) is
// kept from the original reference paper as the lighter secondary tone for
// header/footer bands and bars.
const BRAND_MAROON = '#400c4d'
const BRAND_MAUVE = '#d7bcd2'
const HEADER_BAND_HEIGHT_MM = 13
const FOOTER_BAND_HEIGHT_MM = 9

function escapeHtml(input: string | null | undefined): string {
  if (!input) return ''
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

// Preserves the verbatim question text exactly as stored — this function
// only escapes it for safe HTML embedding and converts literal newlines to
// <br>, it never rewrites, corrects, or reformats the content itself.
function textToHtml(text: string | null | undefined): string {
  return escapeHtml(text).replace(/\n/g, '<br/>')
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const

// Real, computed-from-data subject breakdown (never fabricated) — mirrors
// the reference paper's "SUBJECTS / QUESTIONS" table. Only meaningful (and
// only rendered) when a paper actually spans more than one subject.
function buildSubjectBreakdown(questions: SnapshotQuestion[]): { subject: string; count: number }[] {
  const counts = new Map<string, number>()
  for (const q of questions) {
    counts.set(q.subject, (counts.get(q.subject) ?? 0) + 1)
  }
  return Array.from(counts.entries()).map(([subject, count]) => ({ subject, count }))
}

// Prefer the paper's explicitly-set max marks; otherwise, only claim a
// total if every question actually carries a marks value — a partial sum
// would misrepresent the paper's real total, which the "no fabricated
// data" rule rules out.
function resolveMaxMarks(settings: PaperSettings, questions: SnapshotQuestion[]): number | null {
  if (settings.maxMarks) return settings.maxMarks
  if (questions.length > 0 && questions.every((q) => q.marks !== null)) {
    return questions.reduce((sum, q) => sum + (q.marks ?? 0), 0)
  }
  return null
}

/**
 * Renders a paper (question paper, answer key, or detailed solutions) as a
 * fully self-contained, print-ready HTML document. Used both for the
 * in-browser "Print / Save as PDF" flow and as the input to the
 * server-side Puppeteer PDF export (see /api/papers/[id]/export/pdf) — same
 * markup, same visual result, either path.
 *
 * Letterhead design: this reproduces the structural design of a real
 * S-CUBUS exam-paper PDF the user supplied as an InDesign stand-in (branded
 * cover page, repeating mauve/maroon header & footer bands, faint logo
 * watermark, ruled two-column body) — see the design notes on
 * renderCoverPage()/renderPageBands() below for exactly what was measured
 * from that reference vs. what had to be approximated (no vector logo or
 * exact font file was available, only the rendered PDF).
 *
 * Math/scientific notation: question/option/explanation text may contain
 * LaTeX delimited by $...$ or \(...\)/\[...\]; MathJax (loaded from CDN)
 * typesets it client-side after the page loads.
 */
export function renderPaperHtml(
  settings: PaperSettings,
  questions: SnapshotQuestion[],
  mode: PaperExportMode,
  layout: PaperLayoutSettings = DEFAULT_PAPER_LAYOUT_SETTINGS,
  // Cover Page Designer (add-on) — both optional and both purely additive:
  // every pre-existing caller that omits them renders EXACTLY as before
  // (coverDesign null → renderCoverPage(), separateFrontPage defaulting
  // true → identical showCover logic to the original `mode === 'question'`
  // check). `coverDesign.elements[].imagePath`/`background.referenceImagePath`
  // must already be resolved to real (signed) URLs by the caller — this
  // function does no I/O, matching how `settings.logoUrl` already works.
  coverDesign: CoverDesign | null = null,
  separateFrontPage: boolean = true
): string {
  const heading =
    mode === 'answerKey' ? 'Answer Key' : mode === 'solutions' ? 'Detailed Solutions' : 'Question Paper'

  const bodyContent =
    mode === 'answerKey' ? renderAnswerKey(questions) : renderQuestions(questions, mode === 'solutions', layout)

  // The answer key already lays out compactly as its own 4-column grid — a
  // multi-column wrapper around that grid fights it visually, so the
  // configured column count only ever applies to the question paper /
  // solutions body text.
  const useMultiColumn = layout.columns > 1 && mode !== 'answerKey'
  const pageSizeCss = `${layout.pageSize}${layout.orientation === 'LANDSCAPE' ? ' landscape' : ''}`
  const headerReserveMm = layout.showHeader ? HEADER_BAND_HEIGHT_MM + layout.marginTopMm : layout.marginTopMm
  const footerReserveMm = layout.showFooter ? FOOTER_BAND_HEIGHT_MM + layout.marginBottomMm : layout.marginBottomMm
  const imageAlign = layout.imageAlignment.toLowerCase()

  // Relative asset URLs (e.g. a logo at /branding/logo.png) only resolve
  // correctly when this HTML is loaded as a real page in the browser
  // (Print view). The server-side PDF export renders this same HTML via
  // Puppeteer's page.setContent(), which has NO base URL (about:blank) —
  // without an explicit <base>, any relative <img src> would silently fail
  // to load. Setting NEXT_PUBLIC_APP_URL as the base makes both paths work
  // identically. The bundled brand logo assets sidestep this entirely by
  // being inline base64 data URIs (see brandAssets.ts).
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL

  const instituteName = settings.instituteName || 'S-CUBUS'
  // Spec §21: page 1 = cover, page break, page 2 = questions — strictly
  // separate whenever a cover is shown at all. separateFrontPage defaults
  // true, so an existing caller (any question paper) keeps rendering a
  // cover exactly as before; it only becomes a real toggle once a caller
  // starts threading Paper.separateFrontPage through.
  const showCover = mode === 'question' && separateFrontPage !== false
  const hasDesignedCover = showCover && !!coverDesign && coverDesign.elements.length > 0

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${escapeHtml(settings.title)} — ${heading}</title>
${baseUrl ? `<base href="${escapeHtml(baseUrl)}/" />` : ''}
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script>
  window.MathJax = {
    tex: { inlineMath: [['$', '$'], ['\\\\(', '\\\\)']], displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']] },
    svg: { fontCache: 'global' },
  };
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" id="MathJax-script" async></script>
<style>
  /* Full-bleed page box — the header/footer bands below are drawn edge to
     edge (matching the reference PDF, where they run the full page width
     with no surrounding white margin) and everything else is inset via
     body padding instead of @page margin. This also has to match the
     margin option passed to Puppeteer's page.pdf() in paperPdf.ts exactly
     (both are 0), or the two render paths (server PDF vs. browser print)
     would disagree on where the printable area starts. */
  @page { size: ${pageSizeCss}; margin: 0; }
  * { box-sizing: border-box; }
  html, body { background: #fff; }
  body {
    font-family: '${escapeHtml(layout.fontFamily)}', 'Carlito', 'Segoe UI', Arial, sans-serif;
    color: #14161f;
    font-size: ${layout.fontSizePt}pt;
    line-height: ${layout.lineSpacing};
    margin: 0;
    padding: ${headerReserveMm}mm ${layout.marginRightMm}mm ${footerReserveMm}mm ${layout.marginLeftMm}mm;
    position: relative;
    /* Chromium's print pagination treats page 2+ as continuation
       fragments of this same <body> box. By default (box-decoration-break:
       slice) only the FIRST fragment gets the top padding and only the
       LAST fragment gets the bottom padding — so on every page after the
       first, the reserved header/footer space collapses to 0 and real
       content starts flush at the physical page edge, right under the
       position:fixed header band, clipping the first line(s) of text.
       box-decoration-break: clone re-applies the full padding to every
       page fragment, so the header/footer reservation is honored on
       every page, not just the first. */
    box-decoration-break: clone;
    -webkit-box-decoration-break: clone;
  }

  /* --- Repeating header/footer bands ---------------------------------
     position:fixed content repeats on every printed page in Chromium's
     print pipeline (verified against this exact renderer/Puppeteer combo)
     regardless of where in the DOM it sits, so these show on the cover
     page too — intentional: the reference PDF's footer band appears on
     its cover page as well, so this keeps a single consistent frame
     rather than special-casing page 1. */
  .page-band-header {
    position: fixed; top: 0; left: 0; right: 0; height: ${HEADER_BAND_HEIGHT_MM}mm;
    background: ${BRAND_MAUVE};
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 10mm;
  }
  .page-band-header .band-institute { display: flex; align-items: center; gap: 8px; font-size: 9.5pt; font-weight: 700; color: ${BRAND_MAROON}; }
  .page-band-header .band-institute img { height: 8mm; width: auto; }
  .page-band-header .band-title { font-size: 8.5pt; color: #4a2440; text-align: right; }
  .page-band-footer {
    position: fixed; bottom: 0; left: 0; right: 0; height: ${FOOTER_BAND_HEIGHT_MM}mm;
    background: ${BRAND_MAROON}; color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 8pt; text-align: center; padding: 0 10mm;
  }
  .page-watermark {
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    width: 55%; opacity: 0.05; z-index: -1; pointer-events: none;
  }

  /* --- Cover page (question papers only) ------------------------------ */
  .cover-page { page-break-after: always; padding: 4mm 2mm 2mm 2mm; }
  .cover-frame { border: 2.5pt solid ${BRAND_MAROON}; border-radius: 4mm; padding: 8mm 9mm 6mm 9mm; }
  .cover-top-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4mm; }
  .cover-pill { display: inline-block; background: ${BRAND_MAROON}; color: #fff; font-size: 9pt; font-weight: 700; padding: 2mm 5mm; border-radius: 2mm; }
  .cover-logo { text-align: center; margin: 2mm 0 4mm 0; }
  .cover-logo img { height: 30mm; width: auto; }
  .cover-title-banner { background: ${BRAND_MAROON}; color: #fff; border-radius: 3mm; text-align: center; padding: 6mm 4mm 5mm 4mm; }
  .cover-title { font-size: 22pt; font-weight: 800; letter-spacing: 0.03em; text-transform: uppercase; }
  .cover-subtitle { font-size: 13pt; font-weight: 600; margin-top: 1mm; }
  .cover-meta-bar { background: ${BRAND_MAUVE}; color: ${BRAND_MAROON}; font-weight: 700; font-size: 10pt; text-align: center; padding: 3mm; margin-top: 2.5mm; border-radius: 0 0 2mm 2mm; display: flex; justify-content: center; gap: 6mm; flex-wrap: wrap; }
  .cover-candidate-fields { margin-top: 6mm; font-size: 10.5pt; display: grid; grid-template-columns: 1fr 1fr; gap: 4mm 8mm; }
  .cover-candidate-fields .fill-line { display: inline-block; border-bottom: 1px solid #14161f; min-width: 55mm; margin-left: 2mm; }
  .cover-instructions { margin-top: 6mm; font-size: 9.5pt; }
  .cover-instructions-title { font-weight: 800; font-size: 11pt; margin-bottom: 2mm; }
  .cover-instructions ol { margin: 0; padding-left: 5mm; }
  .cover-instructions li { margin-bottom: 1mm; }
  .cover-subjects-table { width: 100%; border-collapse: collapse; margin-top: 6mm; font-size: 10pt; }
  .cover-subjects-table th, .cover-subjects-table td { border: 1px solid ${BRAND_MAROON}; padding: 2mm 3mm; text-align: center; }
  .cover-subjects-table th { background: ${BRAND_MAROON}; color: #fff; }
  .cover-subjects-table td:first-child, .cover-subjects-table th:first-child { text-align: left; background: ${BRAND_MAUVE}; color: ${BRAND_MAROON}; font-weight: 700; }

  /* --- Designed cover page (Cover Page Designer add-on) ----------------
     The designer's canvas is the FULL physical page (0,0 = true page
     top-left), matching what the user saw while designing it, so canvas
     mm coordinates map 1:1 here with no per-consumer conversion. The
     negative margins below cancel the body's own header/footer-reserving
     padding so the canvas reaches the true page edges. Because this markup
     is emitted after the fixed header/footer bands in the DOM, normal
     paint order lets a designed cover visually take over any area where it
     overlaps a band, rather than the band showing through underneath —
     the user's own cover design wins in the region they placed content,
     with no double/garbled text. */
  .cover-page.designed { padding: 0; }
  .cover-designed-canvas {
    position: relative;
    margin: -${headerReserveMm}mm -${layout.marginRightMm}mm -${footerReserveMm}mm -${layout.marginLeftMm}mm;
    overflow: hidden;
    background: #fff;
  }
  .cover-designed-reference { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; }
  .cover-el { position: absolute; overflow: hidden; }
  .cover-el-image { object-fit: contain; }
  .cover-el-text { white-space: pre-wrap; }
  .cover-el-table { white-space: pre-wrap; padding: 2mm; }

  /* --- Simple (non-cover) header, used for answer key / solutions modes */
  .paper-header { text-align: center; border-bottom: 2px solid ${BRAND_MAROON}; padding-bottom: 12px; margin-bottom: 18px; }
  .paper-header img.logo { max-height: 40px; margin-bottom: 8px; }
  .institute-name { font-size: 16pt; font-weight: 700; letter-spacing: 0.02em; color: ${BRAND_MAROON}; }
  .exam-name { font-size: 12pt; margin-top: 2px; font-weight: 600; }
  .meta-row { display: flex; justify-content: space-between; font-size: 10pt; margin-top: 8px; flex-wrap: wrap; gap: 6px 18px; }
  .heading-badge { display: inline-block; font-size: 10.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 6px; color: ${BRAND_MAROON}; }

  .instructions { font-size: 10pt; background: #f7f8fa; border: 1px solid #e2e5eb; border-radius: 6px; padding: 10px 14px; margin-bottom: 20px; white-space: pre-wrap; }
  .instructions-title { font-weight: 700; margin-bottom: 4px; }

  .paper-body.multi-column {
    column-count: ${layout.columns};
    column-gap: ${layout.columnGapMm}mm;
    column-rule: 0.75pt solid ${BRAND_MAROON};
  }
  .question { margin-bottom: ${layout.questionSpacingPx}px; page-break-inside: avoid; break-inside: avoid-column; }
  .question-number { font-weight: 700; margin-right: 6px; }
  .question-marks { font-weight: 600; margin-right: 6px; color: ${BRAND_MAROON}; }
  .question-text { display: inline; }
  .options { margin: 6px 0 0 22px; }
  .options .option { margin-bottom: 3px; }
  .option-letter { font-weight: 600; margin-right: 6px; }
  .option-image-wrap { display: block; margin: 4px 0 4px 20px; }
  .option-image { display: inline-block; max-width: min(${layout.maxImageWidthMm}mm, 45mm); max-height: 160px; }
  .question-image-wrap { text-align: ${imageAlign}; }
  .question-image { display: inline-block; max-width: ${layout.maxImageWidthMm}mm; max-height: 320px; margin: 8px 0; }
  .explanation { margin-top: 6px; margin-left: 22px; font-size: 10.5pt; color: #333a4d; font-style: italic; }
  .answer-space { border: 1px dashed #c7c9d4; border-radius: 4px; margin: 8px 0 0 0; page-break-inside: avoid; break-inside: avoid-column; }

  /* Section headings (Advanced Paper Builder) break out to full page width
     even inside a multi-column body — a genuine full-width band via
     column-span, not columns of manually-matched empty space, per the
     spec's "do not fake column positions" requirement. */
  .section-heading { column-span: all; margin: 10px 0 10px 0; break-after: avoid-column; }
  .section-heading:first-child { margin-top: 0; }
  .section-heading-title { font-weight: 700; font-size: 12.5pt; color: ${BRAND_MAROON}; text-transform: uppercase; letter-spacing: 0.03em; }
  .section-heading-rule { border: none; border-top: 1.5pt solid ${BRAND_MAROON}; margin: 3px 0 6px 0; }
  .section-heading-instructions { font-size: 9.5pt; color: #333a4d; font-style: italic; margin-bottom: 4px; white-space: pre-wrap; }
  .answer-key-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px 20px; }
  .answer-key-item { font-size: 12pt; }
  @media print {
    .no-print { display: none !important; }
  }
</style>
</head>
<body>
  <div class="page-watermark"><img src="${CUBUS_WATERMARK_LOGO_DATA_URI}" alt="" style="width:100%;" /></div>
  ${
    layout.showHeader
      ? `<div class="page-band-header">
    <span class="band-institute"><img src="${SCUBUS_LOGO_ICON_DATA_URI}" alt="" />${escapeHtml(instituteName)}${settings.subjectLabel ? ` — ${escapeHtml(settings.subjectLabel)}` : ''}</span>
    <span class="band-title">${escapeHtml(settings.title)} · Paper #${settings.paperNumber}</span>
  </div>`
      : ''
  }
  ${
    layout.showFooter
      ? `<div class="page-band-footer">
    ${escapeHtml(settings.footerText) || `${escapeHtml(instituteName)} — Paper #${settings.paperNumber} — ${escapeHtml(settings.title)}`}
  </div>`
      : ''
  }

  ${
    showCover
      ? hasDesignedCover
        ? renderDesignedCoverPage(coverDesign as CoverDesign, settings, layout)
        : renderCoverPage(settings, questions)
      : renderSimpleHeader(settings, instituteName, heading)
  }

  <div class="paper-body${useMultiColumn ? ' multi-column' : ''}">
    ${bodyContent}
  </div>

  <button class="no-print" onclick="window.print()" style="position:fixed;top:16px;right:16px;padding:10px 16px;background:${BRAND_MAROON};color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;">Print / Save as PDF</button>
</body>
</html>`
}

function renderSimpleHeader(settings: PaperSettings, instituteName: string, heading: string): string {
  return `<div class="paper-header">
    ${settings.logoUrl ? `<img class="logo" src="${escapeHtml(settings.logoUrl)}" alt="Institute logo" />` : ''}
    <div class="institute-name">${escapeHtml(instituteName)}</div>
    ${settings.examName ? `<div class="exam-name">${escapeHtml(settings.examName)}</div>` : ''}
    <div class="meta-row">
      <span>${settings.subjectLabel ? `Subject: ${escapeHtml(settings.subjectLabel)}` : ''}</span>
      <span>${settings.classLabel ? `Class/Exam: ${escapeHtml(settings.classLabel)}` : ''}</span>
      <span>${settings.examDate ? `Date: ${escapeHtml(settings.examDate)}` : ''}</span>
      <span>${settings.examTime ? `Time: ${escapeHtml(settings.examTime)}` : ''}</span>
      <span>${settings.maxMarks ? `Maximum Marks: ${settings.maxMarks}` : ''}</span>
    </div>
    <div class="heading-badge">${heading}</div>
  </div>`
}

/**
 * The branded cover page — structurally modeled on the reference PDF's
 * first page (bordered frame, date/paper-code pills, centered logo, a
 * maroon title banner, a mauve meta bar, blank candidate-detail fill-in
 * lines, a general-instructions block, and a subjects/marks table).
 *
 * What's faithful vs. approximated, for the record (see also the "InDesign
 * compatibility" section of the delivery report): the colors are sampled
 * directly from the reference PDF, and the logo is a real cropped asset
 * extracted from it (see brandAssets.ts) — but the reference uses a custom
 * display typeface this app has no license/file for, so the cover falls
 * back to the same Calibri family as the rest of the document rather than
 * approximating a different font. Every piece of data shown (question
 * count, subject breakdown, marks) is computed from the paper's actual
 * questions, never invented — a field is simply omitted when the
 * underlying data isn't there (e.g. no subjects table for a single-subject
 * paper, no marks line if marks aren't set on every question).
 */
function renderCoverPage(settings: PaperSettings, questions: SnapshotQuestion[]): string {
  const subjectBreakdown = buildSubjectBreakdown(questions)
  const maxMarks = resolveMaxMarks(settings, questions)

  const metaParts = [
    `Total Questions: ${questions.length}`,
    settings.classLabel ? `Class: ${escapeHtml(settings.classLabel)}` : null,
    maxMarks ? `Maximum Marks: ${maxMarks}` : null,
  ].filter(Boolean)

  const subjectsTable =
    subjectBreakdown.length > 1
      ? `<table class="cover-subjects-table">
          <tr><th>Subjects</th>${subjectBreakdown.map((s) => `<th>${escapeHtml(s.subject)}</th>`).join('')}</tr>
          <tr><td>Questions</td>${subjectBreakdown.map((s) => `<td>${s.count}</td>`).join('')}</tr>
        </table>`
      : ''

  const instructionsBlock = settings.instructions
    ? `<div class="cover-instructions">
        <div class="cover-instructions-title">General Instructions</div>
        <div>${textToHtml(settings.instructions)}</div>
      </div>`
    : ''

  return `<div class="cover-page">
    <div class="cover-frame">
      <div class="cover-top-row">
        <span class="cover-pill">${settings.examDate ? escapeHtml(settings.examDate) : `Paper #${settings.paperNumber}`}</span>
        <span class="cover-pill">${escapeHtml(settings.classLabel) || escapeHtml(settings.subjectLabel) || `#${settings.paperNumber}`}</span>
      </div>
      <div class="cover-logo"><img src="${SCUBUS_LOGO_FULL_DATA_URI}" alt="${escapeHtml(settings.instituteName || 'S-CUBUS')} logo" /></div>
      <div class="cover-title-banner">
        <div class="cover-title">${escapeHtml(settings.title)}</div>
        ${settings.subtitle ? `<div class="cover-subtitle">${escapeHtml(settings.subtitle)}</div>` : settings.examName ? `<div class="cover-subtitle">${escapeHtml(settings.examName)}</div>` : ''}
      </div>
      ${metaParts.length ? `<div class="cover-meta-bar">${metaParts.map((p) => `<span>${p}</span>`).join('')}</div>` : ''}
      <div class="cover-candidate-fields">
        <div>Name of Student: <span class="fill-line"></span></div>
        <div>Phone No.: <span class="fill-line"></span></div>
        <div>Candidate's Signature: <span class="fill-line"></span></div>
        <div>Roll No.: <span class="fill-line"></span></div>
      </div>
      ${instructionsBlock}
      ${subjectsTable}
    </div>
  </div>`
}

/**
 * The Cover Page Designer's rendering path (spec §26-27): renders a saved
 * CoverDesign as absolutely-positioned elements on a page-sized canvas, in
 * the SAME mm coordinate system the designer canvas uses — no scaling or
 * unit conversion between "what the user designed" and "what prints".
 * Used by both the PDF export and the browser Print view (both call
 * renderPaperHtml); the DOCX exporter instead screenshots the sibling
 * renderCoverOnlyHtml() output and embeds it as one flattened image (the
 * user's explicit choice — Word can't natively host freely-overlapping,
 * absolutely-positioned elements the way a page/PDF can).
 */
function renderDesignedCoverPage(design: CoverDesign, settings: PaperSettings, layout: PaperLayoutSettings): string {
  const { widthMm, heightMm } = getPageDimensionsMm(layout)
  const placeholderMap = buildCoverPlaceholderMap(settings, design)
  const bg = design.background
  const bgStyle = bg.color ? `background-color: ${escapeHtml(bg.color)};` : ''
  const referenceLayer =
    bg.mode === 'background' && bg.referenceImagePath
      ? `<img class="cover-designed-reference" src="${escapeHtml(bg.referenceImagePath)}" alt="" style="opacity:${(bg.referenceOpacity ?? 35) / 100};" />`
      : ''
  const elementsHtml = design.elements
    .filter((el) => !el.hidden)
    .slice()
    .sort((a, b) => a.zIndex - b.zIndex)
    .map((el) => renderCoverElement(el, placeholderMap))
    .join('\n')

  return `<div class="cover-page designed">
    <div class="cover-designed-canvas" style="width:${widthMm}mm;height:${heightMm}mm;${bgStyle}">
      ${referenceLayer}
      ${elementsHtml}
    </div>
  </div>`
}

// Standalone, minimal HTML (no MathJax, no header/footer bands, no print
// button) sized exactly to the physical page — the Puppeteer screenshot
// source for the DOCX flatten-to-image path (paperPdf.ts's
// renderHtmlToPngBuffer + paperDocx.ts's designed-cover branch). Shares
// renderCoverElement()/CSS class names with renderDesignedCoverPage() above
// so the two renderers can never visually drift apart.
export function renderCoverOnlyHtml(design: CoverDesign, settings: PaperSettings, layout: PaperLayoutSettings): string {
  const { widthMm, heightMm } = getPageDimensionsMm(layout)
  const placeholderMap = buildCoverPlaceholderMap(settings, design)
  const bg = design.background
  const bgStyle = bg.color ? `background-color: ${escapeHtml(bg.color)};` : 'background-color: #fff;'
  const referenceLayer =
    bg.mode === 'background' && bg.referenceImagePath
      ? `<img class="cover-designed-reference" src="${escapeHtml(bg.referenceImagePath)}" alt="" style="opacity:${(bg.referenceOpacity ?? 35) / 100};" />`
      : ''
  const elementsHtml = design.elements
    .filter((el) => !el.hidden)
    .slice()
    .sort((a, b) => a.zIndex - b.zIndex)
    .map((el) => renderCoverElement(el, placeholderMap))
    .join('\n')

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: #fff; }
  .cover-designed-canvas { position: relative; width: ${widthMm}mm; height: ${heightMm}mm; overflow: hidden; ${bgStyle} }
  .cover-designed-reference { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; }
  .cover-el { position: absolute; overflow: hidden; }
  .cover-el-image { object-fit: contain; }
  .cover-el-text { white-space: pre-wrap; }
  .cover-el-table { white-space: pre-wrap; padding: 2mm; }
</style>
</head>
<body>
  <div class="cover-designed-canvas">
    ${referenceLayer}
    ${elementsHtml}
  </div>
</body>
</html>`
}

function renderCoverElement(el: CoverElement, placeholderMap: Record<string, string>): string {
  const posStyle = `left:${el.x}mm; top:${el.y}mm; width:${el.width}mm; height:${el.height}mm; z-index:${el.zIndex};`

  if (el.type === 'logo' || el.type === 'image') {
    // An unfilled image/logo slot (e.g. created by "Use as Template" before
    // the user has uploaded the actual picture) renders nothing rather than
    // a broken-image icon.
    if (!el.imagePath) return ''
    return `<img class="cover-el cover-el-image" style="${posStyle} opacity:${(el.opacity ?? 100) / 100};" src="${escapeHtml(el.imagePath)}" alt="" />`
  }

  if (el.type === 'line') {
    const color = el.borderColor || el.color || '#14161f'
    return `<div class="cover-el cover-el-line" style="${posStyle} background:${escapeHtml(color)};"></div>`
  }

  if (el.type === 'rectangle' || el.type === 'divider') {
    const border = el.borderWidthPt ? `border: ${el.borderWidthPt}pt solid ${escapeHtml(el.borderColor || '#14161f')};` : ''
    const fill = el.backgroundColor ? `background-color: ${escapeHtml(el.backgroundColor)};` : ''
    return `<div class="cover-el cover-el-shape" style="${posStyle} ${border} ${fill}"></div>`
  }

  if (el.type === 'table') {
    // Simplified table element: one bordered text box, not a real
    // row/column grid — CoverElement has no cell-structure field
    // (documented limitation, see the feature's delivery report).
    const border = `border: ${el.borderWidthPt || 0.75}pt solid ${escapeHtml(el.borderColor || '#14161f')};`
    return `<div class="cover-el cover-el-table" style="${posStyle} ${border}">${textToHtml(resolveCoverElementText(el, placeholderMap))}</div>`
  }

  // text / heading / subheading / instructions / customField — all share
  // one rendering path; only their font/color/alignment fields (set at
  // creation time or by the user) differ.
  const text = resolveCoverElementText(el, placeholderMap)
  const fontStyle = [
    `font-family: '${escapeHtml(el.fontFamily)}', 'Carlito', Arial, sans-serif;`,
    `font-size: ${el.fontSizePt}pt;`,
    `font-weight: ${el.fontWeight === 'bold' ? 700 : 400};`,
    `font-style: ${el.fontStyle === 'italic' ? 'italic' : 'normal'};`,
    `text-align: ${el.alignment};`,
    `color: ${escapeHtml(el.color || '#14161f')};`,
    el.backgroundColor ? `background-color: ${escapeHtml(el.backgroundColor)};` : '',
    el.borderWidthPt ? `border: ${el.borderWidthPt}pt solid ${escapeHtml(el.borderColor || '#14161f')};` : '',
  ].join(' ')

  return `<div class="cover-el cover-el-text" style="${posStyle} ${fontStyle}">${textToHtml(text)}</div>`
}

// "1, 2, 3" / "Q1, Q2, Q3" / "1(a), 1(b), 1(c)" — applied consistently
// across the whole document (spec §20). LETTERED groups every question in
// a section under ONE outer number, lettering (a)/(b)/(c)... within it —
// the conventional exam-paper reading of that style, since this app's data
// model has no separate "sub-part" entity to letter otherwise. Restart-vs-
// continue (spec §20's per-section option) only affects PLAIN/Q_PREFIX: a
// RESTART section shows its own local 1..N instead of the paper-wide
// running count; it does not rewind the running count for later CONTINUE
// sections.
export function computeQuestionNumbers(questions: SnapshotQuestion[], style: PaperLayoutSettings['questionNumberingStyle']): string[] {
  const labels: string[] = []
  let globalCounter = 0
  let sectionCounter = 0
  let outerSectionNumber = 0
  let letterIndex = 0
  let lastSectionId: string | null | undefined = 'unset'

  for (const q of questions) {
    if (q.sectionId !== lastSectionId) {
      lastSectionId = q.sectionId
      sectionCounter = 0
      outerSectionNumber += 1
      letterIndex = 0
    }
    sectionCounter += 1
    globalCounter += 1

    if (style === 'LETTERED') {
      const letter = String.fromCharCode(97 + (letterIndex % 26))
      letterIndex += 1
      labels.push(`${outerSectionNumber}(${letter})`)
      continue
    }

    const n = q.sectionNumberingMode === 'RESTART' ? sectionCounter : globalCounter
    labels.push(style === 'Q_PREFIX' ? `Q${n}` : `${n}`)
  }
  return labels
}

export function formatMarksDisplay(marks: number | null, style: PaperLayoutSettings['marksDisplayStyle']): string {
  if (marks === null) return ''
  switch (style) {
    case 'PAREN_NUMBER':
      return `(${marks})`
    case 'BRACKET_NUMBER':
      return `[${marks}]`
    default:
      return `[${marks} Mark${marks === 1 ? '' : 's'}]`
  }
}

function renderSectionHeading(q: SnapshotQuestion): string {
  if (!q.sectionLabel) return ''
  return `<div class="section-heading">
    <div class="section-heading-title">Section ${escapeHtml(q.sectionLabel)}${q.sectionTitle ? `: ${escapeHtml(q.sectionTitle)}` : ''}</div>
    <hr class="section-heading-rule" />
    ${q.sectionInstructions ? `<div class="section-heading-instructions">${textToHtml(q.sectionInstructions)}</div>` : ''}
  </div>`
}

function renderAnswerSpace(q: SnapshotQuestion): string {
  if (q.questionType !== 'SUBJECTIVE' || !q.sectionAnswerSpace || q.sectionAnswerSpace === 'NONE') return ''
  const heightMm = q.sectionAnswerSpace === 'CUSTOM' ? (q.sectionCustomAnswerSpaceMm ?? 40) : ANSWER_SPACE_MM[q.sectionAnswerSpace]
  if (!heightMm) return ''
  return `<div class="answer-space" style="height: ${heightMm}mm;"></div>`
}

function renderQuestions(questions: SnapshotQuestion[], includeSolutions: boolean, layout: PaperLayoutSettings): string {
  const numbers = computeQuestionNumbers(questions, layout.questionNumberingStyle)

  return questions
    .map((q, idx) => {
      const optionImages = (letter: string) =>
        q.images
          .filter((img) => img.optionSlot === letter && img.url)
          .map(
            (img) =>
              `<div class="option-image-wrap"><img class="option-image" src="${escapeHtml(img.url)}" alt="${escapeHtml(img.altText || `Option ${letter} image`)}" /></div>`
          )
          .join('')

      const options = OPTION_LETTERS.map((letter) => {
        const key = `option${letter}` as 'optionA' | 'optionB' | 'optionC' | 'optionD'
        const value = q[key]
        const imgs = optionImages(letter)
        if (!value && !imgs) return ''
        return `<div class="option"><span class="option-letter">${letter}.</span>${value ? textToHtml(value) : ''}${imgs}</div>`
      }).join('')

      // General question images only — an image tagged to a specific
      // option (optionSlot A-D) renders inside that option above instead,
      // never duplicated in both places.
      const images = q.images
        .filter((img) => !img.optionSlot)
        .map((img) =>
          img.url
            ? `<div class="question-image-wrap"><img class="question-image" src="${escapeHtml(img.url)}" alt="${escapeHtml(img.altText || 'Question image')}" /></div>`
            : ''
        )
        .join('')

      const solution =
        includeSolutions && (q.correctAnswer || q.explanation)
          ? `<div class="explanation">${q.correctAnswer ? `<strong>Answer: ${escapeHtml(q.correctAnswer)}</strong><br/>` : ''}${textToHtml(q.explanation)}</div>`
          : ''

      const marksLabel = formatMarksDisplay(q.marks, layout.marksDisplayStyle)
      const sectionChanged = idx === 0 || q.sectionId !== questions[idx - 1]?.sectionId
      const sectionHeading = sectionChanged ? renderSectionHeading(q) : ''

      return `${sectionHeading}<div class="question">
        <span class="question-number">${escapeHtml(numbers[idx])}.</span>${marksLabel ? `<span class="question-marks">${escapeHtml(marksLabel)}</span>` : ''}<span class="question-text">${textToHtml(q.questionText)}</span>
        ${images}
        ${options ? `<div class="options">${options}</div>` : ''}
        ${renderAnswerSpace(q)}
        ${solution}
      </div>`
    })
    .join('\n')
}

function renderAnswerKey(questions: SnapshotQuestion[]): string {
  const items = questions
    .map(
      (q) =>
        `<div class="answer-key-item"><strong>${q.position}.</strong> ${escapeHtml(q.correctAnswer) || '<em>Not specified</em>'}</div>`
    )
    .join('\n')
  return `<div class="answer-key-grid">${items}</div>`
}
