import 'server-only'

export type PdfPageNumberOptions = {
  showPageNumbers: boolean
  // Whether the branded maroon footer band is present — when it is, the
  // page number is stamped in white inside that band (matching the
  // reference design); when it isn't, it's stamped in dark gray at the
  // plain page corner instead, since there's no colored band to sit on.
  showFooter: boolean
  pageWidthMm: number
  pageHeightMm: number
}

// Shared Chromium launch — factored out of renderHtmlToPdfBuffer so the
// Cover Page Designer's DOCX-flatten screenshot path (renderHtmlToPngBuffer
// below) can reuse the exact same launch logic/env handling rather than
// duplicating it.
async function launchBrowser() {
  const puppeteer = await import('puppeteer-core')

  let executablePath: string | undefined = process.env.PUPPETEER_EXECUTABLE_PATH
  let args: string[] = []
  let headless: boolean | 'shell' = true

  if (!executablePath) {
    const chromium = (await import('@sparticuz/chromium')).default
    executablePath = await chromium.executablePath()
    args = chromium.args
    headless = chromium.headless as unknown as boolean
  }

  return puppeteer.launch({ args, executablePath, headless })
}

/**
 * Renders HTML to a PDF buffer using headless Chromium.
 *
 * - In production (deployed to Vercel or similar serverless hosts),
 *   `@sparticuz/chromium` provides a Lambda-compatible Chromium binary.
 * - In local development, set PUPPETEER_EXECUTABLE_PATH to a local Chrome/
 *   Chromium install (or `npm i puppeteer` as a dev convenience, which
 *   bundles one) — see README.md § PDF Export.
 *
 * If Chromium cannot be launched for any reason, this throws; the caller
 * (the export API route) turns that into a clear "PDF export failed, use
 * Print instead" message rather than a silent/blank download — every paper
 * can ALWAYS be exported via the browser's own Print → Save as PDF on the
 * /papers/:id/print page, so this server path is a convenience, not a
 * single point of failure.
 */
export async function renderHtmlToPdfBuffer(
  html: string,
  options: Partial<PdfPageNumberOptions> = {}
): Promise<Buffer> {
  const browser = await launchBrowser()

  let pdfBuffer: Buffer
  try {
    const page = await browser.newPage()
    await page.setContent(html, { waitUntil: 'networkidle0', timeout: 30_000 })

    // Give MathJax a chance to finish typesetting equations before printing.
    await page
      .evaluate(async () => {
        const w = window as unknown as { MathJax?: { startup?: { promise?: Promise<unknown> } } }
        if (w.MathJax?.startup?.promise) await w.MathJax.startup.promise
      })
      .catch(() => {
        // Non-fatal — the PDF still renders, just without typeset math.
      })

    // Zero margins here so Puppeteer doesn't inset the page box beyond
    // what paperHtml.ts's own `@page { margin: 0 }` already establishes —
    // the letterhead's header/footer bands are drawn full-bleed to the
    // physical page edge, and all real content insetting happens via CSS
    // padding on <body> instead. Keep this in sync with paperHtml.ts's
    // @page margin if that ever changes, or the server PDF and the
    // browser "Print / Save as PDF" path will disagree on page geometry.
    //
    // Page numbers are deliberately NOT done via Puppeteer's own
    // displayHeaderFooter/headerTemplate/footerTemplate mechanism — it was
    // tried and, in real testing against this project's actual Chromium
    // binary, the `pageNumber`/`totalPages` template fields consistently
    // rendered blank ("Page  of ") even though the header/footer area
    // itself displayed correctly. Rather than ship a toggle that silently
    // produces broken output, page numbers are stamped afterwards with
    // pdf-lib (see stampPageNumbers below), which reads the PDF's own real
    // page count directly and has no dependency on that Chromium feature.
    // preferCSSPageSize makes Puppeteer honor paperHtml.ts's own `@page {
    // size: ... }` rule (which already reflects PaperSettings.pageSize +
    // orientation) instead of hardcoding 'A4' regardless of what the paper
    // was actually configured for — without this, a paper set to
    // LETTER/LANDSCAPE would render correctly in the browser Print view
    // (CSS-driven) but silently export as plain A4 portrait via this
    // server path.
    const pdf = await page.pdf({
      preferCSSPageSize: true,
      printBackground: true,
      margin: { top: '0mm', bottom: '0mm', left: '0mm', right: '0mm' },
    })
    pdfBuffer = Buffer.from(pdf)
  } finally {
    await browser.close()
  }

  if (options.showPageNumbers) {
    pdfBuffer = await stampPageNumbers(pdfBuffer, {
      showPageNumbers: true,
      showFooter: options.showFooter ?? true,
      pageWidthMm: options.pageWidthMm ?? 210,
      pageHeightMm: options.pageHeightMm ?? 297,
    })
  }

  return pdfBuffer
}

// CSS absolute units always resolve at 96px/inch regardless of viewport
// size (the CSS spec's fixed 1in = 96px reference pixel) — so a page whose
// content is sized in `mm` (renderCoverOnlyHtml's canvas) needs a viewport
// of exactly this many CSS px to show with zero cropping/scrollbars.
const MM_TO_CSS_PX = 96 / 25.4

/**
 * Screenshots a standalone HTML document (renderCoverOnlyHtml's output) as
 * a PNG sized exactly to the given physical page dimensions — the DOCX
 * flatten-to-image path for the Cover Page Designer (spec: DOCX can't host
 * freely-positioned/overlapping elements, so the designed cover is embedded
 * as one full-bleed image there instead of rebuilt as Word paragraphs, per
 * explicit user choice). `scale` raises deviceScaleFactor for a sharper
 * embedded image (2 = effectively 192 DPI) without changing the page's
 * physical size.
 */
export async function renderHtmlToPngBuffer(
  html: string,
  dimensions: { widthMm: number; heightMm: number },
  options: { scale?: number } = {}
): Promise<Buffer> {
  const scale = options.scale ?? 2
  const browser = await launchBrowser()
  try {
    const page = await browser.newPage()
    const width = Math.ceil(dimensions.widthMm * MM_TO_CSS_PX)
    const height = Math.ceil(dimensions.heightMm * MM_TO_CSS_PX)
    await page.setViewport({ width, height, deviceScaleFactor: scale })
    await page.setContent(html, { waitUntil: 'networkidle0', timeout: 30_000 })
    const screenshot = await page.screenshot({ type: 'png', clip: { x: 0, y: 0, width, height } })
    return Buffer.from(screenshot)
  } finally {
    await browser.close()
  }
}

const MM_TO_PT = 72 / 25.4
// Matches paperHtml.ts's FOOTER_BAND_HEIGHT_MM — kept as a separate literal
// (not imported) because paperHtml.ts is a client-safe/browser-renderable
// module and this file is server-only; duplicating one constant here is
// simpler and safer than restructuring that boundary for it.
const FOOTER_BAND_HEIGHT_MM = 9

/**
 * Stamps real "Page N of M" text onto every page of an already-rendered
 * PDF, using pdf-lib to read the PDF's own actual page count directly
 * (not Chromium's flaky header/footer template fields — see the note in
 * renderHtmlToPdfBuffer above).
 */
async function stampPageNumbers(pdfBuffer: Buffer, options: PdfPageNumberOptions): Promise<Buffer> {
  const { PDFDocument, StandardFonts, rgb } = await import('pdf-lib')

  const doc = await PDFDocument.load(pdfBuffer)
  const font = await doc.embedFont(StandardFonts.Helvetica)
  const pages = doc.getPages()
  const total = pages.length
  const fontSize = 8

  pages.forEach((pdfPage, index) => {
    const text = `Page ${index + 1} of ${total}`
    const textWidth = font.widthOfTextAtSize(text, fontSize)
    const { width } = pdfPage.getSize()
    const x = width - MM_TO_PT * 10 - textWidth
    const y = options.showFooter
      ? (FOOTER_BAND_HEIGHT_MM * MM_TO_PT) / 2 - fontSize / 2.5 // vertically centered inside the maroon band
      : MM_TO_PT * 6 // no band present — sit in the plain bottom margin instead
    pdfPage.drawText(text, {
      x,
      y,
      size: fontSize,
      font,
      color: options.showFooter ? rgb(1, 1, 1) : rgb(0.42, 0.42, 0.46),
    })
  })

  return Buffer.from(await doc.save())
}
