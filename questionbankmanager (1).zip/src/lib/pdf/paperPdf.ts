import 'server-only'

export type PdfPageNumberOptions = {
  showPageNumbers: boolean
  // Whether the branded maroon footer band is present — when it is, the
  // page number is stamped in white inside that band (matching the
  // reference design); when it isn't, it's stamped in dark gray at the
  // plain page corner instead, since there's no colored band to sit on.
  showFooter: boolean
  pageWidthMm: number
  pageHeightMm: number
}

/**
 * Renders HTML to a PDF buffer using headless Chromium.
 *
 * - In production (deployed to Vercel or similar serverless hosts),
 *   `@sparticuz/chromium` provides a Lambda-compatible Chromium binary.
 * - In local development, set PUPPETEER_EXECUTABLE_PATH to a local Chrome/
 *   Chromium install (or `npm i puppeteer` as a dev convenience, which
 *   bundles one) — see README.md § PDF Export.
 *
 * If Chromium cannot be launched for any reason, this throws; the caller
 * (the export API route) turns that into a clear "PDF export failed, use
 * Print instead" message rather than a silent/blank download — every paper
 * can ALWAYS be exported via the browser's own Print → Save as PDF on the
 * /papers/:id/print page, so this server path is a convenience, not a
 * single point of failure.
 */
export async function renderHtmlToPdfBuffer(
  html: string,
  options: Partial<PdfPageNumberOptions> = {}
): Promise<Buffer> {
  const puppeteer = await import('puppeteer-core')

  let executablePath: string | undefined = process.env.PUPPETEER_EXECUTABLE_PATH
  let args: string[] = []
  let headless: boolean | 'shell' = true

  if (!executablePath) {
    const chromium = (await import('@sparticuz/chromium')).default
    executablePath = await chromium.executablePath()
    args = chromium.args
    headless = chromium.headless as unknown as boolean
  }

  const browser = await puppeteer.launch({ args, executablePath, headless })

  let pdfBuffer: Buffer
  try {
    const page = await browser.newPage()
    await page.setContent(html, { waitUntil: 'networkidle0', timeout: 30_000 })

    // Give MathJax a chance to finish typesetting equations before printing.
    await page
      .evaluate(async () => {
        const w = window as unknown as { MathJax?: { startup?: { promise?: Promise<unknown> } } }
        if (w.MathJax?.startup?.promise) await w.MathJax.startup.promise
      })
      .catch(() => {
        // Non-fatal — the PDF still renders, just without typeset math.
      })

    // Zero margins here so Puppeteer doesn't inset the page box beyond
    // what paperHtml.ts's own `@page { margin: 0 }` already establishes —
    // the letterhead's header/footer bands are drawn full-bleed to the
    // physical page edge, and all real content insetting happens via CSS
    // padding on <body> instead. Keep this in sync with paperHtml.ts's
    // @page margin if that ever changes, or the server PDF and the
    // browser "Print / Save as PDF" path will disagree on page geometry.
    //
    // Page numbers are deliberately NOT done via Puppeteer's own
    // displayHeaderFooter/headerTemplate/footerTemplate mechanism — it was
    // tried and, in real testing against this project's actual Chromium
    // binary, the `pageNumber`/`totalPages` template fields consistently
    // rendered blank ("Page  of ") even though the header/footer area
    // itself displayed correctly. Rather than ship a toggle that silently
    // produces broken output, page numbers are stamped afterwards with
    // pdf-lib (see stampPageNumbers below), which reads the PDF's own real
    // page count directly and has no dependency on that Chromium feature.
    // preferCSSPageSize makes Puppeteer honor paperHtml.ts's own `@page {
    // size: ... }` rule (which already reflects PaperSettings.pageSize +
    // orientation) instead of hardcoding 'A4' regardless of what the paper
    // was actually configured for — without this, a paper set to
    // LETTER/LANDSCAPE would render correctly in the browser Print view
    // (CSS-driven) but silently export as plain A4 portrait via this
    // server path.
    const pdf = await page.pdf({
      preferCSSPageSize: true,
      printBackground: true,
      margin: { top: '0mm', bottom: '0mm', left: '0mm', right: '0mm' },
    })
    pdfBuffer = Buffer.from(pdf)
  } finally {
    await browser.close()
  }

  if (options.showPageNumbers) {
    pdfBuffer = await stampPageNumbers(pdfBuffer, {
      showPageNumbers: true,
      showFooter: options.showFooter ?? true,
      pageWidthMm: options.pageWidthMm ?? 210,
      pageHeightMm: options.pageHeightMm ?? 297,
    })
  }

  return pdfBuffer
}

const MM_TO_PT = 72 / 25.4
// Matches paperHtml.ts's FOOTER_BAND_HEIGHT_MM — kept as a separate literal
// (not imported) because paperHtml.ts is a client-safe/browser-renderable
// module and this file is server-only; duplicating one constant here is
// simpler and safer than restructuring that boundary for it.
const FOOTER_BAND_HEIGHT_MM = 9

/**
 * Stamps real "Page N of M" text onto every page of an already-rendered
 * PDF, using pdf-lib to read the PDF's own actual page count directly
 * (not Chromium's flaky header/footer template fields — see the note in
 * renderHtmlToPdfBuffer above).
 */
async function stampPageNumbers(pdfBuffer: Buffer, options: PdfPageNumberOptions): Promise<Buffer> {
  const { PDFDocument, StandardFonts, rgb } = await import('pdf-lib')

  const doc = await PDFDocument.load(pdfBuffer)
  const font = await doc.embedFont(StandardFonts.Helvetica)
  const pages = doc.getPages()
  const total = pages.length
  const fontSize = 8

  pages.forEach((pdfPage, index) => {
    const text = `Page ${index + 1} of ${total}`
    const textWidth = font.widthOfTextAtSize(text, fontSize)
    const { width } = pdfPage.getSize()
    const x = width - MM_TO_PT * 10 - textWidth
    const y = options.showFooter
      ? (FOOTER_BAND_HEIGHT_MM * MM_TO_PT) / 2 - fontSize / 2.5 // vertically centered inside the maroon band
      : MM_TO_PT * 6 // no band present — sit in the plain bottom margin instead
    pdfPage.drawText(text, {
      x,
      y,
      size: fontSize,
      font,
      color: options.showFooter ? rgb(1, 1, 1) : rgb(0.42, 0.42, 0.46),
    })
  })

  return Buffer.from(await doc.save())
}
