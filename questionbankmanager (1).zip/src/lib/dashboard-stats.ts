import 'server-only'
import { prisma } from '@/lib/prisma'

// Dashboard/Reports "Questions by …" breakdowns cover every tag on a
// question, in the same order they're entered in Add Question: Subject,
// Class/Exam, Chapter, Topic, Code, Difficulty — plus Question Type, which
// isn't part of that numbered field order but is just as much a tag.
// Chapter/Topic are returned here fully sorted (by count, descending) since
// Reports wants the complete breakdown; the Dashboard's compact bar-list
// widgets slice to a top-N themselves (see dashboard/page.tsx) since those
// two can run to dozens of entries, unlike the small fixed lookup tables.
const QUESTION_TYPE_LABELS: Record<string, string> = { MCQ: 'MCQ', SUBJECTIVE: 'Subjective', INTEGER: 'Integer' }

function sortedCounts(counts: Map<string, number>): { label: string; count: number }[] {
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count }))
}

// One decimal place — 0 stays 0 rather than NaN when the denominator is 0.
function pct(part: number, whole: number): number {
  return whole > 0 ? Math.round((part / whole) * 1000) / 10 : 0
}

export async function getDashboardStats() {
  const [
    totalQuestions,
    activeQuestions,
    archivedQuestions,
    bySubjectRaw,
    byClassRaw,
    byDifficultyRaw,
    byCodeRaw,
    byQuestionTypeRaw,
    byChapterRaw,
    byTopicRaw,
    byDifficultyUsedRaw,
    recentQuestions,
    recentPapers,
    totalPapers,
    totalUsers,
    activeUsersNow,
  ] = await Promise.all([
    prisma.question.count(),
    prisma.question.count({ where: { status: 'ACTIVE' } }),
    prisma.question.count({ where: { status: 'ARCHIVED' } }),
    prisma.question.groupBy({ by: ['subjectId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['examClassId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['difficultyId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['codeId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['questionType'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['chapterId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['topicId'], where: { status: 'ACTIVE' }, _count: true }),
    // "Used" = tagged with this difficulty AND included in at least one
    // generated paper (any PaperQuestion row references it) — this is the
    // question-bank utilization figure, distinct from `byDifficulty` above
    // which is just how many questions exist at each difficulty.
    prisma.question.groupBy({
      by: ['difficultyId'],
      where: { status: 'ACTIVE', paperQuestions: { some: {} } },
      _count: true,
    }),
    prisma.question.findMany({
      where: { status: 'ACTIVE' },
      orderBy: { createdAt: 'desc' },
      take: 8,
      include: { subject: true, examClass: true, createdBy: { select: { id: true, fullName: true, email: true } } },
    }),
    prisma.paper.findMany({
      orderBy: { createdAt: 'desc' },
      take: 8,
      include: { createdBy: { select: { id: true, fullName: true, email: true } }, _count: { select: { questions: true } } },
    }),
    prisma.paper.count(),
    prisma.profile.count({ where: { isActive: true } }),
    prisma.presence.count({ where: { lastSeenAt: { gt: new Date(Date.now() - 5 * 60 * 1000) } } }),
  ])

  const [subjects, examClasses, codes, difficulties, chapters, topics] = await Promise.all([
    prisma.subject.findMany(),
    prisma.examClass.findMany(),
    prisma.code.findMany(),
    prisma.difficultyLevel.findMany(),
    prisma.chapter.findMany(),
    prisma.topic.findMany(),
  ])
  const subjectLabel = new Map(subjects.map((s) => [s.id, s.label]))
  const classLabel = new Map(examClasses.map((s) => [s.id, s.label]))
  const codeLabel = new Map(codes.map((s) => [s.id, s.label]))
  const difficultyLabel = new Map(difficulties.map((s) => [s.id, s.label]))
  const chapterLabel = new Map(chapters.map((c) => [c.id, c.label]))
  const topicLabel = new Map(topics.map((t) => [t.id, t.label]))

  const chapterCounts = new Map<string, number>()
  for (const r of byChapterRaw) {
    const label = r.chapterId ? chapterLabel.get(r.chapterId) ?? 'Unknown' : 'No Chapter'
    chapterCounts.set(label, (chapterCounts.get(label) ?? 0) + r._count)
  }
  const topicCounts = new Map<string, number>()
  for (const r of byTopicRaw) {
    const label = r.topicId ? topicLabel.get(r.topicId) ?? 'Unknown' : 'No Topic'
    topicCounts.set(label, (topicCounts.get(label) ?? 0) + r._count)
  }
  const byChapter = sortedCounts(chapterCounts)
  const byTopic = sortedCounts(topicCounts)

  // Detailed per-difficulty breakdown: how much of the bank sits at each
  // difficulty, and how much of THAT has actually been pulled into a
  // generated paper at least once. Iterates the full lookup table (not just
  // `byDifficultyRaw`'s rows) so a difficulty with zero questions still
  // shows up as 0 / 0% instead of silently disappearing.
  const countByDifficulty = new Map(byDifficultyRaw.map((r) => [r.difficultyId, r._count]))
  const usedByDifficulty = new Map(byDifficultyUsedRaw.map((r) => [r.difficultyId, r._count]))
  const difficultyBreakdown = [...difficulties]
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((d) => {
      const count = countByDifficulty.get(d.id) ?? 0
      const usedCount = usedByDifficulty.get(d.id) ?? 0
      return {
        label: d.label,
        count,
        percentOfBank: pct(count, activeQuestions),
        usedCount,
        percentUsed: pct(usedCount, count),
      }
    })

  return {
    totalQuestions,
    activeQuestions,
    archivedQuestions,
    totalPapers,
    totalUsers,
    activeUsersNow,
    bySubject: bySubjectRaw.map((r) => ({ label: subjectLabel.get(r.subjectId) ?? 'Unknown', count: r._count })),
    byClass: byClassRaw.map((r) => ({ label: classLabel.get(r.examClassId) ?? 'Unknown', count: r._count })),
    byDifficulty: byDifficultyRaw.map((r) => ({ label: difficultyLabel.get(r.difficultyId) ?? 'Unknown', count: r._count })),
    difficultyBreakdown,
    byCode: byCodeRaw.map((r) => ({ label: codeLabel.get(r.codeId) ?? 'Unknown', count: r._count })),
    byQuestionType: byQuestionTypeRaw.map((r) => ({ label: QUESTION_TYPE_LABELS[r.questionType] ?? r.questionType, count: r._count })),
    // Fully sorted, uncapped — Reports uses these as-is; Dashboard slices
    // to a top-N (see dashboard/page.tsx).
    byChapter,
    byTopic,
    recentQuestions: recentQuestions.map((q) => ({
      id: q.id,
      questionNumber: q.questionNumber,
      subject: q.subject.label,
      examClass: q.examClass.label,
      createdBy: q.createdBy.fullName ?? q.createdBy.email,
      createdAt: q.createdAt.toISOString(),
    })),
    recentPapers: recentPapers.map((p) => ({
      id: p.id,
      paperNumber: p.paperNumber,
      title: p.title,
      questionCount: p._count.questions,
      createdBy: p.createdBy.fullName ?? p.createdBy.email,
      createdAt: p.createdAt.toISOString(),
    })),
  }
}

export type DashboardStats = Awaited<ReturnType<typeof getDashboardStats>>
