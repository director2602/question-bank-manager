import 'server-only'
import { prisma } from '@/lib/prisma'

export async function getDashboardStats() {
  const [
    totalQuestions,
    activeQuestions,
    archivedQuestions,
    bySubjectRaw,
    byClassRaw,
    byDifficultyRaw,
    byCodeRaw,
    recentQuestions,
    recentPapers,
    totalPapers,
    totalUsers,
    activeUsersNow,
  ] = await Promise.all([
    prisma.question.count(),
    prisma.question.count({ where: { status: 'ACTIVE' } }),
    prisma.question.count({ where: { status: 'ARCHIVED' } }),
    prisma.question.groupBy({ by: ['subjectId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['examClassId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['difficultyId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.groupBy({ by: ['codeId'], where: { status: 'ACTIVE' }, _count: true }),
    prisma.question.findMany({
      where: { status: 'ACTIVE' },
      orderBy: { createdAt: 'desc' },
      take: 8,
      include: { subject: true, examClass: true, createdBy: { select: { id: true, fullName: true, email: true } } },
    }),
    prisma.paper.findMany({
      orderBy: { createdAt: 'desc' },
      take: 8,
      include: { createdBy: { select: { id: true, fullName: true, email: true } }, _count: { select: { questions: true } } },
    }),
    prisma.paper.count(),
    prisma.profile.count({ where: { isActive: true } }),
    prisma.presence.count({ where: { lastSeenAt: { gt: new Date(Date.now() - 5 * 60 * 1000) } } }),
  ])

  const [subjects, examClasses, codes, difficulties] = await Promise.all([
    prisma.subject.findMany(),
    prisma.examClass.findMany(),
    prisma.code.findMany(),
    prisma.difficultyLevel.findMany(),
  ])
  const subjectLabel = new Map(subjects.map((s) => [s.id, s.label]))
  const classLabel = new Map(examClasses.map((s) => [s.id, s.label]))
  const codeLabel = new Map(codes.map((s) => [s.id, s.label]))
  const difficultyLabel = new Map(difficulties.map((s) => [s.id, s.label]))

  return {
    totalQuestions,
    activeQuestions,
    archivedQuestions,
    totalPapers,
    totalUsers,
    activeUsersNow,
    bySubject: bySubjectRaw.map((r) => ({ label: subjectLabel.get(r.subjectId) ?? 'Unknown', count: r._count })),
    byClass: byClassRaw.map((r) => ({ label: classLabel.get(r.examClassId) ?? 'Unknown', count: r._count })),
    byDifficulty: byDifficultyRaw.map((r) => ({ label: difficultyLabel.get(r.difficultyId) ?? 'Unknown', count: r._count })),
    byCode: byCodeRaw.map((r) => ({ label: codeLabel.get(r.codeId) ?? 'Unknown', count: r._count })),
    recentQuestions: recentQuestions.map((q) => ({
      id: q.id,
      questionNumber: q.questionNumber,
      subject: q.subject.label,
      examClass: q.examClass.label,
      createdBy: q.createdBy.fullName ?? q.createdBy.email,
      createdAt: q.createdAt.toISOString(),
    })),
    recentPapers: recentPapers.map((p) => ({
      id: p.id,
      paperNumber: p.paperNumber,
      title: p.title,
      questionCount: p._count.questions,
      createdBy: p.createdBy.fullName ?? p.createdBy.email,
      createdAt: p.createdAt.toISOString(),
    })),
  }
}

export type DashboardStats = Awaited<ReturnType<typeof getDashboardStats>>
