// Canonical seed values for the lookup tables. Used by prisma/seed.ts to
// populate `subjects`, `exam_classes`, `codes`, `difficulty_levels`, and
// `roles`, and by the UI as a typed reference. The DATABASE is the source of
// truth at runtime (so an admin can extend it later) — this file only seeds
// the initial, spec-required set and gives the frontend typed labels.

export const SUBJECTS = [
  { code: 'PHYSICS', label: 'Physics', sortOrder: 1 },
  { code: 'CHEMISTRY', label: 'Chemistry', sortOrder: 2 },
  { code: 'ZOOLOGY', label: 'Zoology', sortOrder: 3 },
  { code: 'BOTANY', label: 'Botany', sortOrder: 4 },
  { code: 'MATH', label: 'Math', sortOrder: 5 },
  { code: 'MAT', label: 'MAT', sortOrder: 6 },
] as const

export const EXAM_CLASSES = [
  { code: 'CLASS_7', label: '7', sortOrder: 1 },
  { code: 'CLASS_8', label: '8', sortOrder: 2 },
  { code: 'CLASS_9', label: '9', sortOrder: 3 },
  { code: 'CLASS_10_NEET', label: '10 NEET', sortOrder: 4 },
  { code: 'CLASS_10_JEE', label: '10 JEE', sortOrder: 5 },
  { code: 'CLASS_11_NEET', label: '11 NEET', sortOrder: 6 },
  { code: 'CLASS_11_JEE', label: '11 JEE', sortOrder: 7 },
] as const

export const CODES = [
  { code: 'A', label: 'Code A', sortOrder: 1 },
  { code: 'B', label: 'Code B', sortOrder: 2 },
  { code: 'C', label: 'Code C', sortOrder: 3 },
  { code: 'D', label: 'Code D', sortOrder: 4 },
] as const

export const DIFFICULTY_LEVELS = [
  { code: 'E', label: 'Easy', sortOrder: 1 },
  { code: 'M', label: 'Medium', sortOrder: 2 },
  { code: 'D', label: 'Difficult', sortOrder: 3 },
] as const

// This organization runs a simple 1-Owner-plus-Users model: exactly one
// account holds OWNER rights (full control — user management, system
// settings, audit logs, deletion), and every other account is a standard
// USER (add/upload questions, edit tags, generate and edit papers). VIEWER
// remains in the schema as an optional, stricter read-only tier an Owner
// can assign later, but it is not part of the default seed/signup flow.
export const ROLES = [
  {
    code: 'ADMIN' as const,
    label: 'Owner',
    description: 'Full control: manage users, questions, tags, papers, and system settings. Can delete questions and view audit logs.',
  },
  {
    code: 'EDITOR' as const,
    label: 'User',
    description: 'Standard access: add/upload questions, edit tags, generate and edit papers.',
  },
  {
    code: 'VIEWER' as const,
    label: 'Viewer (read-only)',
    description: 'Optional stricter tier: search and view questions, generate papers if permitted. Not used by default.',
  },
]

export const PAGE_SIZE_DEFAULT = 25
export const PAGE_SIZE_MAX = 100

// Max upload sizes/types enforced both client- and server-side.
export const MAX_IMAGE_SIZE_BYTES = 8 * 1024 * 1024 // 8 MB — preserves quality, still bounded
export const ALLOWED_IMAGE_MIME_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml']
export const MAX_BULK_IMPORT_ROWS = 2000
