export type ImageProcessResult = {
  buffer: Buffer
  mimeType: string
  width: number
  height: number
}

export interface ImageProcessingProvider {
  name: string
  process(input: Buffer): Promise<ImageProcessResult>
}
