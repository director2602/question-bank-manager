import sharp from 'sharp'
import type { ImageProcessingProvider, ImageProcessResult } from './types'

const TARGET_MIN_WIDTH = 1800 // upscale smaller photos so output is genuinely high-resolution

/**
 * Deterministic, classical image-processing cleanup for photographed
 * handwritten pages — no AI/generative step, so it can never invent or
 * "artistically reinterpret" content. Every operation is a well-understood
 * document-scanning technique:
 *
 *  1. auto-rotate      — apply the camera's EXIF orientation, then drop it
 *  2. flat-field/shading correction — divide the image by a heavily-smoothed
 *                        copy of itself (the "background", estimated by
 *                        shrinking the image drastically then growing it
 *                        back — see note below) to flatten uneven lighting
 *                        without amplifying grain the way adaptive local-
 *                        contrast (CLAHE) does. This is the standard
 *                        technique flatbed/phone document scanners use for
 *                        shading correction.
 *  3. median filter    — removes speckle/paper-grain/camera noise while
 *                        preserving edges (unlike a Gaussian blur, which
 *                        would soften the handwriting itself). Kept to a
 *                        3x3 window deliberately: a larger window (5x5+)
 *                        cleans noise more aggressively but was found to
 *                        erode thin strokes and wash out small handwritten
 *                        text, which the spec explicitly requires preserved.
 *  4. mild linear contrast — a modest, fixed gain/offset rather than a full
 *                        min-max auto-stretch (`normalize()`). Auto-stretch
 *                        was tried and rejected: because the flat-field step
 *                        already pins paper-white near 235, the remaining
 *                        tonal range is narrow, and stretching it to the
 *                        full 0-255 range hugely amplified tiny residual
 *                        pixel-level variance into visible mottled/checkered
 *                        background noise.
 *  5. sharpen           — crisps up thin pen/pencil strokes
 *  6. upscale           — Lanczos3 resampling up to a real working resolution
 *                        if the source photo was small; this is resolution
 *                        interpolation, not detail invention
 *
 * Geometry (line positions, arrow directions, label placement, diagram
 * shapes) is never touched — nothing here warps, crops, or redraws.
 */
export class LocalImageProcessor implements ImageProcessingProvider {
  name = 'local-sharp'

  async process(input: Buffer): Promise<ImageProcessResult> {
    const rotated = sharp(input).rotate() // consumes EXIF orientation, then strips it

    // Work in raw pixels so we can do a pixel-level flat-field division —
    // sharp/libvips doesn't expose a "divide" blend mode, so this step is
    // done by hand on raw buffers.
    const { data: raw, info } = await rotated.removeAlpha().toColourspace('srgb').raw().toBuffer({ resolveWithObject: true })
    const { width: w, height: h, channels: c } = info

    // Background estimate: shrink drastically then blow back up with smooth
    // interpolation. Downsampling this far acts as a very aggressive
    // low-pass filter — thin strokes and even a modestly-sized circle
    // collapse into a handful of pixels and blend into their surroundings —
    // so the estimate captures only the slow-varying shadow/lighting
    // gradient. A direct large-radius blur was tried first, but even a
    // 100px-sigma blur only partially attenuates thicker shapes, leaving a
    // visible bright "halo" around them once divided out; the shrink/regrow
    // approach does not have that failure mode.
    // NOTE: two `.resize()` calls chained on the same sharp pipeline do NOT
    // apply sequentially — the second overwrites the first's options, so
    // this must be two separate pipelines with the shrunk result actually
    // materialized in between, or the "background" ends up identical to the
    // full-resolution input (no smoothing at all).
    const bgTiny = Math.max(6, Math.round(Math.min(w, h) / 70))
    const bgSmall = await sharp(raw, { raw: { width: w, height: h, channels: c } })
      .resize({ width: bgTiny, height: bgTiny, fit: 'fill', kernel: 'cubic' })
      .raw()
      .toBuffer()
    const background = await sharp(bgSmall, { raw: { width: bgTiny, height: bgTiny, channels: c } })
      .resize({ width: w, height: h, fit: 'fill', kernel: 'cubic' })
      .raw()
      .toBuffer()

    // Flat-field correction: corrected = original / background, rescaled so
    // "paper white" lands near 235. This flattens shadows/uneven lighting
    // without touching local contrast (so it does not amplify grain noise
    // the way CLAHE does), which is why it runs before denoising.
    const corrected = Buffer.alloc(raw.length)
    for (let i = 0; i < raw.length; i++) {
      const bg = background[i] || 1
      const value = (raw[i] / bg) * 235
      corrected[i] = value < 0 ? 0 : value > 255 ? 255 : Math.round(value)
    }

    let pipeline = sharp(corrected, { raw: { width: w, height: h, channels: c } })
      .median(3)
      .linear(1.15, -20)
      .sharpen({ sigma: 0.6, m1: 0.2, m2: 0.8 })

    if (w > 0 && w < TARGET_MIN_WIDTH) {
      pipeline = pipeline.resize({ width: TARGET_MIN_WIDTH, kernel: 'lanczos3', fit: 'inside' })
    }

    const output = await pipeline.png({ compressionLevel: 8 }).toBuffer({ resolveWithObject: true })

    return {
      buffer: output.data,
      mimeType: 'image/png',
      width: output.info.width,
      height: output.info.height,
    }
  }
}
