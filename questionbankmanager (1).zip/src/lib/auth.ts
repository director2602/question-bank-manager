import 'server-only'
import { createClient } from '@/lib/supabase/server'
import { prisma } from '@/lib/prisma'
import type { RoleCode } from '@prisma/client'

export class AuthError extends Error {
  status: number
  constructor(message: string, status = 401) {
    super(message)
    this.status = status
  }
}

export type CurrentUser = {
  id: string
  email: string
  fullName: string | null
  role: RoleCode
  isActive: boolean
}

/**
 * Resolves the current authenticated user AND their application role from
 * `profiles`. Every API route that needs to authorize an action should call
 * this (or requireRole below) rather than trusting anything from the client
 * — client-sent role/permission fields must never be used to gate access.
 */
export async function getCurrentUser(): Promise<CurrentUser | null> {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const profile = await prisma.profile.findUnique({
    where: { id: user.id },
    include: { role: true },
  })

  if (!profile || !profile.isActive) return null

  return {
    id: profile.id,
    email: profile.email,
    fullName: profile.fullName,
    role: profile.role.code,
    isActive: profile.isActive,
  }
}

/**
 * Throws AuthError(401) if unauthenticated, or AuthError(403) if the user's
 * role is not in `allowed`. Always call this from within a try/catch (or let
 * it bubble to the route's top-level error handler) — never assume it
 * resolves successfully.
 */
export async function requireRole(allowed: RoleCode[]): Promise<CurrentUser> {
  const user = await getCurrentUser()
  if (!user) {
    throw new AuthError('You must be signed in to do that.', 401)
  }
  if (!allowed.includes(user.role)) {
    throw new AuthError('You do not have permission to perform this action.', 403)
  }
  return user
}

export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser()
  if (!user) {
    throw new AuthError('You must be signed in to do that.', 401)
  }
  return user
}

// Central role → permission matrix. Kept in one place so a permission is
// never checked inconsistently across routes.
export const PERMISSIONS = {
  QUESTION_CREATE: ['ADMIN', 'EDITOR'] as RoleCode[],
  QUESTION_EDIT_TAGS: ['ADMIN', 'EDITOR'] as RoleCode[],
  QUESTION_EDIT_CONTENT: ['ADMIN', 'EDITOR'] as RoleCode[],
  QUESTION_ARCHIVE: ['ADMIN', 'EDITOR'] as RoleCode[],
  QUESTION_DELETE: ['ADMIN'] as RoleCode[],
  QUESTION_BULK_IMPORT: ['ADMIN', 'EDITOR'] as RoleCode[],
  QUESTION_EXPORT: ['ADMIN'] as RoleCode[],
  PAPER_GENERATE: ['ADMIN', 'EDITOR', 'VIEWER'] as RoleCode[],
  PAPER_EDIT: ['ADMIN', 'EDITOR'] as RoleCode[],
  FOLDER_MANAGE: ['ADMIN', 'EDITOR'] as RoleCode[],
  IMAGE_PROCESS: ['ADMIN', 'EDITOR'] as RoleCode[],
  USER_MANAGE: ['ADMIN'] as RoleCode[],
  SETTINGS_MANAGE: ['ADMIN'] as RoleCode[],
  AUDIT_VIEW: ['ADMIN'] as RoleCode[],
} as const
