import { z } from 'zod'

const uuid = z.string().uuid()

// Chapter/Topic/Question Type/Exam Category are all OPTIONAL, additional
// narrowing on top of the original required Subject/Class/Code/Difficulty
// combination — omitting them behaves exactly as before (no change to any
// paper generated before this was added, since `generationFilters` is
// stored as opaque JSON and old rows simply have these keys absent).
export const paperFilterLineSchema = z.object({
  subjectId: uuid,
  examClassId: uuid,
  codeId: uuid,
  difficultyId: uuid,
  chapterId: uuid.optional().nullable(),
  topicId: uuid.optional().nullable(),
  questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']).optional().nullable(),
  examCategoryId: uuid.optional().nullable(),
  count: z.number().int().min(0).max(500),
})

export const availableCountQuerySchema = z.object({
  lines: z.array(
    z.object({
      subjectId: uuid,
      examClassId: uuid,
      codeId: uuid,
      difficultyId: uuid,
      chapterId: uuid.optional().nullable(),
      topicId: uuid.optional().nullable(),
      questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']).optional().nullable(),
      examCategoryId: uuid.optional().nullable(),
    })
  ),
  allowReuseOfPastQuestions: z.boolean().optional().default(false),
})

export const generatePaperSchema = z.object({
  title: z.string().trim().min(1).max(200),
  mode: z.enum(['RANDOM', 'MANUAL']),
  lines: z.array(paperFilterLineSchema).min(1, 'Select at least one subject/class/code/difficulty combination.'),
  allowReuseOfPastQuestions: z.boolean().optional().default(false),
  // Only used when mode === 'MANUAL': explicit question IDs the user picked,
  // still validated server-side against the same filter lines/counts.
  manualQuestionIds: z.array(uuid).optional(),

  instituteName: z.string().trim().max(200).optional(),
  // A relative site path (e.g. "/branding/logo.png") or an absolute URL —
  // both are valid, so this deliberately does NOT use z.string().url().
  logoUrl: z.string().trim().max(2000).optional(),
  examName: z.string().trim().max(200).optional(),
  subjectLabel: z.string().trim().max(100).optional(),
  classLabel: z.string().trim().max(100).optional(),
  examDate: z.string().datetime().optional(),
  examTime: z.string().trim().max(50).optional(),
  maxMarks: z.number().int().positive().optional(),
  instructions: z.string().trim().max(5000).optional(),
  headerText: z.string().trim().max(2000).optional(),
  footerText: z.string().trim().max(2000).optional(),
})

export const updatePaperSchema = z.object({
  rowVersion: z.number().int().positive(),
  title: z.string().trim().min(1).max(200).optional(),
  subtitle: z.string().trim().max(300).optional().nullable(),
  questionIds: z.array(uuid).min(1).max(500).optional(), // full ordered list, replaces paper_questions
  instituteName: z.string().trim().max(200).optional().nullable(),
  logoUrl: z.string().max(2000).optional().nullable(),
  examName: z.string().trim().max(200).optional().nullable(),
  subjectLabel: z.string().trim().max(100).optional().nullable(),
  classLabel: z.string().trim().max(100).optional().nullable(),
  examDate: z.string().datetime().optional().nullable(),
  examTime: z.string().trim().max(50).optional().nullable(),
  maxMarks: z.number().int().positive().optional().nullable(),
  instructions: z.string().trim().max(5000).optional().nullable(),
  headerText: z.string().trim().max(2000).optional().nullable(),
  footerText: z.string().trim().max(2000).optional().nullable(),
  status: z.enum(['DRAFT', 'FINAL']).optional(),
  createSnapshot: z.boolean().optional().default(false),
})

export const replaceQuestionSchema = z.object({
  rowVersion: z.number().int().positive(),
  paperQuestionId: uuid,
  newQuestionId: uuid,
})

// PATCH /api/papers/:id/questions/:paperQuestionId — paper-scoped content
// override for a single question. `rowVersion` is the PAPER's optimistic
// lock (the same counter PaperEditor already tracks for title/question-list
// saves), not the question's — an override never touches Question/
// QuestionVersion rowVersion at all.
//
// `clear: true` reverts every override on this row back to the live
// Question Bank content and ignores the other fields. Otherwise, each
// field that's present is written as this row's override for that field
// (an explicit `null` reverts just that one field to the bank value while
// leaving the others overridden) — `questionText`, when present, must be
// non-empty, same rule as editing content in the bank.
export const paperQuestionOverrideSchema = z.object({
  rowVersion: z.number().int().positive(),
  clear: z.boolean().optional().default(false),
  questionText: z.string().trim().min(1, 'Question text is required.').max(20000).optional(),
  optionA: z.string().trim().max(4000).optional().nullable(),
  optionB: z.string().trim().max(4000).optional().nullable(),
  optionC: z.string().trim().max(4000).optional().nullable(),
  optionD: z.string().trim().max(4000).optional().nullable(),
  correctAnswer: z.string().trim().max(500).optional().nullable(),
  explanation: z.string().trim().max(20000).optional().nullable(),
  markingScheme: z.string().trim().max(20000).optional().nullable(),
})

// PATCH /api/papers/:id/questions/:paperQuestionId/images — paper-scoped
// IMAGE overrides for a single question, mirroring the text override
// endpoint above (same rowVersion lock on the PAPER, never on the
// question). `imageId`/`overrideImageId` values always refer to a
// QuestionImage row uploaded via the existing POST /api/questions/images
// (the same upload endpoint the Question Bank forms use) — this schema
// only validates which action to apply to it:
//   - add:            attach a brand-new image, only visible in this paper.
//   - replace:        attach a new image standing in for one specific
//                      master image, only within this paper.
//   - removeOverride: delete a paper-scoped image (an 'add' or 'replace'
//                      result) — for a 'replace', the master image it stood
//                      in for reappears automatically.
//   - hideMaster:      hide one master image within this paper only.
//   - restoreMaster:   un-hide a previously hidden master image.
export const paperQuestionImageActionSchema = z.discriminatedUnion('action', [
  z.object({ rowVersion: z.number().int().positive(), action: z.literal('add'), imageId: uuid }),
  z.object({ rowVersion: z.number().int().positive(), action: z.literal('replace'), imageId: uuid, masterImageId: uuid }),
  z.object({ rowVersion: z.number().int().positive(), action: z.literal('removeOverride'), overrideImageId: uuid }),
  z.object({ rowVersion: z.number().int().positive(), action: z.literal('hideMaster'), masterImageId: uuid }),
  z.object({ rowVersion: z.number().int().positive(), action: z.literal('restoreMaster'), masterImageId: uuid }),
])
