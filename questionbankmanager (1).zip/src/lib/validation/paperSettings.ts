import { z } from 'zod'

// Mirrors prisma/schema.prisma's PaperSettings model exactly — one row per
// paper, created lazily (see /api/papers/[id]/settings) with the app
// defaults (2 columns / Calibri / 11pt) already encoded as the Prisma
// column @default()s, so this schema's .optional() fields simply mean
// "leave unchanged" on PATCH rather than re-declaring separate defaults
// that could drift from the DB.
export const paperSettingsSchema = z.object({
  pageSize: z.enum(['A4', 'LETTER', 'LEGAL']).optional(),
  orientation: z.enum(['PORTRAIT', 'LANDSCAPE']).optional(),

  marginTopMm: z.number().min(0).max(60).optional(),
  marginBottomMm: z.number().min(0).max(60).optional(),
  marginLeftMm: z.number().min(0).max(60).optional(),
  marginRightMm: z.number().min(0).max(60).optional(),

  columns: z.number().int().min(1).max(3).optional(),
  columnGapMm: z.number().min(0).max(30).optional(),
  showHeader: z.boolean().optional(),
  showFooter: z.boolean().optional(),
  showPageNumbers: z.boolean().optional(),

  fontFamily: z.string().trim().min(1).max(100).optional(),
  fontSizePt: z.number().min(7).max(24).optional(),
  lineSpacing: z.number().min(1).max(3).optional(),
  questionSpacingPx: z.number().min(0).max(60).optional(),

  imageQualityPercent: z.number().int().min(10).max(100).optional(),
  maxImageWidthMm: z.number().min(10).max(180).optional(),
  imageAlignment: z.enum(['LEFT', 'CENTER', 'RIGHT']).optional(),

  // Advanced Paper Builder additions.
  questionNumberingStyle: z.enum(['PLAIN', 'Q_PREFIX', 'LETTERED']).optional(),
  marksDisplayStyle: z.enum(['BRACKET_MARKS', 'PAREN_NUMBER', 'BRACKET_NUMBER']).optional(),
})

export type PaperSettingsInput = z.infer<typeof paperSettingsSchema>
