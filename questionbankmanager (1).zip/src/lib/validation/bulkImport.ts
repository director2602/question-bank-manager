import { z } from 'zod'

// Mirrors public/templates/question_import_template.csv columns exactly.
export const csvRowSchema = z.object({
  Question: z.string().trim().min(1, 'Question text is required.'),
  'Option A': z.string().trim().optional().default(''),
  'Option B': z.string().trim().optional().default(''),
  'Option C': z.string().trim().optional().default(''),
  'Option D': z.string().trim().optional().default(''),
  'Correct Answer': z.string().trim().optional().default(''),
  Subject: z.string().trim().min(1, 'Subject is required.'),
  Class: z.string().trim().min(1, 'Class is required.'),
  Code: z.string().trim().min(1, 'Code is required.'),
  'Question Number': z.string().trim().min(1, 'Question number is required.'),
  Difficulty: z.string().trim().min(1, 'Difficulty is required.'),
  Explanation: z.string().trim().optional().default(''),
})

export type CsvRow = z.infer<typeof csvRowSchema>

export const CSV_TEMPLATE_HEADERS = [
  'Question',
  'Option A',
  'Option B',
  'Option C',
  'Option D',
  'Correct Answer',
  'Subject',
  'Class',
  'Code',
  'Question Number',
  'Difficulty',
  'Explanation',
] as const

export const confirmImportSchema = z.object({
  // Row indexes (into the previously-validated preview) the user wants to
  // actually commit — lets them exclude rows flagged as likely duplicates.
  rowIndexes: z.array(z.number().int().min(0)).min(1),
  rows: z.array(
    z.object({
      rowIndex: z.number().int().min(0),
      questionText: z.string().min(1),
      optionA: z.string().optional().nullable(),
      optionB: z.string().optional().nullable(),
      optionC: z.string().optional().nullable(),
      optionD: z.string().optional().nullable(),
      correctAnswer: z.string().optional().nullable(),
      explanation: z.string().optional().nullable(),
      subjectId: z.string().uuid(),
      examClassId: z.string().uuid(),
      codeId: z.string().uuid(),
      difficultyId: z.string().uuid(),
      questionNumber: z.string().min(1),
      // Ids of QuestionImage rows already uploaded to storage (e.g. diagrams
      // pulled out of a PDF during AI-assisted import) that should be
      // attached to this question once it's created. Optional — plain
      // CSV/manual imports never send this.
      imageIds: z.array(z.string().uuid()).optional().default([]),
    })
  ),
})
