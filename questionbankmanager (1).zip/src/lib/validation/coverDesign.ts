import { z } from 'zod'

// ── Cover Page Designer — data model ────────────────────────────────────
//
// A CoverDesign is stored as JSON (on Paper.coverDesign and
// CoverTemplate.design) — the SAME normalized element-list shape in both
// places, so "Save as Cover Template" is a pure copy with no conversion,
// and "Use" a template is a pure copy back onto a paper. Positions/sizes
// are always in millimetres, matching the physical page — the same unit
// every other layout number in this app already uses (PaperSettings
// margins, image widths, etc.) — so the designer canvas, the PDF/print
// renderer, and the DOCX flattener all agree on one coordinate system with
// no per-consumer conversion math to keep in sync.
//
// This is deliberately a NEW, additive concept — it does not touch
// Paper.headingConfig (the existing, currently-unrendered rich heading
// config from the Advanced Paper Builder) or the flat instituteName/
// logoUrl/examName/... columns the original hardcoded cover still reads.
// A paper with no coverDesign renders EXACTLY as it always has.

export const COVER_ELEMENT_TYPES = [
  'text',
  'heading',
  'subheading',
  'logo',
  'image',
  'line',
  'rectangle',
  'divider',
  'instructions',
  'table',
  'customField',
] as const

export const COVER_FONT_FAMILIES = [
  'Calibri',
  'Arial',
  'Times New Roman',
  'Georgia',
  'Verdana',
  'Helvetica',
  'Courier New',
  'Trebuchet MS',
] as const

export const COVER_FONT_SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 60, 72] as const

// Every placeholder the designer can bind a text element to — resolved from
// the paper's real data at render/generation time (see
// src/lib/pdf/coverPlaceholders.ts). "custom" fields use their own key,
// namespaced separately so they can never collide with a built-in one.
export const COVER_PLACEHOLDER_KEYS = [
  'schoolName',
  'examName',
  'paperTitle',
  'subject',
  'class',
  'academicYear',
  'date',
  'time',
  'maximumMarks',
  'instructions',
] as const

const hexColor = z
  .string()
  .trim()
  .regex(/^#[0-9a-fA-F]{3,8}$/, 'Must be a hex color, e.g. #400c4d.')

export const coverElementSchema = z.object({
  id: z.string().min(1),
  type: z.enum(COVER_ELEMENT_TYPES),
  // Position/size in millimetres, relative to the top-left of the page.
  x: z.number(),
  y: z.number(),
  width: z.number().positive(),
  height: z.number().positive(),
  zIndex: z.number().int().default(0),
  locked: z.boolean().default(false),
  hidden: z.boolean().default(false),

  // Text-family fields (text/heading/subheading/instructions/customField).
  // `text` is the literal content when `placeholderKey` is null, or the
  // last-known preview text when a placeholder is bound (the real render
  // always re-resolves the placeholder from live paper data — `text` is
  // never trusted as the source of truth once a placeholder is set).
  text: z.string().optional().default(''),
  placeholderKey: z.enum(COVER_PLACEHOLDER_KEYS).nullish(),
  customFieldKey: z.string().nullish(),
  fontFamily: z.enum(COVER_FONT_FAMILIES).optional().default('Calibri'),
  fontSizePt: z.number().positive().optional().default(12),
  fontWeight: z.enum(['normal', 'bold']).optional().default('normal'),
  fontStyle: z.enum(['normal', 'italic']).optional().default('normal'),
  alignment: z.enum(['left', 'center', 'right']).optional().default('left'),
  color: hexColor.optional().default('#14161f'),

  // Box-family fields (rectangle/line/divider/image/logo).
  backgroundColor: hexColor.nullish(),
  borderColor: hexColor.nullish(),
  borderWidthPt: z.number().min(0).optional().default(0),

  // image/logo — a Supabase Storage path (never a signed URL: those expire,
  // see storage.ts), resolved to a fresh signed URL whenever the design is
  // loaded for editing or rendering.
  imagePath: z.string().nullish(),
  opacity: z.number().min(0).max(100).optional().default(100),

  // OCR/design-analysis provenance — set only on elements created via
  // "Use as Template" from a reference image, so the editor can show a
  // confidence badge and the user can spot-check before trusting it.
  // Never present on a manually-added element.
  ocrConfidence: z.enum(['HIGH', 'MEDIUM', 'LOW']).nullish(),
  needsReview: z.boolean().optional().default(false),
})
export type CoverElement = z.infer<typeof coverElementSchema>

export const coverCustomFieldSchema = z.object({
  key: z.string().min(1),
  label: z.string().min(1),
  value: z.string(),
})
export type CoverCustomField = z.infer<typeof coverCustomFieldSchema>

export const coverDesignSchema = z.object({
  pageSize: z.enum(['A4', 'LETTER', 'LEGAL']).default('A4'),
  orientation: z.enum(['PORTRAIT', 'LANDSCAPE']).default('PORTRAIT'),
  background: z
    .object({
      color: hexColor.nullish(),
      // "Use Reference as Background" — mode:'background' keeps the
      // uploaded reference image visible (at referenceOpacity) so the user
      // can trace/recreate it; mode:'none' means no reference is shown even
      // if referenceImagePath is still set (e.g. after the user unchecks
      // it, without losing the upload). Distinct from "Use as Template",
      // which converts the reference into real editable elements instead.
      mode: z.enum(['none', 'background']).default('none'),
      referenceImagePath: z.string().nullish(),
      referenceOpacity: z.number().min(0).max(100).default(35),
    })
    .default({ mode: 'none', referenceOpacity: 35 }),
  elements: z.array(coverElementSchema).default([]),
  settings: z
    .object({
      academicYear: z.string().nullish(),
      customFields: z.array(coverCustomFieldSchema).default([]),
      showGrid: z.boolean().default(false),
      snapToGrid: z.boolean().default(false),
      gridSizeMm: z.number().positive().default(5),
    })
    .default({ showGrid: false, snapToGrid: false, gridSizeMm: 5 }),
})
export type CoverDesign = z.infer<typeof coverDesignSchema>

export function emptyCoverDesign(pageSize: CoverDesign['pageSize'] = 'A4'): CoverDesign {
  return coverDesignSchema.parse({ pageSize })
}

// ── API payload schemas ──────────────────────────────────────────────────

export const saveCoverDesignSchema = z.object({
  coverDesign: coverDesignSchema,
  separateFrontPage: z.boolean().default(true),
  // Required, mirroring the main Paper PATCH route's optimistic-lock
  // pattern (src/app/api/papers/[id]/route.ts) — the cover design shares
  // the same Paper row/rowVersion, so a stale save here must be rejected
  // exactly the same way a stale question-list save is.
  rowVersion: z.number().int(),
})

export const createCoverTemplateSchema = z.object({
  name: z.string().trim().min(1, 'Template name is required.').max(120),
  design: coverDesignSchema,
})

export const updateCoverTemplateSchema = z.object({
  name: z.string().trim().min(1).max(120).optional(),
  design: coverDesignSchema.optional(),
})
