import { z } from 'zod'

const uuid = z.string().uuid()

// A "code" here is the short, unique-within-scope slug (e.g. "QE" for
// Quadratic Equations) — mirrors the existing Subject/ExamClass/Code/
// DifficultyLevel lookup pattern (code + label + sortOrder + isActive).
const codeField = z
  .string()
  .trim()
  .min(1, 'Code is required.')
  .max(30)
  .regex(/^[A-Za-z0-9_-]+$/, 'Code may only contain letters, numbers, hyphens, and underscores.')
const labelField = z.string().trim().min(1, 'Name is required.').max(150)

export const createChapterSchema = z.object({
  subjectId: uuid,
  code: codeField,
  label: labelField,
})

export const updateChapterSchema = z.object({
  code: codeField.optional(),
  label: labelField.optional(),
  isActive: z.boolean().optional(),
})

export const reorderChaptersSchema = z.object({
  subjectId: uuid,
  orderedIds: z.array(uuid).min(1),
})

export const createTopicSchema = z.object({
  chapterId: uuid,
  code: codeField,
  label: labelField,
})

export const updateTopicSchema = z.object({
  code: codeField.optional(),
  label: labelField.optional(),
  isActive: z.boolean().optional(),
})

export const reorderTopicsSchema = z.object({
  chapterId: uuid,
  orderedIds: z.array(uuid).min(1),
})
