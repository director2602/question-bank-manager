import { z } from 'zod'

// Folder names are a flat namespace (no nesting), so uniqueness is a simple
// global constraint — matches the unique index on paper_folders.name.
const folderName = z
  .string()
  .trim()
  .min(1, 'Folder name is required.')
  .max(80, 'Folder name is too long (80 characters max).')
  .regex(/^[^<>]*$/, 'Folder name cannot contain "<" or ">".')

export const createFolderSchema = z.object({
  name: folderName,
})

export const renameFolderSchema = z.object({
  name: folderName,
})

// folderId: null moves the paper back to "Uncategorized".
export const movePaperSchema = z.object({
  folderId: z.string().uuid().nullable(),
})
