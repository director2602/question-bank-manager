import { z } from 'zod'

const uuid = z.string().uuid()

// Question CONTENT — the fields that make up a question_versions row. This
// schema is intentionally the ONLY place question text/options/answer are
// validated, and it is never merged with the tag schema below, to keep the
// "content vs. tags" separation enforced in code as well as in the DB.
export const questionContentSchema = z.object({
  questionText: z.string().trim().min(1, 'Question text is required.').max(20000),
  optionA: z.string().trim().max(4000).optional().nullable(),
  optionB: z.string().trim().max(4000).optional().nullable(),
  optionC: z.string().trim().max(4000).optional().nullable(),
  optionD: z.string().trim().max(4000).optional().nullable(),
  // MCQ: the correct option letter. SUBJECTIVE: the "expected answer"
  // summary. INTEGER: the numeric answer itself (format enforced below,
  // cross-checked against questionType in createQuestionSchema/route
  // handlers since questionType lives on the TAGS schema, not this one).
  correctAnswer: z.string().trim().max(500).optional().nullable(),
  explanation: z.string().trim().max(20000).optional().nullable(),
  // SUBJECTIVE-only marking scheme/rubric — never shown on the student
  // paper (same rule as correctAnswer/explanation).
  markingScheme: z.string().trim().max(20000).optional().nullable(),
  changeNote: z.string().trim().max(500).optional().nullable(),
})

// An INTEGER-type answer must be a whole number (optionally negative) —
// "0", "5", "12", "-4" are valid; "2.5" is not. Shared by every place that
// validates an Integer question's answer (creation, content edit, and the
// Advanced Paper Builder's pre-generation check in paper-generation.ts).
export const INTEGER_ANSWER_PATTERN = /^-?\d+$/

export function validateAnswerForQuestionType(
  questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER',
  correctAnswer: string | null | undefined
): string | null {
  const answer = (correctAnswer ?? '').trim()
  if (questionType === 'INTEGER' && answer && !INTEGER_ANSWER_PATTERN.test(answer)) {
    return 'An Integer question’s answer must be a whole number (e.g. 0, 5, 12, -4) — decimals are not allowed.'
  }
  return null
}

// Question TAGS/metadata — independent of content. questionType/chapterId/
// topicId are the Advanced Paper Builder's tagging additions: questionType
// defaults to MCQ (matching the schema default, so every existing question
// stays correctly classified without requiring every caller to pass it),
// chapter/topic are optional (nullable) — tagging by them is never forced.
export const questionTagsSchema = z.object({
  questionNumber: z.string().trim().min(1, 'Question number is required.').max(50),
  subjectId: uuid,
  examClassId: uuid,
  codeId: uuid,
  difficultyId: uuid,
  questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']).optional().default('MCQ'),
  chapterId: uuid.optional().nullable(),
  topicId: uuid.optional().nullable(),
})

// Full create payload = tags + content + optional images already uploaded.
export const createQuestionSchema = questionTagsSchema
  .merge(questionContentSchema)
  .extend({
    imageIds: z.array(uuid).max(10).optional().default([]),
    confirmDespiteDuplicateWarning: z.boolean().optional().default(false),
  })
  .superRefine((data, ctx) => {
    const error = validateAnswerForQuestionType(data.questionType, data.correctAnswer)
    if (error) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['correctAnswer'], message: error })
  })

// Tag-only update. rowVersion is REQUIRED — this is the optimistic-lock
// token the client must send back so we can detect a concurrent edit.
export const updateQuestionTagsSchema = questionTagsSchema.extend({
  rowVersion: z.number().int().positive(),
})

// Content update — creates a new question_versions row. Also requires
// rowVersion for the same reason.
export const updateQuestionContentSchema = questionContentSchema.extend({
  rowVersion: z.number().int().positive(),
  imageIds: z.array(uuid).max(10).optional(),
})

export const bulkTagEditSchema = z.object({
  questionIds: z.array(uuid).min(1).max(500),
  subjectId: uuid.optional(),
  examClassId: uuid.optional(),
  codeId: uuid.optional(),
  difficultyId: uuid.optional(),
  questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']).optional(),
  chapterId: uuid.optional().nullable(),
  topicId: uuid.optional().nullable(),
})

// Bulk archive (soft delete) and bulk hard-delete both take a plain list of
// question ids — capped at 500 per request, same ceiling as bulk tag edit,
// to keep a single request's transaction bounded even for very large banks.
export const bulkQuestionIdsSchema = z.object({
  questionIds: z.array(uuid).min(1).max(500),
})

export const questionListQuerySchema = z.object({
  q: z.string().trim().max(300).optional(),
  subjectId: uuid.optional(),
  examClassId: uuid.optional(),
  codeId: uuid.optional(),
  difficultyId: uuid.optional(),
  questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']).optional(),
  chapterId: uuid.optional(),
  topicId: uuid.optional(),
  status: z.enum(['ACTIVE', 'ARCHIVED', 'ALL']).optional().default('ACTIVE'),
  questionNumber: z.string().trim().max(50).optional(),
  createdById: uuid.optional(),
  dateFrom: z.string().datetime().optional(),
  dateTo: z.string().datetime().optional(),
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(100).optional().default(25),
  sort: z.enum(['newest', 'oldest', 'questionNumber']).optional().default('newest'),
})

export type QuestionListQuery = z.infer<typeof questionListQuerySchema>
