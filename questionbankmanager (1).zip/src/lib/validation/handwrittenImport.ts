import { z } from 'zod'

const uuid = z.string().uuid()

export const confirmHandwrittenRowSchema = z.object({
  tempId: z.string(),
  questionNumber: z.string().trim().min(1, 'Question number is required.').max(50),
  subjectId: uuid,
  examClassId: uuid,
  chapterId: uuid.optional().nullable(),
  topicId: uuid.optional().nullable(),
  codeId: uuid,
  difficultyId: uuid,
  questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']),
  questionText: z.string().trim().min(1, 'Question text is required.').max(20000),
  optionA: z.string().trim().max(4000).optional().nullable(),
  optionB: z.string().trim().max(4000).optional().nullable(),
  optionC: z.string().trim().max(4000).optional().nullable(),
  optionD: z.string().trim().max(4000).optional().nullable(),
  correctAnswer: z.string().trim().max(500).optional().nullable(),
  explanation: z.string().trim().max(20000).optional().nullable(),
  markingScheme: z.string().trim().max(20000).optional().nullable(),
  // Diagram keys this row keeps, each with which version to save (the
  // generated SVG or the original crop) — "Never automatically overwrite
  // the original without retaining it" per Part 6: the original crop
  // stays in storage regardless of which the user picks here.
  diagramSelections: z
    .array(z.object({ key: z.string(), choice: z.enum(['generated', 'original']), editedSvg: z.string().max(200000).optional() }))
    .optional()
    .default([]),
})

export const confirmHandwrittenImportSchema = z.object({
  rows: z.array(confirmHandwrittenRowSchema).min(1).max(500),
})
