import { z } from 'zod'

const uuid = z.string().uuid()

// One row of per-type configuration within a section — e.g. "MCQ: 10
// questions, 1 mark each, Medium difficulty". A section can list more than
// one of these to mix question types within itself (spec §4). `count` is
// only a real *target* for AUTOMATIC sections; for MANUAL/HYBRID sections
// this is used purely to look up the per-question-type marks value for the
// questions the user picked (see selectSectionedQuestions in
// lib/paper-generation.ts and its caller in api/papers/sectioned).
export const sectionTypeConfigSchema = z.object({
  key: z.string().min(1),
  questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']),
  count: z.number().int().min(1).max(200),
  marksPerQuestion: z.number().positive().max(100),
  difficultyId: uuid.optional().nullable(),
})

export const paperSectionInputSchema = z
  .object({
    key: z.string().min(1),
    // Section Label (e.g. "A", "I") and Section Title (e.g. "Multiple
    // Choice Questions") are independently configurable — never forced to
    // "Section A/B/C".
    label: z.string().trim().min(1, 'Every section needs a label.').max(20),
    title: z.string().trim().min(1, 'Every section needs a title.').max(200),
    instructions: z.string().trim().max(2000).optional().nullable(),
    numberingMode: z.enum(['CONTINUE', 'RESTART']).optional().default('CONTINUE'),
    answerSpace: z.enum(['NONE', 'SMALL', 'MEDIUM', 'LARGE', 'CUSTOM']).optional().default('MEDIUM'),
    customAnswerSpaceMm: z.number().min(5).max(400).optional().nullable(),
    chapterScope: z.enum(['ALL', 'SELECTED']).optional().default('ALL'),
    chapterIds: z.array(uuid).max(100).optional().default([]),
    topicScope: z.enum(['ALL', 'SELECTED']).optional().default('ALL'),
    topicIds: z.array(uuid).max(200).optional().default([]),
    selectionMode: z.enum(['AUTOMATIC', 'MANUAL', 'HYBRID']),
    types: z.array(sectionTypeConfigSchema).max(10).optional().default([]),
    // The final, explicit, ORDERED question-id list for MANUAL/HYBRID
    // sections — "the final PDF/DOCX must follow exactly this order".
    manualQuestionIds: z.array(uuid).max(500).optional().default([]),
  })
  .refine((s) => (s.selectionMode === 'AUTOMATIC' ? s.types.length > 0 : true), {
    message: 'Automatic sections need at least one question type with a count.',
    path: ['types'],
  })
  .refine((s) => (s.selectionMode !== 'AUTOMATIC' ? s.manualQuestionIds.length > 0 : true), {
    message: 'Manual/Hybrid sections need at least one selected question.',
    path: ['manualQuestionIds'],
  })
  .refine((s) => (s.chapterScope === 'SELECTED' ? s.chapterIds.length > 0 : true), {
    message: 'Select at least one chapter, or switch back to "All Chapters".',
    path: ['chapterIds'],
  })
  .refine((s) => (s.topicScope === 'SELECTED' ? s.topicIds.length > 0 : true), {
    message: 'Select at least one topic, or switch back to "All Topics".',
    path: ['topicIds'],
  })

const paperHeadingFieldSchema = z.object({
  show: z.boolean(),
  customText: z.string().trim().max(300).optional().nullable(),
})

export const paperHeadingConfigSchema = z.object({
  title: z.string().trim().max(300).optional().nullable(),
  subtitle: z.string().trim().max(300).optional().nullable(),
  fields: z.object({
    schoolName: paperHeadingFieldSchema,
    examName: paperHeadingFieldSchema,
    subject: paperHeadingFieldSchema,
    class: paperHeadingFieldSchema,
    academicYear: paperHeadingFieldSchema,
    time: paperHeadingFieldSchema,
    maximumMarks: paperHeadingFieldSchema,
    rollNumber: paperHeadingFieldSchema,
    studentName: paperHeadingFieldSchema,
    date: paperHeadingFieldSchema,
  }),
  fontFamily: z.string().trim().max(80).optional().nullable(),
  fontSizePt: z.number().min(6).max(48).optional().nullable(),
  bold: z.boolean().optional().default(false),
  alignment: z.enum(['LEFT', 'CENTER', 'RIGHT']).optional().default('CENTER'),
  // A relative site path or absolute URL to an already-uploaded logo image
  // — never stretched: the renderer always sizes it by width only and lets
  // height follow the source image's own aspect ratio.
  logoUrl: z.string().trim().max(2000).optional().nullable(),
  logoWidthMm: z.number().min(5).max(120).optional().nullable(),
})

export const createSectionedPaperSchema = z.object({
  title: z.string().trim().min(1).max(200),
  subtitle: z.string().trim().max(300).optional().nullable(),

  // Chosen once, up front, per the spec's own ideal workflow ("Choose
  // Subject/Class" happens before "Choose Chapters/Add Sections") — every
  // section's chapter/topic scoping is constrained to this one subject.
  subjectId: uuid,
  examClassId: uuid,
  codeId: uuid,

  folderId: uuid.optional().nullable(),
  allowReuseOfPastQuestions: z.boolean().optional().default(false),

  instituteName: z.string().trim().max(200).optional(),
  logoUrl: z.string().trim().max(2000).optional(),
  examName: z.string().trim().max(200).optional(),
  examDate: z.string().datetime().optional(),
  examTime: z.string().trim().max(50).optional(),
  headerText: z.string().trim().max(2000).optional(),
  footerText: z.string().trim().max(2000).optional(),

  // General instructions — add/delete/reorder/edit-able list, shown below
  // the heading and before the first section. Stored joined by newlines
  // into Paper.instructions (the same column the flat generator already
  // uses), so no schema change was needed for this.
  instructions: z.array(z.string().trim().min(1).max(1000)).max(50).optional().default([]),

  headingConfig: paperHeadingConfigSchema.optional().nullable(),

  sections: z.array(paperSectionInputSchema).min(1, 'Add at least one section.').max(20),
})

export type CreateSectionedPaperInput = z.infer<typeof createSectionedPaperSchema>
export type PaperSectionInputParsed = z.infer<typeof paperSectionInputSchema>
