import { z } from 'zod'

// Owner-created accounts — mirrors (auth)/register/page.tsx's own rules
// (password >= 8 chars) so an Owner-created account and a self-registered
// account are held to the same bar.
export const createUserSchema = z.object({
  email: z.string().trim().email().max(320),
  fullName: z.string().trim().min(1, 'Full name is required.').max(200),
  password: z.string().min(8, 'Password must be at least 8 characters.').max(200),
  roleCode: z.enum(['ADMIN', 'EDITOR', 'VIEWER']).optional().default('EDITOR'),
})

export const updateUserRoleSchema = z.object({
  roleCode: z.enum(['ADMIN', 'EDITOR', 'VIEWER']),
})

export const updateUserStatusSchema = z.object({
  isActive: z.boolean(),
})
