'use client'

import type { ApiErrorBody } from '@/types'

export class ApiError extends Error {
  status: number
  body: ApiErrorBody
  constructor(status: number, body: ApiErrorBody) {
    super(body.error || 'Request failed')
    this.status = status
    this.body = body
  }
}

/**
 * Thin fetch wrapper used by every client component. Centralizes JSON
 * handling and turns a non-2xx response into a typed ApiError carrying the
 * server's human-readable message — so the UI never has to guess or show a
 * raw network/HTTP error to the user (business rule §21/§33).
 */
export async function apiFetch<T = unknown>(url: string, init?: RequestInit): Promise<T> {
  let res: Response
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        ...(init?.body && !(init.body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}),
        ...(init?.headers || {}),
      },
    })
  } catch (networkError) {
    throw new ApiError(0, {
      error: 'Could not reach the server. Check your connection and try again.',
    })
  }

  let body: unknown = null
  const text = await res.text()
  if (text) {
    try {
      body = JSON.parse(text)
    } catch {
      body = null
    }
  }

  if (!res.ok) {
    const errorBody = (body as ApiErrorBody) || { error: `Request failed (${res.status}).` }
    throw new ApiError(res.status, errorBody)
  }

  return body as T
}

/**
 * Fetches a binary file (PDF/DOCX/CSV export) and returns it as a Blob plus
 * the server-suggested filename, instead of navigating the browser to the
 * URL directly (a plain `<a href>` link). This is what makes a real loading
 * state ("Generating PDF…") and graceful failure messaging possible for
 * exports — a bare link gives the browser's own opaque
 * download/"can't reach page" handling with no hook for either, and can't
 * distinguish a binary success response from a JSON error body.
 */
export async function downloadFile(url: string): Promise<{ blob: Blob; filename: string }> {
  let res: Response
  try {
    res = await fetch(url)
  } catch {
    throw new ApiError(0, { error: 'Could not reach the server. Check your connection and try again.' })
  }

  if (!res.ok) {
    let body: ApiErrorBody = { error: `Export failed (${res.status}).` }
    try {
      const text = await res.text()
      if (text) body = JSON.parse(text)
    } catch {
      // Non-JSON error body — fall back to the generic message above.
    }
    throw new ApiError(res.status, body)
  }

  const disposition = res.headers.get('Content-Disposition') || ''
  const match = /filename="([^"]+)"/.exec(disposition)
  const filename = match?.[1] || 'download'

  return { blob: await res.blob(), filename }
}
