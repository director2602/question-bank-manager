import 'server-only'
import { createAdminClient } from '@/lib/supabase/admin'

const BUCKET = process.env.SUPABASE_STORAGE_BUCKET || 'question-bank-files'
const SIGNED_URL_TTL_SECONDS = 60 * 60 // 1 hour

/**
 * Question images are stored in a PRIVATE bucket (see supabase/sql/002) so
 * access can be restricted to authenticated users — we hand out short-lived
 * signed URLs rather than making the bucket public.
 */
export async function getSignedImageUrl(storagePath: string): Promise<string> {
  const supabase = createAdminClient()
  const { data, error } = await supabase.storage
    .from(BUCKET)
    .createSignedUrl(storagePath, SIGNED_URL_TTL_SECONDS)

  if (error || !data) {
    console.error('[storage] failed to sign URL for', storagePath, error)
    return ''
  }
  return data.signedUrl
}

export async function getSignedImageUrls(paths: string[]): Promise<Record<string, string>> {
  const entries = await Promise.all(
    paths.map(async (p) => [p, await getSignedImageUrl(p)] as const)
  )
  return Object.fromEntries(entries)
}

export { BUCKET as STORAGE_BUCKET }
