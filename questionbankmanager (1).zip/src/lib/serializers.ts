import 'server-only'
import type { Prisma } from '@prisma/client'
import { getSignedImageUrls } from '@/lib/storage'
import type { QuestionDetail, QuestionListItem, LookupOption } from '@/types'

const questionWithRelations = {
  subject: true,
  examClass: true,
  code: true,
  difficulty: true,
  chapter: true,
  topic: true,
  createdBy: { select: { id: true, fullName: true, email: true } },
  currentVersion: { include: { images: true } },
} satisfies Prisma.QuestionInclude

export type QuestionWithRelations = Prisma.QuestionGetPayload<{ include: typeof questionWithRelations }>
export { questionWithRelations }

function lookup(l: { id: string; code: string; label: string; sortOrder: number }): LookupOption {
  return { id: l.id, code: l.code, label: l.label, sortOrder: l.sortOrder }
}

export function toQuestionListItem(q: QuestionWithRelations): QuestionListItem {
  return {
    id: q.id,
    questionNumber: q.questionNumber,
    status: q.status,
    rowVersion: q.rowVersion,
    subject: lookup(q.subject),
    examClass: lookup(q.examClass),
    code: lookup(q.code),
    difficulty: lookup(q.difficulty),
    questionType: q.questionType,
    chapter: q.chapter ? lookup(q.chapter) : null,
    topic: q.topic ? lookup(q.topic) : null,
    questionText: q.currentVersion?.questionText ?? '',
    hasImages: (q.currentVersion?.images.length ?? 0) > 0,
    versionNumber: q.currentVersion?.versionNumber ?? 0,
    createdBy: q.createdBy,
    createdAt: q.createdAt.toISOString(),
    updatedAt: q.updatedAt.toISOString(),
  }
}

export async function toQuestionDetail(q: QuestionWithRelations): Promise<QuestionDetail> {
  const base = toQuestionListItem(q)
  const images = q.currentVersion?.images.sort((a, b) => a.sortOrder - b.sortOrder) ?? []
  const urls = await getSignedImageUrls(images.map((i) => i.storagePath))

  return {
    ...base,
    optionA: q.currentVersion?.optionA ?? null,
    optionB: q.currentVersion?.optionB ?? null,
    optionC: q.currentVersion?.optionC ?? null,
    optionD: q.currentVersion?.optionD ?? null,
    correctAnswer: q.currentVersion?.correctAnswer ?? null,
    explanation: q.currentVersion?.explanation ?? null,
    images: images.map((img) => ({
      id: img.id,
      storagePath: img.storagePath,
      fileName: img.fileName,
      sortOrder: img.sortOrder,
      url: urls[img.storagePath] ?? '',
    })),
  }
}
