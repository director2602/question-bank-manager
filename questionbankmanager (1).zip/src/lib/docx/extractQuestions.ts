// NOTE: deliberately NOT `import 'server-only'` here (same reasoning as
// src/lib/pdf/extractQuestions.ts) — that guard throws unconditionally
// outside Next.js's bundler (e.g. under Vitest), which would make
// extractDocxContent() impossible to unit test in isolation. Safety is
// preserved anyway: this module is only ever imported from
// src/app/api/questions/bulk-import/docx-preview/route.ts (a server route
// handler) and uses Node-only APIs (Buffer) that simply do not work in a
// browser bundle.

import JSZip from 'jszip'

export type DocxImage = {
  /** Index into the `lines` array of the paragraph this image appears in —
   * used by the caller to attach the image to the nearest extracted
   * question (see docx-preview/route.ts's assignLinesToBlocks). */
  paragraphIndex: number
  buffer: Buffer
  mimeType: string
  fileName: string
}

export type DocxExtractResult = {
  /** One entry per Word paragraph, in document order — the plain-text
   * content of that paragraph, with internal tabs/manual line-breaks
   * collapsed to spaces. Feeding `lines.join('\n')` into
   * `splitIntoQuestions` (see src/lib/pdf/extractQuestions.ts, which works
   * on arbitrary plain text) treats one paragraph as one line, which is
   * exactly how a typed exam Word document is normally laid out (each
   * question/option/answer on its own paragraph). */
  lines: string[]
  images: DocxImage[]
}

const ENTITY_MAP: Record<string, string> = {
  amp: '&',
  lt: '<',
  gt: '>',
  quot: '"',
  apos: "'",
}

function decodeXmlEntities(s: string): string {
  return s
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, code: string) => String.fromCharCode(parseInt(code, 16)))
    .replace(/&(amp|lt|gt|quot|apos);/g, (_, name: string) => ENTITY_MAP[name] ?? `&${name};`)
}

function paragraphText(paragraphXml: string): string {
  // A manual line/tab break WITHIN a paragraph collapses to a single space
  // — splitIntoQuestions works one full line per array entry, and a
  // mid-paragraph <w:br/> almost always just wraps a sentence rather than
  // starting a new question/option.
  const withBreaksCollapsed = paragraphXml.replace(/<w:(?:br|tab)\s*\/>/g, ' ')
  const texts: string[] = []
  const re = /<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(withBreaksCollapsed))) {
    texts.push(decodeXmlEntities(m[1]))
  }
  return texts
    .join('')
    .replace(/\s+/g, ' ')
    .trim()
}

function paragraphImageRIds(paragraphXml: string): string[] {
  const ids: string[] = []
  const re = /r:embed="(rId\d+)"/g
  let m: RegExpExecArray | null
  while ((m = re.exec(paragraphXml))) ids.push(m[1])
  return ids
}

const MIME_BY_EXT: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  bmp: 'image/bmp',
  webp: 'image/webp',
}

/**
 * Extracts plain text (one line per Word paragraph, in document order) plus
 * every embedded image (tagged with the paragraph it appears in) from a
 * .docx file's raw bytes.
 *
 * A .docx is just a ZIP archive of XML parts — this reads `word/document.xml`
 * (the body text) and `word/_rels/document.xml.rels` (which maps each
 * embedded image's relationship id to its `word/media/...` file) directly
 * via JSZip (already a project dependency, used elsewhere) rather than
 * pulling in a full XML parser or a new package like `mammoth`.
 */
export async function extractDocxContent(buffer: Buffer): Promise<DocxExtractResult> {
  const zip = await JSZip.loadAsync(buffer)

  const documentXmlFile = zip.file('word/document.xml')
  if (!documentXmlFile) {
    throw new Error('This does not look like a valid .docx file (word/document.xml was not found).')
  }
  const documentXml = await documentXmlFile.async('string')

  const relsFile = zip.file('word/_rels/document.xml.rels')
  const relsXml = relsFile ? await relsFile.async('string') : ''
  const targetByRId = new Map<string, string>()
  const relRe = /<Relationship\s+Id="(rId\d+)"[^>]*Target="([^"]+)"/g
  let relMatch: RegExpExecArray | null
  while ((relMatch = relRe.exec(relsXml))) {
    targetByRId.set(relMatch[1], relMatch[2])
  }

  // Paragraphs are the top-level "line" unit in a Word doc — split the body
  // into <w:p>...</w:p> blocks in document order (dotall via [\s\S] so a
  // paragraph's XML can itself span multiple raw lines in the file).
  const paragraphXmls = documentXml.match(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g) ?? []

  const lines: string[] = []
  const images: DocxImage[] = []

  for (let i = 0; i < paragraphXmls.length; i++) {
    const pXml = paragraphXmls[i]
    lines.push(paragraphText(pXml))

    for (const rId of paragraphImageRIds(pXml)) {
      const target = targetByRId.get(rId)
      if (!target) continue
      const mediaPath = target.startsWith('media/') ? `word/${target}` : `word/${target.replace(/^\/+/, '')}`
      const mediaFile = zip.file(mediaPath)
      if (!mediaFile) continue
      const ext = mediaPath.split('.').pop()?.toLowerCase() ?? 'png'
      const mimeType = MIME_BY_EXT[ext] ?? 'image/png'
      const imgBuffer = await mediaFile.async('nodebuffer')
      images.push({
        paragraphIndex: i,
        buffer: imgBuffer,
        mimeType,
        fileName: mediaPath.split('/').pop() ?? `image.${ext}`,
      })
    }
  }

  return { lines, images }
}
