import 'server-only'
import {
  AlignmentType,
  BorderStyle,
  Document,
  Footer,
  Header,
  ImageRun,
  PageNumber,
  Packer,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TabStopType,
  TextRun,
  WidthType,
  convertMillimetersToTwip,
} from 'docx'
import type { SnapshotQuestion } from '@/lib/paper-snapshot'
import {
  getPageDimensionsMm,
  computeQuestionNumbers,
  formatMarksDisplay,
  ANSWER_SPACE_MM,
  renderCoverOnlyHtml,
  type PaperExportMode,
  type PaperLayoutSettings,
  type PaperSettings as PaperContentSettings,
} from '@/lib/pdf/paperHtml'
import { renderHtmlToPngBuffer } from '@/lib/pdf/paperPdf'
import { SCUBUS_LOGO_FULL_DATA_URI, SCUBUS_LOGO_ICON_DATA_URI } from '@/lib/pdf/brandAssets'
import type { CoverDesign } from '@/lib/validation/coverDesign'

// Same brand palette as the PDF/print letterhead (see paperHtml.ts) — Word
// wants hex without a leading '#'.
const BRAND_MAROON = '400C4D'
const BRAND_MAUVE = 'D7BCD2'
const WHITE = 'FFFFFF'

function dataUriToBuffer(dataUri: string): Buffer {
  const base64 = dataUri.split(',')[1] ?? ''
  return Buffer.from(base64, 'base64')
}

const LOGO_ICON_BUFFER = dataUriToBuffer(SCUBUS_LOGO_ICON_DATA_URI)
const LOGO_FULL_BUFFER = dataUriToBuffer(SCUBUS_LOGO_FULL_DATA_URI)

// docx's ImageRun transformation width/height is in pixels at 96dpi.
function mmToPx(mm: number): number {
  return Math.max(1, Math.round((mm / 25.4) * 96))
}

function pt(fontSizePt: number): number {
  return Math.round(fontSizePt * 2) // docx sizes are in half-points
}

/**
 * Fetches a question image (a short-lived signed Supabase Storage URL) and
 * downsizes/re-encodes it with sharp to the paper's configured image
 * quality/max-width settings — unlike the PDF/print path (which only ever
 * constrains display size via CSS, since the browser renders the original
 * bytes), Word embeds the actual image bytes into the .docx package, so
 * this is the one export path where "image quality" in Paper Settings has
 * a real, direct effect on the output file. A failure here degrades
 * gracefully (the image is simply omitted, with a text placeholder) rather
 * than failing the whole export — one broken/expired signed URL shouldn't
 * block a teacher from getting their paper.
 */
async function fetchAndProcessImage(
  url: string,
  layout: PaperLayoutSettings
): Promise<{ buffer: Buffer; widthPx: number; heightPx: number } | null> {
  if (!url) return null
  try {
    const res = await fetch(url)
    if (!res.ok) return null
    const original = Buffer.from(await res.arrayBuffer())

    const sharp = (await import('sharp')).default
    const targetWidthPx = mmToPx(layout.maxImageWidthMm)
    const image = sharp(original).rotate()
    const meta = await image.metadata()
    const resized =
      meta.width && meta.width > targetWidthPx ? image.resize({ width: targetWidthPx }) : image

    const outBuffer = await resized.jpeg({ quality: layout.imageQualityPercent }).toBuffer()
    const outMeta = await sharp(outBuffer).metadata()
    return {
      buffer: outBuffer,
      widthPx: outMeta.width ?? targetWidthPx,
      heightPx: outMeta.height ?? targetWidthPx,
    }
  } catch (err) {
    console.error('[paperDocx] failed to fetch/process image', url, err)
    return null
  }
}

function alignmentForImage(layout: PaperLayoutSettings) {
  if (layout.imageAlignment === 'CENTER') return AlignmentType.CENTER
  if (layout.imageAlignment === 'RIGHT') return AlignmentType.RIGHT
  return AlignmentType.LEFT
}

function buildHeader(content: PaperContentSettings): Header {
  return new Header({
    children: [
      new Paragraph({
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: BRAND_MAROON, space: 4 } },
        children: [
          new ImageRun({ type: 'png', data: LOGO_ICON_BUFFER, transformation: { width: mmToPx(6), height: mmToPx(6) } }),
          new TextRun({
            text: `  ${content.instituteName || 'S-CUBUS'}${content.subjectLabel ? ` — ${content.subjectLabel}` : ''}`,
            bold: true,
            color: BRAND_MAROON,
            size: pt(9.5),
          }),
          new TextRun({
            text: `\t${content.title} · Paper #${content.paperNumber}`,
            color: '4A2440',
            size: pt(8.5),
          }),
        ],
        tabStops: [{ type: TabStopType.RIGHT, position: convertMillimetersToTwip(170) }],
      }),
    ],
  })
}

function buildFooter(content: PaperContentSettings, layout: PaperLayoutSettings): Footer {
  const footerText =
    content.footerText || `${content.instituteName || 'S-CUBUS'} — Paper #${content.paperNumber} — ${content.title}`
  return new Footer({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        shading: { type: ShadingType.CLEAR, fill: BRAND_MAROON },
        children: [
          new TextRun({ text: footerText, color: WHITE, size: pt(8) }),
          ...(layout.showPageNumbers
            ? [
                new TextRun({
                  text: '   —   ',
                  color: WHITE,
                  size: pt(8),
                }),
                new TextRun({
                  children: ['Page ', PageNumber.CURRENT, ' of ', PageNumber.TOTAL_PAGES],
                  color: WHITE,
                  size: pt(8),
                }),
              ]
            : []),
        ],
      }),
    ],
  })
}

function buildCoverParagraphs(
  content: PaperContentSettings,
  questions: SnapshotQuestion[],
  layout: PaperLayoutSettings
): Paragraph[] {
  const maxMarks =
    content.maxMarks ??
    (questions.length > 0 && questions.every((q) => q.marks !== null)
      ? questions.reduce((sum, q) => sum + (q.marks ?? 0), 0)
      : null)

  const paragraphs: Paragraph[] = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
      children: [new ImageRun({ type: 'png', data: LOGO_FULL_BUFFER, transformation: { width: mmToPx(45), height: mmToPx(20) } })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      shading: { type: ShadingType.CLEAR, fill: BRAND_MAROON },
      spacing: { before: 100, after: 0 },
      children: [new TextRun({ text: content.title, bold: true, color: WHITE, size: pt(22), allCaps: true })],
    }),
    ...(content.subtitle || content.examName
      ? [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            shading: { type: ShadingType.CLEAR, fill: BRAND_MAROON },
            spacing: { after: 200 },
            children: [new TextRun({ text: content.subtitle || content.examName || '', bold: true, color: WHITE, size: pt(13) })],
          }),
        ]
      : []),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      shading: { type: ShadingType.CLEAR, fill: BRAND_MAUVE },
      spacing: { after: 300 },
      children: [
        new TextRun({
          text: [
            `Total Questions: ${questions.length}`,
            content.classLabel ? `Class: ${content.classLabel}` : null,
            maxMarks ? `Maximum Marks: ${maxMarks}` : null,
            content.examDate ? `Date: ${content.examDate}` : null,
            content.examTime ? `Time: ${content.examTime}` : null,
          ]
            .filter(Boolean)
            .join('    |    '),
          bold: true,
          color: BRAND_MAROON,
          size: pt(10),
        }),
      ],
    }),
    new Paragraph({
      spacing: { after: 100 },
      children: [new TextRun({ text: 'Name of Student: ______________________________     Roll No.: ______________', size: pt(10.5) })],
    }),
    new Paragraph({
      spacing: { after: 300 },
      children: [new TextRun({ text: "Phone No.: ______________________________     Candidate's Signature: ______________", size: pt(10.5) })],
    }),
  ]

  if (content.instructions) {
    paragraphs.push(
      new Paragraph({
        spacing: { after: 100 },
        children: [new TextRun({ text: 'General Instructions', bold: true, size: pt(11), color: BRAND_MAROON })],
      })
    )
    for (const line of content.instructions.split('\n').filter((l) => l.trim())) {
      paragraphs.push(
        new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: `• ${line.trim()}`, size: pt(9.5) })] })
      )
    }
  }

  // The subject/count breakdown renders as a docx Table, which (unlike
  // HTML) can't be a child of a Paragraph — buildSubjectTable() builds it
  // separately and the caller (buildPaperDocxBuffer) splices it into the
  // section's children list between these paragraphs and the trailing
  // page break below.
  paragraphs.push(new Paragraph({ children: [], pageBreakBefore: true }))
  return paragraphs
}

function buildSubjectTable(questions: SnapshotQuestion[]): Table | null {
  const subjectCounts = new Map<string, number>()
  for (const q of questions) subjectCounts.set(q.subject, (subjectCounts.get(q.subject) ?? 0) + 1)
  const subjectBreakdown = Array.from(subjectCounts.entries())
  if (subjectBreakdown.length <= 1) return null

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { type: ShadingType.CLEAR, fill: BRAND_MAROON },
            children: [new Paragraph({ children: [new TextRun({ text: 'Subject', bold: true, color: WHITE, size: pt(10) })] })],
          }),
          ...subjectBreakdown.map(
            ([subject]) =>
              new TableCell({
                shading: { type: ShadingType.CLEAR, fill: BRAND_MAROON },
                children: [
                  new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: subject, bold: true, color: WHITE, size: pt(10) })] }),
                ],
              })
          ),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            shading: { type: ShadingType.CLEAR, fill: BRAND_MAUVE },
            children: [new Paragraph({ children: [new TextRun({ text: 'Questions', bold: true, color: BRAND_MAROON, size: pt(10) })] })],
          }),
          ...subjectBreakdown.map(
            ([, count]) =>
              new TableCell({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: String(count), size: pt(10) })] })] })
          ),
        ],
      }),
    ],
  })
}

async function buildQuestionParagraphs(
  questions: SnapshotQuestion[],
  includeSolutions: boolean,
  layout: PaperLayoutSettings
): Promise<(Paragraph | Table)[]> {
  const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const
  const out: (Paragraph | Table)[] = []
  const numbers = computeQuestionNumbers(questions, layout.questionNumberingStyle)

  for (let qIdx = 0; qIdx < questions.length; qIdx++) {
    const q = questions[qIdx]
    if (!q) continue
    const marksLabel = formatMarksDisplay(q.marks, layout.marksDisplayStyle)
    const sectionChanged = qIdx === 0 || q.sectionId !== questions[qIdx - 1]?.sectionId

    if (sectionChanged && q.sectionLabel) {
      out.push(
        new Paragraph({
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: BRAND_MAROON, space: 2 } },
          spacing: { before: qIdx === 0 ? 0 : 200, after: 100 },
          children: [
            new TextRun({
              text: `Section ${q.sectionLabel}${q.sectionTitle ? `: ${q.sectionTitle}` : ''}`,
              bold: true,
              allCaps: true,
              color: BRAND_MAROON,
              size: pt(12.5),
            }),
          ],
        })
      )
      if (q.sectionInstructions) {
        out.push(
          new Paragraph({
            spacing: { after: 100 },
            children: [new TextRun({ text: q.sectionInstructions, italics: true, size: pt(9.5) })],
          })
        )
      }
    }

    out.push(
      new Paragraph({
        spacing: { after: layout.questionSpacingPx * 0.75 },
        children: [
          new TextRun({ text: `${numbers[qIdx]}. `, bold: true, size: pt(layout.fontSizePt) }),
          ...(marksLabel ? [new TextRun({ text: `${marksLabel} `, bold: true, color: BRAND_MAROON, size: pt(layout.fontSizePt) })] : []),
          new TextRun({ text: q.questionText, size: pt(layout.fontSizePt) }),
        ],
      })
    )

    // General question images only — an image tagged to a specific option
    // (optionSlot A-D) renders under that option below instead, never
    // duplicated in both places.
    for (const img of q.images.filter((i) => !i.optionSlot)) {
      const processed = await fetchAndProcessImage(img.url, layout)
      if (processed) {
        const maxWidthPx = mmToPx(layout.maxImageWidthMm)
        const scale = processed.widthPx > maxWidthPx ? maxWidthPx / processed.widthPx : 1
        out.push(
          new Paragraph({
            alignment: alignmentForImage(layout),
            spacing: { after: 100 },
            children: [
              new ImageRun({
                type: 'jpg',
                data: processed.buffer,
                transformation: {
                  width: Math.round(processed.widthPx * scale),
                  height: Math.round(processed.heightPx * scale),
                },
              }),
            ],
          })
        )
      } else if (img.url) {
        out.push(
          new Paragraph({ children: [new TextRun({ text: '[Image could not be embedded — see PDF export]', italics: true, size: pt(9) })] })
        )
      }
    }

    for (const letter of OPTION_LETTERS) {
      const key = `option${letter}` as 'optionA' | 'optionB' | 'optionC' | 'optionD'
      const value = q[key]
      const optionImgs = q.images.filter((i) => i.optionSlot === letter)
      if (!value && optionImgs.length === 0) continue
      out.push(
        new Paragraph({
          indent: { left: convertMillimetersToTwip(6) },
          spacing: { after: 40 },
          children: [
            new TextRun({ text: `${letter}. `, bold: true, size: pt(layout.fontSizePt) }),
            ...(value ? [new TextRun({ text: value, size: pt(layout.fontSizePt) })] : []),
          ],
        })
      )
      for (const img of optionImgs) {
        const processed = await fetchAndProcessImage(img.url, layout)
        if (!processed) continue
        // Options are small illustrations, not full-width figures — cap at
        // ~45mm regardless of the paper's general max image width, same
        // cap used in the HTML/PDF renderer for consistency.
        const maxWidthPx = mmToPx(Math.min(layout.maxImageWidthMm, 45))
        const scale = processed.widthPx > maxWidthPx ? maxWidthPx / processed.widthPx : 1
        out.push(
          new Paragraph({
            indent: { left: convertMillimetersToTwip(10) },
            spacing: { after: 60 },
            children: [
              new ImageRun({
                type: 'jpg',
                data: processed.buffer,
                transformation: {
                  width: Math.round(processed.widthPx * scale),
                  height: Math.round(processed.heightPx * scale),
                },
              }),
            ],
          })
        )
      }
    }

    if (q.questionType === 'SUBJECTIVE' && q.sectionAnswerSpace && q.sectionAnswerSpace !== 'NONE') {
      const heightMm =
        q.sectionAnswerSpace === 'CUSTOM' ? (q.sectionCustomAnswerSpaceMm ?? 40) : ANSWER_SPACE_MM[q.sectionAnswerSpace]
      if (heightMm) {
        // docx has no literal "reserved blank box" primitive — an empty
        // paragraph with a large `spacing.after` (in twips, same unit
        // convertMillimetersToTwip already produces) reserves that much
        // vertical space in the normal document flow, so — exactly like
        // the PDF's block-level answer-space div — it can never overlap
        // the next question; Word simply flows the next paragraph below it.
        out.push(new Paragraph({ spacing: { after: convertMillimetersToTwip(heightMm) }, children: [] }))
      }
    }

    if (includeSolutions && (q.correctAnswer || q.explanation)) {
      out.push(
        new Paragraph({
          indent: { left: convertMillimetersToTwip(6) },
          spacing: { after: layout.questionSpacingPx * 0.75 },
          children: [
            ...(q.correctAnswer ? [new TextRun({ text: `Answer: ${q.correctAnswer}`, bold: true, italics: true, size: pt(10.5) })] : []),
            ...(q.correctAnswer && q.explanation ? [new TextRun({ text: '  ', size: pt(10.5) })] : []),
            ...(q.explanation ? [new TextRun({ text: q.explanation, italics: true, size: pt(10.5) })] : []),
          ],
        })
      )
    }
  }

  return out
}

function buildAnswerKeyTable(questions: SnapshotQuestion[]): Table {
  const rows: TableRow[] = []
  for (let i = 0; i < questions.length; i += 4) {
    const chunk = questions.slice(i, i + 4)
    rows.push(
      new TableRow({
        children: chunk.map(
          (q) =>
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({ text: `${q.position}. `, bold: true, size: pt(11) }),
                    new TextRun({ text: q.correctAnswer || 'Not specified', size: pt(11) }),
                  ],
                }),
              ],
            })
        ),
      })
    )
  }
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows })
}

// Renders the designed cover to a PNG sized exactly to the paper's page —
// shared screenshot helper for buildPaperDocxBuffer()'s flatten-to-image
// branch. Kept as its own function (rather than inlined) so the flattening
// step is easy to find/adjust independently of the rest of the docx
// assembly logic.
async function renderDesignedCoverPngBuffer(
  design: CoverDesign,
  content: PaperContentSettings,
  layout: PaperLayoutSettings
): Promise<Buffer> {
  const { widthMm, heightMm } = getPageDimensionsMm(layout)
  const html = renderCoverOnlyHtml(design, content, layout)
  return renderHtmlToPngBuffer(html, { widthMm, heightMm })
}

/**
 * Builds a Word (.docx) rendition of a paper matching the PDF/print
 * letterhead's brand look (maroon/mauve header & footer bands, logo,
 * cover page, subject breakdown) as closely as the .docx format allows.
 *
 * Known, deliberate gaps versus the PDF (not fabricated fidelity — Word's
 * layout model genuinely can't do these): LaTeX/MathJax math ($...$
 * delimited text) is embedded as literal text rather than a typeset
 * equation — Word has no client-side MathJax equivalent and converting to
 * OMML is out of scope; and "avoid breaking a question across columns" is
 * approximated by Word's own natural column balancing rather than the
 * PDF's per-question `break-inside: avoid`, since docx's column model
 * doesn't expose that control.
 */
export async function buildPaperDocxBuffer(
  content: PaperContentSettings,
  questions: SnapshotQuestion[],
  mode: PaperExportMode,
  layout: PaperLayoutSettings,
  // Cover Page Designer (add-on) — optional and purely additive, mirroring
  // renderPaperHtml()'s same two new params: an existing caller that omits
  // them gets the exact same output as before (hardcoded cover paragraphs).
  // coverDesign.elements[].imagePath/background.referenceImagePath must
  // already be resolved to real (signed) URLs by the caller.
  coverDesign: CoverDesign | null = null,
  separateFrontPage: boolean = true
): Promise<Buffer> {
  const heading = mode === 'answerKey' ? 'Answer Key' : mode === 'solutions' ? 'Detailed Solutions' : 'Question Paper'
  const showCover = mode === 'question' && separateFrontPage !== false
  const hasDesignedCover = showCover && !!coverDesign && coverDesign.elements.length > 0
  const useMultiColumn = layout.columns > 1 && mode !== 'answerKey'

  // getPageDimensionsMm already accounts for orientation (swaps width/
  // height for LANDSCAPE), so no separate landscape-swap logic is needed
  // here — unlike paperHtml.ts's CSS `@page` sizing, which handles
  // orientation via a plain `landscape` keyword instead.
  const { widthMm, heightMm } = getPageDimensionsMm(layout)

  const pageProperties = {
    size: {
      width: convertMillimetersToTwip(widthMm),
      height: convertMillimetersToTwip(heightMm),
    },
    margin: {
      top: convertMillimetersToTwip(layout.marginTopMm),
      bottom: convertMillimetersToTwip(layout.marginBottomMm),
      left: convertMillimetersToTwip(layout.marginLeftMm),
      right: convertMillimetersToTwip(layout.marginRightMm),
    },
  }

  const headers = layout.showHeader ? { default: buildHeader(content) } : undefined
  const footers = layout.showFooter ? { default: buildFooter(content, layout) } : undefined

  const bodyContent =
    mode === 'answerKey' ? [buildAnswerKeyTable(questions)] : await buildQuestionParagraphs(questions, mode === 'solutions', layout)

  const sections = []

  if (hasDesignedCover) {
    // DOCX flatten-to-image path (user's explicit choice — Word can't host
    // freely-positioned/overlapping elements the way the PDF/print canvas
    // can): screenshot the exact same element list the PDF/print cover
    // renders, via the shared renderCoverOnlyHtml(), and embed it as one
    // full-bleed image on its own zero-margin section. No header/footer
    // band on this page — the designed cover already is the entire page,
    // mirroring how it visually takes over the PDF/print cover too.
    const coverPng = await renderDesignedCoverPngBuffer(coverDesign as CoverDesign, content, layout)
    sections.push({
      properties: {
        page: {
          size: pageProperties.size,
          margin: { top: 0, bottom: 0, left: 0, right: 0 },
        },
      },
      children: [
        new Paragraph({
          spacing: { before: 0, after: 0 },
          children: [
            new ImageRun({
              type: 'png',
              data: coverPng,
              transformation: { width: mmToPx(widthMm), height: mmToPx(heightMm) },
            }),
          ],
        }),
      ],
    })
  } else if (showCover) {
    const coverParagraphs = buildCoverParagraphs(content, questions, layout)
    const subjectTable = buildSubjectTable(questions)
    let coverChildren: (Paragraph | Table)[] = coverParagraphs
    if (subjectTable) {
      // Insert the subject-breakdown table just before the trailing
      // page-break paragraph that buildCoverParagraphs() always ends with
      // (a Table can't be a Paragraph's own child in docx, so it has to be
      // spliced in at the section level instead).
      const trailingBreak = coverParagraphs[coverParagraphs.length - 1]
      coverChildren = trailingBreak
        ? [...coverParagraphs.slice(0, -1), subjectTable, trailingBreak]
        : [...coverParagraphs, subjectTable]
    }
    sections.push({
      properties: { page: pageProperties },
      headers,
      footers,
      children: coverChildren,
    })
  }

  sections.push({
    properties: {
      page: pageProperties,
      column: useMultiColumn ? { count: layout.columns, space: convertMillimetersToTwip(layout.columnGapMm) } : undefined,
    },
    headers,
    footers,
    children: [
      ...(showCover
        ? []
        : [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { after: 200 },
              children: [new TextRun({ text: heading, bold: true, size: pt(14), color: BRAND_MAROON })],
            }),
          ]),
      ...bodyContent,
    ],
  })

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: { font: layout.fontFamily, size: pt(layout.fontSizePt) },
        },
      },
    },
    sections,
  })

  return Packer.toBuffer(doc)
}
