// Reads a CSV file's raw bytes into a JS string, auto-detecting its
// encoding instead of blindly assuming UTF-8 (unlike `File.text()` /
// `Blob.text()`, which always decode as UTF-8 per spec — this is what the
// bulk-import preview route used to call directly).
//
// Exam-question CSVs very often started life in Microsoft Word/Excel on
// Windows (superscripts, multiplication signs, degree symbols, square
// roots, Greek letters pasted from an equation editor) and were saved in
// the legacy Windows-1252 codepage, not UTF-8. Decoding those bytes as
// UTF-8 corrupts every non-ASCII character into the U+FFFD replacement
// character ("�", rendered as "�") — which looks exactly like a
// broken equation to anyone opening the imported question, even though
// it has nothing to do with LaTeX/KaTeX parsing at all.
//
// Detection strategy: try a STRICT UTF-8 decode first (fatal: true). If
// the bytes aren't valid UTF-8, fall back to decoding as Windows-1252,
// which can represent any byte 0x00-0xFF and therefore never itself
// fails — it's by far the most common source encoding for this kind of
// file. (A file already in UTF-8 is left completely untouched; this only
// ever changes behavior for files that would otherwise come out
// corrupted.)

// WHATWG windows-1252 index for code points 0x80-0x9F (the only range
// where windows-1252 diverges from Latin-1/ISO-8859-1 — bytes 0x00-0x7F
// are plain ASCII and 0xA0-0xFF match Unicode U+00A0-U+00FF directly in
// both encodings). A handful of these byte values are undefined in the
// windows-1252 table; those fall back to mapping onto their own C1
// control code point, same as a browser's "windows-1252" TextDecoder.
const CP1252_0x80_0x9F = [
  0x20ac, 0x81, 0x201a, 0x192, 0x201e, 0x2026, 0x2020, 0x2021, 0x2c6, 0x2030, 0x160, 0x2039, 0x152, 0x8d, 0x17d, 0x8f,
  0x90, 0x2018, 0x2019, 0x201c, 0x201d, 0x2022, 0x2013, 0x2014, 0x2dc, 0x2122, 0x161, 0x203a, 0x153, 0x9d, 0x17e, 0x178,
]

function decodeWindows1252(bytes: Uint8Array): string {
  let out = ''
  for (const byte of bytes) {
    out += String.fromCharCode(byte >= 0x80 && byte <= 0x9f ? CP1252_0x80_0x9F[byte - 0x80] : byte)
  }
  return out
}

/**
 * Decodes an uploaded CSV file's raw bytes into text, trying UTF-8 first
 * (stripping a byte-order-mark if present, same as `File.text()`) and
 * falling back to Windows-1252 only when the bytes aren't valid UTF-8.
 */
export function decodeCsvBuffer(buffer: Buffer): string {
  let bytes: Uint8Array = buffer
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    bytes = bytes.subarray(3)
  }
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes)
  } catch {
    return decodeWindows1252(bytes)
  }
}
