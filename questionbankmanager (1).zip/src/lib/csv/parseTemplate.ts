import 'server-only'
import Papa from 'papaparse'
import { prisma } from '@/lib/prisma'
import { csvRowSchema, MAX_ROWS_MESSAGE } from './constants'
import { MAX_BULK_IMPORT_ROWS } from '@/lib/constants'
import { hashNormalizedText, normalizeQuestionText } from '@/lib/duplicate-detection'
import { validateAnswerForQuestionType } from '@/lib/validation/question'

export type PreviewRowError = { field: string; message: string }

export type PreviewRow = {
  rowIndex: number
  raw: Record<string, string>
  resolved: {
    questionText: string
    optionA: string | null
    optionB: string | null
    optionC: string | null
    optionD: string | null
    correctAnswer: string | null
    explanation: string | null
    subjectId: string | null
    subjectLabel: string | null
    examClassId: string | null
    examClassLabel: string | null
    codeId: string | null
    codeLabel: string | null
    difficultyId: string | null
    difficultyLabel: string | null
    questionNumber: string
    questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER'
    chapterId: string | null
    chapterLabel: string | null
    topicId: string | null
    topicLabel: string | null
    markingScheme: string | null
  }
  errors: PreviewRowError[]
  isDuplicateInFile: boolean
  isDuplicateInBank: boolean
  duplicateOfQuestionNumber?: string
}

export type PreviewResult = {
  totalRows: number
  validRows: number
  invalidRows: number
  duplicateRows: number
  rows: PreviewRow[]
}

/**
 * Parses + validates a CSV file for bulk import WITHOUT writing anything to
 * the database. The caller (preview API route) shows this to the user, who
 * then explicitly confirms which rows to commit.
 */
export async function parseAndValidateCsv(csvText: string): Promise<PreviewResult> {
  const parsed = Papa.parse<Record<string, string>>(csvText, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  })

  if (parsed.data.length > MAX_BULK_IMPORT_ROWS) {
    throw new Error(MAX_ROWS_MESSAGE)
  }

  const [subjects, examClasses, codes, difficulties, chapters, topics] = await Promise.all([
    prisma.subject.findMany({ where: { isActive: true } }),
    prisma.examClass.findMany({ where: { isActive: true } }),
    prisma.code.findMany({ where: { isActive: true } }),
    prisma.difficultyLevel.findMany({ where: { isActive: true } }),
    prisma.chapter.findMany({ where: { isActive: true } }),
    prisma.topic.findMany({ where: { isActive: true } }),
  ])

  const findLookup = <T extends { id: string; code: string; label: string }>(
    list: T[],
    value: string
  ): T | undefined => {
    const v = value.trim().toLowerCase()
    return list.find((l) => l.code.toLowerCase() === v || l.label.toLowerCase() === v)
  }

  // Pull existing normalized-text hashes once so we can flag exact-match
  // duplicates against the live bank without a query per row.
  const existing = await prisma.question.findMany({
    where: { status: 'ACTIVE' },
    select: { questionNumber: true, normalizedTextHash: true },
  })
  const existingHashes = new Map(existing.map((q) => [q.normalizedTextHash, q.questionNumber]))

  const seenInFile = new Set<string>()
  const rows: PreviewRow[] = []

  parsed.data.forEach((raw, idx) => {
    const errors: PreviewRowError[] = []
    const result = csvRowSchema.safeParse(raw)

    if (!result.success) {
      for (const issue of result.error.issues) {
        errors.push({ field: String(issue.path[0] ?? 'row'), message: issue.message })
      }
    }

    const questionText = (raw['Question'] ?? '').trim()
    const subject = findLookup(subjects, raw['Subject'] ?? '')
    const examClass = findLookup(examClasses, raw['Class'] ?? '')
    const code = findLookup(codes, raw['Code'] ?? '')
    const difficulty = findLookup(difficulties, raw['Difficulty'] ?? '')

    if (!subject) errors.push({ field: 'Subject', message: `Unknown subject "${raw['Subject']}".` })
    if (!examClass) errors.push({ field: 'Class', message: `Unknown class/exam "${raw['Class']}".` })
    if (!code) errors.push({ field: 'Code', message: `Unknown code "${raw['Code']}".` })
    if (!difficulty)
      errors.push({ field: 'Difficulty', message: `Unknown difficulty "${raw['Difficulty']}". Use E, M, or D.` })

    // Chapter/Topic — optional, same as the Add Question form, but if a
    // value IS given it must match a real chapter (scoped to the resolved
    // Subject) / topic (scoped to the resolved Chapter), so a typo is
    // caught here rather than silently importing an untagged question.
    const chapterCell = (raw['Chapter'] ?? '').trim()
    let chapter: (typeof chapters)[number] | undefined
    if (chapterCell) {
      if (subject) {
        chapter = chapters.find(
          (c) => c.subjectId === subject.id && (c.code.toLowerCase() === chapterCell.toLowerCase() || c.label.toLowerCase() === chapterCell.toLowerCase())
        )
        if (!chapter) errors.push({ field: 'Chapter', message: `Unknown chapter "${chapterCell}" for subject "${raw['Subject']}". Leave blank, fix the name, or add it first in Settings → Chapters & topics.` })
      } else {
        errors.push({ field: 'Chapter', message: `Chapter "${chapterCell}" given but Subject is invalid.` })
      }
    }

    const topicCell = (raw['Topic'] ?? '').trim()
    let topic: (typeof topics)[number] | undefined
    if (topicCell) {
      if (chapter) {
        topic = topics.find(
          (t) => t.chapterId === chapter!.id && (t.code.toLowerCase() === topicCell.toLowerCase() || t.label.toLowerCase() === topicCell.toLowerCase())
        )
        if (!topic) errors.push({ field: 'Topic', message: `Unknown topic "${topicCell}" for chapter "${chapterCell}". Leave blank, fix the name, or add it first in Settings → Chapters & topics.` })
      } else {
        errors.push({ field: 'Topic', message: `Topic "${topicCell}" given but no valid Chapter was resolved for this row.` })
      }
    }

    // Question Type — defaults to MCQ (same default as manual entry)
    // rather than erroring on a blank cell, since most existing CSVs
    // predate this column entirely.
    const typeCell = (raw['Question Type'] ?? '').trim().toUpperCase()
    let questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER' = 'MCQ'
    if (typeCell) {
      if (typeCell === 'MCQ' || typeCell === 'SUBJECTIVE' || typeCell === 'INTEGER') {
        questionType = typeCell
      } else {
        errors.push({ field: 'Question Type', message: `Unknown question type "${raw['Question Type']}". Use MCQ, SUBJECTIVE, or INTEGER.` })
      }
    }

    const correctAnswerCell = raw['Correct Answer']?.trim() || null
    const answerTypeError = validateAnswerForQuestionType(questionType, correctAnswerCell)
    if (answerTypeError) errors.push({ field: 'Correct Answer', message: answerTypeError })

    let isDuplicateInFile = false
    let isDuplicateInBank = false
    let duplicateOfQuestionNumber: string | undefined

    if (questionText) {
      const hash = hashNormalizedText(questionText)
      const normalized = normalizeQuestionText(questionText)
      if (seenInFile.has(normalized)) {
        isDuplicateInFile = true
      }
      seenInFile.add(normalized)

      if (existingHashes.has(hash)) {
        isDuplicateInBank = true
        duplicateOfQuestionNumber = existingHashes.get(hash)
      }
    }

    rows.push({
      rowIndex: idx,
      raw,
      resolved: {
        questionText,
        optionA: raw['Option A']?.trim() || null,
        optionB: raw['Option B']?.trim() || null,
        optionC: raw['Option C']?.trim() || null,
        optionD: raw['Option D']?.trim() || null,
        correctAnswer: correctAnswerCell,
        explanation: raw['Explanation']?.trim() || null,
        subjectId: subject?.id ?? null,
        subjectLabel: subject?.label ?? null,
        examClassId: examClass?.id ?? null,
        examClassLabel: examClass?.label ?? null,
        codeId: code?.id ?? null,
        codeLabel: code?.label ?? null,
        difficultyId: difficulty?.id ?? null,
        difficultyLabel: difficulty?.label ?? null,
        questionNumber: (raw['Question Number'] ?? '').trim(),
        questionType,
        chapterId: chapter?.id ?? null,
        chapterLabel: chapter?.label ?? null,
        topicId: topic?.id ?? null,
        topicLabel: topic?.label ?? null,
        markingScheme: raw['Marks']?.trim() || null,
      },
      errors,
      isDuplicateInFile,
      isDuplicateInBank,
      duplicateOfQuestionNumber,
    })
  })

  return {
    totalRows: rows.length,
    validRows: rows.filter((r) => r.errors.length === 0).length,
    invalidRows: rows.filter((r) => r.errors.length > 0).length,
    duplicateRows: rows.filter((r) => r.isDuplicateInBank || r.isDuplicateInFile).length,
    rows,
  }
}
