import { csvRowSchema } from '@/lib/validation/bulkImport'

export { csvRowSchema }
export const MAX_ROWS_MESSAGE =
  'This file has too many rows for a single import. Please split it into smaller batches (2000 rows max) and import each separately.'
