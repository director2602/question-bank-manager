import crypto from 'crypto'

/**
 * Normalizes question text for duplicate comparison purposes ONLY. This
 * value is never used as the stored/displayed question text — the verbatim
 * original is always preserved in question_versions.questionText.
 */
export function normalizeQuestionText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFKC')
    // Smart/curly quotes and apostrophes (common when text is pasted from
    // Word or a PDF) are treated the same as their straight equivalents so
    // "Newton's" and "Newton’s" normalize identically.
    .replace(/[‘’‚‛]/g, "'")
    .replace(/[“”„‟]/g, '"')
    .replace(/\s+/g, ' ')
    .replace(/[.,;:!?'"()\[\]{}]/g, '')
    .trim()
}

export function hashNormalizedText(text: string): string {
  return crypto.createHash('sha256').update(normalizeQuestionText(text)).digest('hex')
}

/**
 * Cheap similarity score (0–1) via token overlap (Jaccard on word sets).
 * Good enough to flag "probably the same question, different wording" for a
 * human to review — this never blocks or auto-merges, only warns.
 */
export function tokenOverlapSimilarity(a: string, b: string): number {
  const setA = new Set(normalizeQuestionText(a).split(' ').filter(Boolean))
  const setB = new Set(normalizeQuestionText(b).split(' ').filter(Boolean))
  if (setA.size === 0 || setB.size === 0) return 0
  let intersection = 0
  for (const tok of setA) if (setB.has(tok)) intersection++
  const union = setA.size + setB.size - intersection
  return union === 0 ? 0 : intersection / union
}

export const SIMILARITY_WARNING_THRESHOLD = 0.6
