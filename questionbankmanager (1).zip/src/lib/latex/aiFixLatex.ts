// AI-assisted LaTeX repair — a LAST RESORT for equations the deterministic
// repairs in autoFixLatex.ts can't fix (badly garbled OCR/paste artifacts,
// not just one of the handful of known mistakes those heuristics target).
//
// Requires ANTHROPIC_API_KEY, same as the PDF/handwritten AI import paths
// (src/lib/pdf/extractQuestionsAI.ts, src/lib/pdf/extractHandwrittenAI.ts) —
// when it isn't configured, callers simply skip this step and leave those
// equations flagged for manual review, same as before this existed.
//
// Every fix this returns is re-validated by the CALLER with KaTeX before
// being used (see autoFixExpr's `aiFixes` parameter) — this module never
// gets to unilaterally decide an expression is "fixed"; it only ever
// proposes a candidate.

import Anthropic from '@anthropic-ai/sdk'

const MODEL = 'claude-sonnet-5'
const MAX_OUTPUT_TOKENS = 8000
// Keep one request bounded regardless of how many broken equations a huge
// import turns up — comfortably enough for any realistic single file, and
// cheap/fast since each item is just a short math expression, not a whole
// question.
const MAX_EXPRESSIONS_PER_CALL = 200

const SYSTEM_PROMPT = `You repair broken LaTeX math expressions from an exam question bank CSV/Excel import. Each one failed to render and you're given the exact parser error.

Rules:
- Fix ONLY what's needed to make the expression render — preserve the author's intended meaning and notation style exactly. Never simplify, solve, or rewrite the math itself.
- Common causes: a missing closing brace, a stray/missing backslash, an unescaped special character (%, &, #, _), mismatched \\left \\right, a command that doesn't exist (likely a typo of a real one), or OCR noise (e.g. a letter where a symbol belongs).
- Return the expression WITHOUT the surrounding delimiters ($ or \\( \\) or $$) — just the inner LaTeX.
- If you cannot determine a safe fix with high confidence, return the ORIGINAL expression unchanged rather than guessing.
- Report a fix for every item you're given, in the same order, via the report_fixes tool.`

export type BrokenExpr = { expr: string; error: string }

/**
 * Attempts to fix a batch of distinct broken LaTeX expressions in ONE
 * request (cheap and fast — each item is a short math snippet, not a whole
 * question), and returns a map of original expression -> candidate fix.
 * Never throws on a partial/total failure to reach the AI — callers treat a
 * missing/empty result exactly like "no fix available" and move on, same as
 * every other AI-assisted import path in this codebase degrading to its
 * non-AI behavior.
 */
export async function fixBrokenLatexWithAI(items: BrokenExpr[]): Promise<Map<string, string>> {
  const result = new Map<string, string>()
  if (items.length === 0) return result

  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) return result

  const batch = items.slice(0, MAX_EXPRESSIONS_PER_CALL)

  try {
    const client = new Anthropic({ apiKey })

    const tool: Anthropic.Tool = {
      name: 'report_fixes',
      description: 'Report the corrected LaTeX for every broken expression given, in the same order.',
      input_schema: {
        type: 'object',
        properties: {
          fixes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                index: { type: 'integer', description: '0-based index matching the input list.' },
                fixedLatex: { type: 'string', description: 'The corrected LaTeX, without surrounding $ / \\( \\) / $$ delimiters.' },
              },
              required: ['index', 'fixedLatex'],
            },
          },
        },
        required: ['fixes'],
      },
    }

    const userContent = batch
      .map((item, idx) => `${idx}. Expression: ${item.expr}\n   Parser error: ${item.error}`)
      .join('\n\n')

    const response = await client.messages.create({
      model: MODEL,
      max_tokens: MAX_OUTPUT_TOKENS,
      system: SYSTEM_PROMPT,
      tools: [tool],
      tool_choice: { type: 'tool', name: 'report_fixes' },
      messages: [{ role: 'user', content: `Fix these ${batch.length} broken LaTeX expression(s):\n\n${userContent}` }],
    })

    for (const block of response.content) {
      if (block.type !== 'tool_use' || block.name !== 'report_fixes') continue
      const input = block.input as { fixes?: Array<{ index: number; fixedLatex: string }> }
      for (const fix of input.fixes ?? []) {
        const original = batch[fix.index]?.expr
        if (original && typeof fix.fixedLatex === 'string') {
          result.set(original, fix.fixedLatex)
        }
      }
    }
  } catch (err) {
    console.error('[aiFixLatex] AI repair call failed — leaving these equations flagged for manual review', err)
  }

  return result
}
