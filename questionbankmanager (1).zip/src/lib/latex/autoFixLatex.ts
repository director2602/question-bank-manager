// NOTE: deliberately NOT `import 'server-only'` (same reasoning as
// src/lib/pdf/extractQuestions.ts and src/lib/docx/extractQuestions.ts) —
// keeps this testable under Vitest. In practice this is only ever imported
// from the bulk-import CSV/XLSX parsing path (a server module).
//
// katex itself is isomorphic (no DOM dependency for renderToString), so the
// exact same rendering check the browser uses to display math (see
// MathText in components/questions/MathRenderer.tsx) can run here, on the
// server, before a question is ever saved — catching the broken-equation
// case at import time instead of leaving it for someone to notice (and
// manually re-type) later on the question's own page.

import katex from 'katex'

export type LatexFix = { before: string; after: string }
export type LatexIssue = { expr: string; message: string }

export type AutoFixTextResult = {
  text: string
  fixes: LatexFix[]
  issues: LatexIssue[]
}

// Matches the exact same two inline-math delimiter styles MathText renders
// ($...$ and \(...\)) plus $$...$$ for a standalone/display equation (the
// AI transcription pipelines emit this; MathText's own regex doesn't handle
// it today, but it's valid LaTeX we should still validate/fix here rather
// than silently skip).
const SEGMENT_PATTERN = /\$\$([^$]+)\$\$|\$([^$]+)\$|\\\(([^)]+?)\\\)/g

function tryRenderLatex(expr: string): { ok: true } | { ok: false; message: string } {
  try {
    // strict: 'ignore' — don't flag LaTeX that's merely non-standard/
    // deprecated (KaTeX warns about plenty of perfectly common exam-paper
    // notation under strict mode); we only care about things that actually
    // fail to render.
    katex.renderToString(expr, { throwOnError: true, strict: 'ignore' })
    return { ok: true }
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : 'This expression could not be parsed.' }
  }
}

// Deterministic repair heuristics, applied in sequence and re-checked after
// EVERY step — stops the moment the expression renders cleanly. Each one
// targets one specific, well-known mistake seen in pasted/typed/OCR'd exam
// content. None of these ever touches an expression that already renders
// correctly, and none of them ever DELETES text (only adds the characters a
// parse error says are missing) — so the worst case of a bad guess is "no
// change", never silent data loss.
const DETERMINISTIC_REPAIRS: Array<(expr: string) => string> = [
  // Smart quotes/dashes/non-breaking spaces from Word/Excel autocorrect —
  // these are a very common source of "unexpected character" parse errors
  // and are always safe to normalize inside math.
  (e) =>
    e
      .replace(/[‘’]/g, "'")
      .replace(/[“”]/g, '"')
      .replace(/[–—]/g, '-')
      .replace(/ /g, ' '),
  // Bare %, &, # — reserved characters KaTeX rejects outside their special
  // role. A stray one in pasted exam text almost always means "literally
  // this character" (a percentage, an ampersand), so escape it.
  (e) => e.replace(/(^|[^\\])([%&#])/g, (_m, pre, ch) => `${pre}\\${ch}`),
  // Balance braces — appends any missing closing braces at the very end.
  // Never removes a character, so a run of legitimately nested braces is
  // never touched; only ever completes an expression a parse error already
  // flagged as unterminated.
  (e) => {
    let depth = 0
    for (const ch of e) {
      if (ch === '{') depth++
      else if (ch === '}') depth = Math.max(0, depth - 1)
    }
    return depth > 0 ? e + '}'.repeat(depth) : e
  },
]

/**
 * Attempts to fix one LaTeX expression (the content between delimiters,
 * WITHOUT the $ / \( \) wrapper) so it renders cleanly. Tries each
 * deterministic repair in turn, then — if `aiFixes` has an entry for this
 * exact original expression (from a prior AI-assisted pass; see
 * aiFixLatex.ts) and it actually renders — uses that as the final attempt.
 * Returns the best version found; `stillBroken` is only true if nothing
 * fixed it, in which case the ORIGINAL expression is kept unchanged (a
 * failed repair attempt is never left in its place).
 */
export function autoFixExpr(
  expr: string,
  aiFixes?: Map<string, string>
): { text: string; changed: boolean; stillBroken: boolean; error?: string } {
  const original = expr
  if (tryRenderLatex(original).ok) {
    return { text: original, changed: false, stillBroken: false }
  }

  let best = original
  for (const repair of DETERMINISTIC_REPAIRS) {
    const next = repair(best)
    if (next === best) continue
    best = next
    if (tryRenderLatex(best).ok) {
      return { text: best, changed: true, stillBroken: false }
    }
  }

  const aiFix = aiFixes?.get(original)
  if (aiFix && tryRenderLatex(aiFix).ok) {
    return { text: aiFix, changed: true, stillBroken: false }
  }

  // Nothing worked — report the original failure, not a half-applied
  // deterministic guess, so the error message matches what's actually
  // shown to the reviewer.
  const finalCheck = tryRenderLatex(original)
  return {
    text: original,
    changed: false,
    stillBroken: true,
    error: finalCheck.ok ? undefined : finalCheck.message,
  }
}

/**
 * Scans free text for every $$...$$ / $...$ / \(...\) LaTeX segment,
 * auto-fixes any that fail to render, and returns the corrected text plus
 * exactly what changed. Plain text with no LaTeX segments (the overwhelming
 * majority of question/option/explanation text) passes through completely
 * untouched. Pass `aiFixes` (from a prior fixBrokenLatexWithAI call) to let
 * previously AI-corrected expressions be applied on a second pass.
 */
export function autoFixLatexInText(text: string, aiFixes?: Map<string, string>): AutoFixTextResult {
  if (!text) return { text, fixes: [], issues: [] }

  const fixes: LatexFix[] = []
  const issues: LatexIssue[] = []

  const result = text.replace(SEGMENT_PATTERN, (match, displayExpr, dollarExpr, parenExpr) => {
    const expr = displayExpr ?? dollarExpr ?? parenExpr
    const wrap = (inner: string) => (displayExpr !== undefined ? `$$${inner}$$` : dollarExpr !== undefined ? `$${inner}$` : `\\(${inner}\\)`)

    const { text: fixedExpr, changed, stillBroken, error } = autoFixExpr(expr, aiFixes)
    if (changed) fixes.push({ before: expr, after: fixedExpr })
    if (stillBroken) issues.push({ expr, message: error ?? 'This expression could not be parsed.' })
    return wrap(fixedExpr)
  })

  return { text: result, fixes, issues }
}
