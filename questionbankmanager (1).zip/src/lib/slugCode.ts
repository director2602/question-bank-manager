// Auto-generates a lookup `code` from a typed label (letters/numbers/
// underscores, suffixed with a time-based tag so two chapters/topics named
// the same thing never collide) — used everywhere a Chapter/Topic is
// created by just typing a name, with no separate "code" field shown to
// the user (Add Question form, Handwritten PDF Import review).
export function slugCode(label: string, fallback: string): string {
  const base = label.toUpperCase().replace(/[^A-Z0-9]+/g, '_').slice(0, 20) || fallback
  return `${base}_${Date.now().toString(36)}`
}
