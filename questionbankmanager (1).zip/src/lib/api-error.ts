import { NextResponse } from 'next/server'
import { ZodError } from 'zod'
import { AuthError } from '@/lib/auth'
import { Prisma } from '@prisma/client'

/**
 * Central error → HTTP response translator for API routes. Ensures we NEVER
 * leak raw database/internal error messages to the client (business rule:
 * "Never display raw database errors to normal users"), while still logging
 * the real error server-side for debugging.
 */
export function handleApiError(error: unknown) {
  if (error instanceof AuthError) {
    return NextResponse.json({ error: error.message }, { status: error.status })
  }

  if (error instanceof ZodError) {
    return NextResponse.json(
      {
        error: 'The data you submitted is invalid.',
        fieldErrors: error.flatten().fieldErrors,
      },
      { status: 400 }
    )
  }

  if (error instanceof ConflictError) {
    return NextResponse.json(
      { error: error.message, code: 'CONFLICT', latest: error.latest },
      { status: 409 }
    )
  }

  if (error instanceof InsufficientQuestionsError) {
    return NextResponse.json(
      { error: error.message, code: 'INSUFFICIENT_QUESTIONS', shortfalls: error.shortfalls },
      { status: 422 }
    )
  }

  if (error instanceof SectionedInsufficientQuestionsError) {
    return NextResponse.json(
      { error: error.message, code: 'INSUFFICIENT_QUESTIONS', sectionShortfalls: error.sectionShortfalls },
      { status: 422 }
    )
  }

  if (error instanceof PaperValidationError) {
    return NextResponse.json({ error: error.message, code: 'PAPER_VALIDATION_FAILED', issues: error.issues }, { status: 422 })
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    console.error('[Prisma error]', error.code, error.message)
    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'A record with the same unique value already exists.' },
        { status: 409 }
      )
    }
    if (error.code === 'P2025') {
      return NextResponse.json({ error: 'The requested record was not found.' }, { status: 404 })
    }
    return NextResponse.json(
      { error: 'A database error occurred. Please try again.' },
      { status: 500 }
    )
  }

  console.error('[Unhandled API error]', error)
  return NextResponse.json(
    { error: 'An unexpected error occurred. Please try again.' },
    { status: 500 }
  )
}

/** Thrown when an optimistic-lock rowVersion check fails. */
export class ConflictError extends Error {
  latest?: unknown
  constructor(message: string, latest?: unknown) {
    super(message)
    this.latest = latest
  }
}

/** Thrown when a paper generation request asks for more questions than exist. */
export class InsufficientQuestionsError extends Error {
  shortfalls: Array<{
    subject: string
    examClass: string
    code: string
    difficulty: string
    requested: number
    available: number
  }>
  constructor(message: string, shortfalls: InsufficientQuestionsError['shortfalls']) {
    super(message)
    this.shortfalls = shortfalls
  }
}

/**
 * Thrown when the Advanced Paper Builder's section-aware selection engine
 * (selectSectionedQuestions) can't fully satisfy one or more section/type
 * requests — spec §23: "If there are not enough matching questions, clearly
 * report the shortage... Do not silently substitute questions."
 */
export class SectionedInsufficientQuestionsError extends Error {
  sectionShortfalls: Array<{
    sectionLabel: string
    questionType: string
    chapterLabel: string | null
    requested: number
    available: number
    message: string
  }>
  constructor(message: string, sectionShortfalls: SectionedInsufficientQuestionsError['sectionShortfalls']) {
    super(message)
    this.sectionShortfalls = sectionShortfalls
  }
}

/**
 * Thrown by the Advanced Paper Builder's pre-generation content validation
 * (spec §23: missing MCQ options, invalid Integer answers, missing marks,
 * duplicate questions) — distinct from Zod's shape validation, since these
 * checks require looking at the actual question content in the database.
 */
export class PaperValidationError extends Error {
  issues: string[]
  constructor(message: string, issues: string[]) {
    super(message)
    this.issues = issues
  }
}
