import 'server-only'

// Provider abstraction for handwritten-document understanding (Part 20 of
// the spec: "Do not hard-code an AI provider... create a provider
// abstraction"). Today there is exactly one real implementation
// (Claude/Anthropic, via ANTHROPIC_API_KEY — the same env var and SDK
// already used by extractQuestionsAI.ts for typed-PDF transcription), but
// callers only ever depend on this interface, never on the Anthropic SDK
// directly, so a second backend can be added later without touching the
// pipeline that calls it.
//
// AI_PROVIDER selects the backend (only 'anthropic' is implemented right
// now — anything else, or an unset key, makes isConfigured() false and the
// pipeline reports a clear "not configured" error rather than silently
// returning fake results).

export type HandwritingExtractionRequest = {
  pdfBuffer: Buffer
  fileName: string
}

export type DiagramShape =
  | { type: 'line'; x1: number; y1: number; x2: number; y2: number; arrow?: boolean }
  | { type: 'circle'; cx: number; cy: number; r: number }
  | { type: 'polygon'; points: Array<{ x: number; y: number }>; closed?: boolean }
  | { type: 'text'; x: number; y: number; text: string; fontSize?: number }

export type ExtractedDiagram = {
  key: string
  pageNumber: number
  diagramType: 'geometry' | 'graph' | 'circuit' | 'chemistry' | 'flowchart' | 'table' | 'other'
  // Normalized 0-1000 x 0-1000 canvas coordinate space, rendered by
  // src/lib/pdf/diagramSvgRenderer.ts into an actual SVG — deterministic
  // code renders the shapes Claude reports, so the drawing itself is never
  // "hallucinated" pixel content, only the shape list is AI-derived.
  shapes: DiagramShape[]
  // Approximate bounding box (same 0-1000 space) on the ORIGINAL page,
  // used to crop the original page image for the "Original" side of the
  // review screen (Part 6).
  boundingBox: { x: number; y: number; width: number; height: number }
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
}

export type ExtractedHandwrittenQuestion = {
  tempId: string
  pageNumber: number
  questionNumber: string | null
  questionType: 'MCQ' | 'SUBJECTIVE' | 'INTEGER'
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  diagramKeys: string[]
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
}

export type HandwritingExtractionResult = {
  totalPages: number
  questions: ExtractedHandwrittenQuestion[]
  diagrams: ExtractedDiagram[]
}

export interface OCRProvider {
  isConfigured(): boolean
  extractHandwriting(req: HandwritingExtractionRequest): Promise<HandwritingExtractionResult>
}

export function getConfiguredOcrProviderName(): string | null {
  const provider = (process.env.AI_PROVIDER || 'anthropic').toLowerCase()
  if (provider === 'anthropic' && process.env.ANTHROPIC_API_KEY) return 'anthropic'
  return null
}
