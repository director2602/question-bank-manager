// Cover Page Designer's "Analyze Design" step — reference-image → bounded,
// checkable design description. Mirrors src/lib/pdf/extractHandwrittenAI.ts
// exactly on purpose (same model, same tool-forced-structured-output
// pattern, same anti-hallucination contract): Claude reports a BOUNDED list
// of detected text blocks / images / shapes in a fixed 0-1000 x 0-1000
// normalized coordinate space, never raw pixels or free-form prose, and
// every item carries HIGH/MEDIUM/LOW confidence + needsReview + a specific
// reason when uncertain. Nothing here ever silently invents text.
//
// Per the spec's explicit "do not copy uncertain content" rule, every
// detected text block reports BOTH halves the reviewer needs to judge it:
// - content: the transcribed text + a best-guess field classification
//   (schoolName/examName/subject/... or "custom"/null if it doesn't map to
//   a known field) — this is what becomes an editable element.
// - styling: position/size, estimated font size/weight/alignment/color —
//   visual properties, never treated as "content" that could be wrong in
//   the same way transcribed text can be.
// These are kept as separate fields on the SAME block (not two separate
// lists), since a reviewer needs to see both together when deciding
// whether to trust one detected element — see coverDesignPipeline.ts for
// how this result is turned into an editable draft CoverDesign.

import Anthropic from '@anthropic-ai/sdk'

const MODEL = 'claude-sonnet-5'
const MAX_OUTPUT_TOKENS = 16000

export type CoverFieldGuess =
  | 'schoolName'
  | 'examName'
  | 'paperTitle'
  | 'subject'
  | 'class'
  | 'academicYear'
  | 'date'
  | 'time'
  | 'maximumMarks'
  | 'instructions'
  | 'custom'

export type CoverBoundingBox = { x: number; y: number; width: number; height: number }

export type CoverTextBlock = {
  key: string
  text: string
  fieldGuess: CoverFieldGuess | null
  boundingBox: CoverBoundingBox
  fontSizeGuessPt: number | null
  fontWeightGuess: 'normal' | 'bold' | null
  fontStyleGuess: 'normal' | 'italic' | null
  alignmentGuess: 'left' | 'center' | 'right' | null
  colorGuess: string | null
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
}

export type CoverImageBlock = {
  key: string
  kind: 'logo' | 'photo' | 'decorative' | 'other'
  boundingBox: CoverBoundingBox
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
}

export type CoverShapeBlock = {
  key: string
  kind: 'line' | 'rectangle' | 'border' | 'divider'
  boundingBox: CoverBoundingBox
  colorGuess: string | null
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  needsReview: boolean
  reviewReason: string | null
}

export type CoverDesignAnalysisResult = {
  textBlocks: CoverTextBlock[]
  images: CoverImageBlock[]
  shapes: CoverShapeBlock[]
  // A soft, descriptive estimate of visually distinct regions (e.g. "top
  // logo band", "title banner", "candidate details", "instructions") —
  // purely informational for the "Sections detected: N" summary, never
  // used to drive layout logic.
  sectionsDetected: number
  backgroundColorGuess: string | null
}

const SYSTEM_PROMPT = `You are analyzing a REFERENCE IMAGE of an exam-paper cover/front page so it can be reconstructed as an editable design, not just transcribed as text. This is a careful design-analysis task, not a solving or content-generation task.

CRITICAL RULES:
- Only report text you can actually read in the image. If a word is genuinely illegible or ambiguous, still report your best reading but set confidence to LOW and needsReview to true with a specific reason (e.g. "logo obscures part of this line"). Never invent text that is not visibly present.
- For every text block, classify it as ONE of: schoolName, examName, paperTitle, subject, class, academicYear, date, time, maximumMarks, instructions, or custom (anything that doesn't map to a known field — e.g. a slogan, a candidate-details label, decorative text). Only assign a specific field when you are reasonably confident that's what it represents; otherwise use "custom".
- Report position as a bounding box in a 0-1000 x 0-1000 normalized coordinate space (0,0 = top-left of the image, 1000,1000 = bottom-right), matching where the element actually appears in the image as closely as you can tell.
- Estimate visual styling (font size in points relative to a full page ~11pt body text baseline, bold/normal weight, italic/normal style, left/center/right alignment, approximate text color as a hex code) as your best VISUAL estimate — these are styling properties, always editable afterward, and being approximately right is fine; do not skip a block just because you're unsure of the exact pixel values.
- Separately report images (logos, photos, decorative graphics) and shapes (lines, rectangles, borders, dividers) with their own bounding boxes.
- Report a rough count of visually distinct layout sections/regions (e.g. logo band, title banner, meta bar, candidate-details block, instructions block) as sectionsDetected — a descriptive estimate only.
- If the background has a solid or dominant color, report your best guess as a hex code; otherwise leave it null rather than guessing.
- Use the report_cover_layout tool for your entire response.`

export function isCoverAnalysisConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY)
}

export async function analyzeCoverReferenceImage(
  imageBuffer: Buffer,
  imageMimeType: 'image/png' | 'image/jpeg' | 'image/webp'
): Promise<CoverDesignAnalysisResult> {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    throw new Error(
      'Cover design analysis is not configured on this server (missing ANTHROPIC_API_KEY). Ask an administrator to add it in the deployment environment variables.'
    )
  }
  const client = new Anthropic({ apiKey })

  const boundingBoxSchema = {
    type: 'object',
    properties: {
      x: { type: 'number' },
      y: { type: 'number' },
      width: { type: 'number' },
      height: { type: 'number' },
    },
    required: ['x', 'y', 'width', 'height'],
  }

  const tool: Anthropic.Tool = {
    name: 'report_cover_layout',
    description: 'Report every detected text block, image, and shape on this cover-page reference image.',
    input_schema: {
      type: 'object',
      properties: {
        textBlocks: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              key: { type: 'string' },
              text: { type: 'string' },
              fieldGuess: {
                type: 'string',
                enum: ['schoolName', 'examName', 'paperTitle', 'subject', 'class', 'academicYear', 'date', 'time', 'maximumMarks', 'instructions', 'custom'],
              },
              boundingBox: boundingBoxSchema,
              fontSizeGuessPt: { type: 'number' },
              fontWeightGuess: { type: 'string', enum: ['normal', 'bold'] },
              fontStyleGuess: { type: 'string', enum: ['normal', 'italic'] },
              alignmentGuess: { type: 'string', enum: ['left', 'center', 'right'] },
              colorGuess: { type: 'string', description: 'Hex color, e.g. #14161f.' },
              confidence: { type: 'string', enum: ['HIGH', 'MEDIUM', 'LOW'] },
              needsReview: { type: 'boolean' },
              reviewReason: { type: 'string' },
            },
            required: ['key', 'text', 'boundingBox', 'confidence', 'needsReview'],
          },
        },
        images: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              key: { type: 'string' },
              kind: { type: 'string', enum: ['logo', 'photo', 'decorative', 'other'] },
              boundingBox: boundingBoxSchema,
              confidence: { type: 'string', enum: ['HIGH', 'MEDIUM', 'LOW'] },
              needsReview: { type: 'boolean' },
              reviewReason: { type: 'string' },
            },
            required: ['key', 'kind', 'boundingBox', 'confidence', 'needsReview'],
          },
        },
        shapes: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              key: { type: 'string' },
              kind: { type: 'string', enum: ['line', 'rectangle', 'border', 'divider'] },
              boundingBox: boundingBoxSchema,
              colorGuess: { type: 'string' },
              confidence: { type: 'string', enum: ['HIGH', 'MEDIUM', 'LOW'] },
              needsReview: { type: 'boolean' },
              reviewReason: { type: 'string' },
            },
            required: ['key', 'kind', 'boundingBox', 'confidence', 'needsReview'],
          },
        },
        sectionsDetected: { type: 'integer' },
        backgroundColorGuess: { type: 'string' },
      },
      required: ['textBlocks', 'images', 'shapes', 'sectionsDetected'],
    },
  }

  let response
  try {
    response = await client.messages.create({
      model: MODEL,
      max_tokens: MAX_OUTPUT_TOKENS,
      system: SYSTEM_PROMPT,
      tools: [tool],
      tool_choice: { type: 'tool', name: 'report_cover_layout' },
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: imageMimeType, data: imageBuffer.toString('base64') } },
            { type: 'text', text: 'Analyze this cover-page reference image using the report_cover_layout tool, following the system instructions exactly.' },
          ],
        },
      ],
    })
  } catch (err) {
    console.error('[coverDesignAnalysis] Claude API call failed', err)
    throw new Error('The design analysis service could not process this image. It may be too large, too low quality, or briefly unavailable — please try again shortly.')
  }

  const toolUse = response.content.find(
    (block): block is Anthropic.ToolUseBlock => block.type === 'tool_use' && block.name === 'report_cover_layout'
  )
  if (!toolUse) {
    throw new Error('The design analysis service did not return a structured result for this image. Please try again.')
  }
  const parsed = toolUse.input as {
    textBlocks?: Array<Record<string, unknown>>
    images?: Array<Record<string, unknown>>
    shapes?: Array<Record<string, unknown>>
    sectionsDetected?: unknown
    backgroundColorGuess?: unknown
  }

  const textBlocks: CoverTextBlock[] = (Array.isArray(parsed.textBlocks) ? parsed.textBlocks : []).map((b, idx) => ({
    key: typeof b.key === 'string' && b.key ? b.key : `t${idx + 1}`,
    text: typeof b.text === 'string' ? b.text : '',
    fieldGuess: isFieldGuess(b.fieldGuess) ? b.fieldGuess : null,
    boundingBox: coerceBoundingBox(b.boundingBox),
    fontSizeGuessPt: isNum(b.fontSizeGuessPt) ? b.fontSizeGuessPt : null,
    fontWeightGuess: b.fontWeightGuess === 'bold' ? 'bold' : b.fontWeightGuess === 'normal' ? 'normal' : null,
    fontStyleGuess: b.fontStyleGuess === 'italic' ? 'italic' : b.fontStyleGuess === 'normal' ? 'normal' : null,
    alignmentGuess: isAlignment(b.alignmentGuess) ? b.alignmentGuess : null,
    colorGuess: nullableString(b.colorGuess),
    confidence: isConfidence(b.confidence) ? b.confidence : 'LOW',
    needsReview: b.needsReview === true,
    reviewReason: nullableString(b.reviewReason),
  }))

  const images: CoverImageBlock[] = (Array.isArray(parsed.images) ? parsed.images : []).map((b, idx) => ({
    key: typeof b.key === 'string' && b.key ? b.key : `img${idx + 1}`,
    kind: isImageKind(b.kind) ? b.kind : 'other',
    boundingBox: coerceBoundingBox(b.boundingBox),
    confidence: isConfidence(b.confidence) ? b.confidence : 'LOW',
    needsReview: b.needsReview === true,
    reviewReason: nullableString(b.reviewReason),
  }))

  const shapes: CoverShapeBlock[] = (Array.isArray(parsed.shapes) ? parsed.shapes : []).map((b, idx) => ({
    key: typeof b.key === 'string' && b.key ? b.key : `s${idx + 1}`,
    kind: isShapeKind(b.kind) ? b.kind : 'line',
    boundingBox: coerceBoundingBox(b.boundingBox),
    colorGuess: nullableString(b.colorGuess),
    confidence: isConfidence(b.confidence) ? b.confidence : 'LOW',
    needsReview: b.needsReview === true,
    reviewReason: nullableString(b.reviewReason),
  }))

  return {
    textBlocks,
    images,
    shapes,
    sectionsDetected: typeof parsed.sectionsDetected === 'number' ? Math.max(0, Math.floor(parsed.sectionsDetected)) : 0,
    backgroundColorGuess: nullableString(parsed.backgroundColorGuess),
  }
}

function isNum(v: unknown): v is number {
  return typeof v === 'number' && !Number.isNaN(v)
}
function nullableString(v: unknown): string | null {
  if (typeof v !== 'string') return null
  const t = v.trim()
  return t ? t : null
}
function isConfidence(v: unknown): v is 'HIGH' | 'MEDIUM' | 'LOW' {
  return v === 'HIGH' || v === 'MEDIUM' || v === 'LOW'
}
function isAlignment(v: unknown): v is 'left' | 'center' | 'right' {
  return v === 'left' || v === 'center' || v === 'right'
}
function isImageKind(v: unknown): v is CoverImageBlock['kind'] {
  return v === 'logo' || v === 'photo' || v === 'decorative' || v === 'other'
}
function isShapeKind(v: unknown): v is CoverShapeBlock['kind'] {
  return v === 'line' || v === 'rectangle' || v === 'border' || v === 'divider'
}
function isFieldGuess(v: unknown): v is CoverFieldGuess {
  return (
    v === 'schoolName' ||
    v === 'examName' ||
    v === 'paperTitle' ||
    v === 'subject' ||
    v === 'class' ||
    v === 'academicYear' ||
    v === 'date' ||
    v === 'time' ||
    v === 'maximumMarks' ||
    v === 'instructions' ||
    v === 'custom'
  )
}
function coerceBoundingBox(v: unknown): CoverBoundingBox {
  const box = (v ?? {}) as Record<string, unknown>
  return {
    x: isNum(box.x) ? box.x : 0,
    y: isNum(box.y) ? box.y : 0,
    width: isNum(box.width) ? box.width : 100,
    height: isNum(box.height) ? box.height : 40,
  }
}
