// NOTE: deliberately NOT `import 'server-only'` (same reasoning as the
// .docx/.pdf extractors) — keeps this testable under Vitest.
//
// A .xlsx file is a ZIP archive of OOXML parts, same family as .docx — this
// reads xl/workbook.xml (to find the first worksheet, in display order),
// xl/sharedStrings.xml (most text cells reference an index into this table
// rather than embedding their text inline), and that worksheet's own XML
// directly via JSZip (already a project dependency, used identically for
// .docx import — see src/lib/docx/extractQuestions.ts) rather than adding a
// new dependency like `xlsx`/`exceljs`: this app's import template is a
// plain flat table (no formulas, merged cells, or multiple sheets to
// support), well within what a focused reader like this needs.

import JSZip from 'jszip'

const ENTITY_MAP: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }

function decodeXmlEntities(s: string): string {
  return s
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, code: string) => String.fromCharCode(parseInt(code, 16)))
    .replace(/&(amp|lt|gt|quot|apos);/g, (_, name: string) => ENTITY_MAP[name] ?? `&${name};`)
}

/** "A" -> 0, "B" -> 1, ..., "Z" -> 25, "AA" -> 26, ... */
function columnLetterToIndex(letters: string): number {
  let idx = 0
  for (const ch of letters) idx = idx * 26 + (ch.charCodeAt(0) - 64)
  return idx - 1
}

async function readSharedStrings(zip: JSZip): Promise<string[]> {
  const file = zip.file('xl/sharedStrings.xml')
  if (!file) return []
  const xml = await file.async('string')
  // Each <si>...</si> is one shared-string table entry; a rich-text string
  // can split its content across several <r><t>...</t></r> runs, which
  // need concatenating — same idea as concatenating a Word paragraph's
  // <w:t> runs in the .docx extractor.
  const siBlocks = xml.match(/<si>[\s\S]*?<\/si>/g) ?? []
  return siBlocks.map((block) => {
    const texts: string[] = []
    const re = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g
    let m: RegExpExecArray | null
    while ((m = re.exec(block))) texts.push(decodeXmlEntities(m[1]))
    return texts.join('')
  })
}

/** Resolves the FIRST worksheet in the workbook's own tab order (not just
 * "sheet1.xml", which is usually but not always the first tab) to its XML
 * part path inside the archive. */
async function firstWorksheetPath(zip: JSZip): Promise<string> {
  const workbookFile = zip.file('xl/workbook.xml')
  if (!workbookFile) {
    throw new Error('This does not look like a valid Excel (.xlsx) file (xl/workbook.xml was not found).')
  }
  const workbookXml = await workbookFile.async('string')
  const sheetMatch = workbookXml.match(/<sheet\b[^>]*\/?>/)
  if (!sheetMatch) {
    throw new Error('No worksheets were found in this Excel file.')
  }

  const rIdMatch = sheetMatch[0].match(/r:id="(rId\d+)"/)
  const relsFile = zip.file('xl/_rels/workbook.xml.rels')
  if (rIdMatch && relsFile) {
    const relsXml = await relsFile.async('string')
    const relRe = new RegExp(`<Relationship\\s+Id="${rIdMatch[1]}"[^>]*Target="([^"]+)"`)
    const relMatch = relsXml.match(relRe)
    if (relMatch) {
      const target = relMatch[1].replace(/^\/?xl\//, '')
      const path = `xl/${target}`
      if (zip.file(path)) return path
    }
  }

  // Conventional default — correct for the overwhelming majority of real
  // files, and a safe fallback if the relationship lookup above comes up
  // empty for any reason.
  return 'xl/worksheets/sheet1.xml'
}

async function readWorksheetGrid(zip: JSZip, sheetPath: string, sharedStrings: string[]): Promise<string[][]> {
  const sheetFile = zip.file(sheetPath)
  if (!sheetFile) {
    throw new Error(`Worksheet part "${sheetPath}" was not found in this Excel file.`)
  }
  const xml = await sheetFile.async('string')

  const rowBlocks = xml.match(/<row\b[^>]*>[\s\S]*?<\/row>/g) ?? []
  const grid: string[][] = []

  for (const rowBlock of rowBlocks) {
    const cells: string[] = []
    // Matches both <c ...>...</c> and the self-closing empty-cell form <c .../>.
    const cellRe = /<c\b([^>]*?)\/>|<c\b([^>]*?)>([\s\S]*?)<\/c>/g
    let m: RegExpExecArray | null
    let implicitCol = 0
    while ((m = cellRe.exec(rowBlock))) {
      const attrs = m[1] ?? m[2] ?? ''
      const inner = m[3] ?? ''
      const refMatch = attrs.match(/r="([A-Z]+)\d+"/)
      const col = refMatch ? columnLetterToIndex(refMatch[1]) : implicitCol
      implicitCol = col + 1

      const typeMatch = attrs.match(/t="([^"]+)"/)
      const type = typeMatch ? typeMatch[1] : 'n'

      let value = ''
      if (type === 's') {
        const vMatch = inner.match(/<v>([\s\S]*?)<\/v>/)
        const idx = vMatch ? parseInt(vMatch[1], 10) : -1
        value = sharedStrings[idx] ?? ''
      } else if (type === 'inlineStr') {
        const tMatches = inner.match(/<t(?:\s[^>]*)?>[\s\S]*?<\/t>/g) ?? []
        value = tMatches.map((t) => decodeXmlEntities(t.replace(/^<t(?:\s[^>]*)?>/, '').replace(/<\/t>$/, ''))).join('')
      } else {
        const vMatch = inner.match(/<v>([\s\S]*?)<\/v>/)
        value = vMatch ? decodeXmlEntities(vMatch[1]) : ''
      }

      while (cells.length < col) cells.push('')
      cells[col] = value
    }
    grid.push(cells)
  }

  return grid
}

/**
 * Reads the first worksheet of an .xlsx file into the SAME shape
 * Papa.parse({header: true}) produces for a CSV — an array of plain
 * `Record<string, string>` row objects keyed by the header row's cell text
 * — so it can feed directly into the existing CSV validation pipeline
 * (see validateRows in src/lib/csv/parseTemplate.ts) with zero changes to
 * that logic. Blank rows (every cell empty) are skipped, matching Papa's
 * own `skipEmptyLines` behavior.
 */
export async function parseXlsxToRows(buffer: Buffer): Promise<Record<string, string>[]> {
  const zip = await JSZip.loadAsync(buffer)
  const sharedStrings = await readSharedStrings(zip)
  const sheetPath = await firstWorksheetPath(zip)
  const grid = await readWorksheetGrid(zip, sheetPath, sharedStrings)

  if (grid.length === 0) return []

  const headerRow = grid[0].map((h) => (h ?? '').trim())
  const rows: Record<string, string>[] = []

  for (let i = 1; i < grid.length; i++) {
    const row = grid[i]
    if (!row || row.every((c) => !c || !c.trim())) continue

    const obj: Record<string, string> = {}
    headerRow.forEach((header, colIdx) => {
      if (!header) return
      obj[header] = (row[colIdx] ?? '').trim()
    })
    rows.push(obj)
  }

  return rows
}
