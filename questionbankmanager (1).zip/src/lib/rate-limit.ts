import 'server-only'

/**
 * Minimal in-memory sliding-window rate limiter. Adequate for a single
 * Node.js instance; if you deploy multiple server instances behind a load
 * balancer, replace this with a shared store (e.g. Upstash Redis — see
 * DEPLOYMENT.md "Scaling beyond a single instance") so limits are enforced
 * across all of them rather than per-process.
 */
const buckets = new Map<string, { count: number; resetAt: number }>()

export function rateLimit(
  key: string,
  { limit, windowMs }: { limit: number; windowMs: number }
): { allowed: boolean; remaining: number; resetAt: number } {
  const now = Date.now()
  const bucket = buckets.get(key)

  if (!bucket || bucket.resetAt <= now) {
    const resetAt = now + windowMs
    buckets.set(key, { count: 1, resetAt })
    return { allowed: true, remaining: limit - 1, resetAt }
  }

  if (bucket.count >= limit) {
    return { allowed: false, remaining: 0, resetAt: bucket.resetAt }
  }

  bucket.count += 1
  return { allowed: true, remaining: limit - bucket.count, resetAt: bucket.resetAt }
}

// Periodic cleanup so the map doesn't grow unbounded on a long-lived process.
if (typeof setInterval !== 'undefined') {
  setInterval(() => {
    const now = Date.now()
    for (const [key, bucket] of buckets) {
      if (bucket.resetAt <= now) buckets.delete(key)
    }
  }, 5 * 60 * 1000).unref?.()
}
