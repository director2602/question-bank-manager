import { describe, it, expect } from 'vitest'
import { autoFixExpr, autoFixLatexInText } from '@/lib/latex/autoFixLatex'

describe('autoFixExpr', () => {
  it('leaves an already-valid expression completely untouched', () => {
    const result = autoFixExpr('\\frac{1}{2} + x^2')
    expect(result).toEqual({ text: '\\frac{1}{2} + x^2', changed: false, stillBroken: false })
  })

  it('does not touch \\frac/\\sqrt without braces when KaTeX already accepts it (single-token argument)', () => {
    // \frac12 and \sqrt2 are valid TeX (the "next atom" rule) — confirming
    // the repair pipeline never fires on something that already renders.
    expect(autoFixExpr('\\frac12')).toEqual({ text: '\\frac12', changed: false, stillBroken: false })
    expect(autoFixExpr('\\sqrt2')).toEqual({ text: '\\sqrt2', changed: false, stillBroken: false })
  })

  it('closes an unterminated brace', () => {
    const result = autoFixExpr('\\frac{1}{2')
    expect(result.stillBroken).toBe(false)
    expect(result.changed).toBe(true)
    expect(result.text).toBe('\\frac{1}{2}')
  })

  it('closes an unterminated brace on a \\sqrt argument without mangling valid braces elsewhere', () => {
    const result = autoFixExpr('\\sqrt{x^2 + y^2 + 1')
    expect(result.stillBroken).toBe(false)
    expect(result.text).toBe('\\sqrt{x^2 + y^2 + 1}')
  })

  it('escapes a bare & that would otherwise fail to parse outside an alignment environment', () => {
    const result = autoFixExpr('a & b')
    expect(result.stillBroken).toBe(false)
    expect(result.text).toBe('a \\& b')
  })

  it('escapes a bare # that would otherwise fail to parse', () => {
    const result = autoFixExpr('a # b')
    expect(result.stillBroken).toBe(false)
    expect(result.text).toBe('a \\# b')
  })

  it('combines brace-balancing with character escaping when both are needed', () => {
    const result = autoFixExpr('\\text{a & b')
    expect(result.stillBroken).toBe(false)
    expect(result.text).toBe('\\text{a \\& b}')
  })

  it('reports stillBroken with the real parser error when nothing fixes it', () => {
    const result = autoFixExpr('\\notarealcommand{x}')
    expect(result.stillBroken).toBe(true)
    expect(result.changed).toBe(false)
    expect(result.text).toBe('\\notarealcommand{x}') // never left half-modified
    expect(result.error).toBeTruthy()
  })

  it('accepts a validated AI-provided fix when deterministic repairs fail', () => {
    const aiFixes = new Map([['\\notarealcommand{x}', '\\mathrm{x}']])
    const result = autoFixExpr('\\notarealcommand{x}', aiFixes)
    expect(result.stillBroken).toBe(false)
    expect(result.changed).toBe(true)
    expect(result.text).toBe('\\mathrm{x}')
  })

  it('ignores an AI-provided fix that itself does not render', () => {
    const aiFixes = new Map([['\\notarealcommand{x}', '\\alsofake{x}']])
    const result = autoFixExpr('\\notarealcommand{x}', aiFixes)
    expect(result.stillBroken).toBe(true)
    expect(result.text).toBe('\\notarealcommand{x}')
  })
})

describe('autoFixLatexInText', () => {
  it('passes plain text with no LaTeX segments through completely unchanged', () => {
    const result = autoFixLatexInText('Plain question text, no math at all.')
    expect(result).toEqual({ text: 'Plain question text, no math at all.', fixes: [], issues: [] })
  })

  it('fixes a broken equation embedded in a real question, preserving surrounding text verbatim', () => {
    const text = 'Simplify $\\frac{1}{2 + x$ and state the result.'
    const result = autoFixLatexInText(text)
    expect(result.text).toBe('Simplify $\\frac{1}{2 + x}$ and state the result.')
    expect(result.fixes).toHaveLength(1)
    expect(result.issues).toHaveLength(0)
  })

  it('fixes multiple broken equations in the same text independently', () => {
    const text = 'If $\\text{a & b}$ is true then $\\sqrt{4$ equals what?'
    const result = autoFixLatexInText(text)
    expect(result.text).toBe('If $\\text{a \\& b}$ is true then $\\sqrt{4}$ equals what?')
    expect(result.fixes).toHaveLength(2)
  })

  it('leaves a correctly-formed equation in the text untouched while fixing a broken one', () => {
    const text = 'Compare $x^2 + y^2$ with $\\text{a & b}$ instead.'
    const result = autoFixLatexInText(text)
    expect(result.text).toBe('Compare $x^2 + y^2$ with $\\text{a \\& b}$ instead.')
    expect(result.fixes).toHaveLength(1)
  })

  it('leaves a stray unpaired $ (e.g. a currency symbol, not a math delimiter) completely alone', () => {
    // Mirrors MathText's own rendering behavior today: only a matched pair
    // of delimiters is ever treated as a LaTeX segment at all — a single
    // "$" with no closing partner (very common as plain currency in a word
    // problem, e.g. "costs $50") is never guessed at or rewrapped, since
    // doing so could just as easily mangle ordinary prose as fix a real
    // mistake.
    const text = 'A book costs $50. How much do 3 books cost?'
    const result = autoFixLatexInText(text)
    expect(result).toEqual({ text, fixes: [], issues: [] })
  })

  it('reports an unfixable equation as an issue without corrupting the rest of the text', () => {
    const text = 'Evaluate $\\notarealcommand{x}$ at x=1.'
    const result = autoFixLatexInText(text)
    expect(result.text).toBe(text)
    expect(result.issues).toHaveLength(1)
    expect(result.issues[0].expr).toBe('\\notarealcommand{x}')
  })

  it('applies a supplied AI fix map on a second pass', () => {
    const text = 'Evaluate $\\notarealcommand{x}$ at x=1.'
    const aiFixes = new Map([['\\notarealcommand{x}', '\\mathrm{x}']])
    const result = autoFixLatexInText(text, aiFixes)
    expect(result.text).toBe('Evaluate $\\mathrm{x}$ at x=1.')
    expect(result.issues).toHaveLength(0)
  })

  it('handles \\( \\) delimiters the same way as $ $', () => {
    const text = 'Find \\(\\frac{1}{2\\) of the total.'
    const result = autoFixLatexInText(text)
    expect(result.text).toBe('Find \\(\\frac{1}{2}\\) of the total.')
  })

  it('handles $$ display-math delimiters', () => {
    const text = 'Energy: $$E = \\frac{1}{2 m v^2$$'
    const result = autoFixLatexInText(text)
    expect(result.text).toBe('Energy: $$E = \\frac{1}{2 m v^2}$$')
  })
})
