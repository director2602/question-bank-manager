import { describe, it, expect } from 'vitest'
import { decodeCsvBuffer } from '@/lib/csv/decodeCsvText'

describe('decodeCsvBuffer', () => {
  it('decodes plain ASCII content unchanged', () => {
    const buffer = Buffer.from('Question,Option A\nWhat is 2+2?,4\n', 'utf-8')
    expect(decodeCsvBuffer(buffer)).toBe('Question,Option A\nWhat is 2+2?,4\n')
  })

  it('decodes valid UTF-8 content (e.g. already-correct Unicode math symbols) unchanged', () => {
    const text = 'r = 2t² i + 3t j, v = √(x² + y²), θ = 45°, 9.1 × 10⁻³¹ kg'
    const buffer = Buffer.from(text, 'utf-8')
    expect(decodeCsvBuffer(buffer)).toBe(text)
  })

  it('strips a UTF-8 byte-order-mark the same way File.text() does', () => {
    const bom = Buffer.from([0xef, 0xbb, 0xbf])
    const buffer = Buffer.concat([bom, Buffer.from('Question,Option A\n', 'utf-8')])
    expect(decodeCsvBuffer(buffer)).toBe('Question,Option A\n')
  })

  it('recovers Windows-1252-encoded special characters that would otherwise become U+FFFD', () => {
    // Real-world case: a CSV authored in Word/Excel on Windows, saved in
    // the legacy ANSI codepage. Byte 0xB2 is "²" in windows-1252 but is
    // not valid as a lone UTF-8 byte at all (decoding as UTF-8 would turn
    // it into "�" -- exactly the "broken equation" symptom this fixes).
    const buffer = Buffer.from([0x32, 0x74, 0xb2, 0x20, 0x69]) // "2t² i"
    expect(decodeCsvBuffer(buffer)).toBe('2t² i')
  })

  it('recovers multiple windows-1252 special characters in the same row (×, ³, ¹)', () => {
    // "9.1 × 10?³¹; kg" — the literal "?" here is baked into the source
    // file itself (not a decoding artifact) and is intentionally left
    // alone; only the genuinely mis-decodable bytes are recovered.
    const buffer = Buffer.from([
      0x39, 0x2e, 0x31, 0x20, 0xd7, 0x20, 0x31, 0x30, 0x3f, 0xb3, 0xb9, 0x3b, 0x20, 0x6b, 0x67,
    ])
    expect(decodeCsvBuffer(buffer)).toBe('9.1 × 10?³¹; kg')
  })
})
