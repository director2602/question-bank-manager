import { describe, it, expect } from 'vitest'
import JSZip from 'jszip'
import { parseXlsxToRows } from '@/lib/xlsx/parseXlsxRows'

/**
 * Builds a minimal, real .xlsx (a ZIP archive containing just the OOXML
 * parts parseXlsxToRows actually reads) so this test exercises the real
 * unzip + XML-scraping logic end-to-end, not a mocked stand-in for it.
 *
 * `rows` is a simple 2D array of cell text; the first row is the header.
 * Every cell is written as a shared string (type="s"), the overwhelming
 * majority case for a real Excel-saved file.
 */
async function buildTestXlsx(rows: string[][]): Promise<Buffer> {
  const zip = new JSZip()

  const sharedStrings: string[] = []
  const sharedStringIndex = new Map<string, number>()
  function sIndexFor(text: string): number {
    if (sharedStringIndex.has(text)) return sharedStringIndex.get(text)!
    const idx = sharedStrings.length
    sharedStrings.push(text)
    sharedStringIndex.set(text, idx)
    return idx
  }

  const colLetter = (n: number) => String.fromCharCode(65 + n)

  const rowsXml = rows
    .map((row, rowIdx) => {
      const cells = row
        .map((cellText, colIdx) => {
          const ref = `${colLetter(colIdx)}${rowIdx + 1}`
          const idx = sIndexFor(cellText)
          return `<c r="${ref}" t="s"><v>${idx}</v></c>`
        })
        .join('')
      return `<row r="${rowIdx + 1}">${cells}</row>`
    })
    .join('')

  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${rowsXml}</sheetData></worksheet>`

  const sharedStringsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedStrings.length}" uniqueCount="${sharedStrings.length}">
${sharedStrings.map((s) => `<si><t xml:space="preserve">${s}</t></si>`).join('\n')}
</sst>`

  const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>
</workbook>`

  const workbookRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>`

  zip.file('xl/workbook.xml', workbookXml)
  zip.file('xl/_rels/workbook.xml.rels', workbookRelsXml)
  zip.file('xl/worksheets/sheet1.xml', sheetXml)
  zip.file('xl/sharedStrings.xml', sharedStringsXml)

  return zip.generateAsync({ type: 'nodebuffer' })
}

describe('parseXlsxToRows', () => {
  it('reads the header row and data rows into Papa.parse-shaped row objects', async () => {
    const buffer = await buildTestXlsx([
      ['Subject', 'Class', 'Code', 'Difficulty', 'Question'],
      ['Physics', '11th', 'A', 'E', 'What is the SI unit of force?'],
      ['Chemistry', '12th', 'B', 'M', 'What is the pH of pure water?'],
    ])

    const rows = await parseXlsxToRows(buffer)

    expect(rows).toHaveLength(2)
    expect(rows[0]).toEqual({
      Subject: 'Physics',
      Class: '11th',
      Code: 'A',
      Difficulty: 'E',
      Question: 'What is the SI unit of force?',
    })
    expect(rows[1].Subject).toBe('Chemistry')
  })

  it('decodes XML entities in cell text', async () => {
    const buffer = await buildTestXlsx([['Question'], ['If a &amp; b are constants, find a &lt; b.']])
    const rows = await parseXlsxToRows(buffer)
    expect(rows[0].Question).toBe('If a & b are constants, find a < b.')
  })

  it('skips fully blank rows, same as Papa.parse skipEmptyLines', async () => {
    const buffer = await buildTestXlsx([
      ['Subject', 'Question'],
      ['Physics', 'Q1'],
      ['', ''],
      ['Chemistry', 'Q2'],
    ])
    const rows = await parseXlsxToRows(buffer)
    expect(rows).toHaveLength(2)
    expect(rows.map((r) => r.Subject)).toEqual(['Physics', 'Chemistry'])
  })

  it('reuses the same shared-string entry across multiple cells correctly', async () => {
    const buffer = await buildTestXlsx([
      ['Subject', 'Difficulty'],
      ['Physics', 'E'],
      ['Physics', 'M'],
    ])
    const rows = await parseXlsxToRows(buffer)
    expect(rows[0].Subject).toBe('Physics')
    expect(rows[1].Subject).toBe('Physics')
    expect(rows[0].Difficulty).toBe('E')
    expect(rows[1].Difficulty).toBe('M')
  })

  it('rejects a buffer that is not a real .xlsx', async () => {
    await expect(parseXlsxToRows(Buffer.from('not a zip file'))).rejects.toThrow()
  })
})
