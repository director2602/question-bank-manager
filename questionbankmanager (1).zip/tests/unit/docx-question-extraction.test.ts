import { describe, it, expect } from 'vitest'
import JSZip from 'jszip'
import { extractDocxContent } from '@/lib/docx/extractQuestions'
import { splitIntoQuestions } from '@/lib/pdf/extractQuestions'

/**
 * Builds a minimal, real .docx (a ZIP archive containing just the OOXML
 * parts extractDocxContent actually reads) so this test exercises the real
 * unzip + XML-scraping logic end-to-end, not a mocked stand-in for it.
 */
function buildTestDocx(paragraphsXml: string[], opts?: { withImageInParagraph?: number }): Promise<Buffer> {
  const zip = new JSZip()

  const bodyParagraphs = paragraphsXml
    .map((text, idx) => {
      const imageRun =
        opts?.withImageInParagraph === idx
          ? '<w:r><w:drawing><wp:inline><a:graphic><a:graphicData><pic:pic><pic:blipFill><a:blip r:embed="rId1"/></a:blipFill></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>'
          : ''
      return `<w:p><w:r><w:t xml:space="preserve">${text}</w:t></w:r>${imageRun}</w:p>`
    })
    .join('')

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${bodyParagraphs}</w:body></w:document>`

  zip.file('word/document.xml', documentXml)

  if (opts?.withImageInParagraph !== undefined) {
    const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>
</Relationships>`
    zip.file('word/_rels/document.xml.rels', relsXml)
    // Content doesn't need to be a real PNG for extraction purposes — only
    // that the bytes round-trip through the zip untouched.
    zip.file('word/media/image1.png', Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0xde, 0xad, 0xbe, 0xef]))
  }

  return zip.generateAsync({ type: 'nodebuffer' })
}

describe('extractDocxContent', () => {
  it('extracts one plain-text line per Word paragraph, in document order', async () => {
    const buffer = await buildTestDocx([
      'Physics Practice Set',
      '1. What is the SI unit of force?',
      'A) Joule',
      'B) Newton',
      'C) Watt',
      'D) Pascal',
      'Ans: B',
    ])

    const { lines, images } = await extractDocxContent(buffer)

    expect(lines).toEqual([
      'Physics Practice Set',
      '1. What is the SI unit of force?',
      'A) Joule',
      'B) Newton',
      'C) Watt',
      'D) Pascal',
      'Ans: B',
    ])
    expect(images).toHaveLength(0)
  })

  it('decodes XML entities inside question text', async () => {
    const buffer = await buildTestDocx(['1. If a &amp; b are constants, find a &lt; b &amp; a &gt; c.'])
    const { lines } = await extractDocxContent(buffer)
    expect(lines[0]).toBe('1. If a & b are constants, find a < b & a > c.')
  })

  it('feeds cleanly into splitIntoQuestions to produce real structured questions', async () => {
    const buffer = await buildTestDocx([
      '1. What is the SI unit of force?',
      'A) Joule',
      'B) Newton',
      'C) Watt',
      'D) Pascal',
      'Ans: B',
      '2. A body moving with constant velocity has:',
      'A) Zero acceleration',
      'B) Non-zero acceleration',
      'Answer: A',
    ])

    const { lines } = await extractDocxContent(buffer)
    const questions = splitIntoQuestions(lines.join('\n'))

    expect(questions).toHaveLength(2)
    expect(questions[0].questionNumber).toBe('1')
    expect(questions[0].optionB).toContain('Newton')
    expect(questions[0].correctAnswer).toBe('B')
    expect(questions[1].questionNumber).toBe('2')
    expect(questions[1].correctAnswer).toBe('A')
  })

  it('extracts an embedded image, tagged with the paragraph it appears in', async () => {
    const buffer = await buildTestDocx(
      ['1. Identify the circuit component shown below.', 'A) Resistor', 'B) Capacitor'],
      { withImageInParagraph: 0 }
    )

    const { lines, images } = await extractDocxContent(buffer)

    expect(images).toHaveLength(1)
    expect(images[0].paragraphIndex).toBe(0)
    expect(images[0].mimeType).toBe('image/png')
    expect(images[0].fileName).toBe('image1.png')
    expect(images[0].buffer.byteLength).toBeGreaterThan(0)
    expect(lines[0]).toBe('1. Identify the circuit component shown below.')
  })

  it('rejects a buffer that is not a real .docx', async () => {
    await expect(extractDocxContent(Buffer.from('not a zip file'))).rejects.toThrow()
  })
})
