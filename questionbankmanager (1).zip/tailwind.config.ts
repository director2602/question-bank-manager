import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Brand scale derived from the CUBUS brand color #400c4d, same
        // hue tapered across lightness/saturation. Anchored EXACTLY at
        // shade 600 (not 900) because brand-600/700 are what the app's own
        // UI actually renders — .btn-primary and the vast majority of
        // buttons, focus rings, badges, and links reference brand-600/700 —
        // so #400c4d is now genuinely the app's visible primary color, not
        // just a value sitting unused in the scale.
        brand: {
          50: '#fbf5fc',
          100: '#f5eaf8',
          200: '#eacdf1',
          300: '#daa1e8',
          400: '#c360dc',
          500: '#a926c9',
          600: '#400c4d',
          700: '#34093e',
          800: '#290731',
          900: '#200526',
          950: '#150319',
        },
        surface: {
          DEFAULT: '#ffffff',
          subtle: '#f7f8fa',
          muted: '#eef0f4',
          border: '#e2e5eb',
        },
        ink: {
          DEFAULT: '#161a2b',
          muted: '#565d72',
          faint: '#8891a5',
        },
        success: '#16794f',
        warning: '#9a6a03',
        danger: '#b3261e',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(22,26,43,0.06), 0 1px 3px 0 rgba(22,26,43,0.08)',
      },
    },
  },
  plugins: [],
}

export default config
