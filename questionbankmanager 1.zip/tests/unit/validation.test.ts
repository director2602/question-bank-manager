import { describe, it, expect } from 'vitest'
import { createQuestionSchema, updateQuestionTagsSchema, questionListQuerySchema } from '@/lib/validation/question'
import { generatePaperSchema } from '@/lib/validation/paper'

const uuid1 = '11111111-1111-1111-1111-111111111111'
const uuid2 = '22222222-2222-2222-2222-222222222222'
const uuid3 = '33333333-3333-3333-3333-333333333333'
const uuid4 = '44444444-4444-4444-4444-444444444444'

describe('createQuestionSchema', () => {
  it('accepts a minimal valid question', () => {
    const result = createQuestionSchema.safeParse({
      questionText: 'What is 2 + 2?',
      questionNumber: '1',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      difficultyId: uuid4,
    })
    expect(result.success).toBe(true)
  })

  it('rejects a question with empty text (business rule: question text is required)', () => {
    const result = createQuestionSchema.safeParse({
      questionText: '   ',
      questionNumber: '1',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      difficultyId: uuid4,
    })
    expect(result.success).toBe(false)
  })

  it('rejects a question missing a required tag', () => {
    const result = createQuestionSchema.safeParse({
      questionText: 'What is 2 + 2?',
      questionNumber: '1',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      // difficultyId missing
    })
    expect(result.success).toBe(false)
  })

  it('supports alphanumeric question numbers like "Q-25"', () => {
    const result = createQuestionSchema.safeParse({
      questionText: 'Sample',
      questionNumber: 'Q-25',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      difficultyId: uuid4,
    })
    expect(result.success).toBe(true)
  })
})

describe('updateQuestionTagsSchema', () => {
  it('requires rowVersion for optimistic locking', () => {
    const withoutRowVersion = updateQuestionTagsSchema.safeParse({
      questionNumber: '1',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      difficultyId: uuid4,
    })
    expect(withoutRowVersion.success).toBe(false)

    const withRowVersion = updateQuestionTagsSchema.safeParse({
      questionNumber: '1',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      difficultyId: uuid4,
      rowVersion: 1,
    })
    expect(withRowVersion.success).toBe(true)
  })

  it('never accepts question content fields (tags/content stay separated)', () => {
    const parsed = updateQuestionTagsSchema.safeParse({
      questionNumber: '1',
      subjectId: uuid1,
      examClassId: uuid2,
      codeId: uuid3,
      difficultyId: uuid4,
      rowVersion: 1,
      questionText: 'this should be ignored/stripped, not applied',
    })
    expect(parsed.success).toBe(true)
    if (parsed.success) {
      expect((parsed.data as any).questionText).toBeUndefined()
    }
  })
})

describe('questionListQuerySchema', () => {
  it('defaults to ACTIVE status, page 1, pageSize 25', () => {
    const parsed = questionListQuerySchema.parse({})
    expect(parsed.status).toBe('ACTIVE')
    expect(parsed.page).toBe(1)
    expect(parsed.pageSize).toBe(25)
  })

  it('caps pageSize at 100 to prevent loading the whole bank at once', () => {
    const parsed = questionListQuerySchema.safeParse({ pageSize: '5000' })
    expect(parsed.success).toBe(false)
  })
})

describe('generatePaperSchema', () => {
  it('requires at least one filter line', () => {
    const parsed = generatePaperSchema.safeParse({ title: 'Test Paper', mode: 'RANDOM', lines: [] })
    expect(parsed.success).toBe(false)
  })

  it('accepts a valid random-mode request', () => {
    const parsed = generatePaperSchema.safeParse({
      title: 'Physics Unit Test',
      mode: 'RANDOM',
      lines: [{ subjectId: uuid1, examClassId: uuid2, codeId: uuid3, difficultyId: uuid4, count: 10 }],
    })
    expect(parsed.success).toBe(true)
  })
})
