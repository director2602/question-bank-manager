import { describe, it, expect } from 'vitest'
import { renderPaperHtml, type PaperSettings } from '@/lib/pdf/paperHtml'
import type { SnapshotQuestion } from '@/lib/paper-snapshot'

const settings: PaperSettings = {
  title: 'Demo Paper',
  paperNumber: 1,
  instituteName: 'Demo Institute',
  logoUrl: null,
  examName: 'Unit Test',
  subjectLabel: 'Physics',
  classLabel: '11 JEE',
  examDate: '2026-01-01',
  examTime: '10:00 AM',
  maxMarks: 100,
  instructions: 'Answer all questions.',
  headerText: null,
  footerText: null,
}

function makeQuestion(overrides: Partial<SnapshotQuestion> = {}): SnapshotQuestion {
  return {
    questionId: 'q1',
    questionVersionId: 'v1',
    position: 1,
    questionNumber: '1',
    questionText: 'What is $x^2$ when x = 2?',
    optionA: 'A) 2',
    optionB: 'B) 4',
    optionC: 'C) 8',
    optionD: 'D) 16',
    correctAnswer: 'B',
    explanation: 'x^2 = 4 when x = 2.',
    subject: 'Physics',
    examClass: '11 JEE',
    code: 'A',
    difficulty: 'Easy',
    marks: null,
    images: [],
    ...overrides,
  }
}

describe('renderPaperHtml', () => {
  it('escapes HTML-unsafe characters in question text (never trusts it as raw HTML)', () => {
    const html = renderPaperHtml(settings, [makeQuestion({ questionText: '<script>alert(1)</script>' })], 'question')
    expect(html).not.toContain('<script>alert(1)</script>')
    expect(html).toContain('&lt;script&gt;')
  })

  it('preserves math delimiters verbatim so MathJax can typeset them', () => {
    const html = renderPaperHtml(settings, [makeQuestion()], 'question')
    expect(html).toContain('$x^2$')
  })

  it('answer key mode lists the correct answer per question number, not the question text', () => {
    const html = renderPaperHtml(settings, [makeQuestion({ correctAnswer: 'B' })], 'answerKey')
    expect(html).toContain('<strong>1.</strong> B')
    expect(html).not.toContain('What is')
  })

  it('solutions mode includes the explanation text', () => {
    const html = renderPaperHtml(settings, [makeQuestion()], 'solutions')
    expect(html).toContain('x^2 = 4 when x = 2')
  })

  it('question mode omits the correct-answer/explanation panel entirely', () => {
    const html = renderPaperHtml(settings, [makeQuestion()], 'question')
    expect(html).not.toContain('x^2 = 4 when x = 2')
  })
})
