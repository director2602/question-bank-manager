import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError, ConflictError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { paperQuestionOverrideSchema } from '@/lib/validation/paper'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'

// PATCH /api/papers/:id/questions/:paperQuestionId — edit (or revert) this
// ONE question's text/options/answer/explanation as displayed in THIS paper
// only. Writes to paper_questions' *_override columns — never to
// Question/QuestionVersion — so the master Question Bank and every other
// paper referencing the same question are completely unaffected (per the
// explicit "only this paper" requirement). See buildPaperSnapshot for where
// these overrides are applied when rendering.
export async function PATCH(
  request: Request,
  { params }: { params: { id: string; paperQuestionId: string } }
) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)
    const body = paperQuestionOverrideSchema.parse(await request.json())

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    // Optimistic lock on the PAPER (the same rowVersion PaperEditor already
    // tracks for every other save on this page) — not on the question,
    // since this edit never touches Question/QuestionVersion.
    if (paper.rowVersion !== body.rowVersion) {
      throw new ConflictError(
        'This paper was changed by another user while you were editing. Reload to see the latest version before saving.'
      )
    }

    const pq = await prisma.paperQuestion.findUnique({
      where: { id: params.paperQuestionId },
      include: { question: { select: { questionNumber: true } } },
    })
    if (!pq || pq.paperId !== params.id) {
      return NextResponse.json({ error: 'This question is not part of this paper.' }, { status: 404 })
    }

    await prisma.$transaction(async (tx) => {
      const lock = await tx.paper.updateMany({
        where: { id: params.id, rowVersion: body.rowVersion },
        data: { rowVersion: { increment: 1 } },
      })
      if (lock.count === 0) {
        throw new ConflictError(
          'This paper was changed by another user while you were editing. Reload to see the latest version before saving.'
        )
      }

      const overrideData = body.clear
        ? {
            questionTextOverride: null,
            optionAOverride: null,
            optionBOverride: null,
            optionCOverride: null,
            optionDOverride: null,
            correctAnswerOverride: null,
            explanationOverride: null,
            markingSchemeOverride: null,
          }
        : {
            ...(body.questionText !== undefined ? { questionTextOverride: body.questionText } : {}),
            ...(body.optionA !== undefined ? { optionAOverride: body.optionA } : {}),
            ...(body.optionB !== undefined ? { optionBOverride: body.optionB } : {}),
            ...(body.optionC !== undefined ? { optionCOverride: body.optionC } : {}),
            ...(body.optionD !== undefined ? { optionDOverride: body.optionD } : {}),
            ...(body.correctAnswer !== undefined ? { correctAnswerOverride: body.correctAnswer } : {}),
            ...(body.explanation !== undefined ? { explanationOverride: body.explanation } : {}),
            ...(body.markingScheme !== undefined ? { markingSchemeOverride: body.markingScheme } : {}),
          }

      await tx.paperQuestion.update({ where: { id: pq.id }, data: overrideData })

      await writeAuditLog(
        {
          userId: user.id,
          action: body.clear ? 'PAPER_QUESTION_OVERRIDE_CLEARED' : 'PAPER_QUESTION_OVERRIDDEN',
          entityType: 'PAPER',
          entityId: params.id,
          description: body.clear
            ? `${user.fullName ?? user.email} reverted question ${pq.question.questionNumber} in paper "${paper.title}" back to its original Question Bank text.`
            : `${user.fullName ?? user.email} edited question ${pq.question.questionNumber}'s text/options for paper "${paper.title}" only — the Question Bank and any other paper using this question are unaffected.`,
        },
        tx
      )
    })

    const [updatedPaper, questions] = await Promise.all([
      prisma.paper.findUniqueOrThrow({ where: { id: params.id } }),
      buildPaperSnapshot(params.id),
    ])

    return NextResponse.json({ paper: updatedPaper, questions })
  } catch (error) {
    return handleApiError(error)
  }
}
