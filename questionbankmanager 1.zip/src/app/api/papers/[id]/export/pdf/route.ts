import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { renderPaperHtml, type PaperExportMode, type PaperColumnLayout } from '@/lib/pdf/paperHtml'
import { renderHtmlToPdfBuffer } from '@/lib/pdf/paperPdf'

// GET /api/papers/:id/export/pdf?mode=question|answerKey|solutions
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    const mode = (searchParams.get('mode') as PaperExportMode) || 'question'
    if (!['question', 'answerKey', 'solutions'].includes(mode)) {
      return NextResponse.json({ error: 'Invalid export mode.' }, { status: 400 })
    }
    const columns: PaperColumnLayout = searchParams.get('columns') === '2' ? 2 : 1

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const questions = await buildPaperSnapshot(params.id)
    if (questions.length === 0) {
      return NextResponse.json({ error: 'This paper has no questions to export.' }, { status: 422 })
    }

    const html = renderPaperHtml(
      {
        title: paper.title,
        paperNumber: paper.paperNumber,
        instituteName: paper.instituteName,
        logoUrl: paper.logoUrl,
        examName: paper.examName,
        subjectLabel: paper.subjectLabel,
        classLabel: paper.classLabel,
        examDate: paper.examDate ? paper.examDate.toISOString().slice(0, 10) : null,
        examTime: paper.examTime,
        maxMarks: paper.maxMarks,
        instructions: paper.instructions,
        headerText: paper.headerText,
        footerText: paper.footerText,
      },
      questions,
      mode,
      columns
    )

    let pdfBuffer: Buffer
    try {
      pdfBuffer = await renderHtmlToPdfBuffer(html)
    } catch (err) {
      console.error('[paper export pdf] Puppeteer failed', err)
      return NextResponse.json(
        {
          error:
            'Server-side PDF generation is unavailable right now. Use the Print button on the paper’s print view instead — it produces an identical PDF via your browser’s Save as PDF option.',
        },
        { status: 502 }
      )
    }

    await writeAuditLog({
      userId: user.id,
      action: 'PAPER_EXPORTED_PDF',
      entityType: 'PAPER',
      entityId: params.id,
      description: `${user.fullName ?? user.email} exported paper "${paper.title}" (#${paper.paperNumber}) as PDF (${mode}).`,
    })

    return new NextResponse(new Uint8Array(pdfBuffer), {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="paper-${paper.paperNumber}-${mode}.pdf"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    return handleApiError(error)
  }
}
