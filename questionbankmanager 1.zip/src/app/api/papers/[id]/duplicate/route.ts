import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'

// POST /api/papers/:id/duplicate — creates a brand-new DRAFT paper with the
// same current question composition and settings, so a user can produce a
// fresh variant (e.g. a re-sit paper) without touching the original.
export async function POST(_request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.PAPER_EDIT)

    const source = await prisma.paper.findUnique({
      where: { id: params.id },
      include: { questions: { orderBy: { position: 'asc' } } },
    })
    if (!source) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const created = await prisma.$transaction(async (tx) => {
      const newPaper = await tx.paper.create({
        data: {
          title: `${source.title} (Copy)`,
          mode: source.mode,
          status: 'DRAFT',
          generationFilters: source.generationFilters as any,
          allowReuseOfPastQuestions: source.allowReuseOfPastQuestions,
          instituteName: source.instituteName,
          logoUrl: source.logoUrl,
          examName: source.examName,
          subjectLabel: source.subjectLabel,
          classLabel: source.classLabel,
          examDate: source.examDate,
          examTime: source.examTime,
          maxMarks: source.maxMarks,
          instructions: source.instructions,
          headerText: source.headerText,
          footerText: source.footerText,
          createdById: user.id,
        },
      })

      await tx.paperQuestion.createMany({
        data: source.questions.map((q) => ({
          paperId: newPaper.id,
          questionId: q.questionId,
          questionVersionId: q.questionVersionId,
          position: q.position,
          sectionLabel: q.sectionLabel,
          marks: q.marks,
        })),
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'PAPER_DUPLICATED',
          entityType: 'PAPER',
          entityId: newPaper.id,
          description: `${user.fullName ?? user.email} duplicated paper "${source.title}" (#${source.paperNumber}) into a new draft.`,
        },
        tx
      )

      return newPaper
    })

    return NextResponse.json({ item: { id: created.id, paperNumber: created.paperNumber } }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
