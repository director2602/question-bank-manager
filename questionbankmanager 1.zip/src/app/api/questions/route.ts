import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, requireUser, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { rateLimit } from '@/lib/rate-limit'
import { writeAuditLog } from '@/lib/audit'
import { createQuestionSchema, questionListQuerySchema } from '@/lib/validation/question'
import { questionWithRelations, toQuestionListItem } from '@/lib/serializers'
import { hashNormalizedText, tokenOverlapSimilarity, SIMILARITY_WARNING_THRESHOLD } from '@/lib/duplicate-detection'
import type { Prisma } from '@prisma/client'

// GET /api/questions — server-side filtered, paginated question list.
// Never returns the whole bank at once (performance requirement §20):
// pageSize is capped at 100 and callers must page through results.
export async function GET(request: Request) {
  try {
    await requireUser()

    const { searchParams } = new URL(request.url)
    const parsed = questionListQuerySchema.parse(Object.fromEntries(searchParams))
    // Used by the Paper Generator's manual question picker to hide
    // questions already used in a previous paper, mirroring the same rule
    // random generation enforces (see lib/paper-generation.ts).
    const excludeUsedInPapers = searchParams.get('excludeUsedInPapers') === 'true'

    const where: Prisma.QuestionWhereInput = {}
    if (excludeUsedInPapers) {
      where.paperQuestions = { none: {} }
    }

    if (parsed.status !== 'ALL') where.status = parsed.status
    if (parsed.subjectId) where.subjectId = parsed.subjectId
    if (parsed.examClassId) where.examClassId = parsed.examClassId
    if (parsed.codeId) where.codeId = parsed.codeId
    if (parsed.difficultyId) where.difficultyId = parsed.difficultyId
    if (parsed.questionType) where.questionType = parsed.questionType
    if (parsed.chapterId) where.chapterId = parsed.chapterId
    if (parsed.topicId) where.topicId = parsed.topicId
    if (parsed.examCategoryId) where.examCategoryId = parsed.examCategoryId
    if (parsed.createdById) where.createdById = parsed.createdById
    if (parsed.questionNumber) {
      where.questionNumber = { contains: parsed.questionNumber, mode: 'insensitive' }
    }
    if (parsed.dateFrom || parsed.dateTo) {
      where.createdAt = {
        ...(parsed.dateFrom ? { gte: new Date(parsed.dateFrom) } : {}),
        ...(parsed.dateTo ? { lte: new Date(parsed.dateTo) } : {}),
      }
    }
    if (parsed.q) {
      const q = parsed.q.trim()
      where.OR = [
        { currentVersion: { questionText: { contains: q, mode: 'insensitive' } } },
        { questionNumber: { contains: q, mode: 'insensitive' } },
        ...(isUuidLike(q) ? [{ id: q }] : []),
      ]
    }

    const orderBy: Prisma.QuestionOrderByWithRelationInput =
      parsed.sort === 'oldest'
        ? { createdAt: 'asc' }
        : parsed.sort === 'questionNumber'
          ? { questionNumber: 'asc' }
          : { createdAt: 'desc' }

    const [total, questions] = await prisma.$transaction([
      prisma.question.count({ where }),
      prisma.question.findMany({
        where,
        include: questionWithRelations,
        orderBy,
        skip: (parsed.page - 1) * parsed.pageSize,
        take: parsed.pageSize,
      }),
    ])

    return NextResponse.json({
      items: questions.map(toQuestionListItem),
      page: parsed.page,
      pageSize: parsed.pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / parsed.pageSize)),
    })
  } catch (error) {
    return handleApiError(error)
  }
}

// POST /api/questions — create a new question (metadata + first content
// version, inside a single transaction so the two are never left
// inconsistent). Runs duplicate detection first and returns a 409-like
// warning (still 200, `duplicateWarning` field) unless the caller has
// already confirmed via confirmDespiteDuplicateWarning.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_CREATE)

    const limit = rateLimit(`question-create:${user.id}`, { limit: 60, windowMs: 60_000 })
    if (!limit.allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please slow down and try again shortly.' },
        { status: 429 }
      )
    }

    const body = createQuestionSchema.parse(await request.json())

    const [subject, examClass, code, difficulty, chapter, topic, examCategory] = await Promise.all([
      prisma.subject.findUnique({ where: { id: body.subjectId } }),
      prisma.examClass.findUnique({ where: { id: body.examClassId } }),
      prisma.code.findUnique({ where: { id: body.codeId } }),
      prisma.difficultyLevel.findUnique({ where: { id: body.difficultyId } }),
      body.chapterId ? prisma.chapter.findUnique({ where: { id: body.chapterId } }) : Promise.resolve(null),
      body.topicId ? prisma.topic.findUnique({ where: { id: body.topicId } }) : Promise.resolve(null),
      body.examCategoryId ? prisma.examCategory.findUnique({ where: { id: body.examCategoryId } }) : Promise.resolve(null),
    ])
    if (!subject || !examClass || !code || !difficulty) {
      return NextResponse.json({ error: 'One or more selected tags are invalid.' }, { status: 400 })
    }
    if (body.examCategoryId && !examCategory) {
      return NextResponse.json({ error: 'The selected exam category is invalid.' }, { status: 400 })
    }
    if (body.chapterId && !chapter) {
      return NextResponse.json({ error: 'The selected chapter is invalid.' }, { status: 400 })
    }
    if (body.topicId && !topic) {
      return NextResponse.json({ error: 'The selected topic is invalid.' }, { status: 400 })
    }
    if (body.topicId && topic && body.chapterId && topic.chapterId !== body.chapterId) {
      return NextResponse.json({ error: 'The selected topic does not belong to the selected chapter.' }, { status: 400 })
    }

    const normalizedHash = hashNormalizedText(body.questionText)

    if (!body.confirmDespiteDuplicateWarning) {
      const candidates = await prisma.question.findMany({
        where: { status: 'ACTIVE', normalizedTextHash: normalizedHash },
        include: questionWithRelations,
        take: 5,
      })
      // Exact normalized match → hard warning. Also check near-duplicates
      // within the same subject for a softer, similarity-based warning.
      let similar = candidates
      if (similar.length === 0) {
        const sameSubject = await prisma.question.findMany({
          where: { status: 'ACTIVE', subjectId: body.subjectId },
          include: questionWithRelations,
          take: 200,
          orderBy: { createdAt: 'desc' },
        })
        similar = sameSubject.filter(
          (c) =>
            tokenOverlapSimilarity(c.currentVersion?.questionText ?? '', body.questionText) >=
            SIMILARITY_WARNING_THRESHOLD
        )
      }

      // Duplicate CODE/QUESTION NO check — soft warning, same
      // confirm-to-proceed flow as the text-similarity check, so an
      // accidental repeat is caught without hard-blocking a legitimate
      // re-use (e.g. the same paper-set code across chapters).
      const duplicateNumber = await prisma.question.findFirst({
        where: { status: 'ACTIVE', questionNumber: body.questionNumber },
        include: questionWithRelations,
      })

      if (similar.length > 0 || duplicateNumber) {
        return NextResponse.json({
          duplicateWarning: true,
          message: duplicateNumber
            ? `Question number "${body.questionNumber}" is already used by another question. Review below, then confirm to save anyway.`
            : 'A similar question already exists. Review it below, then confirm to save anyway.',
          candidates: (duplicateNumber ? [duplicateNumber, ...similar] : similar).slice(0, 5).map(toQuestionListItem),
        })
      }
    }

    const created = await prisma.$transaction(async (tx) => {
      const question = await tx.question.create({
        data: {
          questionNumber: body.questionNumber,
          subjectId: body.subjectId,
          examClassId: body.examClassId,
          codeId: body.codeId,
          difficultyId: body.difficultyId,
          questionType: body.questionType,
          chapterId: body.chapterId ?? null,
          topicId: body.topicId ?? null,
          examCategoryId: body.examCategoryId ?? null,
          normalizedTextHash: normalizedHash,
          createdById: user.id,
        },
      })

      const version = await tx.questionVersion.create({
        data: {
          questionId: question.id,
          versionNumber: 1,
          questionText: body.questionText,
          optionA: body.optionA ?? null,
          optionB: body.optionB ?? null,
          optionC: body.optionC ?? null,
          optionD: body.optionD ?? null,
          correctAnswer: body.correctAnswer ?? null,
          explanation: body.explanation ?? null,
          markingScheme: body.markingScheme ?? null,
          changeNote: 'Initial version',
          createdById: user.id,
        },
      })

      if (body.imageIds && body.imageIds.length > 0) {
        await tx.questionImage.updateMany({
          where: { id: { in: body.imageIds } },
          data: { questionVersionId: version.id },
        })
      }

      const updated = await tx.question.update({
        where: { id: question.id },
        data: { currentVersionId: version.id },
        include: questionWithRelations,
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_CREATED',
          entityType: 'QUESTION',
          entityId: question.id,
          description: `${user.fullName ?? user.email} added question ${body.questionNumber} (${subject.label} / ${examClass.label} / ${code.label} / ${difficulty.label}).`,
          newValue: { questionNumber: body.questionNumber, subject: subject.label, examClass: examClass.label },
        },
        tx
      )

      return updated
    })

    return NextResponse.json({ item: toQuestionListItem(created) }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}

function isUuidLike(v: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)
}
