import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError, ConflictError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { updateQuestionContentSchema } from '@/lib/validation/question'
import { questionWithRelations, toQuestionDetail } from '@/lib/serializers'
import { hashNormalizedText } from '@/lib/duplicate-detection'

// PATCH /api/questions/:id/content — MANUAL content edit. Per the Question
// Integrity Rule, the application itself never rewrites/auto-corrects this
// text; this endpoint only exists so a human can deliberately fix a real
// mistake, and doing so ALWAYS creates a new immutable question_versions
// row rather than mutating the old one, so historical papers referencing
// the prior version are unaffected.
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_EDIT_CONTENT)
    const body = updateQuestionContentSchema.parse(await request.json())

    const existing = await prisma.question.findUnique({
      where: { id: params.id },
      include: questionWithRelations,
    })
    if (!existing) {
      return NextResponse.json({ error: 'Question not found.' }, { status: 404 })
    }

    if (existing.rowVersion !== body.rowVersion) {
      throw new ConflictError(
        'This question was changed by another user while you were editing. Reload to see the latest version before saving.',
        await toQuestionDetail(existing)
      )
    }

    const nextVersionNumber = (existing.currentVersion?.versionNumber ?? 0) + 1
    const normalizedHash = hashNormalizedText(body.questionText)

    const updated = await prisma.$transaction(async (tx) => {
      const lock = await tx.question.updateMany({
        where: { id: params.id, rowVersion: body.rowVersion },
        data: { rowVersion: { increment: 1 } },
      })
      if (lock.count === 0) {
        throw new ConflictError(
          'This question was changed by another user while you were editing. Reload to see the latest version before saving.'
        )
      }

      const newVersion = await tx.questionVersion.create({
        data: {
          questionId: params.id,
          versionNumber: nextVersionNumber,
          questionText: body.questionText,
          optionA: body.optionA ?? null,
          optionB: body.optionB ?? null,
          optionC: body.optionC ?? null,
          optionD: body.optionD ?? null,
          correctAnswer: body.correctAnswer ?? null,
          explanation: body.explanation ?? null,
          changeNote: body.changeNote ?? `Manual edit by ${user.fullName ?? user.email}`,
          createdById: user.id,
        },
      })

      if (body.imageIds) {
        await tx.questionImage.updateMany({
          where: { id: { in: body.imageIds } },
          data: { questionVersionId: newVersion.id },
        })
      }

      await tx.question.update({
        where: { id: params.id },
        data: { currentVersionId: newVersion.id, normalizedTextHash: normalizedHash },
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_CONTENT_EDITED',
          entityType: 'QUESTION',
          entityId: params.id,
          description: `${user.fullName ?? user.email} manually edited the content of question ${existing.questionNumber} (v${existing.currentVersion?.versionNumber ?? '?'} → v${nextVersionNumber}). The prior version remains available in version history.`,
          previousValue: { versionNumber: existing.currentVersion?.versionNumber, questionText: existing.currentVersion?.questionText },
          newValue: { versionNumber: nextVersionNumber, questionText: body.questionText },
        },
        tx
      )

      return tx.question.findUniqueOrThrow({ where: { id: params.id }, include: questionWithRelations })
    })

    return NextResponse.json({ item: await toQuestionDetail(updated) })
  } catch (error) {
    return handleApiError(error)
  }
}
