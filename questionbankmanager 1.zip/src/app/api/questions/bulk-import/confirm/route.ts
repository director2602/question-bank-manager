import { NextResponse } from 'next/server'
import type { Prisma } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { confirmImportSchema } from '@/lib/validation/bulkImport'
import { validateAnswerForQuestionType } from '@/lib/validation/question'
import { hashNormalizedText } from '@/lib/duplicate-detection'
import { slugCode } from '@/lib/slugCode'

// Finds an existing Chapter for this Subject (case-insensitive on code or
// label — same match rule parseAndValidateCsv uses) or creates a new one,
// exactly like the Add Question form's CreatableSelect does inline. `cache`
// is shared across the whole import batch so ten rows naming the same new
// chapter create it only once instead of racing to insert it ten times.
async function findOrCreateChapter(
  tx: Prisma.TransactionClient,
  subjectId: string,
  label: string,
  cache: Map<string, string>,
  createdLabels: Map<string, string>
): Promise<string> {
  const key = `${subjectId}:${label.trim().toLowerCase()}`
  const cached = cache.get(key)
  if (cached) return cached

  const existing = await tx.chapter.findFirst({
    where: {
      subjectId,
      OR: [{ code: { equals: label, mode: 'insensitive' } }, { label: { equals: label, mode: 'insensitive' } }],
    },
  })
  if (existing) {
    cache.set(key, existing.id)
    return existing.id
  }

  const maxOrder = await tx.chapter.aggregate({ where: { subjectId }, _max: { sortOrder: true } })
  const created = await tx.chapter.create({
    data: { subjectId, code: slugCode(label, 'CH'), label: label.trim(), sortOrder: (maxOrder._max.sortOrder ?? 0) + 1 },
  })
  cache.set(key, created.id)
  createdLabels.set(created.id, created.label)
  return created.id
}

async function findOrCreateTopic(
  tx: Prisma.TransactionClient,
  chapterId: string,
  label: string,
  cache: Map<string, string>,
  createdLabels: Map<string, string>
): Promise<string> {
  const key = `${chapterId}:${label.trim().toLowerCase()}`
  const cached = cache.get(key)
  if (cached) return cached

  const existing = await tx.topic.findFirst({
    where: {
      chapterId,
      OR: [{ code: { equals: label, mode: 'insensitive' } }, { label: { equals: label, mode: 'insensitive' } }],
    },
  })
  if (existing) {
    cache.set(key, existing.id)
    return existing.id
  }

  const maxOrder = await tx.topic.aggregate({ where: { chapterId }, _max: { sortOrder: true } })
  const created = await tx.topic.create({
    data: { chapterId, code: slugCode(label, 'TP'), label: label.trim(), sortOrder: (maxOrder._max.sortOrder ?? 0) + 1 },
  })
  cache.set(key, created.id)
  createdLabels.set(created.id, created.label)
  return created.id
}

// POST /api/questions/bulk-import/confirm — commits the rows the user
// selected from the preview screen. Runs entirely inside ONE database
// transaction: if any row fails validation against the live lookup tables
// (e.g. a tag was deactivated between preview and confirm), the ENTIRE
// import is rolled back and nothing is partially saved — the response lists
// exactly which rows failed and why, so the user can fix and retry.
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_BULK_IMPORT)
    const body = confirmImportSchema.parse(await request.json())

    const selected = body.rows.filter((r) => body.rowIndexes.includes(r.rowIndex))
    if (selected.length === 0) {
      return NextResponse.json({ error: 'No rows were selected to import.' }, { status: 400 })
    }

    const [subjectIds, examClassIds, codeIds, difficultyIds, chapterRows, topicRows, examCategoryIds] = await Promise.all([
      prisma.subject.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.examClass.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.code.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.difficultyLevel.findMany({ where: { isActive: true }, select: { id: true } }),
      prisma.chapter.findMany({ where: { isActive: true }, select: { id: true, subjectId: true } }),
      prisma.topic.findMany({ where: { isActive: true }, select: { id: true, chapterId: true } }),
      prisma.examCategory.findMany({ where: { isActive: true }, select: { id: true } }),
    ])
    const validSubjects = new Set(subjectIds.map((s) => s.id))
    const validClasses = new Set(examClassIds.map((s) => s.id))
    const validCodes = new Set(codeIds.map((s) => s.id))
    const validDifficulties = new Set(difficultyIds.map((s) => s.id))
    const validExamCategories = new Set(examCategoryIds.map((s) => s.id))
    const chapterById = new Map(chapterRows.map((c) => [c.id, c]))
    const topicById = new Map(topicRows.map((t) => [t.id, t]))

    const rowErrors: Array<{ rowIndex: number; message: string }> = []
    for (const row of selected) {
      if (!validSubjects.has(row.subjectId)) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid subject.' })
      if (!validClasses.has(row.examClassId)) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid class/exam.' })
      if (!validCodes.has(row.codeId)) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid code.' })
      if (!validDifficulties.has(row.difficultyId))
        rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid difficulty.' })
      if (row.chapterId) {
        const chapter = chapterById.get(row.chapterId)
        if (!chapter) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid chapter.' })
        else if (chapter.subjectId !== row.subjectId)
          rowErrors.push({ rowIndex: row.rowIndex, message: 'Chapter does not belong to the selected subject.' })
      }
      if (row.topicId) {
        const topic = topicById.get(row.topicId)
        if (!topic) rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid topic.' })
        else if (row.chapterId && topic.chapterId !== row.chapterId)
          rowErrors.push({ rowIndex: row.rowIndex, message: 'Topic does not belong to the selected chapter.' })
      }
      if (row.examCategoryId && !validExamCategories.has(row.examCategoryId))
        rowErrors.push({ rowIndex: row.rowIndex, message: 'Invalid exam category.' })
      if (!row.questionText.trim()) rowErrors.push({ rowIndex: row.rowIndex, message: 'Question text is empty.' })
      const answerError = validateAnswerForQuestionType(row.questionType, row.correctAnswer ?? null)
      if (answerError) rowErrors.push({ rowIndex: row.rowIndex, message: answerError })
    }

    if (rowErrors.length > 0) {
      return NextResponse.json(
        {
          error: 'Some rows failed validation. No questions were imported — fix the rows below and try again.',
          rowErrors,
        },
        { status: 422 }
      )
    }

    // Larger timeout than Prisma's 5s default: a big-but-legal batch (up to
    // MAX_BULK_IMPORT_ROWS) needs more time to insert transactionally. For
    // very large recurring imports, move this to a background queue (see
    // README.md § Known Limitations & Future Work) instead of raising this
    // further.
    const importedIds = await prisma.$transaction(async (tx) => {
      const ids: string[] = []
      // Auto-create a Chapter/Topic the first time a new name is seen in
      // this batch (see findOrCreateChapter/findOrCreateTopic above) —
      // silent, per the "auto-create silently" bulk-import behavior; the
      // audit log below still records exactly what got created.
      const chapterCache = new Map<string, string>()
      const topicCache = new Map<string, string>()
      const createdChapterLabels = new Map<string, string>()
      const createdTopicLabels = new Map<string, string>()

      for (const row of selected) {
        let chapterId = row.chapterId ?? null
        if (!chapterId && row.chapterLabel) {
          chapterId = await findOrCreateChapter(tx, row.subjectId, row.chapterLabel, chapterCache, createdChapterLabels)
        }
        let topicId = row.topicId ?? null
        if (!topicId && row.topicLabel && chapterId) {
          topicId = await findOrCreateTopic(tx, chapterId, row.topicLabel, topicCache, createdTopicLabels)
        }

        const question = await tx.question.create({
          data: {
            questionNumber: row.questionNumber,
            subjectId: row.subjectId,
            examClassId: row.examClassId,
            chapterId,
            topicId,
            examCategoryId: row.examCategoryId ?? null,
            codeId: row.codeId,
            difficultyId: row.difficultyId,
            questionType: row.questionType,
            normalizedTextHash: hashNormalizedText(row.questionText),
            createdById: user.id,
          },
        })
        const version = await tx.questionVersion.create({
          data: {
            questionId: question.id,
            versionNumber: 1,
            questionText: row.questionText,
            optionA: row.optionA ?? null,
            optionB: row.optionB ?? null,
            optionC: row.optionC ?? null,
            optionD: row.optionD ?? null,
            correctAnswer: row.correctAnswer ?? null,
            explanation: row.explanation ?? null,
            markingScheme: row.markingScheme ?? null,
            changeNote: 'Imported via bulk CSV upload',
            createdById: user.id,
          },
        })
        await tx.question.update({ where: { id: question.id }, data: { currentVersionId: version.id } })

        if (row.imageIds && row.imageIds.length > 0) {
          await tx.questionImage.updateMany({
            where: { id: { in: row.imageIds } },
            data: { questionVersionId: version.id },
          })
        }

        ids.push(question.id)
      }

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_BULK_IMPORTED',
          entityType: 'QUESTION',
          entityId: null,
          description: `${user.fullName ?? user.email} bulk-imported ${ids.length} question(s) via CSV.`,
          newValue: { count: ids.length },
        },
        tx
      )

      for (const [chapterId, label] of createdChapterLabels) {
        await writeAuditLog(
          {
            userId: user.id,
            action: 'CHAPTER_CREATED',
            entityType: 'SETTINGS',
            entityId: chapterId,
            description: `${user.fullName ?? user.email} auto-created chapter "${label}" during bulk CSV import.`,
          },
          tx
        )
      }
      for (const [topicId, label] of createdTopicLabels) {
        await writeAuditLog(
          {
            userId: user.id,
            action: 'TOPIC_CREATED',
            entityType: 'SETTINGS',
            entityId: topicId,
            description: `${user.fullName ?? user.email} auto-created topic "${label}" during bulk CSV import.`,
          },
          tx
        )
      }

      return ids
    }, { timeout: 60_000, maxWait: 10_000 })

    return NextResponse.json({ importedCount: importedIds.length, questionIds: importedIds }, { status: 201 })
  } catch (error) {
    return handleApiError(error)
  }
}
