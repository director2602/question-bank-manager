import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { writeAuditLog } from '@/lib/audit'
import { bulkTagEditSchema } from '@/lib/validation/question'

// POST /api/questions/bulk-tag-edit — apply the same tag change(s) to many
// questions at once, transactionally: either every question is updated, or
// none are (business rule "bulk operations must be transactional").
export async function POST(request: Request) {
  try {
    const user = await requireRole(PERMISSIONS.QUESTION_EDIT_TAGS)
    const body = bulkTagEditSchema.parse(await request.json())

    const { subjectId, examClassId, codeId, difficultyId, questionIds } = body
    if (!subjectId && !examClassId && !codeId && !difficultyId) {
      return NextResponse.json({ error: 'Select at least one tag to change.' }, { status: 400 })
    }

    const result = await prisma.$transaction(async (tx) => {
      const updateResult = await tx.question.updateMany({
        where: { id: { in: questionIds } },
        data: {
          ...(subjectId ? { subjectId } : {}),
          ...(examClassId ? { examClassId } : {}),
          ...(codeId ? { codeId } : {}),
          ...(difficultyId ? { difficultyId } : {}),
          rowVersion: { increment: 1 },
        },
      })

      await writeAuditLog(
        {
          userId: user.id,
          action: 'QUESTION_BULK_TAG_EDITED',
          entityType: 'QUESTION',
          entityId: null,
          description: `${user.fullName ?? user.email} bulk-updated tags on ${updateResult.count} question(s).`,
          newValue: { questionIds, subjectId, examClassId, codeId, difficultyId },
        },
        tx
      )

      return updateResult.count
    })

    return NextResponse.json({ updatedCount: result })
  } catch (error) {
    return handleApiError(error)
  }
}
