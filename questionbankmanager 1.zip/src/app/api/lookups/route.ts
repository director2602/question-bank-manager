import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireUser } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

/**
 * Returns the active subjects/exam-classes/codes/difficulty-levels used to
 * populate every tag dropdown in the app. Cached briefly at the edge/CDN
 * layer via the Cache-Control header since these change rarely.
 */
export async function GET() {
  try {
    await requireUser()

    const [subjects, examClasses, codes, difficultyLevels] = await Promise.all([
      prisma.subject.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } }),
      prisma.examClass.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } }),
      prisma.code.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } }),
      prisma.difficultyLevel.findMany({ where: { isActive: true }, orderBy: { sortOrder: 'asc' } }),
    ])

    return NextResponse.json(
      { subjects, examClasses, codes, difficultyLevels },
      { headers: { 'Cache-Control': 'private, max-age=60' } }
    )
  } catch (error) {
    return handleApiError(error)
  }
}
