import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'

// GET /api/users — ADMIN only. Full user directory for the Users screen.
export async function GET() {
  try {
    await requireRole(PERMISSIONS.USER_MANAGE)

    const profiles = await prisma.profile.findMany({
      include: { role: true },
      orderBy: { createdAt: 'asc' },
    })

    return NextResponse.json({
      items: profiles.map((p) => ({
        id: p.id,
        email: p.email,
        fullName: p.fullName,
        role: p.role.code,
        roleLabel: p.role.label,
        isActive: p.isActive,
        createdAt: p.createdAt.toISOString(),
      })),
    })
  } catch (error) {
    return handleApiError(error)
  }
}
