import { PaperGeneratorForm } from '@/components/papers/PaperGeneratorForm'

export default function NewPaperPage() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Create Paper</h1>
        <p className="text-sm text-ink-muted">
          Select the tag combinations and quantities you need. Available question counts update live as you
          configure filters.
        </p>
      </div>
      <PaperGeneratorForm />
    </div>
  )
}
