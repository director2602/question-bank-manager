import Link from 'next/link'
import { getCurrentUser } from '@/lib/auth'

export default async function SettingsPage() {
  const user = await getCurrentUser()

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Settings</h1>
        <p className="text-sm text-ink-muted">System configuration and account details.</p>
      </div>

      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">Your account</h2>
        <dl className="grid grid-cols-2 gap-2 text-sm">
          <dt className="text-ink-muted">Name</dt>
          <dd>{user?.fullName ?? '—'}</dd>
          <dt className="text-ink-muted">Email</dt>
          <dd>{user?.email}</dd>
          <dt className="text-ink-muted">Role</dt>
          <dd>{user?.role}</dd>
        </dl>
      </div>

      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">Paper templates</h2>
        <p className="mb-3 text-sm text-ink-muted">
          Institute name, logo, header/footer, and default exam instructions used when generating papers.
        </p>
        <Link href="/papers/templates" className="btn-secondary">
          Manage templates
        </Link>
      </div>

      <div className="card p-5">
        <h2 className="mb-2 text-sm font-semibold text-ink">Users &amp; permissions</h2>
        <p className="mb-3 text-sm text-ink-muted">Manage who can access the system and what they can do.</p>
        <Link href="/users" className="btn-secondary">
          Manage users
        </Link>
      </div>
    </div>
  )
}
