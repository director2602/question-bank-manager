'use client'

import { useState } from 'react'
import { CsvUploadWizard } from '@/components/upload/CsvUploadWizard'
import { PdfUploadWizard } from '@/components/upload/PdfUploadWizard'

export default function BulkUploadPage() {
  const [tab, setTab] = useState<'csv' | 'pdf'>('csv')

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold text-ink">Bulk Upload</h1>
        <p className="text-sm text-ink-muted">
          Import many questions at once from a CSV spreadsheet or a PDF question paper. Nothing is saved until you
          review and confirm — imports run as a single transaction, so a bad row never partially corrupts the bank.
        </p>
      </div>

      <div className="flex gap-1 border-b border-surface-border">
        <button
          className={`px-4 py-2 text-sm font-medium ${tab === 'csv' ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-muted'}`}
          onClick={() => setTab('csv')}
        >
          CSV Import
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium ${tab === 'pdf' ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-muted'}`}
          onClick={() => setTab('pdf')}
        >
          PDF Import
        </button>
      </div>

      {tab === 'csv' ? <CsvUploadWizard /> : <PdfUploadWizard />}
    </div>
  )
}
