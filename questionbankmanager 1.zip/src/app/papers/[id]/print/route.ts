import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireRole, PERMISSIONS } from '@/lib/auth'
import { handleApiError } from '@/lib/api-error'
import { buildPaperSnapshot } from '@/lib/paper-snapshot'
import { renderPaperHtml, type PaperExportMode, type PaperColumnLayout } from '@/lib/pdf/paperHtml'

// GET /papers/:id/print?mode=question|answerKey|solutions
//
// Renders the paper as a standalone, print-ready HTML page (auth-gated by
// middleware.ts like every other non-public route). This is the CANONICAL
// "Printable HTML" / "Print Paper" feature (§14) — a user can hit
// Ctrl/Cmd+P and choose "Save as PDF" for an export that always works, with
// no server-side PDF pipeline dependency.
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    await requireRole(PERMISSIONS.PAPER_GENERATE)
    const { searchParams } = new URL(request.url)
    const mode = (searchParams.get('mode') as PaperExportMode) || 'question'
    if (!['question', 'answerKey', 'solutions'].includes(mode)) {
      return NextResponse.json({ error: 'Invalid print mode.' }, { status: 400 })
    }
    const columns: PaperColumnLayout = searchParams.get('columns') === '2' ? 2 : 1

    const paper = await prisma.paper.findUnique({ where: { id: params.id } })
    if (!paper) return NextResponse.json({ error: 'Paper not found.' }, { status: 404 })

    const questions = await buildPaperSnapshot(params.id)
    if (questions.length === 0) {
      return new NextResponse('<p style="font-family:sans-serif;padding:40px;">This paper has no questions yet.</p>', {
        headers: { 'Content-Type': 'text/html; charset=utf-8' },
      })
    }

    const html = renderPaperHtml(
      {
        title: paper.title,
        paperNumber: paper.paperNumber,
        instituteName: paper.instituteName,
        logoUrl: paper.logoUrl,
        examName: paper.examName,
        subjectLabel: paper.subjectLabel,
        classLabel: paper.classLabel,
        examDate: paper.examDate ? paper.examDate.toISOString().slice(0, 10) : null,
        examTime: paper.examTime,
        maxMarks: paper.maxMarks,
        instructions: paper.instructions,
        headerText: paper.headerText,
        footerText: paper.footerText,
      },
      questions,
      mode,
      columns
    )

    return new NextResponse(html, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })
  } catch (error) {
    return handleApiError(error)
  }
}
