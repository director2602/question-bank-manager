import type { RoleCode, PaperMode, PaperStatus, QuestionStatus } from '@prisma/client'

export type LookupOption = {
  id: string
  code: string
  label: string
  sortOrder: number
}

export type QuestionListItem = {
  id: string
  questionNumber: string
  status: QuestionStatus
  rowVersion: number
  subject: LookupOption
  examClass: LookupOption
  code: LookupOption
  difficulty: LookupOption
  questionText: string
  hasImages: boolean
  versionNumber: number
  createdBy: { id: string; fullName: string | null; email: string }
  createdAt: string
  updatedAt: string
}

export type QuestionDetail = QuestionListItem & {
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  images: { id: string; storagePath: string; fileName: string; sortOrder: number; url: string }[]
}

export type PaperFilterLine = {
  subjectId: string
  examClassId: string
  codeId: string
  difficultyId: string
  count: number
}

export type AvailableCountResult = PaperFilterLine & {
  available: number
  labels: { subject: string; examClass: string; code: string; difficulty: string }
}

export type PaperListItem = {
  id: string
  paperNumber: number
  title: string
  mode: PaperMode
  status: PaperStatus
  questionCount: number
  folder: { id: string; name: string } | null
  createdBy: { id: string; fullName: string | null; email: string }
  createdAt: string
  updatedAt: string
}

export type PaperFolderItem = {
  id: string
  name: string
  paperCount: number
  createdAt: string
}

export type SessionUser = {
  id: string
  email: string
  fullName: string | null
  role: RoleCode
}

export type ApiErrorBody = {
  error: string
  code?: string
  fieldErrors?: Record<string, string[] | undefined>
  shortfalls?: Array<{
    subject: string
    examClass: string
    code: string
    difficulty: string
    requested: number
    available: number
  }>
  latest?: unknown
}
