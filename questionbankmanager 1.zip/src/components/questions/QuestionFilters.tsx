'use client'

import type { Lookups } from '@/hooks/useLookups'

export type QuestionFilterState = {
  q: string
  subjectId: string
  examClassId: string
  codeId: string
  difficultyId: string
  questionNumber: string
}

export const EMPTY_FILTERS: QuestionFilterState = {
  q: '',
  subjectId: '',
  examClassId: '',
  codeId: '',
  difficultyId: '',
  questionNumber: '',
}

export function QuestionFilters({
  lookups,
  value,
  onChange,
}: {
  lookups: Lookups
  value: QuestionFilterState
  onChange: (next: QuestionFilterState) => void
}) {
  const set = <K extends keyof QuestionFilterState>(key: K, v: QuestionFilterState[K]) =>
    onChange({ ...value, [key]: v })

  return (
    <div className="card grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-6">
      <div className="lg:col-span-2">
        <label className="label">Search</label>
        <input
          className="input"
          placeholder="Question text, ID, or number…"
          value={value.q}
          onChange={(e) => set('q', e.target.value)}
        />
      </div>
      <div>
        <label className="label">Subject</label>
        <select className="input" value={value.subjectId} onChange={(e) => set('subjectId', e.target.value)}>
          <option value="">All</option>
          {lookups.subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Class / Exam</label>
        <select className="input" value={value.examClassId} onChange={(e) => set('examClassId', e.target.value)}>
          <option value="">All</option>
          {lookups.examClasses.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Code</label>
        <select className="input" value={value.codeId} onChange={(e) => set('codeId', e.target.value)}>
          <option value="">All</option>
          {lookups.codes.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="label">Difficulty</label>
        <select className="input" value={value.difficultyId} onChange={(e) => set('difficultyId', e.target.value)}>
          <option value="">All</option>
          {lookups.difficultyLevels.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}
