'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiFetch } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { useDebouncedValue } from '@/hooks/useDebouncedValue'
import { useEffect } from 'react'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { ImageUploader, type UploadedImage } from './ImageUploader'
import { HandwritingImageCleanup } from './HandwritingImageCleanup'
import { MathText } from './MathRenderer'
import type { QuestionListItem } from '@/types'

type FormState = {
  subjectId: string | null
  examClassId: string | null
  codeId: string | null
  difficultyId: string | null
  questionNumber: string
  questionText: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: string
  explanation: string
}

const EMPTY_CONTENT: Pick<
  FormState,
  'questionNumber' | 'questionText' | 'optionA' | 'optionB' | 'optionC' | 'optionD' | 'correctAnswer' | 'explanation'
> = {
  questionNumber: '',
  questionText: '',
  optionA: '',
  optionB: '',
  optionC: '',
  optionD: '',
  correctAnswer: '',
  explanation: '',
}

export function QuestionForm() {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()

  // Tags persist across "Save & Add Another" for fast sequential entry —
  // content fields reset. This matches §28 ("Fast Question Entry").
  const [form, setForm] = useState<FormState>({
    subjectId: null,
    examClassId: null,
    codeId: null,
    difficultyId: null,
    ...EMPTY_CONTENT,
  })
  const [images, setImages] = useState<UploadedImage[]>([])
  const [showPreview, setShowPreview] = useState(false)
  const [saving, setSaving] = useState(false)
  const [duplicates, setDuplicates] = useState<QuestionListItem[] | null>(null)
  const [checkingDuplicates, setCheckingDuplicates] = useState(false)

  const debouncedText = useDebouncedValue(form.questionText, 600)

  useEffect(() => {
    if (!debouncedText || debouncedText.trim().length < 12) {
      setDuplicates(null)
      return
    }
    let cancelled = false
    setCheckingDuplicates(true)
    apiFetch<{ hasDuplicates: boolean; candidates: QuestionListItem[] }>('/api/questions/check-duplicate', {
      method: 'POST',
      body: JSON.stringify({ questionText: debouncedText, subjectId: form.subjectId || undefined }),
    })
      .then((res) => {
        if (!cancelled) setDuplicates(res.hasDuplicates ? res.candidates : null)
      })
      .catch(() => {
        // Non-blocking — duplicate detection is a helpful warning, not a
        // hard requirement, so a failed check should never block entry.
      })
      .finally(() => {
        if (!cancelled) setCheckingDuplicates(false)
      })
    return () => {
      cancelled = true
    }
  }, [debouncedText, form.subjectId])

  function set<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function validate(): string | null {
    if (!form.subjectId || !form.examClassId || !form.codeId || !form.difficultyId) {
      return 'Please select Subject, Class/Exam, Code, and Difficulty.'
    }
    if (!form.questionNumber.trim()) return 'Question number is required.'
    if (!form.questionText.trim()) return 'Question text is required.'
    return null
  }

  async function submit(confirmDespiteDuplicateWarning: boolean, addAnother: boolean) {
    const validationError = validate()
    if (validationError) {
      show('error', validationError)
      return
    }
    setSaving(true)
    try {
      const result = await apiFetch<{ item?: QuestionListItem; duplicateWarning?: boolean; candidates?: QuestionListItem[] }>(
        '/api/questions',
        {
          method: 'POST',
          body: JSON.stringify({
            ...form,
            imageIds: images.map((i) => i.id),
            confirmDespiteDuplicateWarning,
          }),
        }
      )

      if (result.duplicateWarning) {
        setDuplicates(result.candidates ?? [])
        show('info', 'Similar question(s) found — review below, then save again to confirm.')
        return
      }

      show('success', `Question ${form.questionNumber} saved.`)

      if (addAnother) {
        setForm((f) => ({ ...f, ...EMPTY_CONTENT }))
        setImages([])
        setDuplicates(null)
      } else if (result.item) {
        router.push(`/questions/${result.item.id}`)
      }
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="card space-y-4 p-5 lg:col-span-2">
        <h2 className="text-sm font-semibold text-ink">Tags</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <SearchableSelect
            label="Subject"
            required
            options={lookups.subjects}
            value={form.subjectId}
            onChange={(v) => set('subjectId', v)}
          />
          <SearchableSelect
            label="Class / Exam"
            required
            options={lookups.examClasses}
            value={form.examClassId}
            onChange={(v) => set('examClassId', v)}
          />
          <SearchableSelect
            label="Code"
            required
            options={lookups.codes}
            value={form.codeId}
            onChange={(v) => set('codeId', v)}
          />
          <SearchableSelect
            label="Difficulty"
            required
            options={lookups.difficultyLevels}
            value={form.difficultyId}
            onChange={(v) => set('difficultyId', v)}
          />
        </div>
        <div className="grid grid-cols-2 gap-3 sm:w-1/2">
          <div>
            <label className="label">
              Question No. <span className="text-danger">*</span>
            </label>
            <input
              className="input"
              placeholder="e.g. 27 or Q-25"
              value={form.questionNumber}
              onChange={(e) => set('questionNumber', e.target.value)}
            />
          </div>
        </div>

        <hr className="border-surface-border" />

        <h2 className="text-sm font-semibold text-ink">Question Content</h2>
        <p className="text-xs text-ink-faint">
          Enter the question exactly as it should appear. Nothing here is auto-corrected or reformatted. Wrap math in
          $...$ for rendering, e.g. <code>$x^2 + 1$</code>.
        </p>
        <div>
          <label className="label">
            Question Text <span className="text-danger">*</span>
          </label>
          <textarea
            className="input min-h-[110px]"
            value={form.questionText}
            onChange={(e) => set('questionText', e.target.value)}
          />
          {checkingDuplicates && <p className="mt-1 text-xs text-ink-faint">Checking for similar questions…</p>}
        </div>

        {duplicates && duplicates.length > 0 && (
          <div className="rounded-md border border-amber-300 bg-amber-50 p-3">
            <p className="text-sm font-medium text-warning">A similar question already exists.</p>
            <ul className="mt-2 space-y-1.5">
              {duplicates.slice(0, 3).map((d) => (
                <li key={d.id} className="text-xs text-ink-muted">
                  <span className="font-medium text-ink">#{d.questionNumber}</span> —{' '}
                  <MathText text={d.questionText.slice(0, 140)} />
                </li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-ink-muted">
              Review the existing question above. If this is genuinely different, click &ldquo;Save anyway&rdquo;
              below.
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="label">Option A</label>
            <input className="input" value={form.optionA} onChange={(e) => set('optionA', e.target.value)} />
          </div>
          <div>
            <label className="label">Option B</label>
            <input className="input" value={form.optionB} onChange={(e) => set('optionB', e.target.value)} />
          </div>
          <div>
            <label className="label">Option C</label>
            <input className="input" value={form.optionC} onChange={(e) => set('optionC', e.target.value)} />
          </div>
          <div>
            <label className="label">Option D</label>
            <input className="input" value={form.optionD} onChange={(e) => set('optionD', e.target.value)} />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="label">Correct Answer</label>
            <input
              className="input"
              placeholder="e.g. A"
              value={form.correctAnswer}
              onChange={(e) => set('correctAnswer', e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="label">Explanation / Solution</label>
          <textarea
            className="input min-h-[80px]"
            value={form.explanation}
            onChange={(e) => set('explanation', e.target.value)}
          />
        </div>

        <ImageUploader images={images} onChange={setImages} />
        <HandwritingImageCleanup images={images} onChange={setImages} />

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-surface-border pt-4">
          <button type="button" className="btn-ghost" onClick={() => setShowPreview((p) => !p)}>
            {showPreview ? 'Hide preview' : 'Preview'}
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              className="btn-secondary"
              disabled={saving}
              onClick={() => submit(duplicates !== null, true)}
            >
              {saving ? 'Saving…' : duplicates ? 'Save anyway & Add Another' : 'Save & Add Another'}
            </button>
            <button
              type="button"
              className="btn-primary"
              disabled={saving}
              onClick={() => submit(duplicates !== null, false)}
            >
              {saving ? 'Saving…' : duplicates ? 'Save anyway' : 'Save Question'}
            </button>
          </div>
        </div>
      </div>

      {showPreview && (
        <div className="card h-fit p-5">
          <h2 className="mb-3 text-sm font-semibold text-ink">Preview</h2>
          <div className="space-y-2 text-sm">
            <p className="font-medium">
              Q{form.questionNumber || '—'}. <MathText text={form.questionText || 'Question text will appear here.'} />
            </p>
            <ul className="ml-4 space-y-1">
              {[form.optionA, form.optionB, form.optionC, form.optionD].map(
                (opt, idx) =>
                  opt && (
                    <li key={idx}>
                      <strong>{['A', 'B', 'C', 'D'][idx]}.</strong> <MathText text={opt} />
                    </li>
                  )
              )}
            </ul>
            {images.map((img) => (
              <img key={img.id} src={img.url} alt={img.fileName} className="max-h-56 rounded-md border border-surface-border" />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
