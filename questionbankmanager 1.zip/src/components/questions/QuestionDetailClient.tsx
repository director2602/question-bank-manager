'use client'

import { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { apiFetch, ApiError } from '@/lib/api-client'
import { useToast, errorMessage } from '@/components/ui/Toast'
import { useLookups } from '@/hooks/useLookups'
import { SearchableSelect } from '@/components/ui/SearchableSelect'
import { CreatableSelect } from '@/components/ui/CreatableSelect'
import { slugCode } from '@/lib/slugCode'
import { MathText } from './MathRenderer'
import { ImageUploader, type UploadedImage } from './ImageUploader'
import { DifficultyBadge, StatusBadge, Tag } from '@/components/ui/Badge'
import { ConfirmDialog } from '@/components/ui/Modal'
import type { QuestionDetail } from '@/types'
import type { RoleCode } from '@prisma/client'
import { VersionHistory } from './VersionHistory'

// Maps each option letter to its field key on the question/content-form
// objects. Iterating `OPTION_LETTERS` directly (rather than iterating the
// key array and re-deriving the letter by array index) keeps `letter`
// narrowed to 'A' | 'B' | 'C' | 'D' everywhere it's used as an index.
const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const
const OPTION_KEYS = {
  A: 'optionA',
  B: 'optionB',
  C: 'optionC',
  D: 'optionD',
} as const

export function QuestionDetailClient({ initial, role }: { initial: QuestionDetail; role: RoleCode }) {
  const router = useRouter()
  const { show } = useToast()
  const { lookups } = useLookups()
  const [question, setQuestion] = useState(initial)
  const canEdit = role === 'ADMIN' || role === 'EDITOR'
  const canDelete = role === 'ADMIN'

  const [editingTags, setEditingTags] = useState(false)
  const [tagForm, setTagForm] = useState({
    subjectId: initial.subject.id,
    examClassId: initial.examClass.id,
    codeId: initial.code.id,
    difficultyId: initial.difficulty.id,
    chapterId: initial.chapter?.id ?? null,
    topicId: initial.topic?.id ?? null,
    examCategoryId: initial.examCategory?.id ?? null,
    questionNumber: initial.questionNumber,
  })
  const [savingTags, setSavingTags] = useState(false)

  const chapterOptions = useMemo(
    () => (tagForm.subjectId ? lookups.chapters.filter((c) => c.subjectId === tagForm.subjectId) : []),
    [lookups.chapters, tagForm.subjectId]
  )
  const topicOptions = useMemo(
    () => (tagForm.chapterId ? lookups.topics.filter((t) => t.chapterId === tagForm.chapterId) : []),
    [lookups.topics, tagForm.chapterId]
  )

  async function createChapter(label: string): Promise<{ id: string; label: string } | null> {
    if (!tagForm.subjectId) return null
    try {
      const res = await apiFetch<{ item: { id: string } }>('/api/chapters', {
        method: 'POST',
        body: JSON.stringify({ subjectId: tagForm.subjectId, code: slugCode(label, 'CH'), label }),
      })
      show('success', `Chapter "${label}" added.`)
      return { id: res.item.id, label }
    } catch (err) {
      show('error', errorMessage(err))
      return null
    }
  }

  async function createTopic(label: string): Promise<{ id: string; label: string } | null> {
    if (!tagForm.chapterId) return null
    try {
      const res = await apiFetch<{ item: { id: string } }>('/api/topics', {
        method: 'POST',
        body: JSON.stringify({ chapterId: tagForm.chapterId, code: slugCode(label, 'TP'), label }),
      })
      show('success', `Topic "${label}" added.`)
      return { id: res.item.id, label }
    } catch (err) {
      show('error', errorMessage(err))
      return null
    }
  }

  const [editingContent, setEditingContent] = useState(false)
  const [contentForm, setContentForm] = useState({
    questionText: initial.questionText,
    optionA: initial.optionA ?? '',
    optionB: initial.optionB ?? '',
    optionC: initial.optionC ?? '',
    optionD: initial.optionD ?? '',
    correctAnswer: initial.correctAnswer ?? '',
    explanation: initial.explanation ?? '',
    changeNote: '',
  })
  const [newImages, setNewImages] = useState<UploadedImage[]>(initial.images.filter((i) => !i.optionSlot))
  const [newOptionImages, setNewOptionImages] = useState<Record<'A' | 'B' | 'C' | 'D', UploadedImage[]>>({
    A: initial.images.filter((i) => i.optionSlot === 'A'),
    B: initial.images.filter((i) => i.optionSlot === 'B'),
    C: initial.images.filter((i) => i.optionSlot === 'C'),
    D: initial.images.filter((i) => i.optionSlot === 'D'),
  })
  const [savingContent, setSavingContent] = useState(false)
  const [conflict, setConflict] = useState<string | null>(null)
  const [confirmArchive, setConfirmArchive] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [busy, setBusy] = useState(false)

  async function reload() {
    const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}`)
    setQuestion(result.item)
    setConflict(null)
  }

  async function saveTags() {
    setSavingTags(true)
    try {
      const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}/tags`, {
        method: 'PATCH',
        body: JSON.stringify({ ...tagForm, rowVersion: question.rowVersion }),
      })
      setQuestion(result.item)
      setEditingTags(false)
      show('success', 'Tags updated.')
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setConflict(err.body.error)
      } else {
        show('error', errorMessage(err))
      }
    } finally {
      setSavingTags(false)
    }
  }

  async function saveContent() {
    setSavingContent(true)
    try {
      const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}/content`, {
        method: 'PATCH',
        body: JSON.stringify({
          ...contentForm,
          rowVersion: question.rowVersion,
          imageIds: [
            ...newImages,
            ...newOptionImages.A,
            ...newOptionImages.B,
            ...newOptionImages.C,
            ...newOptionImages.D,
          ].map((i) => i.id),
        }),
      })
      setQuestion(result.item)
      setEditingContent(false)
      setNewImages([])
      setNewOptionImages({ A: [], B: [], C: [], D: [] })
      show('success', `Saved as version ${result.item.versionNumber}. The previous version remains in history.`)
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setConflict(err.body.error)
      } else {
        show('error', errorMessage(err))
      }
    } finally {
      setSavingContent(false)
    }
  }

  async function handleArchive() {
    setBusy(true)
    try {
      await apiFetch(`/api/questions/${question.id}/archive`, { method: 'POST' })
      show('success', 'Question archived.')
      router.push('/questions')
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusy(false)
      setConfirmArchive(false)
    }
  }

  async function handleDelete() {
    setBusy(true)
    try {
      await apiFetch(`/api/questions/${question.id}`, { method: 'DELETE' })
      show('success', 'Question permanently deleted.')
      router.push('/questions')
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusy(false)
      setConfirmDelete(false)
    }
  }

  async function handleDuplicate() {
    setBusy(true)
    try {
      const result = await apiFetch<{ item: QuestionDetail }>(`/api/questions/${question.id}/duplicate`, {
        method: 'POST',
      })
      show('success', 'Duplicated. Opening the copy…')
      router.push(`/questions/${result.item.id}`)
    } catch (err) {
      show('error', errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold text-ink">Question #{question.questionNumber}</h1>
            <StatusBadge status={question.status} />
          </div>
          <p className="text-sm text-ink-muted">
            v{question.versionNumber} · Created by {question.createdBy.fullName ?? question.createdBy.email} on{' '}
            {new Date(question.createdAt).toLocaleDateString()}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/questions" className="btn-secondary">
            Back to list
          </Link>
          {canEdit && (
            <button className="btn-secondary" onClick={handleDuplicate} disabled={busy}>
              Duplicate
            </button>
          )}
          {canEdit && question.status === 'ACTIVE' && (
            <button className="btn-secondary" onClick={() => setConfirmArchive(true)}>
              Archive
            </button>
          )}
          {canDelete && (
            <button className="btn-danger" onClick={() => setConfirmDelete(true)}>
              Delete
            </button>
          )}
        </div>
      </div>

      {conflict && (
        <div className="rounded-md border border-red-300 bg-red-50 px-4 py-3 text-sm text-danger">
          {conflict}{' '}
          <button className="ml-2 font-medium underline" onClick={reload}>
            Reload latest version
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Tags</h2>
            {canEdit && !editingTags && (
              <button className="btn-ghost !px-2 !py-1" onClick={() => setEditingTags(true)}>
                Edit tags
              </button>
            )}
          </div>
          {!editingTags ? (
            <div className="flex flex-wrap gap-1.5">
              <Tag>{question.subject.label}</Tag>
              <Tag>{question.examClass.label}</Tag>
              <Tag>{question.code.label}</Tag>
              <DifficultyBadge code={question.difficulty.code} label={question.difficulty.label} />
              {question.chapter && <Tag>{question.chapter.label}</Tag>}
              {question.topic && <Tag>{question.topic.label}</Tag>}
              {question.examCategory && <Tag>{question.examCategory.label}</Tag>}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <SearchableSelect
                  label="Subject"
                  options={lookups.subjects}
                  value={tagForm.subjectId}
                  onChange={(v) => setTagForm((f) => ({ ...f, subjectId: v, chapterId: null, topicId: null }))}
                />
                <SearchableSelect
                  label="Class / Exam"
                  options={lookups.examClasses}
                  value={tagForm.examClassId}
                  onChange={(v) => setTagForm((f) => ({ ...f, examClassId: v }))}
                />
                <SearchableSelect
                  label="Code"
                  options={lookups.codes}
                  value={tagForm.codeId}
                  onChange={(v) => setTagForm((f) => ({ ...f, codeId: v }))}
                />
                <SearchableSelect
                  label="Difficulty"
                  options={lookups.difficultyLevels}
                  value={tagForm.difficultyId}
                  onChange={(v) => setTagForm((f) => ({ ...f, difficultyId: v }))}
                />
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <label className="label">Chapter Name</label>
                  <CreatableSelect
                    options={chapterOptions}
                    value={tagForm.chapterId}
                    disabled={!tagForm.subjectId}
                    placeholder={tagForm.subjectId ? 'Type a chapter name…' : 'Select a Subject first'}
                    onSelectExisting={(id) => setTagForm((f) => ({ ...f, chapterId: id, topicId: null }))}
                    onClear={() => setTagForm((f) => ({ ...f, chapterId: null, topicId: null }))}
                    onCreateNew={createChapter}
                  />
                </div>
                <div>
                  <label className="label">Topic Name</label>
                  <CreatableSelect
                    options={topicOptions}
                    value={tagForm.topicId}
                    disabled={!tagForm.chapterId}
                    placeholder={tagForm.chapterId ? 'Type a topic name…' : 'Select a Chapter first'}
                    onSelectExisting={(id) => setTagForm((f) => ({ ...f, topicId: id }))}
                    onClear={() => setTagForm((f) => ({ ...f, topicId: null }))}
                    onCreateNew={createTopic}
                  />
                </div>
                <div>
                  <label className="label">Exam Category</label>
                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <SearchableSelect
                        options={lookups.examCategories}
                        value={tagForm.examCategoryId}
                        onChange={(v) => setTagForm((f) => ({ ...f, examCategoryId: v }))}
                        placeholder="None"
                      />
                    </div>
                    {tagForm.examCategoryId && (
                      <button
                        type="button"
                        className="btn-ghost !px-2 !py-1"
                        onClick={() => setTagForm((f) => ({ ...f, examCategoryId: null }))}
                      >
                        Clear
                      </button>
                    )}
                  </div>
                </div>
              </div>
              <div className="w-40">
                <label className="label">Question No.</label>
                <input
                  className="input"
                  value={tagForm.questionNumber}
                  onChange={(e) => setTagForm((f) => ({ ...f, questionNumber: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <button className="btn-secondary" onClick={() => setEditingTags(false)} disabled={savingTags}>
                  Cancel
                </button>
                <button className="btn-primary" onClick={saveTags} disabled={savingTags}>
                  {savingTags ? 'Saving…' : 'Save Tags'}
                </button>
              </div>
            </div>
          )}

          <hr className="my-4 border-surface-border" />

          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Content</h2>
            {canEdit && !editingContent && (
              <button
                className="btn-ghost !px-2 !py-1"
                onClick={() => {
                  setContentForm({
                    questionText: question.questionText,
                    optionA: question.optionA ?? '',
                    optionB: question.optionB ?? '',
                    optionC: question.optionC ?? '',
                    optionD: question.optionD ?? '',
                    correctAnswer: question.correctAnswer ?? '',
                    explanation: question.explanation ?? '',
                    changeNote: '',
                  })
                  setNewImages(question.images.filter((i) => !i.optionSlot))
                  setNewOptionImages({
                    A: question.images.filter((i) => i.optionSlot === 'A'),
                    B: question.images.filter((i) => i.optionSlot === 'B'),
                    C: question.images.filter((i) => i.optionSlot === 'C'),
                    D: question.images.filter((i) => i.optionSlot === 'D'),
                  })
                  setEditingContent(true)
                }}
              >
                Edit content manually
              </button>
            )}
          </div>

          {editingContent && (
            <div className="mb-3 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-warning">
              You are manually editing the original question. Saving creates a new version — the current version
              stays in history and any papers already generated keep showing the version they used.
            </div>
          )}

          {!editingContent ? (
            <div className="space-y-3 text-sm">
              <p>
                <MathText text={question.questionText} />
              </p>
              {question.images.filter((i) => !i.optionSlot).length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {question.images
                    .filter((i) => !i.optionSlot)
                    .map((img) => (
                      <img key={img.id} src={img.url} alt={img.fileName} className="max-h-48 rounded-md border border-surface-border" />
                    ))}
                </div>
              )}
              <ul className="ml-4 space-y-1.5">
                {OPTION_LETTERS.map((letter) => {
                  const key = OPTION_KEYS[letter]
                  const optionImgs = question.images.filter((i) => i.optionSlot === letter)
                  if (!question[key] && optionImgs.length === 0) return null
                  return (
                    <li key={key}>
                      <strong>{letter}.</strong> {question[key] && <MathText text={question[key]} />}
                      {optionImgs.length > 0 && (
                        <div className="mt-1 flex flex-wrap gap-1.5">
                          {optionImgs.map((img) => (
                            <img key={img.id} src={img.url} alt={img.fileName} className="h-16 w-16 rounded border border-surface-border object-cover" />
                          ))}
                        </div>
                      )}
                    </li>
                  )
                })}
              </ul>
              {question.correctAnswer && (
                <p className="text-ink-muted">
                  <strong>Correct answer:</strong> {question.correctAnswer}
                </p>
              )}
              {question.explanation && (
                <p className="text-ink-muted">
                  <strong>Explanation:</strong> <MathText text={question.explanation} />
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="label">Question Text</label>
                <textarea
                  className="input min-h-[100px]"
                  value={contentForm.questionText}
                  onChange={(e) => setContentForm((f) => ({ ...f, questionText: e.target.value }))}
                />
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {OPTION_LETTERS.map((letter) => {
                  const key = OPTION_KEYS[letter]
                  return (
                    <div key={key}>
                      <label className="label">Option {letter}</label>
                      <input
                        className="input"
                        value={contentForm[key]}
                        onChange={(e) => setContentForm((f) => ({ ...f, [key]: e.target.value }))}
                      />
                      <div className="mt-1.5">
                        <ImageUploader
                          compact
                          optionSlot={letter}
                          images={newOptionImages[letter]}
                          onChange={(next) => setNewOptionImages((prev) => ({ ...prev, [letter]: next }))}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
              <div>
                <label className="label">Correct Answer</label>
                <input
                  className="input w-40"
                  value={contentForm.correctAnswer}
                  onChange={(e) => setContentForm((f) => ({ ...f, correctAnswer: e.target.value }))}
                />
              </div>
              <div>
                <label className="label">Explanation</label>
                <textarea
                  className="input min-h-[70px]"
                  value={contentForm.explanation}
                  onChange={(e) => setContentForm((f) => ({ ...f, explanation: e.target.value }))}
                />
              </div>
              <ImageUploader images={newImages} onChange={setNewImages} />
              <div>
                <label className="label">Reason for this edit (optional, recorded in history)</label>
                <input
                  className="input"
                  value={contentForm.changeNote}
                  onChange={(e) => setContentForm((f) => ({ ...f, changeNote: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <button className="btn-secondary" onClick={() => setEditingContent(false)} disabled={savingContent}>
                  Cancel
                </button>
                <button className="btn-primary" onClick={saveContent} disabled={savingContent}>
                  {savingContent ? 'Saving…' : 'Save New Version'}
                </button>
              </div>
            </div>
          )}
        </div>

        <VersionHistory questionId={question.id} />
      </div>

      <ConfirmDialog
        open={confirmArchive}
        title="Archive this question?"
        message="Archived questions are hidden from search and paper generation but can be restored at any time."
        confirmLabel="Archive"
        loading={busy}
        onCancel={() => setConfirmArchive(false)}
        onConfirm={handleArchive}
      />
      <ConfirmDialog
        open={confirmDelete}
        title="Permanently delete this question?"
        message="This cannot be undone. Questions used in any paper cannot be deleted — archive them instead."
        danger
        confirmLabel="Delete"
        loading={busy}
        onCancel={() => setConfirmDelete(false)}
        onConfirm={handleDelete}
      />
    </div>
  )
}
