'use client'

import { useMemo, useState, useRef, useEffect } from 'react'
import type { LookupOption } from '@/types'

/**
 * Searchable dropdown for tag selection (Subject/Class/Code/Difficulty).
 * Keyboard-friendly: type to filter, Arrow keys to move, Enter to select,
 * Escape to close — per the "keyboard-friendly workflows" requirement.
 */
export function SearchableSelect({
  label,
  options,
  value,
  onChange,
  placeholder = 'Select…',
  required = false,
}: {
  label: string
  options: LookupOption[]
  value: string | null
  onChange: (id: string) => void
  placeholder?: string
  required?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [highlight, setHighlight] = useState(0)
  const rootRef = useRef<HTMLDivElement>(null)

  const selected = options.find((o) => o.id === value) ?? null

  const filtered = useMemo(() => {
    if (!query.trim()) return options
    const q = query.toLowerCase()
    return options.filter((o) => o.label.toLowerCase().includes(q) || o.code.toLowerCase().includes(q))
  }, [options, query])

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [])

  return (
    <div ref={rootRef} className="relative">
      <label className="label">
        {label} {required && <span className="text-danger">*</span>}
      </label>
      <button
        type="button"
        className="input flex items-center justify-between text-left"
        onClick={() => setOpen((o) => !o)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault()
            setOpen(true)
            setHighlight((h) => Math.min(h + 1, filtered.length - 1))
          }
        }}
      >
        <span className={selected ? 'text-ink' : 'text-ink-faint'}>{selected ? selected.label : placeholder}</span>
        <span className="text-ink-faint">▾</span>
      </button>
      {open && (
        <div className="absolute z-20 mt-1 w-full rounded-md border border-surface-border bg-white shadow-card">
          <input
            autoFocus
            className="input rounded-b-none border-x-0 border-t-0"
            placeholder="Search…"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setHighlight(0)
            }}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') {
                e.preventDefault()
                setHighlight((h) => Math.min(h + 1, filtered.length - 1))
              } else if (e.key === 'ArrowUp') {
                e.preventDefault()
                setHighlight((h) => Math.max(h - 1, 0))
              } else if (e.key === 'Enter') {
                e.preventDefault()
                const opt = filtered[highlight]
                if (opt) {
                  onChange(opt.id)
                  setOpen(false)
                  setQuery('')
                }
              } else if (e.key === 'Escape') {
                setOpen(false)
              }
            }}
          />
          <ul className="max-h-56 overflow-y-auto py-1">
            {filtered.length === 0 && <li className="px-3 py-2 text-sm text-ink-faint">No matches</li>}
            {filtered.map((o, idx) => (
              <li key={o.id}>
                <button
                  type="button"
                  className={`block w-full px-3 py-2 text-left text-sm ${
                    idx === highlight ? 'bg-brand-50 text-brand-700' : 'text-ink hover:bg-surface-muted'
                  }`}
                  onClick={() => {
                    onChange(o.id)
                    setOpen(false)
                    setQuery('')
                  }}
                >
                  {o.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
