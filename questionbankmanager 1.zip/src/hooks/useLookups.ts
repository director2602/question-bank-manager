'use client'

import { useEffect, useState } from 'react'
import { apiFetch } from '@/lib/api-client'
import type { LookupOption } from '@/types'

export type Lookups = {
  subjects: LookupOption[]
  examClasses: LookupOption[]
  codes: LookupOption[]
  difficultyLevels: LookupOption[]
}

const EMPTY: Lookups = { subjects: [], examClasses: [], codes: [], difficultyLevels: [] }

export function useLookups() {
  const [lookups, setLookups] = useState<Lookups>(EMPTY)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    apiFetch<Lookups>('/api/lookups')
      .then((data) => {
        if (!cancelled) setLookups(data)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  return { lookups, loading }
}
