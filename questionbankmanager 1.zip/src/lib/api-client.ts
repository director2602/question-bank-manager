'use client'

import type { ApiErrorBody } from '@/types'

export class ApiError extends Error {
  status: number
  body: ApiErrorBody
  constructor(status: number, body: ApiErrorBody) {
    super(body.error || 'Request failed')
    this.status = status
    this.body = body
  }
}

/**
 * Thin fetch wrapper used by every client component. Centralizes JSON
 * handling and turns a non-2xx response into a typed ApiError carrying the
 * server's human-readable message — so the UI never has to guess or show a
 * raw network/HTTP error to the user (business rule §21/§33).
 */
export async function apiFetch<T = unknown>(url: string, init?: RequestInit): Promise<T> {
  let res: Response
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        ...(init?.body && !(init.body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}),
        ...(init?.headers || {}),
      },
    })
  } catch (networkError) {
    throw new ApiError(0, {
      error: 'Could not reach the server. Check your connection and try again.',
    })
  }

  let body: unknown = null
  const text = await res.text()
  if (text) {
    try {
      body = JSON.parse(text)
    } catch {
      body = null
    }
  }

  if (!res.ok) {
    const errorBody = (body as ApiErrorBody) || { error: `Request failed (${res.status}).` }
    throw new ApiError(res.status, errorBody)
  }

  return body as T
}
