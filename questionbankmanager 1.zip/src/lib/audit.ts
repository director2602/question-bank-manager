import 'server-only'
import { prisma } from '@/lib/prisma'
import type { Prisma } from '@prisma/client'

export type AuditAction =
  | 'QUESTION_CREATED'
  | 'QUESTION_CONTENT_EDITED'
  | 'QUESTION_TAGS_EDITED'
  | 'QUESTION_ARCHIVED'
  | 'QUESTION_RESTORED'
  | 'QUESTION_DELETED'
  | 'QUESTION_DUPLICATED'
  | 'QUESTION_BULK_IMPORTED'
  | 'QUESTION_BULK_TAG_EDITED'
  | 'QUESTION_BULK_ARCHIVED'
  | 'QUESTION_BULK_DELETED'
  | 'QUESTION_EXPORTED'
  | 'PAPER_GENERATED'
  | 'PAPER_EDITED'
  | 'PAPER_SNAPSHOT_SAVED'
  | 'PAPER_DUPLICATED'
  | 'PAPER_DELETED'
  | 'PAPER_EXPORTED_PDF'
  | 'PAPER_EXPORTED_DOCX'
  | 'PAPER_EXPORTED_CSV'
  | 'PAPER_MOVED_TO_FOLDER'
  | 'PAPER_SETTINGS_UPDATED'
  | 'FOLDER_CREATED'
  | 'FOLDER_RENAMED'
  | 'FOLDER_DELETED'
  | 'IMAGE_PROCESSED'
  | 'USER_ROLE_CHANGED'
  | 'USER_STATUS_CHANGED'
  | 'SETTINGS_UPDATED'
  | 'SIGN_IN_FAILED'

/**
 * Writes one audit_logs row. Accepts an optional Prisma transaction client
 * (`tx`) so the log entry is committed atomically with the operation it
 * describes — a paper generation and its audit row either both land or
 * neither does.
 */
export async function writeAuditLog(
  params: {
    userId: string | null
    action: AuditAction
    entityType: 'QUESTION' | 'PAPER' | 'FOLDER' | 'IMAGE' | 'USER' | 'SETTINGS' | 'AUTH'
    entityId?: string | null
    description: string
    previousValue?: unknown
    newValue?: unknown
  },
  tx?: Prisma.TransactionClient
) {
  const client = tx ?? prisma
  await client.auditLog.create({
    data: {
      userId: params.userId,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId ?? null,
      description: params.description,
      previousValue: params.previousValue === undefined ? undefined : (params.previousValue as Prisma.InputJsonValue),
      newValue: params.newValue === undefined ? undefined : (params.newValue as Prisma.InputJsonValue),
    },
  })
}
