import 'server-only'
import { prisma } from '@/lib/prisma'
import type { PaperFilterLine, AvailableCountResult } from '@/types'

/**
 * Question IDs that have ever appeared in ANY paper (paper_questions), used
 * to enforce "do not reuse questions from previous papers" when the caller
 * has not explicitly opted into reuse.
 */
async function getGlobalUsedQuestionIds(): Promise<Set<string>> {
  const rows = await prisma.paperQuestion.findMany({ select: { questionId: true }, distinct: ['questionId'] })
  return new Set(rows.map((r) => r.questionId))
}

async function getLookupLabels() {
  const [subjects, examClasses, codes, difficulties] = await Promise.all([
    prisma.subject.findMany(),
    prisma.examClass.findMany(),
    prisma.code.findMany(),
    prisma.difficultyLevel.findMany(),
  ])
  return {
    subject: new Map(subjects.map((s) => [s.id, s.label])),
    examClass: new Map(examClasses.map((s) => [s.id, s.label])),
    code: new Map(codes.map((s) => [s.id, s.label])),
    difficulty: new Map(difficulties.map((s) => [s.id, s.label])),
  }
}

/**
 * For every requested (subject, examClass, code, difficulty) combination,
 * counts how many ACTIVE questions currently qualify — optionally excluding
 * questions already used in a previous paper. This powers both the live
 * "Available: 84" indicator in the Paper Generator UI and the server-side
 * check performed at generation time.
 */
export async function computeAvailableCounts(
  lines: Array<Pick<PaperFilterLine, 'subjectId' | 'examClassId' | 'codeId' | 'difficultyId'>>,
  allowReuseOfPastQuestions: boolean
): Promise<AvailableCountResult[]> {
  const [labels, usedIds] = await Promise.all([
    getLookupLabels(),
    allowReuseOfPastQuestions ? Promise.resolve(new Set<string>()) : getGlobalUsedQuestionIds(),
  ])

  const results: AvailableCountResult[] = []
  for (const line of lines) {
    const matches = await prisma.question.findMany({
      where: {
        status: 'ACTIVE',
        subjectId: line.subjectId,
        examClassId: line.examClassId,
        codeId: line.codeId,
        difficultyId: line.difficultyId,
      },
      select: { id: true },
    })
    const available = allowReuseOfPastQuestions
      ? matches.length
      : matches.filter((m) => !usedIds.has(m.id)).length

    results.push({
      subjectId: line.subjectId,
      examClassId: line.examClassId,
      codeId: line.codeId,
      difficultyId: line.difficultyId,
      count: 0,
      available,
      labels: {
        subject: labels.subject.get(line.subjectId) ?? 'Unknown',
        examClass: labels.examClass.get(line.examClassId) ?? 'Unknown',
        code: labels.code.get(line.codeId) ?? 'Unknown',
        difficulty: labels.difficulty.get(line.difficultyId) ?? 'Unknown',
      },
    })
  }
  return results
}

export type ShortfallLine = {
  subject: string
  examClass: string
  code: string
  difficulty: string
  requested: number
  available: number
}

export type RandomSelectionResult = {
  shortfalls: ShortfallLine[]
  selectedQuestionIds: string[]
  perLine: Array<{ line: PaperFilterLine; selectedQuestionIds: string[] }>
}

/**
 * Randomly selects the requested number of questions per filter line,
 * WITHOUT replacement and WITHOUT ever selecting the same question twice
 * across the whole paper. Uses a Fisher–Yates shuffle over each line's
 * eligible ID pool so selection is unbiased.
 */
export async function selectRandomQuestions(
  lines: PaperFilterLine[],
  allowReuseOfPastQuestions: boolean
): Promise<RandomSelectionResult> {
  const [labels, usedIds] = await Promise.all([
    getLookupLabels(),
    allowReuseOfPastQuestions ? Promise.resolve(new Set<string>()) : getGlobalUsedQuestionIds(),
  ])

  const shortfalls: ShortfallLine[] = []
  const perLine: RandomSelectionResult['perLine'] = []
  const alreadySelected = new Set<string>()

  for (const line of lines) {
    if (line.count === 0) {
      perLine.push({ line, selectedQuestionIds: [] })
      continue
    }

    const pool = await prisma.question.findMany({
      where: {
        status: 'ACTIVE',
        subjectId: line.subjectId,
        examClassId: line.examClassId,
        codeId: line.codeId,
        difficultyId: line.difficultyId,
        ...(allowReuseOfPastQuestions ? {} : { id: { notIn: Array.from(usedIds) } }),
      },
      select: { id: true },
    })

    const eligible = pool.map((p) => p.id).filter((id) => !alreadySelected.has(id))
    shuffleInPlace(eligible)

    const take = Math.min(line.count, eligible.length)
    const chosen = eligible.slice(0, take)
    chosen.forEach((id) => alreadySelected.add(id))

    perLine.push({ line, selectedQuestionIds: chosen })

    if (take < line.count) {
      shortfalls.push({
        subject: labels.subject.get(line.subjectId) ?? 'Unknown',
        examClass: labels.examClass.get(line.examClassId) ?? 'Unknown',
        code: labels.code.get(line.codeId) ?? 'Unknown',
        difficulty: labels.difficulty.get(line.difficultyId) ?? 'Unknown',
        requested: line.count,
        available: eligible.length,
      })
    }
  }

  return {
    shortfalls,
    selectedQuestionIds: perLine.flatMap((p) => p.selectedQuestionIds),
    perLine,
  }
}

function shuffleInPlace<T>(arr: T[]): void {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
}
