import { z } from 'zod'

export const updateUserRoleSchema = z.object({
  roleCode: z.enum(['ADMIN', 'EDITOR', 'VIEWER']),
})

export const updateUserStatusSchema = z.object({
  isActive: z.boolean(),
})
