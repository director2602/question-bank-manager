import { z } from 'zod'

const uuid = z.string().uuid()

export const paperFilterLineSchema = z.object({
  subjectId: uuid,
  examClassId: uuid,
  codeId: uuid,
  difficultyId: uuid,
  count: z.number().int().min(0).max(500),
})

export const availableCountQuerySchema = z.object({
  lines: z.array(
    z.object({ subjectId: uuid, examClassId: uuid, codeId: uuid, difficultyId: uuid })
  ),
  allowReuseOfPastQuestions: z.boolean().optional().default(false),
})

export const generatePaperSchema = z.object({
  title: z.string().trim().min(1).max(200),
  mode: z.enum(['RANDOM', 'MANUAL']),
  lines: z.array(paperFilterLineSchema).min(1, 'Select at least one subject/class/code/difficulty combination.'),
  allowReuseOfPastQuestions: z.boolean().optional().default(false),
  // Only used when mode === 'MANUAL': explicit question IDs the user picked,
  // still validated server-side against the same filter lines/counts.
  manualQuestionIds: z.array(uuid).optional(),

  instituteName: z.string().trim().max(200).optional(),
  // A relative site path (e.g. "/branding/logo.png") or an absolute URL —
  // both are valid, so this deliberately does NOT use z.string().url().
  logoUrl: z.string().trim().max(2000).optional(),
  examName: z.string().trim().max(200).optional(),
  subjectLabel: z.string().trim().max(100).optional(),
  classLabel: z.string().trim().max(100).optional(),
  examDate: z.string().datetime().optional(),
  examTime: z.string().trim().max(50).optional(),
  maxMarks: z.number().int().positive().optional(),
  instructions: z.string().trim().max(5000).optional(),
  headerText: z.string().trim().max(2000).optional(),
  footerText: z.string().trim().max(2000).optional(),
})

export const updatePaperSchema = z.object({
  rowVersion: z.number().int().positive(),
  title: z.string().trim().min(1).max(200).optional(),
  subtitle: z.string().trim().max(300).optional().nullable(),
  questionIds: z.array(uuid).min(1).max(500).optional(), // full ordered list, replaces paper_questions
  instituteName: z.string().trim().max(200).optional().nullable(),
  logoUrl: z.string().max(2000).optional().nullable(),
  examName: z.string().trim().max(200).optional().nullable(),
  subjectLabel: z.string().trim().max(100).optional().nullable(),
  classLabel: z.string().trim().max(100).optional().nullable(),
  examDate: z.string().datetime().optional().nullable(),
  examTime: z.string().trim().max(50).optional().nullable(),
  maxMarks: z.number().int().positive().optional().nullable(),
  instructions: z.string().trim().max(5000).optional().nullable(),
  headerText: z.string().trim().max(2000).optional().nullable(),
  footerText: z.string().trim().max(2000).optional().nullable(),
  status: z.enum(['DRAFT', 'FINAL']).optional(),
  createSnapshot: z.boolean().optional().default(false),
})

export const replaceQuestionSchema = z.object({
  rowVersion: z.number().int().positive(),
  paperQuestionId: uuid,
  newQuestionId: uuid,
})

// PATCH /api/papers/:id/questions/:paperQuestionId — paper-scoped content
// override for a single question. `rowVersion` is the PAPER's optimistic
// lock (the same counter PaperEditor already tracks for title/question-list
// saves), not the question's — an override never touches Question/
// QuestionVersion rowVersion at all.
//
// `clear: true` reverts every override on this row back to the live
// Question Bank content and ignores the other fields. Otherwise, each
// field that's present is written as this row's override for that field
// (an explicit `null` reverts just that one field to the bank value while
// leaving the others overridden) — `questionText`, when present, must be
// non-empty, same rule as editing content in the bank.
export const paperQuestionOverrideSchema = z.object({
  rowVersion: z.number().int().positive(),
  clear: z.boolean().optional().default(false),
  questionText: z.string().trim().min(1, 'Question text is required.').max(20000).optional(),
  optionA: z.string().trim().max(4000).optional().nullable(),
  optionB: z.string().trim().max(4000).optional().nullable(),
  optionC: z.string().trim().max(4000).optional().nullable(),
  optionD: z.string().trim().max(4000).optional().nullable(),
  correctAnswer: z.string().trim().max(500).optional().nullable(),
  explanation: z.string().trim().max(20000).optional().nullable(),
  markingScheme: z.string().trim().max(20000).optional().nullable(),
})
