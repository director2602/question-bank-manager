import { z } from 'zod'

const uuid = z.string().uuid()

// Question CONTENT — the fields that make up a question_versions row. This
// schema is intentionally the ONLY place question text/options/answer are
// validated, and it is never merged with the tag schema below, to keep the
// "content vs. tags" separation enforced in code as well as in the DB.
export const questionContentSchema = z.object({
  questionText: z.string().trim().min(1, 'Question text is required.').max(20000),
  optionA: z.string().trim().max(4000).optional().nullable(),
  optionB: z.string().trim().max(4000).optional().nullable(),
  optionC: z.string().trim().max(4000).optional().nullable(),
  optionD: z.string().trim().max(4000).optional().nullable(),
  correctAnswer: z.string().trim().max(500).optional().nullable(),
  explanation: z.string().trim().max(20000).optional().nullable(),
  changeNote: z.string().trim().max(500).optional().nullable(),
})

// Question TAGS/metadata — independent of content.
export const questionTagsSchema = z.object({
  questionNumber: z.string().trim().min(1, 'Question number is required.').max(50),
  subjectId: uuid,
  examClassId: uuid,
  codeId: uuid,
  difficultyId: uuid,
})

// Full create payload = tags + content + optional images already uploaded.
export const createQuestionSchema = questionTagsSchema.merge(questionContentSchema).extend({
  imageIds: z.array(uuid).max(10).optional().default([]),
  confirmDespiteDuplicateWarning: z.boolean().optional().default(false),
})

// Tag-only update. rowVersion is REQUIRED — this is the optimistic-lock
// token the client must send back so we can detect a concurrent edit.
export const updateQuestionTagsSchema = questionTagsSchema.extend({
  rowVersion: z.number().int().positive(),
})

// Content update — creates a new question_versions row. Also requires
// rowVersion for the same reason.
export const updateQuestionContentSchema = questionContentSchema.extend({
  rowVersion: z.number().int().positive(),
  imageIds: z.array(uuid).max(10).optional(),
})

export const bulkTagEditSchema = z.object({
  questionIds: z.array(uuid).min(1).max(500),
  subjectId: uuid.optional(),
  examClassId: uuid.optional(),
  codeId: uuid.optional(),
  difficultyId: uuid.optional(),
})

// Bulk archive (soft delete) and bulk hard-delete both take a plain list of
// question ids — capped at 500 per request, same ceiling as bulk tag edit,
// to keep a single request's transaction bounded even for very large banks.
export const bulkQuestionIdsSchema = z.object({
  questionIds: z.array(uuid).min(1).max(500),
})

export const questionListQuerySchema = z.object({
  q: z.string().trim().max(300).optional(),
  subjectId: uuid.optional(),
  examClassId: uuid.optional(),
  codeId: uuid.optional(),
  difficultyId: uuid.optional(),
  status: z.enum(['ACTIVE', 'ARCHIVED', 'ALL']).optional().default('ACTIVE'),
  questionNumber: z.string().trim().max(50).optional(),
  createdById: uuid.optional(),
  dateFrom: z.string().datetime().optional(),
  dateTo: z.string().datetime().optional(),
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(100).optional().default(25),
  sort: z.enum(['newest', 'oldest', 'questionNumber']).optional().default('newest'),
})

export type QuestionListQuery = z.infer<typeof questionListQuerySchema>
