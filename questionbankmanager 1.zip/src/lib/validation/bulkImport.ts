import { z } from 'zod'

// Mirrors public/templates/question_import_template.csv columns exactly.
// Chapter/Topic/Question Type/Marking Scheme match the same tag set as the
// Add Question form (Subject → Class/Exam → Chapter → Topic → Code →
// Difficulty → Question No, plus the question-type-conditional content
// fields) — CSV import is not a reduced tag set, just a different way of
// entering the same data.
export const csvRowSchema = z.object({
  Question: z.string().trim().min(1, 'Question text is required.'),
  'Question Type': z.string().trim().optional().default(''),
  'Option A': z.string().trim().optional().default(''),
  'Option B': z.string().trim().optional().default(''),
  'Option C': z.string().trim().optional().default(''),
  'Option D': z.string().trim().optional().default(''),
  'Correct Answer': z.string().trim().optional().default(''),
  Marks: z.string().trim().optional().default(''),
  Explanation: z.string().trim().optional().default(''),
  Subject: z.string().trim().min(1, 'Subject is required.'),
  Class: z.string().trim().min(1, 'Class is required.'),
  Chapter: z.string().trim().optional().default(''),
  Topic: z.string().trim().optional().default(''),
  Code: z.string().trim().min(1, 'Code is required.'),
  Difficulty: z.string().trim().min(1, 'Difficulty is required.'),
  'Question Number': z.string().trim().min(1, 'Question number is required.'),
  // Optional standalone target-exam tag — NEET / IIT-JEE Main / IIT-JEE
  // Advance / Foundation (or blank). Unlike Chapter/Topic this is a small,
  // fixed, admin-managed set, so an unmatched value is still a validation
  // error rather than something auto-created.
  'Exam Category': z.string().trim().optional().default(''),
})

export type CsvRow = z.infer<typeof csvRowSchema>

// Column order below is the user-requested sequence: Question, Question
// Type, Option A-D, Correct Answer, Marks, Explanation, Subject, Class,
// Chapter, Topic, Code, Difficulty, Question Number. "Marks" is the same
// underlying `markingScheme` field (Subjective-only grading rubric, never
// shown on the student paper) — just renamed/repositioned per that request.
export const CSV_TEMPLATE_HEADERS = [
  'Question',
  'Question Type',
  'Option A',
  'Option B',
  'Option C',
  'Option D',
  'Correct Answer',
  'Marks',
  'Explanation',
  'Subject',
  'Class',
  'Chapter',
  'Topic',
  'Code',
  'Difficulty',
  'Question Number',
  'Exam Category',
] as const

export const confirmImportSchema = z.object({
  // Row indexes (into the previously-validated preview) the user wants to
  // actually commit — lets them exclude rows flagged as likely duplicates.
  rowIndexes: z.array(z.number().int().min(0)).min(1),
  rows: z.array(
    z.object({
      rowIndex: z.number().int().min(0),
      questionText: z.string().min(1),
      optionA: z.string().optional().nullable(),
      optionB: z.string().optional().nullable(),
      optionC: z.string().optional().nullable(),
      optionD: z.string().optional().nullable(),
      correctAnswer: z.string().optional().nullable(),
      explanation: z.string().optional().nullable(),
      markingScheme: z.string().optional().nullable(),
      questionType: z.enum(['MCQ', 'SUBJECTIVE', 'INTEGER']).optional().default('MCQ'),
      subjectId: z.string().uuid(),
      examClassId: z.string().uuid(),
      chapterId: z.string().uuid().optional().nullable(),
      // Present when the row's Chapter/Topic cell didn't match an existing
      // row at preview time — the confirm route auto-creates a new
      // Chapter/Topic from this text (scoped to subjectId / the resolved
      // chapter) instead of erroring. Ignored when chapterId/topicId is
      // already set (a real match was found).
      chapterLabel: z.string().trim().min(1).max(150).optional().nullable(),
      topicId: z.string().uuid().optional().nullable(),
      topicLabel: z.string().trim().min(1).max(150).optional().nullable(),
      codeId: z.string().uuid(),
      difficultyId: z.string().uuid(),
      examCategoryId: z.string().uuid().optional().nullable(),
      questionNumber: z.string().min(1),
      // Ids of QuestionImage rows already uploaded to storage (e.g. diagrams
      // pulled out of a PDF during AI-assisted import) that should be
      // attached to this question once it's created. Optional — plain
      // CSV/manual imports never send this.
      imageIds: z.array(z.string().uuid()).optional().default([]),
    })
  ),
})
