import 'server-only'

/**
 * Renders HTML to a PDF buffer using headless Chromium.
 *
 * - In production (deployed to Vercel or similar serverless hosts),
 *   `@sparticuz/chromium` provides a Lambda-compatible Chromium binary.
 * - In local development, set PUPPETEER_EXECUTABLE_PATH to a local Chrome/
 *   Chromium install (or `npm i puppeteer` as a dev convenience, which
 *   bundles one) — see README.md § PDF Export.
 *
 * If Chromium cannot be launched for any reason, this throws; the caller
 * (the export API route) turns that into a clear "PDF export failed, use
 * Print instead" message rather than a silent/blank download — every paper
 * can ALWAYS be exported via the browser's own Print → Save as PDF on the
 * /papers/:id/print page, so this server path is a convenience, not a
 * single point of failure.
 */
export async function renderHtmlToPdfBuffer(html: string): Promise<Buffer> {
  const puppeteer = await import('puppeteer-core')

  let executablePath: string | undefined = process.env.PUPPETEER_EXECUTABLE_PATH
  let args: string[] = []
  let headless: boolean | 'shell' = true

  if (!executablePath) {
    const chromium = (await import('@sparticuz/chromium')).default
    executablePath = await chromium.executablePath()
    args = chromium.args
    headless = chromium.headless as unknown as boolean
  }

  const browser = await puppeteer.launch({ args, executablePath, headless })

  try {
    const page = await browser.newPage()
    await page.setContent(html, { waitUntil: 'networkidle0', timeout: 30_000 })

    // Give MathJax a chance to finish typesetting equations before printing.
    await page
      .evaluate(async () => {
        const w = window as unknown as { MathJax?: { startup?: { promise?: Promise<unknown> } } }
        if (w.MathJax?.startup?.promise) await w.MathJax.startup.promise
      })
      .catch(() => {
        // Non-fatal — the PDF still renders, just without typeset math.
      })

    // Zero margins here so Puppeteer doesn't inset the page box beyond
    // what paperHtml.ts's own `@page { margin: 0 }` already establishes —
    // the letterhead's header/footer bands are drawn full-bleed to the
    // physical page edge, and all real content insetting happens via CSS
    // padding on <body> instead. Keep this in sync with paperHtml.ts's
    // @page margin if that ever changes, or the server PDF and the
    // browser "Print / Save as PDF" path will disagree on page geometry.
    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '0mm', bottom: '0mm', left: '0mm', right: '0mm' },
    })
    return Buffer.from(pdf)
  } finally {
    await browser.close()
  }
}
