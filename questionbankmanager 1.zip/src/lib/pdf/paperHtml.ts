import type { SnapshotQuestion } from '@/lib/paper-snapshot'
import { SCUBUS_LOGO_FULL_DATA_URI, SCUBUS_LOGO_ICON_DATA_URI } from './brandAssets'

export type PaperSettings = {
  title: string
  paperNumber: number
  instituteName: string | null
  logoUrl: string | null
  examName: string | null
  subjectLabel: string | null
  classLabel: string | null
  examDate: string | null
  examTime: string | null
  maxMarks: number | null
  instructions: string | null
  headerText: string | null
  footerText: string | null
}

export type PaperExportMode = 'question' | 'answerKey' | 'solutions'
export type PaperColumnLayout = 1 | 2

// The brand palette this whole letterhead is built around — sampled
// directly from the reference paper (a real S-CUBUS exam booklet PDF the
// user supplied as an InDesign replacement) rather than invented: deep
// maroon banners/badges (#591940) and a lighter mauve accent (#d7bcd2) used
// for header/footer bands and secondary bars.
const BRAND_MAROON = '#591940'
const BRAND_MAUVE = '#d7bcd2'
const HEADER_BAND_HEIGHT_MM = 13
const FOOTER_BAND_HEIGHT_MM = 9

function escapeHtml(input: string | null | undefined): string {
  if (!input) return ''
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

// Preserves the verbatim question text exactly as stored — this function
// only escapes it for safe HTML embedding and converts literal newlines to
// <br>, it never rewrites, corrects, or reformats the content itself.
function textToHtml(text: string | null | undefined): string {
  return escapeHtml(text).replace(/\n/g, '<br/>')
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const

// Real, computed-from-data subject breakdown (never fabricated) — mirrors
// the reference paper's "SUBJECTS / QUESTIONS" table. Only meaningful (and
// only rendered) when a paper actually spans more than one subject.
function buildSubjectBreakdown(questions: SnapshotQuestion[]): { subject: string; count: number }[] {
  const counts = new Map<string, number>()
  for (const q of questions) {
    counts.set(q.subject, (counts.get(q.subject) ?? 0) + 1)
  }
  return Array.from(counts.entries()).map(([subject, count]) => ({ subject, count }))
}

// Prefer the paper's explicitly-set max marks; otherwise, only claim a
// total if every question actually carries a marks value — a partial sum
// would misrepresent the paper's real total, which the "no fabricated
// data" rule rules out.
function resolveMaxMarks(settings: PaperSettings, questions: SnapshotQuestion[]): number | null {
  if (settings.maxMarks) return settings.maxMarks
  if (questions.length > 0 && questions.every((q) => q.marks !== null)) {
    return questions.reduce((sum, q) => sum + (q.marks ?? 0), 0)
  }
  return null
}

/**
 * Renders a paper (question paper, answer key, or detailed solutions) as a
 * fully self-contained, print-ready HTML document. Used both for the
 * in-browser "Print / Save as PDF" flow and as the input to the
 * server-side Puppeteer PDF export (see /api/papers/[id]/export/pdf) — same
 * markup, same visual result, either path.
 *
 * Letterhead design: this reproduces the structural design of a real
 * S-CUBUS exam-paper PDF the user supplied as an InDesign stand-in (branded
 * cover page, repeating mauve/maroon header & footer bands, faint logo
 * watermark, ruled two-column body) — see the design notes on
 * renderCoverPage()/renderPageBands() below for exactly what was measured
 * from that reference vs. what had to be approximated (no vector logo or
 * exact font file was available, only the rendered PDF).
 *
 * Math/scientific notation: question/option/explanation text may contain
 * LaTeX delimited by $...$ or \(...\)/\[...\]; MathJax (loaded from CDN)
 * typesets it client-side after the page loads.
 */
export function renderPaperHtml(
  settings: PaperSettings,
  questions: SnapshotQuestion[],
  mode: PaperExportMode,
  columns: PaperColumnLayout = 1
): string {
  const heading =
    mode === 'answerKey' ? 'Answer Key' : mode === 'solutions' ? 'Detailed Solutions' : 'Question Paper'

  const bodyContent =
    mode === 'answerKey' ? renderAnswerKey(questions) : renderQuestions(questions, mode === 'solutions')

  // The answer key already lays out compactly as its own 4-column grid — a
  // multi-column wrapper around that grid fights it visually, so the
  // two-column layout only ever applies to the question paper / solutions
  // body text.
  const useTwoColumns = columns === 2 && mode !== 'answerKey'

  // Relative asset URLs (e.g. a logo at /branding/logo.png) only resolve
  // correctly when this HTML is loaded as a real page in the browser
  // (Print view). The server-side PDF export renders this same HTML via
  // Puppeteer's page.setContent(), which has NO base URL (about:blank) —
  // without an explicit <base>, any relative <img src> would silently fail
  // to load. Setting NEXT_PUBLIC_APP_URL as the base makes both paths work
  // identically. The bundled brand logo assets sidestep this entirely by
  // being inline base64 data URIs (see brandAssets.ts).
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL

  const instituteName = settings.instituteName || 'S-CUBUS'
  const showCover = mode === 'question'

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${escapeHtml(settings.title)} — ${heading}</title>
${baseUrl ? `<base href="${escapeHtml(baseUrl)}/" />` : ''}
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script>
  window.MathJax = {
    tex: { inlineMath: [['$', '$'], ['\\\\(', '\\\\)']], displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']] },
    svg: { fontCache: 'global' },
  };
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" id="MathJax-script" async></script>
<style>
  /* Full-bleed page box — the header/footer bands below are drawn edge to
     edge (matching the reference PDF, where they run the full page width
     with no surrounding white margin) and everything else is inset via
     body padding instead of @page margin. This also has to match the
     margin option passed to Puppeteer's page.pdf() in paperPdf.ts exactly
     (both are 0), or the two render paths (server PDF vs. browser print)
     would disagree on where the printable area starts. */
  @page { size: A4; margin: 0; }
  * { box-sizing: border-box; }
  html, body { background: #fff; }
  body {
    font-family: 'Calibri', 'Carlito', 'Segoe UI', Arial, sans-serif;
    color: #14161f;
    font-size: 11pt;
    line-height: 1.5;
    margin: 0;
    padding: ${HEADER_BAND_HEIGHT_MM + 7}mm 14mm ${FOOTER_BAND_HEIGHT_MM + 7}mm 14mm;
    position: relative;
  }

  /* --- Repeating header/footer bands ---------------------------------
     position:fixed content repeats on every printed page in Chromium's
     print pipeline (verified against this exact renderer/Puppeteer combo)
     regardless of where in the DOM it sits, so these show on the cover
     page too — intentional: the reference PDF's footer band appears on
     its cover page as well, so this keeps a single consistent frame
     rather than special-casing page 1. */
  .page-band-header {
    position: fixed; top: 0; left: 0; right: 0; height: ${HEADER_BAND_HEIGHT_MM}mm;
    background: ${BRAND_MAUVE};
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 10mm;
  }
  .page-band-header .band-institute { display: flex; align-items: center; gap: 8px; font-size: 9.5pt; font-weight: 700; color: ${BRAND_MAROON}; }
  .page-band-header .band-institute img { height: 8mm; width: auto; }
  .page-band-header .band-title { font-size: 8.5pt; color: #4a2440; text-align: right; }
  .page-band-footer {
    position: fixed; bottom: 0; left: 0; right: 0; height: ${FOOTER_BAND_HEIGHT_MM}mm;
    background: ${BRAND_MAROON}; color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 8pt; text-align: center; padding: 0 10mm;
  }
  .page-watermark {
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    width: 55%; opacity: 0.05; z-index: -1; pointer-events: none;
  }

  /* --- Cover page (question papers only) ------------------------------ */
  .cover-page { page-break-after: always; padding: 4mm 2mm 2mm 2mm; }
  .cover-frame { border: 2.5pt solid ${BRAND_MAROON}; border-radius: 4mm; padding: 8mm 9mm 6mm 9mm; }
  .cover-top-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4mm; }
  .cover-pill { display: inline-block; background: ${BRAND_MAROON}; color: #fff; font-size: 9pt; font-weight: 700; padding: 2mm 5mm; border-radius: 2mm; }
  .cover-logo { text-align: center; margin: 2mm 0 4mm 0; }
  .cover-logo img { height: 30mm; width: auto; }
  .cover-title-banner { background: ${BRAND_MAROON}; color: #fff; border-radius: 3mm; text-align: center; padding: 6mm 4mm 5mm 4mm; }
  .cover-title { font-size: 22pt; font-weight: 800; letter-spacing: 0.03em; text-transform: uppercase; }
  .cover-subtitle { font-size: 13pt; font-weight: 600; margin-top: 1mm; }
  .cover-meta-bar { background: ${BRAND_MAUVE}; color: ${BRAND_MAROON}; font-weight: 700; font-size: 10pt; text-align: center; padding: 3mm; margin-top: 2.5mm; border-radius: 0 0 2mm 2mm; display: flex; justify-content: center; gap: 6mm; flex-wrap: wrap; }
  .cover-candidate-fields { margin-top: 6mm; font-size: 10.5pt; display: grid; grid-template-columns: 1fr 1fr; gap: 4mm 8mm; }
  .cover-candidate-fields .fill-line { display: inline-block; border-bottom: 1px solid #14161f; min-width: 55mm; margin-left: 2mm; }
  .cover-instructions { margin-top: 6mm; font-size: 9.5pt; }
  .cover-instructions-title { font-weight: 800; font-size: 11pt; margin-bottom: 2mm; }
  .cover-instructions ol { margin: 0; padding-left: 5mm; }
  .cover-instructions li { margin-bottom: 1mm; }
  .cover-subjects-table { width: 100%; border-collapse: collapse; margin-top: 6mm; font-size: 10pt; }
  .cover-subjects-table th, .cover-subjects-table td { border: 1px solid ${BRAND_MAROON}; padding: 2mm 3mm; text-align: center; }
  .cover-subjects-table th { background: ${BRAND_MAROON}; color: #fff; }
  .cover-subjects-table td:first-child, .cover-subjects-table th:first-child { text-align: left; background: ${BRAND_MAUVE}; color: ${BRAND_MAROON}; font-weight: 700; }

  /* --- Simple (non-cover) header, used for answer key / solutions modes */
  .paper-header { text-align: center; border-bottom: 2px solid ${BRAND_MAROON}; padding-bottom: 12px; margin-bottom: 18px; }
  .paper-header img.logo { max-height: 40px; margin-bottom: 8px; }
  .institute-name { font-size: 16pt; font-weight: 700; letter-spacing: 0.02em; color: ${BRAND_MAROON}; }
  .exam-name { font-size: 12pt; margin-top: 2px; font-weight: 600; }
  .meta-row { display: flex; justify-content: space-between; font-size: 10pt; margin-top: 8px; flex-wrap: wrap; gap: 6px 18px; }
  .heading-badge { display: inline-block; font-size: 10.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 6px; color: ${BRAND_MAROON}; }

  .instructions { font-size: 10pt; background: #f7f8fa; border: 1px solid #e2e5eb; border-radius: 6px; padding: 10px 14px; margin-bottom: 20px; white-space: pre-wrap; }
  .instructions-title { font-weight: 700; margin-bottom: 4px; }

  .paper-body.two-column {
    column-count: 2;
    column-gap: 8mm;
    column-rule: 0.75pt solid ${BRAND_MAROON};
  }
  .question { margin-bottom: 16px; page-break-inside: avoid; break-inside: avoid-column; }
  .question-number { font-weight: 700; margin-right: 6px; }
  .question-text { display: inline; }
  .options { margin: 6px 0 0 22px; }
  .options .option { margin-bottom: 3px; }
  .option-letter { font-weight: 600; margin-right: 6px; }
  .question-image { display: block; max-width: 100%; max-height: 320px; margin: 8px 0; }
  .explanation { margin-top: 6px; margin-left: 22px; font-size: 10.5pt; color: #333a4d; font-style: italic; }
  .answer-key-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px 20px; }
  .answer-key-item { font-size: 12pt; }
  @media print {
    .no-print { display: none !important; }
  }
</style>
</head>
<body>
  <div class="page-watermark"><img src="${SCUBUS_LOGO_ICON_DATA_URI}" alt="" style="width:100%;" /></div>
  <div class="page-band-header">
    <span class="band-institute"><img src="${SCUBUS_LOGO_ICON_DATA_URI}" alt="" />${escapeHtml(instituteName)}${settings.subjectLabel ? ` — ${escapeHtml(settings.subjectLabel)}` : ''}</span>
    <span class="band-title">${escapeHtml(settings.title)} · Paper #${settings.paperNumber}</span>
  </div>
  <div class="page-band-footer">
    ${escapeHtml(settings.footerText) || `${escapeHtml(instituteName)} — Paper #${settings.paperNumber} — ${escapeHtml(settings.title)}`}
  </div>

  ${showCover ? renderCoverPage(settings, questions) : renderSimpleHeader(settings, instituteName, heading)}

  <div class="paper-body${useTwoColumns ? ' two-column' : ''}">
    ${bodyContent}
  </div>

  <button class="no-print" onclick="window.print()" style="position:fixed;top:16px;right:16px;padding:10px 16px;background:${BRAND_MAROON};color:#fff;border:none;border-radius:6px;font-size:14px;cursor:pointer;">Print / Save as PDF</button>
</body>
</html>`
}

function renderSimpleHeader(settings: PaperSettings, instituteName: string, heading: string): string {
  return `<div class="paper-header">
    ${settings.logoUrl ? `<img class="logo" src="${escapeHtml(settings.logoUrl)}" alt="Institute logo" />` : ''}
    <div class="institute-name">${escapeHtml(instituteName)}</div>
    ${settings.examName ? `<div class="exam-name">${escapeHtml(settings.examName)}</div>` : ''}
    <div class="meta-row">
      <span>${settings.subjectLabel ? `Subject: ${escapeHtml(settings.subjectLabel)}` : ''}</span>
      <span>${settings.classLabel ? `Class/Exam: ${escapeHtml(settings.classLabel)}` : ''}</span>
      <span>${settings.examDate ? `Date: ${escapeHtml(settings.examDate)}` : ''}</span>
      <span>${settings.examTime ? `Time: ${escapeHtml(settings.examTime)}` : ''}</span>
      <span>${settings.maxMarks ? `Maximum Marks: ${settings.maxMarks}` : ''}</span>
    </div>
    <div class="heading-badge">${heading}</div>
  </div>`
}

/**
 * The branded cover page — structurally modeled on the reference PDF's
 * first page (bordered frame, date/paper-code pills, centered logo, a
 * maroon title banner, a mauve meta bar, blank candidate-detail fill-in
 * lines, a general-instructions block, and a subjects/marks table).
 *
 * What's faithful vs. approximated, for the record (see also the "InDesign
 * compatibility" section of the delivery report): the colors are sampled
 * directly from the reference PDF, and the logo is a real cropped asset
 * extracted from it (see brandAssets.ts) — but the reference uses a custom
 * display typeface this app has no license/file for, so the cover falls
 * back to the same Calibri family as the rest of the document rather than
 * approximating a different font. Every piece of data shown (question
 * count, subject breakdown, marks) is computed from the paper's actual
 * questions, never invented — a field is simply omitted when the
 * underlying data isn't there (e.g. no subjects table for a single-subject
 * paper, no marks line if marks aren't set on every question).
 */
function renderCoverPage(settings: PaperSettings, questions: SnapshotQuestion[]): string {
  const subjectBreakdown = buildSubjectBreakdown(questions)
  const maxMarks = resolveMaxMarks(settings, questions)

  const metaParts = [
    `Total Questions: ${questions.length}`,
    settings.classLabel ? `Class: ${escapeHtml(settings.classLabel)}` : null,
    maxMarks ? `Maximum Marks: ${maxMarks}` : null,
  ].filter(Boolean)

  const subjectsTable =
    subjectBreakdown.length > 1
      ? `<table class="cover-subjects-table">
          <tr><th>Subjects</th>${subjectBreakdown.map((s) => `<th>${escapeHtml(s.subject)}</th>`).join('')}</tr>
          <tr><td>Questions</td>${subjectBreakdown.map((s) => `<td>${s.count}</td>`).join('')}</tr>
        </table>`
      : ''

  const instructionsBlock = settings.instructions
    ? `<div class="cover-instructions">
        <div class="cover-instructions-title">General Instructions</div>
        <div>${textToHtml(settings.instructions)}</div>
      </div>`
    : ''

  return `<div class="cover-page">
    <div class="cover-frame">
      <div class="cover-top-row">
        <span class="cover-pill">${settings.examDate ? escapeHtml(settings.examDate) : `Paper #${settings.paperNumber}`}</span>
        <span class="cover-pill">${escapeHtml(settings.classLabel) || escapeHtml(settings.subjectLabel) || `#${settings.paperNumber}`}</span>
      </div>
      <div class="cover-logo"><img src="${SCUBUS_LOGO_FULL_DATA_URI}" alt="${escapeHtml(settings.instituteName || 'S-CUBUS')} logo" /></div>
      <div class="cover-title-banner">
        <div class="cover-title">${escapeHtml(settings.title)}</div>
        ${settings.examName ? `<div class="cover-subtitle">${escapeHtml(settings.examName)}</div>` : ''}
      </div>
      ${metaParts.length ? `<div class="cover-meta-bar">${metaParts.map((p) => `<span>${p}</span>`).join('')}</div>` : ''}
      <div class="cover-candidate-fields">
        <div>Name of Student: <span class="fill-line"></span></div>
        <div>Phone No.: <span class="fill-line"></span></div>
        <div>Candidate's Signature: <span class="fill-line"></span></div>
        <div>Roll No.: <span class="fill-line"></span></div>
      </div>
      ${instructionsBlock}
      ${subjectsTable}
    </div>
  </div>`
}

function renderQuestions(questions: SnapshotQuestion[], includeSolutions: boolean): string {
  return questions
    .map((q) => {
      const options = OPTION_LETTERS.map((letter) => {
        const key = `option${letter}` as 'optionA' | 'optionB' | 'optionC' | 'optionD'
        const value = q[key]
        if (!value) return ''
        return `<div class="option"><span class="option-letter">${letter}.</span>${textToHtml(value)}</div>`
      }).join('')

      const images = q.images
        .map((img) => (img.url ? `<img class="question-image" src="${escapeHtml(img.url)}" alt="${escapeHtml(img.altText || 'Question image')}" />` : ''))
        .join('')

      const solution =
        includeSolutions && (q.correctAnswer || q.explanation)
          ? `<div class="explanation">${q.correctAnswer ? `<strong>Answer: ${escapeHtml(q.correctAnswer)}</strong><br/>` : ''}${textToHtml(q.explanation)}</div>`
          : ''

      return `<div class="question">
        <span class="question-number">Q${q.position}.</span><span class="question-text">${textToHtml(q.questionText)}</span>
        ${images}
        ${options ? `<div class="options">${options}</div>` : ''}
        ${solution}
      </div>`
    })
    .join('\n')
}

function renderAnswerKey(questions: SnapshotQuestion[]): string {
  const items = questions
    .map(
      (q) =>
        `<div class="answer-key-item"><strong>${q.position}.</strong> ${escapeHtml(q.correctAnswer) || '<em>Not specified</em>'}</div>`
    )
    .join('\n')
  return `<div class="answer-key-grid">${items}</div>`
}
