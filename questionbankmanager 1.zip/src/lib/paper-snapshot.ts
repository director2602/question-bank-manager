import 'server-only'
import { prisma } from '@/lib/prisma'
import { getSignedImageUrls } from '@/lib/storage'

export type SnapshotQuestion = {
  questionId: string
  questionVersionId: string
  position: number
  questionNumber: string
  questionText: string
  optionA: string | null
  optionB: string | null
  optionC: string | null
  optionD: string | null
  correctAnswer: string | null
  explanation: string | null
  subject: string
  examClass: string
  code: string
  difficulty: string
  marks: number | null
  images: { url: string; altText: string | null }[]
}

/**
 * Builds a fully self-contained snapshot of a paper's current question
 * composition — every field needed to render/print/export the paper is
 * embedded directly (not just IDs), so a PaperVersion row created from this
 * remains renderable even if the source question is later edited or
 * archived. This is what makes historical papers reproducible (business
 * rule "Historical papers must remain stable").
 */
export async function buildPaperSnapshot(paperId: string): Promise<SnapshotQuestion[]> {
  const paperQuestions = await prisma.paperQuestion.findMany({
    where: { paperId },
    orderBy: { position: 'asc' },
    include: {
      question: { include: { subject: true, examClass: true, code: true, difficulty: true } },
      questionVersion: { include: { images: true } },
    },
  })

  const allImagePaths = paperQuestions.flatMap((pq) => pq.questionVersion.images.map((i) => i.storagePath))
  const urls = await getSignedImageUrls(allImagePaths)

  return paperQuestions.map((pq) => ({
    questionId: pq.questionId,
    questionVersionId: pq.questionVersionId,
    position: pq.position,
    questionNumber: pq.question.questionNumber,
    questionText: pq.questionVersion.questionText,
    optionA: pq.questionVersion.optionA,
    optionB: pq.questionVersion.optionB,
    optionC: pq.questionVersion.optionC,
    optionD: pq.questionVersion.optionD,
    correctAnswer: pq.questionVersion.correctAnswer,
    explanation: pq.questionVersion.explanation,
    subject: pq.question.subject.label,
    examClass: pq.question.examClass.label,
    code: pq.question.code.label,
    difficulty: pq.question.difficulty.label,
    marks: pq.marks,
    images: pq.questionVersion.images
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map((img) => ({ url: urls[img.storagePath] ?? '', altText: img.altText })),
  }))
}
