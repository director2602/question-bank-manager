import { NextResponse } from 'next/server'
import { ZodError } from 'zod'
import { AuthError } from '@/lib/auth'
import { Prisma } from '@prisma/client'

/**
 * Central error → HTTP response translator for API routes. Ensures we NEVER
 * leak raw database/internal error messages to the client (business rule:
 * "Never display raw database errors to normal users"), while still logging
 * the real error server-side for debugging.
 */
export function handleApiError(error: unknown) {
  if (error instanceof AuthError) {
    return NextResponse.json({ error: error.message }, { status: error.status })
  }

  if (error instanceof ZodError) {
    return NextResponse.json(
      {
        error: 'The data you submitted is invalid.',
        fieldErrors: error.flatten().fieldErrors,
      },
      { status: 400 }
    )
  }

  if (error instanceof ConflictError) {
    return NextResponse.json(
      { error: error.message, code: 'CONFLICT', latest: error.latest },
      { status: 409 }
    )
  }

  if (error instanceof InsufficientQuestionsError) {
    return NextResponse.json(
      { error: error.message, code: 'INSUFFICIENT_QUESTIONS', shortfalls: error.shortfalls },
      { status: 422 }
    )
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    console.error('[Prisma error]', error.code, error.message)
    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'A record with the same unique value already exists.' },
        { status: 409 }
      )
    }
    if (error.code === 'P2025') {
      return NextResponse.json({ error: 'The requested record was not found.' }, { status: 404 })
    }
    return NextResponse.json(
      { error: 'A database error occurred. Please try again.' },
      { status: 500 }
    )
  }

  console.error('[Unhandled API error]', error)
  return NextResponse.json(
    { error: 'An unexpected error occurred. Please try again.' },
    { status: 500 }
  )
}

/** Thrown when an optimistic-lock rowVersion check fails. */
export class ConflictError extends Error {
  latest?: unknown
  constructor(message: string, latest?: unknown) {
    super(message)
    this.latest = latest
  }
}

/** Thrown when a paper generation request asks for more questions than exist. */
export class InsufficientQuestionsError extends Error {
  shortfalls: Array<{
    subject: string
    examClass: string
    code: string
    difficulty: string
    requested: number
    available: number
  }>
  constructor(message: string, shortfalls: InsufficientQuestionsError['shortfalls']) {
    super(message)
    this.shortfalls = shortfalls
  }
}
