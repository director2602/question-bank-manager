import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0f5ff',
          100: '#dbe6fe',
          200: '#bfd3fe',
          300: '#93b4fd',
          400: '#608bfa',
          500: '#3b66f5',
          600: '#2547ea',
          700: '#1e37d6',
          800: '#1f2fad',
          900: '#1f2c88',
          950: '#161a54',
        },
        surface: {
          DEFAULT: '#ffffff',
          subtle: '#f7f8fa',
          muted: '#eef0f4',
          border: '#e2e5eb',
        },
        ink: {
          DEFAULT: '#161a2b',
          muted: '#565d72',
          faint: '#8891a5',
        },
        success: '#16794f',
        warning: '#9a6a03',
        danger: '#b3261e',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(22,26,43,0.06), 0 1px 3px 0 rgba(22,26,43,0.08)',
      },
    },
  },
  plugins: [],
}

export default config
